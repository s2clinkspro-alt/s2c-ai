#!/bin/bash
# Visitor Bot — Auto Setup & Start (Linux/Mac/VPS)

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

echo -e "\n${CYAN}╔══════════════════════════════════════╗"
echo -e "║    VISITOR BOT — Auto Setup          ║"
echo -e "╚══════════════════════════════════════╝${NC}\n"

# ── Python check ─────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo -e "${YELLOW}[*] Installing Python3...${NC}"
    if command -v apt-get &>/dev/null; then
        sudo apt-get update -q && sudo apt-get install -y python3 python3-pip
    elif command -v yum &>/dev/null; then
        sudo yum install -y python3 python3-pip
    else
        echo -e "${RED}[ERROR] Cannot install Python. Install manually.${NC}"; exit 1
    fi
fi
echo -e "${GREEN}[OK] Python: $(python3 --version)${NC}"

# ── Display for headed Chromium (Linux VPS) ──────────────────
if [[ -z "$DISPLAY" ]]; then
    if command -v Xvfb &>/dev/null; then
        Xvfb :99 -screen 0 1920x1080x24 -ac +extension GLX +render -noreset &>/dev/null &
        export DISPLAY=:99
        echo -e "${GREEN}[OK] Virtual display started${NC}"
    else
        echo -e "${YELLOW}[*] Installing Xvfb (virtual display)...${NC}"
        sudo apt-get install -y xvfb -q 2>/dev/null || true
        Xvfb :99 -screen 0 1920x1080x24 -ac +extension GLX +render -noreset &>/dev/null &
        export DISPLAY=:99
    fi
fi

# ── Run setup.py ─────────────────────────────────────────────
python3 setup.py
