"""
Authentic Facebook referer builders — organic + paid ads.
Based on real Facebook click captures (desktop + mobile, organic + paid).

Real Facebook click flow:
  1. User clicks link on Facebook → server redirects through link shim
  2. Browser's HTTP Referer = l.facebook.com/l.php?u=...&h=...&tn=H-R&c[0]=...
  3. Browser arrives at destination URL with fbclid in address bar

Organic vs Paid differences:
  - Organic: h starts with AUD (146 chars), c[0]=222 chars, dest has fbclid only
  - Paid:    h starts with AUC (134 chars), c[0]=170 chars, dest has fbclid + utm_* + FBAudience
  - Both:    tn=H-R, c[0] starts with AUC, fbclid has IwZXh0bgNhZW0 prefix + _aem_ suffix

Domain variants (for realism):
  - l.facebook.com  → desktop + mobile web link shim (most common, ~70%)
  - lm.facebook.com → mobile app in-app browser link shim (~20% mobile)
  - www.facebook.com → desktop direct page (no shim, ~10% desktop)
  - m.facebook.com  → mobile web page (no shim, ~10% mobile)
"""

import random
import string
from urllib.parse import quote, urlencode

# v13.7.7 — mibextid pools (Meta In-Browser Extension ID)
# Real Facebook Mobile App click → destination URL always has mibextid
# Each Meta app has its own pool of real captured mibextid values
_MIBEXTID_FB_MAIN    = ["JJWH9B", "cr9h03", "S17X4N", "aYedtS", "6HCLMF", "rjt7Vl", "PKnXoh"]
_MIBEXTID_FB_LITE    = ["cr9h03", "JJWH9B", "S17X4N"]
_MIBEXTID_MESSENGER  = ["S17X4N", "JJWH9B", "cr9h03", "PKnXoh"]
_MIBEXTID_INSTAGRAM  = ["S17X4N", "rjt7Vl", "natr3t", "Ib8wlB"]
_MIBEXTID_THREADS    = ["natr3t", "S17X4N", "rjt7Vl"]
_MIBEXTID_FB_GROUPS  = ["JJWH9B", "S17X4N", "aYedtS"]
_MIBEXTID_FB_MARKET  = ["JJWH9B", "cr9h03", "aYedtS"]
_MIBEXTID_FB_BIZ     = ["S17X4N", "JJWH9B"]
_MIBEXTID_DEFAULT    = ["JJWH9B", "cr9h03", "S17X4N", "aYedtS"]

def _get_mibextid(variant_key="fb_main"):
    """Return a realistic mibextid for the given FB app variant."""
    pool = {
        "fb_main":    _MIBEXTID_FB_MAIN,
        "fb_lite":    _MIBEXTID_FB_LITE,
        "fb_messenger": _MIBEXTID_MESSENGER,
        "instagram":  _MIBEXTID_INSTAGRAM,
        "threads":    _MIBEXTID_THREADS,
        "fb_groups":  _MIBEXTID_FB_GROUPS,
        "fb_marketplace": _MIBEXTID_FB_MARKET,
        "fb_business": _MIBEXTID_FB_BIZ,
    }.get(variant_key, _MIBEXTID_DEFAULT)
    return random.choice(pool)


# ═══════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════
_FBCLID_PREFIX = "IwZXh0bgNhZW0"  # 13 chars — constant across all FB clicks
_AEM_SUFFIX_LEN = 22              # always 22 chars after _aem_
_B64U = string.ascii_letters + string.digits + "-_"

# h parameter prefixes (first 3 chars of base64url)
# AUD = organic, AUC = paid (decoded: AUD→0140d9, AUC→014096)
_H_ORGANIC_PREFIX = "AUB"  # v13.8.0 FIX: Real FB organic h= starts AUB (was wrongly AUD)
_H_PAID_PREFIX = "AUC"
_C0_ORGANIC_PREFIX = "AUD"  # v13.8.0 FIX: Real FB organic c[0]= starts AUD
_C0_PAID_PREFIX    = "AUC"  # Paid c[0]= starts AUC
_C0_PREFIX = _C0_ORGANIC_PREFIX  # backward compat alias

# Real parameter lengths (from captured clicks)
_H_ORGANIC_LEN = 146   # organic h = 146 chars
_H_PAID_LEN = 134      # paid h = 134 chars
_C0_ORGANIC_LEN = 222  # organic c[0] = 222 chars
_C0_PAID_LEN = 170     # paid c[0] = 170 chars


def _rand_b64u(length):
    return ''.join(random.choice(_B64U) for _ in range(length))


def _gen_fbclid(is_mobile=False):
    """
    Generate realistic fbclid matching Facebook's binary format.

    v13.8.1 FIX — confirmed from 2 real FB links:
    Desktop (l.facebook.com link shim, right-click copy):
      Prefix: IwZXh0bgNhZW0C (13+1=14 fixed chars)
      Body:   ~99 random base64url chars
      Suffix: _aem_ + 22 chars
      Total:  ~145 chars

    Mobile (address bar copy after FB feed click in Chrome/Safari):
      Prefix: IwVERDUATMOBple (15 fixed chars) — NEW mobile format
      Body:   ~109 random base64url chars
      Suffix: _aem_ + 22 chars
      Total:  ~151 chars

    Key insight: Mobile browser (Chrome/Safari) click → IwVERD* prefix
    FB IAB (in-app browser) → still IwZXh0* but with mibextid in URL
    """
    aem_suffix = _rand_b64u(_AEM_SUFFIX_LEN)  # always 22 chars
    if is_mobile:
        # Mobile Chrome/Safari external browser click — new format (2024+)
        _MOBILE_FBCLID_PREFIX = "IwVERDUATMOBple"  # 15 chars, confirmed real
        body = _rand_b64u(109)  # 15 + 109 + 5(_aem_) + 22 = 151 total
        return f"{_MOBILE_FBCLID_PREFIX}{body}_aem_{aem_suffix}"
    else:
        # Desktop or legacy format
        body = _rand_b64u(99)  # 13 + 1(C) + 99 + 5 + 22 = 140~146 total
        return f"{_FBCLID_PREFIX}C{body}_aem_{aem_suffix}"


def _gen_h(is_paid=False):
    """Generate l.php h= parameter. AUD prefix for organic, AUC for paid."""
    prefix = _H_PAID_PREFIX if is_paid else _H_ORGANIC_PREFIX
    total_len = _H_PAID_LEN if is_paid else _H_ORGANIC_LEN
    return prefix + _rand_b64u(total_len - len(prefix))


def _gen_c0(is_paid=False):
    """Generate l.php c[0]= parameter.
    v13.8.0 FIX: Organic=AUD prefix (222 chars), Paid=AUC prefix (170 chars).
    Confirmed from real Facebook organic link analysis."""
    if is_paid:
        prefix = _C0_PAID_PREFIX
        total_len = _C0_PAID_LEN
    else:
        prefix = _C0_ORGANIC_PREFIX
        total_len = _C0_ORGANIC_LEN
    return prefix + _rand_b64u(total_len - len(prefix))


def _gen_campaign_id():
    """14-15 digit Facebook campaign ID."""
    length = random.choice([14, 15])
    prefix = random.choice(["52", "97", "62", "46", "38", "70"])
    rest = ''.join(random.choice(string.digits) for _ in range(length - len(prefix)))
    return prefix + rest


def _gen_ad_id():
    """14-digit Facebook ad ID."""
    prefix = random.choice(["52", "62", "46", "38", "70"])
    rest = ''.join(random.choice(string.digits) for _ in range(14 - len(prefix)))
    return prefix + rest


def _gen_adset_id():
    """14-digit Facebook adset ID."""
    prefix = random.choice(["52", "62", "46", "38", "70"])
    rest = ''.join(random.choice(string.digits) for _ in range(14 - len(prefix)))
    return prefix + rest


def _gen_utm_id(campaign_id=None):
    """Generate utm_id: {campaign_id}_v{ver}_s{seq} or {short}_v0_s00_e0_tv2_a1{token}"""
    if campaign_id is None:
        campaign_id = _gen_campaign_id()
    if random.random() < 0.3:
        short_id = str(random.randint(10000, 99999))
        return f"{short_id}_v0_s{random.randint(0,9):02d}_e{random.randint(0,9)}_tv{random.randint(1,5)}_a1{''.join(random.choice(string.ascii_lowercase+string.digits) for _ in range(13))}"
    return f"{campaign_id}_v{random.randint(0,3)}_s{random.randint(0,9):02d}"


# ═══════════════════════════════════════════════════════════════
# Facebook page URL generators (for non-shim variants)
# ═══════════════════════════════════════════════════════════════
def _gen_fb_post_id():
    """Generate a realistic Facebook post ID (18-19 digits)."""
    return str(random.randint(10**17, 10**18 - 1))


def _gen_fb_page_id():
    """Generate a realistic Facebook page ID (15-16 digits)."""
    return str(random.randint(10**14, 10**15 - 1))


def _gen_fb_story_fbid():
    """Generate a realistic story_fbid (16-17 digits)."""
    return str(random.randint(10**15, 10**16 - 1))


# ═══════════════════════════════════════════════════════════════
# Organic Facebook referer builder
# ═══════════════════════════════════════════════════════════════
def build_facebook_organic_referer(url, is_mobile=False):
    """
    Build authentic organic Facebook click referer + tagged destination URL.

    Returns: (referer_url, tagged_destination_url)

    Domain variants (device-aware):
      Desktop: 75% l.facebook.com, 15% www.facebook.com, 10% l.facebook.com (no-lphp)
      Mobile:  50% l.facebook.com, 30% lm.facebook.com, 10% m.facebook.com, 10% l.facebook.com (no-lphp)

    For l.php variants: destination URL has fbclid (authentic FB tracking)
    For page-URL variants (www/m): no fbclid (no link shim = no tracking param)
    """
    fbclid = _gen_fbclid(is_mobile)
    h = _gen_h(is_paid=False)  # AUD prefix for organic
    c0 = _gen_c0(is_paid=False)  # AUC prefix, 222 chars for organic

    if is_mobile:
        # Mobile: 50% l.facebook.com, 30% lm.facebook.com, 10% m.facebook.com, 10% l.facebook.com (no-lphp)
        variant = random.choices(
            ["l_facebook", "lm_facebook", "m_facebook", "l_facebook_noshim"],
            weights=[50, 30, 10, 10]
        )[0]
    else:
        # Desktop: 75% l.facebook.com, 15% www.facebook.com, 10% l.facebook.com (no-lphp)
        variant = random.choices(
            ["l_facebook", "www_facebook", "l_facebook_noshim"],
            weights=[75, 15, 10]
        )[0]

    if variant == "l_facebook":
        # l.facebook.com/l.php — link shim (most common)
        # v13.7.7: __tn__ added to destination URL (real FB organic address bar param)
        tn_val = "-UK-R" if is_mobile else "H-R"
        sep = '&' if '?' in url else '?'
        tagged_url = f"{url}{sep}fbclid={fbclid}"
        referer = (
            f"https://l.facebook.com/l.php?u={quote(tagged_url, safe='')}"
            f"&h={h}&tn={tn_val}"
            f"&c%5B0%5D={c0}"
        )
        return (referer, tagged_url)

    elif variant == "lm_facebook":
        # lm.facebook.com/l.php — mobile FB App in-app browser link shim
        # v13.8.2 FIX: Confirmed from real FB IAB link (address bar copy):
        #   destination URL = only fbclid (IwVERD* format), NO __tn__, NO mibextid
        #   mibextid lives in the l.php referer URL, NOT in the destination
        #   __tn__ is in the l.php referer, NOT in the destination address bar
        tn_val = "-UK-R"  # mobile IAB always -UK-R
        mibext = _get_mibextid("fb_main")  # for referer URL only
        sep = '&' if '?' in url else '?'
        # Clean destination URL: fbclid only (confirmed from real FB IAB address bar)
        tagged_url = f"{url}{sep}fbclid={fbclid}"
        referer = (
            f"https://lm.facebook.com/l.php?u={quote(tagged_url, safe='')}"
            f"&h={h}&tn={tn_val}"
            f"&c%5B0%5D={c0}"
            f"&mibextid={mibext}"  # mibextid in referer, not destination
        )
        return (referer, tagged_url)

    elif variant == "www_facebook":
        # www.facebook.com — desktop page URL (no link shim)
        # No fbclid in destination (no shim = no tracking param)
        post_id = _gen_fb_post_id()
        page_id = _gen_fb_page_id()
        story_fbid = _gen_fb_story_fbid()
        referer = (
            f"https://www.facebook.com/permalink.php"
            f"?story_fbid={story_fbid}&id={page_id}"
        )
        return (referer, None)  # No tagged URL — navigate to plain URL

    elif variant == "m_facebook":
        # m.facebook.com — mobile web page URL (no link shim)
        post_id = _gen_fb_post_id()
        page_id = _gen_fb_page_id()
        story_fbid = _gen_fb_story_fbid()
        referer = (
            f"https://m.facebook.com/story.php"
            f"?story_fbid={story_fbid}&id={page_id}&substory_index=0"
        )
        return (referer, None)  # No tagged URL

    elif variant == "l_facebook_noshim":
        # l.facebook.com without l.php — sometimes FB uses different paths
        post_id = _gen_fb_post_id()
        page_id = _gen_fb_page_id()
        referer = (
            f"https://l.facebook.com/l.php?u={quote(url, safe='')}"
            f"&h={h}&tn=H-R"
            f"&c%5B0%5D={c0}"
        )
        return (referer, None)  # No fbclid in this variant


# ═══════════════════════════════════════════════════════════════
# Paid Facebook Ads referer builder
# ═══════════════════════════════════════════════════════════════
def build_facebook_ads_referer(url, is_mobile=False, campaign_config=None):
    """
    Build authentic Facebook Ads click referer + tagged destination URL.

    Returns: (referer_url, tagged_destination_url)

    Paid ads ALWAYS use l.facebook.com/l.php (no domain mixing — ads go through
    the link shim). Destination URL has fbclid + utm_source=fb + utm_medium=paid
    + utm_id + utm_content + utm_term + utm_campaign + FBAudience.
    """
    cfg = campaign_config or {}
    auto = cfg.get("auto_generate", True)

    campaign_id = cfg.get("campaign_id") if not auto else _gen_campaign_id()
    ad_id = cfg.get("ad_id") if not auto else _gen_ad_id()
    adset_id = cfg.get("adset_id") if not auto else _gen_adset_id()
    utm_id = _gen_utm_id(campaign_id)

    fbclid = _gen_fbclid(is_mobile)

    # Destination URL params (address bar — GA reads these)
    dest_params = {
        "fbclid": fbclid,
        "FBAudience": "engaged_audience",
        "utm_medium": "paid",
        "utm_source": "fb",
        "utm_id": utm_id,
        "utm_content": ad_id,
        "utm_term": adset_id,
        "utm_campaign": campaign_id,
    }
    tagged_url = url + ("&" if "?" in url else "?") + urlencode(dest_params)

    # l.php referer — paid uses AUC prefix, shorter h and c[0]
    h = _gen_h(is_paid=True)   # AUC prefix, 134 chars
    c0 = _gen_c0(is_paid=True)  # AUC prefix, 170 chars
    referer = (
        f"https://l.facebook.com/l.php?u={quote(tagged_url, safe='')}"
        f"&h={h}&tn=H-R"
        f"&c%5B0%5D={c0}"
    )

    return (referer, tagged_url)


# ═══════════════════════════════════════════════════════════════
# Self-test
# ═══════════════════════════════════════════════════════════════
if __name__ == "__main__":
    from urllib.parse import parse_qs, urlparse

    url = "https://smartlink.example.com/offer"

    print("=== ORGANIC Facebook — 10 samples ===")
    variants = {}
    for i in range(10):
        is_mob = i % 2 == 0
        ref, tagged = build_facebook_organic_referer(url, is_mobile=is_mob)
        domain = ref.split("/")[2] if ref else "none"
        has_fbclid = "?fbclid=" in (tagged or "") or "&fbclid=" in (tagged or "")
        key = f"{'MOB' if is_mob else 'DSK'}:{domain}:fbclid={'Y' if has_fbclid else 'N'}"
        variants[key] = variants.get(key, 0) + 1
        if i < 3:
            print(f"  {'MOB' if is_mob else 'DSK'} | domain={domain} | fbclid={'Y' if has_fbclid else 'N'}")
            if tagged:
                p = parse_qs(urlparse(tagged).query)
                print(f"    fbclid={p.get('fbclid',[''])[0][:20]}... (len={len(p.get('fbclid',[''])[0])})")
            print(f"    ref={ref[:70]}...")

    print(f"\n  Variant distribution:")
    for k, v in sorted(variants.items()):
        print(f"    {k}: {v}")

    # Verify organic format
    ref, tagged = build_facebook_organic_referer(url, is_mobile=False)
    if tagged:
        p = parse_qs(urlparse(tagged).query)
        assert p["fbclid"][0].startswith("IwZXh0bgNhZW0"), "fbclid prefix wrong"
        assert "_aem_" in p["fbclid"][0], "fbclid missing _aem_"
        assert "utm_source" not in p, "Organic should NOT have utm_source"
        assert "utm_medium" not in p, "Organic should NOT have utm_medium"
    assert "tn=H-R" in ref, "tn should be H-R"
    if "h=" in ref:
        h_val = ref.split("h=")[1].split("&")[0]
        assert h_val.startswith("AUD"), f"Organic h should start with AUD, got {h_val[:3]}"

    print("\n=== PAID Facebook Ads ===")
    ref2, tagged2 = build_facebook_ads_referer(url, is_mobile=True)
    p2 = parse_qs(urlparse(tagged2).query)
    print(f"  utm_source={p2['utm_source'][0]}")
    print(f"  utm_medium={p2['utm_medium'][0]}")
    print(f"  FBAudience={p2['FBAudience'][0]}")
    assert p2["utm_source"][0] == "fb"
    assert p2["utm_medium"][0] == "paid"
    h2 = ref2.split("h=")[1].split("&")[0]
    assert h2.startswith("AUC"), f"Paid h should start with AUC, got {h2[:3]}"

    # Verify lengths
    print(f"\n=== Length verification ===")
    print(f"  Organic h: {len(h_val)} (real: 146)")
    print(f"  Paid h: {len(h2)} (real: 134)")
    c0_paid = ref2.split("c%5B0%5D=")[1]
    print(f"  Paid c[0]: {len(c0_paid)} (real: 170)")
    print(f"  Organic fbclid: {len(p['fbclid'][0])} (real: ~145)")
    print(f"  Paid fbclid: {len(p2['fbclid'][0])} (real: ~160)")

    print("\n✅ ALL TESTS PASSED")
