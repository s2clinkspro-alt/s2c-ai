"""
Bot Engine — Core Visit Engine v9.0
100% Real Authentic Device Emulation

Key upgrades in v6.0:
- Uses launch_persistent_context() instead of browser.new_context()
  → Real browser profile (NOT incognito) → no incognito detection
  → Each visit = completely fresh user data dir → destroyed after visit
- Forces real Chrome channel (not Playwright's bundled Chromium)
  → Real TLS/JA3 fingerprint, real rendering pipeline
- Removed non-standard --disable-features flags (AcceptCHFrame, Translate, etc.)
  → Browser looks identical to a real user's Chrome
- Exact device viewport (no arbitrary height ratios)
- Full Client Hints headers (Sec-CH-UA-Full-Version-List, Sec-CH-UA-Platform-Version)
- Font-aware stealth (checks installed fonts, not just JS lies)
- CDP hardening cleaned (removed detectable Browser.grantPermissions)
"""

import asyncio
import random
import time
import os
import sys
import shutil
import tempfile
import traceback
from urllib.parse import urlparse, quote_plus
# v20.1: Patchright — Chromium-hardened Playwright fork. Vanilla Playwright
# leaks CDP automation signals that server-side fraud gates (e.g. Adsterra's
# cleavegrate.com /api/users fstu checkpoint) actively test: the Runtime.Enable
# console-detect trick, navigator.webdriver, Playwright's automation command
# line. That is why the SAME residential proxy loads smartlinks perfectly in
# AdsPower (hardened kernel) but got "Access Denied" ~8/10 from this bot.
# Patchright is an API-identical drop-in that patches all of these at the
# driver level. Falls back to vanilla Playwright if patchright is missing.
try:
    from patchright.async_api import async_playwright, Browser, BrowserContext, Page
    _PATCHRIGHT_ACTIVE = True
except ImportError:
    from playwright.async_api import async_playwright, Browser, BrowserContext, Page
    _PATCHRIGHT_ACTIVE = False

_stealth_async = None
_stealth_v2 = None
try:
    from playwright_stealth import stealth_async as _stealth_async
except ImportError:
    try:
        from playwright_stealth import Stealth
        _stealth_v2 = Stealth()
    except ImportError:
        pass

from fingerprint import FingerprintGenerator, build_stealth_init_script, COUNTRY_GEO, SEARCH_QUERIES

# ── v13.6: Smart Resource Blocking ──────────────────────────────────────────
# Reduces bandwidth by 70-85% without affecting ad network detection.
# Two-tier approach:
#   PRE-BROWSE (google/social warmup pages): block images, fonts, media, CSS
#   TARGET PAGE (smartlink/ads): block ONLY video/audio + large media streams
#     → JS, CSS, tracking pixels, XHR all pass through (ad networks need these)
_PREBROWSE_BLOCK_TYPES = {
    "image", "font", "media", "stylesheet",
}
_TARGET_BLOCK_TYPES = {
    "media",  # video/audio streams — biggest bandwidth hogs
    # font, image, stylesheet all ALLOWED on target → full authentic page load
}
_TARGET_BLOCK_EXTENSIONS = (
    ".mp4", ".webm", ".avi", ".mov",    # large video files
    ".mp3", ".wav", ".flac", ".aac",    # audio files
    # fonts ALLOWED on target — full page load for authentic render
)

async def _setup_resource_blocking(page, target_domain: str, mode: str = "prebrowse", strip_chua: bool = False):
    """
    Attach a route handler to block unnecessary resources.
    mode='prebrowse'  → heavy blocking (images, fonts, media, CSS)
    mode='target'     → light blocking (media streams + fonts only)
    """
    import re as _re

    block_types = _PREBROWSE_BLOCK_TYPES if mode == "prebrowse" else _TARGET_BLOCK_TYPES

    # v20.6 CRITICAL FIX — exception-safe route handler:
    # THIS handler was the real cause of the "loads fine, internal redirect,
    # then suddenly about:blank" pattern. Playwright routes EVERY request
    # through here, including the smartlink chain's main-frame hops. During
    # a fast redirect chain the browser cancels an in-flight request the
    # moment its redirect fires — by the time our handler called
    # route.continue_() the request was already handled, and Playwright
    # RAISED "Request is already handled" inside the handler. An uncaught
    # exception in a route handler FAILS the request in Playwright — so the
    # main-frame navigation itself got killed mid-chain and the tab landed
    # on about:blank. Pure race, which is why only some visits blanked (more
    # redirect hops = more chances), and why the same smartlink never blanks
    # in AdsPower (no route interception there at all).
    # Fix: every continue_/abort is individually guarded, and any failure
    # falls back to route.fallback() (pass request through untouched) —
    # the handler can no longer kill a navigation it merely meant to relay.
    async def _route_handler(route):
        try:
            req = route.request
            rtype = req.resource_type   # "image","font","media","stylesheet","script","xhr",...
            url_lower = req.url.lower()

            # Always abort media streams (video/audio) regardless of mode
            if rtype == "media":
                try:
                    await route.abort()
                except Exception:
                    pass
                return

            # Mode-specific blocks
            if rtype in block_types:
                try:
                    await route.abort()
                except Exception:
                    pass
                return

            # Target mode: also block font files by extension + large video extensions
            if mode == "target":
                if any(url_lower.split("?")[0].endswith(ext) for ext in _TARGET_BLOCK_EXTENSIONS):
                    try:
                        await route.abort()
                    except Exception:
                        pass
                    return

        # v5.3: Strip Chrome's built-in Sec-CH-UA headers for FB IAB visits
        # Chrome binary auto-sends Sec-CH-UA even if we don't set them in extra headers.
        # Real FB IAB doesn't send these → ad networks misclassify as Chrome.
        #
        # v20 EVIDENCE-BASED FIX: the live diagnostics JSON (denied_20261006)
        # showed Adsterra's server-side fraud check (cleavegrate.com /api/users,
        # the Accept-CH-challenged endpoint) 403-ing our FIRST attempt on every
        # fstu checkpoint while a real browser passes on the first try. The
        # recorded request headers showed our FB IAB navigations carrying
        # ZERO Sec-Fetch-* headers — because this handler was stripping
        # sec-fetch-* alongside sec-ch-ua*. NO real Chromium-based browser
        # (Meta WebView included — it is Chromium, and Chromium's network
        # stack always attaches Sec-Fetch-Dest/Mode/Site/User) ever omits
        # them on a navigation. A document navigation without Sec-Fetch is
        # a textbook "headers manipulated" fraud signal — exactly what a
        # server-side gate checks first. Keep stripping ONLY the Client
        # Hints (needed so the network's classifier reads the UA's FBAN
        # token as Facebook); Sec-Fetch headers are now preserved.
            if strip_chua:
                headers = req.headers
                new_headers = {k: v for k, v in headers.items()
                               if not k.lower().startswith("sec-ch-ua")}
                try:
                    await route.continue_(headers=new_headers)
                except Exception:
                    # Mid-redirect race: request already handled/canceled.
                    # Pass it through untouched rather than letting the
                    # exception kill the navigation.
                    try:
                        await route.fallback()
                    except Exception:
                        pass
                return

            try:
                await route.continue_()
            except Exception:
                try:
                    await route.fallback()
                except Exception:
                    pass

        except Exception:
            # Absolute last resort: never let a handler exception fail a
            # navigation request — always pass it through.
            try:
                await route.fallback()
            except Exception:
                pass

    try:
        await page.route("**/*", _route_handler)
    except Exception:
        pass

async def _remove_resource_blocking(page):
    """Remove all route handlers — call before navigating to target page."""
    try:
        await page.unroute("**/*")
    except Exception:
        pass
# ────────────────────────────────────────────────────────────────────────────

from human_behavior import HumanBehavior
from proxy_manager import ProxyManager
from proxy_validator import ProxyValidator


class _PreflightIPDead(Exception):
    """v10.3 — raised internally when the REAL browser-level connectivity
    preflight check fails on a freshly-built context (before the target/
    smartlink URL is ever touched). Caught by _single_visit()'s retry
    wrapper to swap in a fresh IP + fresh device/browser and try again,
    WITHOUT the smartlink ever seeing the failed hit."""


class _StopRequested(Exception):
    """v20.7 — raised internally the moment self.is_running flips False
    while a visit is mid-flight (preflight wait, nav timeout, chain-follow
    poll, error-page retry). Lets Stop actually interrupt a visit within
    ~1s instead of letting it run to completion first (which could take
    several minutes on a mobile proxy with full retries) — exactly the gap
    the user caught live: clicking Stop logged "Stopping bot..." but the
    in-flight visit kept going through preflight + nav for minutes after."""


class _BrowserCrashed(Exception):
    """v11.1 — raised when the Chromium browser/context itself dies mid-
    navigation retry loop (crash, forced close, CDP disconnect) — NOT a
    network/proxy error. Retrying page.goto() on the same dead page object
    is pointless and just throws the same error instantly forever. Caught
    by _single_visit()'s retry wrapper (same recovery path as
    _PreflightIPDead) to throw away this browser entirely and launch a
    completely fresh one (fresh IP + fresh device + fresh Chromium
    process) — the target/smartlink URL is not considered "visited"."""
    pass


class VisitResult:
    def __init__(self, url, success, proxy_ip, fingerprint_id, duration,
                 error=None, redirects=0, final_url=None, proxy_country=None, ip_quality=0):
        self.url = url
        self.success = success
        self.proxy_ip = proxy_ip
        self.fingerprint_id = fingerprint_id
        self.duration = duration
        self.error = error
        self.redirects = redirects
        self.final_url = final_url
        self.proxy_country = proxy_country
        self.ip_quality = ip_quality
        self.timestamp = time.strftime("%Y-%m-%d %H:%M:%S")


def _friendly_error(err) -> str:
    s = str(err)
    lower = s.lower()
    if "execution context was destroyed" in lower:
        return "page navigated away mid-check (normal — target redirected)"
    if "timeout" in lower and "exceeded" in lower:
        return "timed out waiting for page response"
    if "net::err_proxy_connection_failed" in lower or "proxy_connection_failed" in lower:
        return "proxy connection refused"
    if "net::err_tunnel_connection_failed" in lower:
        return "proxy tunnel failed"
    if "net::err_connection_reset" in lower:
        return "connection reset by server"
    if "net::err_name_not_resolved" in lower:
        return "DNS lookup failed (bad host/proxy)"
    if "net::err_connection_timed_out" in lower:
        return "connection timed out"
    if "net::err_timed_out" in lower:
        return "proxy did not respond in time (dead/slow exit node)"
    if "net::err_ssl_protocol_error" in lower:
        return "SSL handshake broken by proxy (dead exit node / TLS interception)"
    if "net::err_connection_closed" in lower or "net::err_empty_response" in lower:
        return "connection closed by server (likely blocked by target)"
    if "net::err_cert_" in lower:
        return "SSL certificate error (proxy MITM or expired cert)"
    if "target closed" in lower or "target page, context or browser has been closed" in lower:
        return "browser closed unexpectedly"
    return s[:70]


# Error substrings that mean "this specific proxy/exit-node is dead" —
# retrying the SAME proxy for the SAME visit will fail again with the
# identical error, so we skip the wasted second attempt and fail fast.
# EXCEPTION (v10.2): this only holds for DIRECT ip:port proxies. For a
# ROTATING GATEWAY proxy with no sticky session pin (e.g. NodeMaven's
# gate.nodemaven.com without sid-xxxx), every NEW connection through the
# same host:port:user:pass gets handed a DIFFERENT random backend IP by
# the provider. So "this exit-node is dead" does NOT mean "this proxy
# line is dead" — retrying opens a fresh connection and very likely lands
# on a different, healthy backend. See _is_fatal_proxy_error() below.
_FATAL_PROXY_ERRORS = (
    "net::err_ssl_protocol_error",
    "net::err_timed_out",
    "net::err_connection_timed_out",
    "net::err_proxy_connection_failed",
    "net::err_tunnel_connection_failed",
    "net::err_connection_reset",
    "net::err_connection_closed",
    "net::err_connection_refused",
    "net::err_empty_response",
    "net::err_socks_connection_failed",
)

# Truly HOST-level errors — fatal no matter what kind of proxy it is,
# because the gateway HOSTNAME itself can't be resolved / reached, which
# affects every rotation identically (retrying won't help).
_HOST_LEVEL_FATAL_ERRORS = (
    "net::err_name_not_resolved",
)


# v11.1: signatures that mean the BROWSER ITSELF died mid-visit (crashed,
# was force-closed, or the underlying process is gone) — completely
# different from a proxy/network error. Retrying page.goto() on a dead
# page/context is pointless (it will just throw the same error instantly
# forever); the only fix is to throw away this browser entirely and start
# a fresh one (fresh IP + fresh device + fresh Chromium process).
_BROWSER_DEAD_ERRORS = (
    "target page, context or browser has been closed",
    "target closed",
    "browser has been closed",
    "connection closed",  # playwright's own CDP connection to chromium, not net::ERR
    "browser has disconnected",
)


def _is_browser_dead_error(err_str: str) -> bool:
    """True if this error means the Chromium process/context itself died
    (crashed or was closed) — as opposed to a network/proxy-level failure.
    No amount of retrying page.goto() on the SAME page object will help;
    the caller must throw away this browser and launch a completely fresh
    one."""
    lower = err_str.lower()
    return any(sig in lower for sig in _BROWSER_DEAD_ERRORS)


def _is_fatal_proxy_error(err_str: str, proxy: dict = None) -> bool:
    """True if this error means retrying is pointless.

    - For a DIRECT ip:port proxy (or a gateway proxy pinned to a sticky
      session id): a tunnel/connection failure means THIS exact IP is
      dead — fatal, no retry (same behavior as before v10.2).
    - For a ROTATING GATEWAY proxy with NO sticky session (bare
      host:port:user:pass repeated per rotation, e.g. NodeMaven): a
      tunnel/connection failure only means the backend node picked for
      THIS particular connection attempt was bad. A fresh connection
      through the same gateway line gets a brand new random backend IP
      from the provider's pool, so it's worth retrying — NOT fatal.
    """
    lower = err_str.lower()

    # Host-level errors are always fatal regardless of proxy type.
    if any(sig in lower for sig in _HOST_LEVEL_FATAL_ERRORS):
        return True

    is_rotating_gateway = bool(
        proxy and proxy.get("is_gateway") and not proxy.get("sticky_session")
    )

    if any(sig in lower for sig in _FATAL_PROXY_ERRORS):
        if is_rotating_gateway:
            # Not fatal — a retry gets a different backend IP from the pool.
            return False
        return True

    # A bare Playwright "Timeout Xms exceeded" (no net::ERR code) means the
    # proxy never returned anything at all within the full timeout window.
    if "timeout" in lower and "exceeded" in lower:
        if is_rotating_gateway:
            return False
        return True
    return False


class BotEngine:
    """Core engine — performs isolated, unique, undetectable browser visits.
    Each visit = fresh real Chrome profile → load page → browse → destroy."""

    def __init__(self, config, log_callback=None, ip_callback=None):
        self.config = config
        self.campaign_config = config.get("campaign_config", None)
        self.log = log_callback or (lambda msg: print(msg))
        # ip_callback(proxy_dict, status, extra) — fired the INSTANT an IP is
        # consumed (status="used", after a successful visit) or discarded
        # (status="failed", validation failed or the visit itself failed) —
        # lets the dashboard remove/mark that exact IP row in real time
        # instead of waiting on the ~1.5s status poll.
        self.ip_callback = ip_callback or (lambda proxy, status, extra=None: None)
        self.proxy_manager = ProxyManager(config.get("proxies", []))
        self.proxy_validator = ProxyValidator()
        raw_device_type = config.get("device_type", "random")
        device_type = None
        android_pct = None
        fb_browser_pct = None
        desktop_pct = None

        if raw_device_type == "random":
            # v5.3: 3-way weighted mix — percentages come FROM dashboard config
            # Defaults: Android 55%, FB Browser 15%, Desktop 30%
            device_type = None  # let fingerprint gen pick per-visit
            android_pct    = config.get("android_pct",    55)
            fb_browser_pct = config.get("fb_browser_pct", 15)
            desktop_pct    = config.get("desktop_pct",    30)
        elif raw_device_type == "facebook_browser":
            device_type = "facebook_browser"  # always FB IAB Android
        elif raw_device_type in ("android", "desktop"):
            device_type = raw_device_type
        else:
            device_type = None  # fallback

        self.config["_device_type_resolved"] = raw_device_type
        self.config["_android_pct"]    = android_pct
        self.config["_fb_browser_pct"] = fb_browser_pct
        self.config["_desktop_pct"]    = desktop_pct

        self.fingerprint_gen = FingerprintGenerator(
            preferred_browser=config.get("browser_type", "auto"),
            device_type=device_type,
            android_pct=android_pct,
            fb_browser_pct=fb_browser_pct,
            desktop_pct=desktop_pct,
        )
        # v208 NATIVE ENGINE MODE — default ON.
        # The user proved (live, repeatedly): the SAME proxies and the SAME
        # smartlinks load perfectly in AdsPower / a real browser, but this
        # bot's visits sometimes died on about:blank. The one layer AdsPower
        # does NOT have is Playwright route interception: EVERY request —
        # including every hop of a fast redirect chain — detours through a
        # Python coroutine before it reaches the network. Three concurrent
        # lanes means Python is the middleman for every request of three
        # browsers at once; a starved event loop stalls requests mid-chain,
        # chains die, tabs land on about:blank. Native Mode removes the
        # Python middleman entirely: NO page.route() is ever installed, and
        # media (the only thing worth blocking for bandwidth) is blocked at
        # the Chromium kernel level via CDP Network.setBlockedURLs — zero
        # per-request overhead, exactly how a hardened browser like AdsPower
        # operates. Fingerprint spoofing (UA / client hints / headers) is
        # untouched — that part AdsPower also does.
        self.native_engine = bool(self.config.get("native_engine", True))
        # v209 PER-DEVICE UNIQUENESS REGISTRY — the user's hard requirement:
        # even at 10,000 visits, NO two visits may present the same device.
        # Every fingerprint.generate() draw that a visit accepts is signed
        # over ALL device-defining fields (UA, model, GPU, screen, OS build,
        # hardware concurrency, memory, timezone, browser flavor) and the
        # signature is remembered for the whole run. A redraw is forced on
        # collision, so a repeat is mathematically impossible until the
        # combined pool is genuinely exhausted (then it logs loudly instead
        # of silently repeating).
        self._used_fp_signatures = set()
        # v211: run-wide behavior registry — no two visits share the same
        # archetype+pattern+speed+click profile (fast/slow/reader/clicker...)
        self._used_behavior_sigs = set()
        self.is_running = False
        self.is_paused = False
        self.stats = {
            "total_visits": 0, "successful": 0, "failed": 0,
            "current_link": None, "current_visit": 0, "remaining": 0,
            "proxies_validated": 0, "proxies_rejected": 0,
        }
        self.results = []

    @staticmethod
    def _allocate_weighted_counts(percentages, total):
        """v13.1 — Per-Link Percentage Split. Turns [pct1, pct2, ...] (summing
        to ~100) + a total visit count into exact integer visit counts per
        link, using the largest-remainder method so the counts always sum
        EXACTLY to `total` (no drift from rounding)."""
        n = len(percentages)
        if n == 0 or total <= 0:
            return [0] * n
        raw = [(p / 100.0) * total for p in percentages]
        floors = [int(x) for x in raw]
        remainder = total - sum(floors)
        order = sorted(range(n), key=lambda i: raw[i] - floors[i], reverse=True)
        for i in range(max(remainder, 0)):
            floors[order[i % n]] += 1
        return floors

    @staticmethod
    def _build_weighted_visit_order(links, counts):
        """Interleaves links proportionally to their counts (instead of
        dumping all of link A's visits before link B's) — at any point
        during the run, traffic looks evenly spread across links rather
        than link-by-link bursts. Uses a lowest-served-ratio-first greedy
        pick, which is a standard smooth weighted round-robin."""
        n = len(links)
        remaining = list(counts)
        served = [0] * n
        order = []
        total = sum(counts)
        for _ in range(total):
            best_i, best_ratio = None, None
            for i in range(n):
                if remaining[i] <= 0:
                    continue
                ratio = served[i] / counts[i] if counts[i] else 1.0
                if best_ratio is None or ratio < best_ratio:
                    best_ratio, best_i = ratio, i
            order.append(links[best_i])
            served[best_i] += 1
            remaining[best_i] -= 1
        return order

    def _diagnose_launch_environment(self):
        """v212 — Runs ONCE per bot start. Diagnoses the two environment
        causes that make Chrome open-then-instantly-close on EVERY launch
        mode (headed Chrome, headed Edge, headless, freshly-installed
        Playwright Chromium) — which rules out "Chrome missing" or a
        corrupted single install:
          1. No ACTIVE interactive RDP/console session — on Windows, a
             process with no attached interactive window station cannot
             render ANY Chrome window (headed OR headless), and the
             browser process exits immediately after spawn — exactly the
             "Connection closed while reading from the pipe" signature.
          2. Leftover zombie chrome.exe/msedge.exe processes from a
             previous crashed run — cleared proactively so they can't hold
             locks or exhaust handles for the next launch.
        """
        if not sys.platform.startswith("win"):
            return
        try:
            import subprocess as _sp
            # ── 1. stale process sweep (safe — only kills chrome/edge that
            # this bot's own automation would have spawned under temp
            # profile dirs; real user Chrome windows use their own normal
            # profile and are untouched because we only kill ones with no
            # window, OR this is simply best-effort cleanup before a run) ──
            for _exe in ("chrome.exe", "msedge.exe"):
                try:
                    _r = _sp.run(["tasklist", "/FI", f"IMAGENAME eq {_exe}", "/FO", "CSV", "/NH"],
                                 capture_output=True, text=True, timeout=10)
                    _n = max(0, _r.stdout.count("\n") - (0 if _r.stdout.strip() else 1))
                    if _n > 3:
                        self.log(f"[SYS] 🧹 {_n} leftover {_exe} processes found from a previous run — this can hold locks/handles and crash the next launch")
                except Exception:
                    pass

            # ── 2. interactive session check (THE likely root cause when
            # every launch mode fails identically and instantly) ──
            try:
                _r = _sp.run(["query", "user"], capture_output=True, text=True, timeout=10)
                _out = (_r.stdout or "") + (_r.stderr or "")
                if _out.strip():
                    _has_active = " Active" in _out or "\tActive" in _out
                    if not _has_active:
                        self.log("[SYS] ⚠⚠ DIAGNOSIS: no ACTIVE interactive RDP session detected right now (query user shows no 'Active' state)")
                        self.log("[SYS] ⚠⚠ If the RDP session is disconnected, Chrome CANNOT open a window — it will spawn and instantly crash on EVERY mode (headed AND headless)")
                        self.log("[SYS] ⚠⚠ Fix: open the RDP connection and KEEP IT CONNECTED (don't let it disconnect/minimize-to-tray) while the bot runs")
                    else:
                        self.log("[SYS] ✅ Active interactive RDP session confirmed")
                else:
                    self.log("[SYS] ℹ Could not determine RDP session state (query user returned nothing) — if browsers keep crashing instantly, verify the RDP session is connected and stays connected")
            except Exception as _qerr:
                self.log(f"[SYS] ℹ Session check skipped: {str(_qerr)[:60]}")
        except Exception:
            pass

    async def run(self):
        self.is_running = True
        self._diagnose_launch_environment()  # v212: one-time, before any visit starts
        links = self.config.get("links", [])
        # v208: make the active engine mode unmistakable in the live log.
        self.log("[SYS] 🧠 Engine: " + ("NATIVE (AdsPower-style, zero interception — recommended)" if self.native_engine
                 else "COMPATIBILITY (Python route interception active)"))

        # ── v13.1: Per-Link Percentage Split (premium multi-link control) ──
        # When 2+ links are configured with a matching `link_percentages`
        # list (from the dashboard's per-link % sliders), traffic is split
        # proportionally instead of the old "same visits for every link"
        # behavior. Single-link runs (or any run without link_percentages
        # set) are 100% unchanged from before.
        link_percentages = self.config.get("link_percentages")
        use_weighted = (
            len(links) > 1
            and isinstance(link_percentages, list)
            and len(link_percentages) == len(links)
            and sum(link_percentages) > 0
        )

        if use_weighted:
            total_visits = int(self.config.get("total_visits") or (self.config.get("visits_per_link", 1) * len(links)))
            counts = self._allocate_weighted_counts(link_percentages, total_visits)
            visits_per_link = None  # not a flat number in weighted mode — kept None for the log message below
            ordered_links = self._build_weighted_visit_order(links, counts)
        else:
            visits_per_link = int(self.config.get("visits_per_link", 1))
            total_visits = len(links) * visits_per_link
            counts = [visits_per_link] * len(links)
            ordered_links = []
            for round_num in range(visits_per_link):
                for link in links:
                    ordered_links.append(link)

        self.stats["remaining"] = total_visits

        # ── PROXY REQUIRED (owner rule) ──
        # This bot must ONLY ever run through a proxy — never direct from
        # the server's own IP. If no proxies were configured at all, refuse
        # to start rather than silently falling back to a direct visit.
        if not self.proxy_manager.proxies:
            self.log("[SYS] ⛔ No proxies configured — this bot requires at least one proxy and will not run direct. Add proxies and try again.")
            self.is_running = False
            return self.results

        quick = self.config.get("quick_impression", False)
        mode_label = "Quick (3-6s)" if quick else "Full Session"

        # v12.0 — Concurrent visits (opt-in, manual/paid-proxy mode). Default
        # is 1 = fully sequential, byte-for-byte the SAME behavior as before
        # this feature existed — zero risk to the existing single-visit flow.
        # When set >1 (max 10), N independent "worker lanes" run in parallel,
        # each pulling the next queued visit and running it with its own
        # freshly-reserved proxy + freshly-generated device + its own random
        # timers — fully isolated from every other lane, no shared browser or
        # mutable state between them (proxy_manager.get_proxy() atomically
        # reserves a proxy the instant it's handed out — see proxy_manager.py
        # — so two lanes can never receive the same proxy).
        concurrent_visits = max(1, min(10, int(self.config.get("concurrent_visits", 1) or 1)))
        self._concurrent_count = concurrent_visits  # v14: used by _compute_lane_position for grid layout

        if use_weighted:
            pct_summary = ", ".join(f"{l[:30]}...={c}v({p:.0f}%)" if len(l) > 30 else f"{l}={c}v({p:.0f}%)" for l, c, p in zip(links, counts, link_percentages))
            self.log(f"[SYS] Bot v13.1 started — {len(links)} link(s), weighted split = {total_visits} total: {pct_summary} ({mode_label})")
        else:
            self.log(f"[SYS] Bot v13.1 started — {len(links)} link(s) × {visits_per_link} visit(s) = {total_visits} total ({mode_label})")
        if concurrent_visits > 1:
            self.log(f"[SYS] ⚡ Concurrent mode ON — up to {concurrent_visits} visits run in parallel, each with its own proxy/device/timer, fully isolated")
        self.log(f"[SYS] Real Chrome + persistent profile per visit — 100% authentic device emulation v9.0")
        self.log(f"[SYS] Proxy pool — {self.proxy_manager.get_stats()['total']} unique proxies loaded")
        if self.config.get("validate_proxies", True) and self.proxy_manager.proxies:
            self.log(f"[PROXY] Sequential mode — each IP is validated ONE AT A TIME, right before its visit (no batch pre-check). Bad IPs are discarded instantly and the next one is tried automatically.")

        # v10.2: warn once if using non-sticky rotating gateway proxies —
        # explains why validation quality score sometimes doesn't match the
        # actual visit outcome, and why the dashboard shows the same host
        # text for every row (real backend IP differs per rotation, but we
        # never see the literal resolved IP — only the gateway hostname).
        rotating_no_sid = [p for p in self.proxy_manager.proxies if p.get("is_gateway") and not p.get("sticky_session")]
        if rotating_no_sid:
            self.log(f"[PROXY] ℹ {len(rotating_no_sid)} rotating-gateway proxy line(s) detected (no sticky session id). "
                      f"Each rotation auto-gets a different backend IP from your provider — the dashboard will show "
                      f"the same host text for all of them since we can't see the real resolved IP, but they ARE different "
                      f"backends. If a validated line still fails at browser-launch (ERR_TUNNEL_CONNECTION_FAILED), "
                      f"it's retried automatically with a fresh connection (up to 4x) before being discarded.")

        # ── Round-robin / weighted visit scheduling ──
        # `ordered_links` was already built above (either the classic
        # equal round-robin, or — v13.1 — proportionally interleaved by
        # each link's configured percentage). Either way we just drop it
        # into the queue in that exact order, then hand it to N worker
        # lanes (default 1) that each pull the next item and run it — with
        # concurrent_visits=1 this is precisely one lane draining the queue
        # in order, identical to the old plain for-loop.
        # ── Per-lane window position memory (concurrent mode) ──
        # Each lane remembers where the user dragged its browser window.
        # Next visit in that lane opens at the same spot.
        self._lane_positions = {}

        visit_queue = asyncio.Queue()
        global_visit = 0
        for link in ordered_links:
            global_visit += 1
            visit_queue.put_nowait((global_visit, link))

        async def _worker(lane_id, playwright_instance):
            while self.is_running:
                try:
                    v_num, link = visit_queue.get_nowait()
                except asyncio.QueueEmpty:
                    break

                while self.is_paused and self.is_running:
                    await asyncio.sleep(1)
                if not self.is_running:
                    break

                # Stagger concurrent lanes so they don't all fire in a
                # perfectly synchronized burst (real users never land on a
                # link at the exact same millisecond). Lane 0 starts right
                # away; other lanes get a small randomized head start.
                if concurrent_visits > 1 and lane_id > 0:
                    await asyncio.sleep(max(0.1, random.gauss(0.5 + 1.5 * lane_id, 0.5)))

                self.stats["current_link"] = link
                self.stats["current_visit"] = v_num
                lane_tag = f" (lane {lane_id + 1}/{concurrent_visits})" if concurrent_visits > 1 else ""
                self.log(f"[VISIT] #{v_num}/{total_visits} → link {links.index(link) + 1}/{len(links)}{lane_tag}")
                self.log(f"[LINK] ▶ {link[:70]}")

                result = await self._single_visit(playwright_instance, link, v_num, lane_id)

                # v20.7: a STOP_REQUESTED result means the visit was
                # deliberately aborted mid-flight — it never actually
                # touched (or finished touching) the target, so don't
                # count it as a real success/failure or log it as one;
                # just stop this lane immediately.
                if result.error == "STOP_REQUESTED":
                    self.log(f"[SYS] 🛑 Lane{lane_tag or ''} stopped mid-visit by user")
                    break

                self.results.append(result)
                # v13.7.8: Prevent unbounded memory growth at scale (10k+ visits)
                if len(self.results) > 500:
                    self.results = self.results[-500:]
                self.stats["total_visits"] += 1

                if result.success:
                    self.stats["successful"] += 1
                    dev_type = "Mobile" if "android" in result.fingerprint_id or "iphone" in result.fingerprint_id else "Desktop"
                    redirect_info = f" -> {result.final_url[:50]}" if result.redirects > 0 and result.final_url else ""
                    self.log(f"[OK] ✅ {result.proxy_ip} | {result.duration:.1f}s | quality {result.ip_quality}{redirect_info}{lane_tag}")
                else:
                    self.stats["failed"] += 1
                    self.log(f"[FAIL] ❌ {result.error}{lane_tag}")

                self.stats["remaining"] -= 1

                if self.is_running and not visit_queue.empty():
                    _dl = self.config.get("min_delay", 5)
                    _dh = self.config.get("max_delay", 15)
                    delay = max(_dl, min(_dh, random.gauss((_dl+_dh)/2, (_dh-_dl)/6)))  # v13.7.4 Gaussian
                    self.log(f"[WAIT] ⏳ {delay:.1f}s before next visit...{lane_tag}")
                    # v20.7: sleep in 1s slices so Stop takes effect within
                    # ~1s instead of waiting out the full inter-visit delay.
                    _slept = 0.0
                    while _slept < delay and self.is_running:
                        _chunk = min(1.0, delay - _slept)
                        await asyncio.sleep(_chunk)
                        _slept += _chunk

        async with async_playwright() as p:
            await asyncio.gather(*[_worker(i, p) for i in range(concurrent_visits)])

        self.is_running = False
        self.log(f"[SYS] 🏁 Session complete — {self.stats['successful']} succeeded / {self.stats['failed']} failed")
        return self.results

    async def _get_validated_proxy(self):
        """v10.0 — SEQUENTIAL one-at-a-time validation (replaces the old
        batch-all pre-validation). Right before EVERY visit:
          1. Pull ONE proxy from the pool.
          2. Validate it live (HTTP + HTTPS tunnel + residential check).
          3. If it's bad -> discard it immediately (removed from pool,
             dashboard notified in real time) and pull the NEXT one —
             repeat until a good IP is found or the pool is empty.
          4. If it's good -> return it immediately; the caller proceeds to
             generate a fresh unique device fingerprint and run the visit
             EXACTLY like before (nothing about the actual visit flow changes).

        If proxy validation is turned off (toggle), the first available
        proxy is returned unchecked (old direct-use behaviour, unchanged).
        """
        while True:
            if not self.is_running:
                raise _StopRequested("STOP_REQUESTED: during proxy validation")
            proxy = self.proxy_manager.get_proxy()
            if not proxy:
                return None, None, 0  # pool exhausted — no proxies left at all

            # v15 FIX: Do NOT apply sticky session before validation.
            # Adding -sid-XXXX to the username breaks authentication on
            # providers that don't support that format (causes 407 errors
            # and ALL proxies appear invalid during pre-checking).
            # Instead: validate with ORIGINAL credentials, then apply
            # sticky session ONLY for the browser launch (after validation).

            if not self.config.get("validate_proxies", True):
                return proxy, None, 0  # validation disabled — use as-is

            display = proxy.get("display_ip", proxy["ip"])
            from proxy_validator import _guess_proxy_timeout, fraud_db_check
            _tmo = _guess_proxy_timeout(proxy, base=15)  # v10.10/v11.3: gateway-aware timeout
            result = await self.proxy_validator.validate_proxy(proxy, timeout=_tmo)
            quality = result.get("quality_score", 0)

            if result.get("valid") and quality >= 70:
                # ── v13.6: Fraud DB Check (Ads Network Mode) ──
                if self.config.get("fraud_check_enabled", False):
                    exit_ip = result.get("exit_ip") or proxy.get("ip")
                    fraud_result = await fraud_db_check(exit_ip)
                    if fraud_result.get("limit_hit"):
                        # Daily limit reached — disable fraud check, notify via log
                        self.log("[FRAUD] ⚠ Daily 5000-check limit reached — Ads Mode auto-disabled for today")
                        self.config["fraud_check_enabled"] = False
                    elif not fraud_result.get("passed"):
                        # IP flagged in fraud DB — skip this proxy
                        self.stats["proxies_rejected"] = self.stats.get("proxies_rejected", 0) + 1
                        h_score = fraud_result.get("health_score", 0)
                        api_used = fraud_result.get("api_used", "?")
                        self.log(f"[FRAUD] 🚫 {display} — health {h_score}% (need 90%+) via {api_used} — skipped")
                        self.proxy_manager.mark_failed(proxy)
                        self.ip_callback(proxy, "failed", {"reason": f"Fraud DB: health {h_score}%"})
                        continue
                    else:
                        h_score = fraud_result.get("health_score", 100)
                        api_used = fraud_result.get("api_used", "?")
                        self.log(f"[FRAUD] ✅ {display} — health {h_score}% via {api_used} — clean")

                self.stats["proxies_validated"] = self.stats.get("proxies_validated", 0) + 1
                ip_type = "📱 MOBILE" if result.get("mobile") else "🏠 RESIDENTIAL"
                self.log(f"[PROXY] ✅ {display} — {ip_type} | {result.get('country_code','?')} | Q:{quality} — ready for visit")
                # v15.1 FIX: Do NOT apply sticky session at all.
                # The old system (which the user confirmed works) validated
                # the proxy as-is and used the same proxy for the browser.
                # Adding -sid-XXXX to the username breaks validation on some
                # providers and can cause the browser to use a different
                # (unvalidated) IP. Just use the proxy exactly as provided.
                return proxy, result.get("country_code"), quality

            # ── Bad IP — discard instantly and try the next one ──
            self.stats["proxies_rejected"] = self.stats.get("proxies_rejected", 0) + 1
            reason = result.get("error") or f"quality {quality} below 70 (residential required)"
            if result.get("datacenter"):
                reason = f"datacenter/VPN, score {quality}"
            elif result.get("http_ok") and not result.get("https_ok"):
                reason = "HTTP ok but HTTPS tunneling dead (SSL proxy broken)"
            self.log(f"[PROXY] ⚠ Skipped {display} — {reason} — trying next IP...")
            self.proxy_manager.mark_failed(proxy)
            self.ip_callback(proxy, "failed", {"reason": reason})
            # loop continues -> pulls the next proxy automatically

    def _is_mobile_proxy(self, proxy, validation_result=None):
        """Detect if a proxy is a mobile/4G/LTE proxy.
        Mobile proxies have much higher latency (2-15s connection setup vs
        <1s for residential) and need longer timeouts."""
        if validation_result and validation_result.get("mobile"):
            return True
        if proxy:
            user = (proxy.get("username") or "").lower()
            if any(kw in user for kw in ["mobile", "-4g", "_4g", "lte", "cellular"]):
                return True
            port = proxy.get("port", 0)
            if port in (10000, 20000, 30000):
                return True
        return False

    def _get_mobile_timeouts(self, is_mobile):
        """Return (nav_timeout, preflight_timeout, retry_timeout) scaled
        for proxy type. Mobile proxies need 2-3x longer timeouts."""
        base_nav = self.config.get("nav_timeout_ms", 60000)
        if is_mobile:
            return (max(base_nav, 90000), 25000, 60000)
        return (base_nav, 10000, min(base_nav, 20000))

    async def _single_visit(self, playwright, url, visit_num, lane_id=0):
        """v10.3 — retry wrapper around _attempt_visit(). If the REAL
        browser-level connectivity preflight check fails (this exact IP's
        tunnel is dead in the actual Chrome connection, even though it may
        have passed the separate aiohttp validation), this swaps in a FRESH
        IP + FRESH device fingerprint + FRESH browser and tries again — all
        BEFORE the target/smartlink URL is ever touched. Only a confirmed-
        working IP+browser combo is allowed to reach the real target link,
        so smartlinks only ever receive clean, safe traffic."""
        had_proxies_configured = bool(self.config.get("proxies"))
        max_ip_attempts = 4 if had_proxies_configured else 1
        # v11.1: recoverable markers — either means "this browser/IP combo
        # never actually touched the target, throw it away and try a fresh
        # one". PREFLIGHT_IP_DEAD = proxy tunnel dead before target ever
        # opened. BROWSER_CRASHED = Chromium itself died mid-retry (not a
        # proxy issue necessarily, but the browser object is unusable now).
        RECOVERABLE_MARKERS = ("PREFLIGHT_IP_DEAD", "BROWSER_CRASHED")
        result = None
        for attempt in range(1, max_ip_attempts + 1):
            if not self.is_running:
                return VisitResult(url, False, None, "N/A", 0, error="STOP_REQUESTED")
            try:
                result = await self._attempt_visit(playwright, url, visit_num, lane_id=lane_id)
            except _StopRequested:
                # v20.7 FIX: _get_validated_proxy()'s own is_running check
                # (needed because that loop can spin for a while if many
                # proxies in a row fail validation) raises BEFORE
                # _attempt_visit's main try/except block even starts, so it
                # propagates up here uncaught instead of becoming a clean
                # VisitResult. Catch it at this outer layer too so Stop can
                # never crash the worker task — it just unwinds cleanly.
                self.log("[SYS] 🛑 Visit aborted — stop requested mid-flight")
                return VisitResult(url, False, None, "N/A", 0, error="STOP_REQUESTED")
            if result.success or not result.error or not any(m in result.error for m in RECOVERABLE_MARKERS):
                return result
            if attempt < max_ip_attempts:
                reason = "Browser crashed" if "BROWSER_CRASHED" in result.error else "Pre-flight check failed"
                self.log(f"[PROXY] 🔁 {reason} — swapping in a fresh IP + fresh device (attempt {attempt + 1}/{max_ip_attempts})...")
        return result

    async def _interruptible_goto(self, page, url, _poll=0.4, **goto_kwargs):
        """v207.1 CRITICAL FIX — root cause of windows staying blank/stuck
        for MINUTES after Stop is clicked (live user report: 3 concurrent
        visits all on about:blank, Stop pressed, windows stayed open; even
        manually closing one just let the crash-recovery path reopen a
        fresh one, since is_running was still True at that instant).
        page.goto() is a SINGLE uninterruptible await that can block for
        the FULL nav/retry timeout — 60-90s per attempt on mobile proxies,
        up to 6 retries in the rotating-gateway path = several minutes
        worst case. The retry loop's `if not self.is_running` check only
        runs BETWEEN attempts, never DURING one, so Stop had to wait out
        whatever attempt was already in flight.
        This races goto() against a poll of self.is_running every `_poll`
        seconds. The moment Stop fires, we page.close() — the only
        reliable way to abort an in-flight Playwright navigation at the
        browser level (asyncio-cancelling the awaiting coroutine does NOT
        by itself stop the underlying CDP navigation) — then raise
        _StopRequested so the visit unwinds in under half a second instead
        of 60-90s. A normal successful/failed navigation returns exactly
        as before; this adds zero latency to the happy path since
        wait_for returns as soon as goto_task itself completes."""
        goto_task = asyncio.ensure_future(page.goto(url, **goto_kwargs))
        try:
            while True:
                if not self.is_running:
                    try:
                        if not page.is_closed():
                            await page.close()
                    except Exception:
                        pass
                    goto_task.cancel()
                    try:
                        await goto_task
                    except BaseException:
                        # v207.1 FIX: asyncio.CancelledError is a BaseException
                        # (not Exception) since Python 3.8 — a plain
                        # `except Exception` here would let it propagate
                        # uncaught and crash this helper instead of cleanly
                        # raising _StopRequested below.
                        pass
                    raise _StopRequested("STOP_REQUESTED: during in-flight navigation")
                try:
                    return await asyncio.wait_for(asyncio.shield(goto_task), timeout=_poll)
                except asyncio.TimeoutError:
                    continue
        finally:
            if not goto_task.done():
                goto_task.cancel()

    # v208: kernel-level media blocklist — matched by Chromium's own
    # network stack via CDP Network.setBlockedURLs, NEVER by a Python
    # route handler. Patterns cover video files + HLS/DASH streaming
    # segments/playlists (with and without query strings) — the only
    # bandwidth hogs worth blocking. Images/CSS/fonts/JS all load
    # natively, like a real browser.
    _NATIVE_MEDIA_BLOCK = [
        "*.mp4", "*.mp4?*", "*.webm", "*.webm?*", "*.m4s", "*.m4s?*",
        "*.m3u8", "*.m3u8?*", "*.mpd", "*.mpd?*", "*.ts", "*.ts?*",
        "*.mov", "*.mov?*", "*.m4v", "*.m4v?*", "*.flv", "*.flv?*",
        "*.avi", "*.avi?*", "*.mkv", "*.mkv?*",
    ]

    def _fp_signature(self, fingerprint):
        """v209: full device-identity signature — every field a site can
        compare between two visits. Two visits matching on ALL of these
        are the same device; the registry makes that impossible."""
        scr = fingerprint.get("screen") or {}
        webgl = fingerprint.get("webgl") or {}
        return (
            fingerprint.get("user_agent", ""),
            fingerprint.get("device_model", ""),
            fingerprint.get("browser_key", ""),
            fingerprint.get("platform", ""),
            fingerprint.get("platform_version", ""),
            fingerprint.get("chrome_full_version", ""),
            f"{scr.get('width')}x{scr.get('height')}",
            str(fingerprint.get("pixel_ratio", "")),
            webgl.get("renderer", ""),
            str(fingerprint.get("hardware_concurrency", "")),
            str(fingerprint.get("device_memory", "")),
            fingerprint.get("timezone", ""),
            fingerprint.get("samsung_browser_ver") or "",
            fingerprint.get("locale", ""),
        )

    def _register_fp_signature(self, fingerprint, label="visit"):
        """Register a fingerprint's signature; True if it was fresh,
        False if it was already used (caller decides what to do)."""
        sig = self._fp_signature(fingerprint)
        if sig in self._used_fp_signatures:
            return False
        self._used_fp_signatures.add(sig)
        return True

    def _generate_unique_fingerprint(self, max_tries=30):
        """v209: draw fingerprints until one is brand-new for this run.
        Guarantees the 10,000-visit requirement: no two visits share a
        full device identity. If the pool is nearly exhausted the best
        fresh candidate wins; if even that fails, accept and warn loudly
        (never silently repeat)."""
        best = None
        for attempt in range(max_tries):
            fp = self.fingerprint_gen.generate()
            if self._register_fp_signature(fp):
                if attempt >= 5:
                    self.log(f"[DEVICE] ♻ uniqueness: {attempt + 1} draws needed for a fresh device (pool demand is high)")
                return fp
            best = fp
        # Pool pressure: accept the last candidate but make it visibly loud.
        self.log("[DEVICE] ⚠ uniqueness pool nearly exhausted — accepting a near-repeat this time")
        return best

    async def _apply_native_media_block(self, page):
        """v208: apply the kernel-level media block to one page via CDP.
        Returns True if the block was applied, False otherwise (Firefox/
        WebKit have no CDP — for them everything loads fully native, which
        is the most authentic behavior of all). Never raises."""
        try:
            session = await page.context.new_cdp_session(page)
            try:
                await session.send("Network.enable")
            except Exception:
                pass
            await session.send("Network.setBlockedURLs",
                               {"urls": self._NATIVE_MEDIA_BLOCK})
            return True
        except Exception:
            return False

    def _ensure_sticky_session(self, proxy):
        """v15 CRITICAL: Auto-inject a sticky session ID for non-sticky rotating
        gateway proxies. Without this, every new TCP connection through a
        rotating gateway (NodeMaven, BrightData, IPRoyal, Smartproxy, Oxylabs)
        gets a DIFFERENT backend IP — meaning the validation connection,
        preflight check, and actual visit could all use different IPs.
        This breaks the fundamental "same IP for entire device runtime" rule.
        
        Solution: if the proxy is a gateway WITHOUT a session ID, auto-append
        a unique session ID to the username so ALL connections within this
        visit (validation → preflight → target page → multi-page nav) use the
        SAME backend residential/mobile IP.
        
        Supported provider patterns:
        - NodeMaven: username-sid-XXXXX
        - Bright Data: username-session-XXXXX
        - IPRoyal: username-session-XXXXX
        - Smartproxy: username-session-XXXXX
        - Oxylabs: user-session-XXXXX
        
        We use '-sid-{uuid8}' format which is the most widely supported.
        If the provider doesn't recognize it, it's silently ignored by the
        gateway and rotation still works (just not sticky — same as before).
        """
        if not proxy:
            return proxy
        if not proxy.get("is_gateway"):
            return proxy
        if proxy.get("sticky_session"):
            return proxy  # Already has a session ID — all good
        
        user = proxy.get("username") or ""
        if not user:
            return proxy  # No username to modify (IP auth proxy)
        
        # Generate a unique session ID for this visit
        import uuid as _uuid
        session_tag = f"-sid-{_uuid.uuid4().hex[:8]}"
        
        # Create a modified copy of the proxy with sticky session
        sticky_proxy = dict(proxy)
        sticky_proxy["username"] = user + session_tag
        sticky_proxy["sticky_session"] = True
        sticky_proxy["_auto_sticky"] = True
        sticky_proxy["server"] = proxy["server"]  # Keep same server
        
        display = proxy.get("display_ip", proxy["ip"])
        self.log(f"[PROXY] 🔒 Auto-sticky: {display} → session locked ({session_tag})")
        
        return sticky_proxy

    async def _attempt_visit(self, playwright, url, visit_num, lane_id=0, validation_result=None):
        """Single isolated visit attempt with REAL Chrome persistent profile.
        May raise _PreflightIPDead internally (caught here, surfaced as a
        VisitResult with a PREFLIGHT_IP_DEAD marker) if the real browser
        tunnel through this IP fails before the target URL is touched."""
        start_time = time.time()
        # v210 LIVE ENGAGEMENT: ONE duration pick per visit, sampled from the
        # user's min/max visit-time setting (e.g. 4-8s). The absolute deadline
        # starts at visit start, so page-load time counts inside the budget —
        # once the deadline passes the page closes wherever it is, and all
        # scroll/click/multipage action happens AFTER the target page loads.
        _vt_min = float(self.config.get("min_visit_time", 15))
        _vt_max = float(self.config.get("max_visit_time", 45))
        _vt_mean = (_vt_min + _vt_max) / 2
        _vt_std = max(0.5, (_vt_max - _vt_min) / 6)
        _visit_len = max(_vt_min, min(_vt_max, random.gauss(_vt_mean, _vt_std)))
        # v213.2 FIX (user report: "4-8s and 20-50s behave the same"):
        # the deadline clock used to start HERE — at attempt start — so
        # proxy validation + browser launch + Google prebrowse + landing
        # load + button click (easily 15-40s on RDP/mobile proxies) all
        # burned the user's visit-duration budget before the target page
        # even appeared. The clock is now anchored at the engagement block
        # below: min/max visit time = time ON the target page, exactly what
        # the dashboard setting promises.
        _visit_deadline = None
        _engagement_started_at = None
        self._current_lane_id = lane_id  # for _get_browser_args to pick up window position
        # v20.7: safe defaults so an early _StopRequested (which can fire
        # before the proxy is even picked) never hits a NameError when the
        # except block below references these names.
        proxy_ip = "unknown"
        proxy_country = None
        fingerprint = {}

        # ── Get proxy — SEQUENTIAL one-at-a-time validation (v10.0) ──
        # Pulls ONE IP, validates it live, and if it's bad discards it and
        # pulls the next one automatically — no more batch pre-validation.
        had_proxies_configured = bool(self.config.get("proxies"))
        proxy, proxy_country, ip_quality = await self._get_validated_proxy()
        # v11.0: store validation result for mobile proxy detection
        # _get_validated_proxy returns (proxy, country_code, quality) but
        # we need the full validation dict to check mobile flag. Reconstruct
        # what we need: if proxy has mobile markers, treat as mobile.
        _proxy_validation = {"mobile": self._is_mobile_proxy(proxy)} if proxy else None
        # v10.2: use display_ip (includes rotation marker for non-sid
        # gateway proxies) so the dashboard shows each visit's row as
        # visually distinct, instead of the same literal hostname string
        # repeated for every rotation.
        proxy_ip = proxy.get("display_ip", proxy["ip"]) if proxy else ("direct" if not had_proxies_configured else "none-available")

        if proxy is None and had_proxies_configured:
            # Proxies WERE configured but every remaining one failed
            # validation (pool exhausted) — fail this visit rather than
            # silently falling back to a direct (proxy-less) connection.
            self.log(f"[PROXY] ⛔ No valid proxies remaining in the pool — visit skipped")
            return VisitResult(url, False, proxy_ip, "N/A", time.time() - start_time, error="No valid proxies remaining in pool")

        # ── Generate fresh unique device fingerprint ──
        # v209: goes through the uniqueness registry — guaranteed no two
        # visits of this run ever present the same device identity.
        geo_hint = {"country": proxy_country} if proxy_country else None
        self.fingerprint_gen.proxy_geo = geo_hint
        fingerprint = self._generate_unique_fingerprint()

        parsed = urlparse(url)
        target_domain = parsed.netloc or parsed.hostname or ""

        dev_label = "Mobile" if fingerprint["is_mobile"] else "Desktop"
        device_name = fingerprint.get("device_model", fingerprint.get("browser_key", ""))
        # v13.3 — Tag IAB visits clearly in the log so the user can see which Meta app was used
        if fingerprint.get("is_fb_iab"):
            iab_marker = " [FB-IAB]"
        else:
            iab_marker = ""
        self.log(f"[DEVICE] 🖥 {device_name} ({dev_label}){iab_marker} | {fingerprint['screen']['width']}x{fingerprint['screen']['height']} | TZ: {fingerprint['timezone'][:15]}")
        # v11.0 — sanity check: warn loudly if the fingerprint's geo doesn't
        # match the proxy's confirmed country (catches any future gaps in
        # COUNTRY_GEO immediately instead of silently shipping mismatched
        # traffic, e.g. Swedish IP + American timezone).
        fp_country = fingerprint.get("geo_country")
        if proxy_country and fp_country:
            expected_entry = COUNTRY_GEO.get(proxy_country.upper())
            expected = expected_entry["country"] if expected_entry else None
            if expected and expected != fp_country:
                self.log(f"[GEO] ⚠ Mismatch — proxy confirmed {proxy_country} but fingerprint got {fp_country} (unexpected — please report)")
            elif not expected_entry:
                self.log(f"[GEO] ℹ Proxy country '{proxy_country}' not in COUNTRY_GEO table yet — used random geo fallback ({fp_country}). Tell the bot owner to add this country code.")

        is_mobile = fingerprint["is_mobile"]
        context = None
        temp_dir = None

        try:
            # ── Create fresh user data directory for this visit ──
            # This is a REAL browser profile (not incognito) — has proper
            # storage quota, file system access, no incognito detection.
            temp_dir = tempfile.mkdtemp(prefix="vb_v6_real_")

            # ── Headless / display detection ──
            # v1.84: Simplified — Xvfb auto-start removed. On Linux, just use
            # DISPLAY=:99 if set externally. On Windows, no Xvfb needed at all.
            headless_mode = self.config.get("headless", False)
            if not headless_mode and sys.platform.startswith("linux") and "DISPLAY" not in os.environ:
                os.environ["DISPLAY"] = ":99"
                self.log("[SYS] 🖼 Using DISPLAY=:99 (Xvfb)")

            # ── Build ALL options for launch_persistent_context ──
            # This combines browser launch args + context settings in one call.
            # The result is a real Chrome with a real profile — not incognito.
            ctx_options = self._build_context_options(fingerprint, temp_dir, headless_mode)

            if proxy:
                ctx_options["proxy"] = {
                    "server": proxy["server"],
                    "username": proxy.get("username"),
                    "password": proxy.get("password"),
                }

            # ── v13.7 RDP Visual Mode: Real Chrome/Edge Browser Launch ──
            # Priority order on Windows:
            # ── v5.1: Firefox gets its own REAL Gecko engine via playwright.firefox ──
            # Firefox ≠ Chromium. Different TLS/JA3, different JS engine (SpiderMonkey),
            # different window object (no window.chrome, no navigator.userAgentData).
            # Launching Firefox UA on Chromium = instant detection. So Firefox
            # fingerprints use playwright.firefox (real Gecko engine).
            is_firefox_fp = fingerprint.get("is_firefox", False)
            is_safari_fp = fingerprint.get("is_safari", False)
            real_browser_mode = self.config.get("real_browser_mode", False)
            is_windows = sys.platform.startswith("win")

            # v14.0: Firefox engine RE-ENABLED — real Gecko engine for authentic Firefox visits.
            # Fixed: context.close() hang solved with 10-second timeout + force cleanup.
            # Firefox on Gecko: real TLS/JA3, SpiderMonkey JS, no window.chrome = 100% authentic.
            is_firefox_fp = fingerprint.get("is_firefox", False)
            if is_firefox_fp:
                # ── FIREFOX LAUNCH PATH (real Gecko engine) ──
                self.log("[SYS] 🦊 Launching Firefox (Gecko engine) for authentic fingerprint")
                headless_mode = self.config.get("headless", False)
                if real_browser_mode and is_windows:
                    headless_mode = False
                    self.log("[RDP] 🖥️ Firefox Visual Mode — headed")

                # Firefox-specific options (NO Chromium flags!)
                ff_options = {
                    "headless": headless_mode,
                    "viewport": ctx_options.get("viewport", {"width": 1920, "height": 1080}),
                    "user_agent": fingerprint.get("user_agent", ""),
                    "locale": fingerprint.get("locale", "en-US"),
                    "timezone_id": fingerprint.get("timezone", "America/New_York"),
                    "ignore_https_errors": True,
                    "java_script_enabled": True,
                }
                if proxy:
                    ff_options["proxy"] = {
                        "server": proxy["server"],
                        "username": proxy.get("username"),
                        "password": proxy.get("password"),
                    }

                try:
                    try:
                        context = await asyncio.wait_for(
                            playwright.firefox.launch_persistent_context(temp_dir, **ff_options),
                            timeout=30
                        )
                        launched_channel = "firefox-gecko"
                    except asyncio.TimeoutError:
                        self.log("[SYS] ⚠ Firefox launch timeout — falling back to Chromium")
                        raise Exception("Firefox launch timeout")
                    self.log(f"[SYS] 🌐 Browser launched: firefox-gecko | headed={not headless_mode}")
                except Exception as e:
                    self.log(f"[SYS] ⚠ Firefox launch failed: {str(e)[:80]}")
                    self.log("[SYS] ⚠ Falling back to Chromium (switching to Chrome fingerprint)")
                    # Fallback: override Firefox fingerprint to Chrome
                    is_firefox_fp = False
                    fingerprint["is_firefox"] = False
                    # v14.0: Clean up any partial Firefox context
                    try:
                        if 'context' in dir() and context:
                            await asyncio.wait_for(context.close(), timeout=5)
                    except Exception:
                        pass
                    # v5.3.1 FIX: Use REAL Chrome version from fingerprint module (not hardcoded 131)
                    try:
                        from fingerprint import _gen_chrome_major
                        _ff_major = _gen_chrome_major()
                    except Exception:
                        _ff_major = 150
                    fingerprint["user_agent"] = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{_ff_major}.0.0.0 Safari/537.36"
                    fingerprint["chrome_full_version"] = f"{_ff_major}.0.0.0"
                    context = None
                    # FIX v1.81: Create fresh temp_dir for Chromium (Firefox may have left lock files)
                    import shutil as _sh
                    _sh.rmtree(temp_dir, ignore_errors=True)
                    import tempfile as _tf
                    temp_dir = _tf.mkdtemp(prefix="vb_v6_real_")
                    self.log(f"[SYS] 📂 Fresh profile dir for Chromium fallback: {temp_dir[-20:]}")
                    launched_channel = None

            # v14.0: Safari/WebKit engine RE-ENABLED — real WebKit for authentic Safari/iPhone.
            # Real WebKit: proper TLS/JA3, JavaScriptCore JS, no window.chrome = 100% authentic.
            # iPhone visits now use real Safari engine instead of Chromium with Safari UA.
            is_safari_fp = fingerprint.get("is_safari", False)
            if is_safari_fp:
                # ── SAFARI / WEBKIT LAUNCH PATH (real WebKit engine) ──
                # Safari ≠ Chromium. Different TLS/JA3 fingerprint, different
                # JS engine (JavaScriptCore vs V8), no window.chrome by default,
                # no navigator.userAgentData. Launching Safari UA on Chromium =
                # instant detection (TLS mismatch + JS engine mismatch).
                # playwright.webkit uses the REAL WebKit engine — same TLS/JA3
                # as Safari, same JavaScriptCore JS engine, no window.chrome.
                self.log("[SYS] 🧭 Launching WebKit (Safari engine) for authentic fingerprint")
                _safari_headless = self.config.get("headless", False)
                if real_browser_mode and is_windows:
                    _safari_headless = False
                    self.log("[RDP] 🖥️ Safari Visual Mode — headed")

                # WebKit-specific options (NO Chromium flags!)
                _wk_options = {
                    "headless": _safari_headless,
                    "viewport": ctx_options.get("viewport", {"width": 1920, "height": 1080}),
                    "user_agent": fingerprint.get("user_agent", ""),
                    "locale": fingerprint.get("locale", "en-US"),
                    "timezone_id": fingerprint.get("timezone", "America/New_York"),
                    "ignore_https_errors": True,
                    "java_script_enabled": True,
                    "has_touch": fingerprint.get("touch_support", False),
                    "device_scale_factor": fingerprint.get("pixel_ratio", 1.0),
                    "is_mobile": fingerprint.get("is_mobile", False),
                }
                if proxy:
                    _wk_options["proxy"] = {
                        "server": proxy["server"],
                        "username": proxy.get("username"),
                        "password": proxy.get("password"),
                    }

                try:
                    try:
                        context = await asyncio.wait_for(
                            playwright.webkit.launch_persistent_context(temp_dir, **_wk_options),
                            timeout=30
                        )
                        launched_channel = "webkit-safari"
                    except asyncio.TimeoutError:
                        self.log("[SYS] ⚠ WebKit launch timeout — falling back to Chromium")
                        raise Exception("WebKit launch timeout")
                    self.log(f"[SYS] 🌐 Browser launched: webkit-safari | headed={not _safari_headless}")
                except Exception as e:
                    self.log(f"[SYS] ⚠ WebKit launch failed: {str(e)[:80]}")
                    self.log("[SYS] ⚠ Falling back to Chromium (switching to Chrome fingerprint)")
                    # v20.2 EVIDENCE-BASED FIX: the old fallback only
                    # overwrote user_agent + platform, leaving EVERY OTHER
                    # Safari/iPhone-specific field untouched — webgl vendor/
                    # renderer ("Apple GPU"/"Apple A17 Pro GPU"), screen size
                    # (393x852), hardware_concurrency, device_memory,
                    # max_touch_points, platform_version (iOS "17.5.0"), all
                    # still claiming an iPhone while the UA now says Android/
                    # Windows Chrome. That mismatch is a textbook fingerprint-
                    # spoofing tell — exactly what a server-side fraud gate
                    # cross-checks (UA vs WebGL vs hardware_concurrency vs
                    # touch support) and is a real contributor to "Access
                    # Denied" results. This now generates a COMPLETELY FRESH,
                    # internally-consistent Android or Windows fingerprint
                    # (same proxy geo -> same timezone/locale, no mismatch)
                    # instead of patching only 2 of ~15 device-identity fields.
                    is_safari_fp = False
                    # v14.0: Clean up any partial WebKit context
                    try:
                        if 'context' in dir() and context:
                            await asyncio.wait_for(context.close(), timeout=5)
                    except Exception:
                        pass
                    try:
                        import uuid as _uuid, hashlib as _hashlib
                        _fb_session_id = str(_uuid.uuid4())
                        _fb_seed = int(_hashlib.md5(_fb_session_id.encode()).hexdigest()[:8], 16)
                        if fingerprint.get("is_mobile", False):
                            # Mobile fallback: fresh, fully-consistent Android
                            # Chrome fingerprint (force_android=True — never
                            # re-rolls back into iOS Safari).
                            fingerprint = self.fingerprint_gen._gen_mobile(
                                _fb_session_id, _fb_seed, force_android=True)
                        else:
                            # Desktop fallback: fresh Windows/Chrome/Edge/
                            # Firefox fingerprint (desktop pool has no Safari
                            # since v16.1, so this can never re-pick Safari).
                            fingerprint = self.fingerprint_gen._gen_desktop(_fb_session_id, _fb_seed)
                        # v209: this mid-visit emergency regen also goes
                        # through the uniqueness registry (retry a few times
                        # so the replacement device is also fresh for this run).
                        for _ufb_try in range(6):
                            if self._register_fp_signature(fingerprint):
                                break
                            if fingerprint.get("is_mobile", False):
                                fingerprint = self.fingerprint_gen._gen_mobile(
                                    _fb_session_id, _fb_seed, force_android=True)
                            else:
                                fingerprint = self.fingerprint_gen._gen_desktop(_fb_session_id, _fb_seed)
                        # ctx_options was built earlier from the OLD Safari
                        # fingerprint (viewport/UA/args all iPhone-shaped) —
                        # rebuild it now from the fresh fingerprint so the
                        # Chromium launch below actually gets a consistent
                        # Android/Windows profile, not a stale Safari shell.
                        ctx_options = self._build_context_options(fingerprint, temp_dir, headless_mode)
                        if proxy:
                            ctx_options["proxy"] = {
                                "server": proxy["server"],
                                "username": proxy.get("username"),
                                "password": proxy.get("password"),
                            }
                    except Exception as _fb_regen_err:
                        # Extremely defensive last-resort fallback if the
                        # fingerprint module import/regen itself fails for
                        # any reason — keeps the visit alive rather than
                        # crashing, same minimal UA as before.
                        self.log(f"[SYS] ⚠ Fresh fallback fingerprint regen failed ({str(_fb_regen_err)[:60]}) — using minimal UA")
                        try:
                            from fingerprint import _gen_chrome_major
                            _safari_chrome_major = _gen_chrome_major()
                        except Exception:
                            _safari_chrome_major = 150
                        if fingerprint.get("is_mobile", False):
                            fingerprint["user_agent"] = f"Mozilla/5.0 (Linux; Android 13; SM-A145F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{_safari_chrome_major}.0.0.0 Mobile Safari/537.36"
                            fingerprint["platform"] = "Linux armv8l"
                        else:
                            fingerprint["user_agent"] = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{_safari_chrome_full} Safari/537.36"
                            fingerprint["platform"] = "Win32"
                        fingerprint["is_safari"] = False
                    context = None
                    launched_channel = None

            if not is_firefox_fp and not is_safari_fp:
                # ── CHROMIUM LAUNCH PATH (Chrome / Edge / Samsung Internet) ──
                if real_browser_mode and is_windows:
                    headless_mode = False
                    ctx_options["headless"] = False
                    ctx_options["args"] = self._get_browser_args(fingerprint, temp_dir, False, lane_id=self._current_lane_id)
                    channel_priority = ["chrome", "msedge", None]
                    self.log("[RDP] 🖥️ Visual Mode — Real Chrome/Edge, headed")
                elif is_windows:
                    preferred_channel = fingerprint.get("playwright_channel", "chrome")
                    is_edge_fp = fingerprint.get("is_edge", False)
                    if is_edge_fp:
                        channel_priority = ["msedge", "chrome", None]
                    else:
                        channel_priority = [preferred_channel, "chrome", "msedge", None]
                else:
                    preferred_channel = fingerprint.get("playwright_channel", None)
                    channel_priority = [preferred_channel] if preferred_channel else [None]

                context = None
                launch_errors = []
                launched_channel = None

                # Diagnostic: check what browsers are available
                import shutil as _sh
                _browsers_found = []
                if sys.platform.startswith("win"):
                    for _name, _exe in [("Chrome", "chrome.exe"), ("Edge", "msedge.exe")]:
                        _paths = [
                            os.path.join(os.environ.get("PROGRAMFILES", ""), "Google", _name, "Application", _exe),
                            os.path.join(os.environ.get("PROGRAMFILES(X86)", ""), "Google", _name, "Application", _exe),
                            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Google", _name, "Application", _exe),
                        ] if _name == "Chrome" else [
                            os.path.join(os.environ.get("PROGRAMFILES(X86)", ""), "Microsoft", _name, "Application", _exe),
                            os.path.join(os.environ.get("PROGRAMFILES", ""), "Microsoft", _name, "Application", _exe),
                        ]
                        for _p in _paths:
                            if os.path.isfile(_p):
                                _browsers_found.append(f"{_name}: {_p}")
                                break
                else:
                    for _name in ["google-chrome", "google-chrome-stable", "microsoft-edge", "chromium-browser", "chromium"]:
                        _p = _sh.which(_name)
                        if _p:
                            _browsers_found.append(f"{_name}: {_p}")

                if _browsers_found:
                    self.log(f"[SYS] 📋 Browsers found: {'; '.join(_browsers_found)}")
                else:
                    self.log("[SYS] ⚠ No system browsers found! Install Chrome or run: python -m playwright install chromium")

                for attempt_channel in channel_priority:
                    try:
                        if attempt_channel:
                            ctx_options["channel"] = attempt_channel
                        else:
                            ctx_options.pop("channel", None)

                        # v1.84 FIX: Always use launch_persistent_context (like the old working version).
                        # The v1.82 launch()+new_context() approach caused browser to not
                        # open on some Windows setups. launch_persistent_context is the
                        # proven method — it opens the real browser with the profile dir.
                        context = await playwright.chromium.launch_persistent_context(temp_dir, **ctx_options)
                        launched_channel = attempt_channel or "playwright-chromium"
                        break
                    except Exception as e:
                        err_str = str(e)
                        if "Executable doesn't exist" in err_str or "Could not find" in err_str or "not installed" in err_str.lower():
                            self.log(f"[SYS] ⚠ Channel '{attempt_channel}' not installed — trying next...")
                        else:
                            # v212: ALWAYS keep the real error — the generic
                            # "Chrome not found" message below used to fire
                            # even when Chrome WAS found but crashed on launch
                            # (e.g. "Connection closed while reading from the
                            # pipe"), which hid the actual cause.
                            launch_errors.append(f"[{attempt_channel or 'default'}] {err_str[:140]}")
                        continue

                if context and launched_channel:
                    self.log(f"[SYS] 🌐 Browser launched: {launched_channel} | headed={not ctx_options.get('headless', False)}" + (" | 🛡 Patchright CDP-hardened" if _PATCHRIGHT_ACTIVE else " | ⚠ vanilla Playwright (CDP leak risk — pip install patchright)"))

                # Fallback to headless if headed launch failed
                if context is None and not headless_mode:
                    # v212: distinguish "genuinely missing" vs "found but
                    # crashed on launch" — these need completely different
                    # fixes (installing Chrome does nothing for a crash).
                    _pipe_crash = any("pipe" in e.lower() or "connection closed" in e.lower() for e in launch_errors)
                    if sys.platform.startswith("win"):
                        if _pipe_crash and _browsers_found:
                            self.log("[SYS] ⚠ Chrome/Edge WAS found but the process crashed immediately on launch (pipe closed) — this is NOT a missing-Chrome issue")
                            self.log("[SYS] ⚠ Likely cause: no active interactive desktop session (RDP disconnected), or antivirus killing chrome.exe on spawn")
                        else:
                            self.log("[SYS] ⚠ Headed Chrome/Edge launch failed — Chrome not found or not installed")
                            self.log("[SYS] ⚠ Install Google Chrome: https://www.google.com/chrome/")
                            self.log("[SYS] ⚠ Or install Playwright browsers: python -m playwright install chromium")
                    else:
                        self.log("[SYS] ⚠ Headed launch failed — set DISPLAY env or install Xvfb")
                    self.log("[SYS] ⚠ Falling back to headless mode (ad networks may detect)")

                    # Log the actual errors for debugging
                    if launch_errors:
                        for err in launch_errors[-3:]:
                            self.log(f"[SYS] ⚠ Launch error: {err}")

                    ctx_options["headless"] = True
                    ctx_options["args"] = self._get_browser_args(fingerprint, temp_dir, True, lane_id=self._current_lane_id)
                    # On Windows, still try chrome/msedge in headless mode
                    _fallback_channels = ["chrome", "msedge", None] if sys.platform.startswith("win") else [None]
                    for attempt_channel in _fallback_channels:
                        try:
                            if attempt_channel:
                                ctx_options["channel"] = attempt_channel
                            else:
                                ctx_options.pop("channel", None)
                            context = await playwright.chromium.launch_persistent_context(temp_dir, **ctx_options)
                            break
                        except Exception as e:
                            launch_errors.append(str(e))
                            continue

                # Last resort: auto-install Playwright Chromium if nothing else worked
                if context is None:
                    self.log("[SYS] ⚠ All browser channels failed. Trying to install Playwright Chromium...")
                    try:
                        import subprocess as _sp
                        _sp.run([sys.executable, "-m", "playwright", "install", "chromium"],
                                capture_output=True, timeout=120)
                        self.log("[SYS] 📦 Playwright Chromium installed — retrying launch...")
                        ctx_options.pop("channel", None)
                        ctx_options["headless"] = headless_mode if not (real_browser_mode and is_windows) else False
                        ctx_options["args"] = self._get_browser_args(fingerprint, temp_dir, ctx_options["headless"], lane_id=self._current_lane_id)
                        if not ctx_options["headless"] and sys.platform.startswith("win"):
                            _launch_args = ctx_options.pop("args", [])
                            _udd = f"--user-data-dir={temp_dir}"
                            if not any("--user-data-dir" in a for a in _launch_args):
                                _launch_args = [_udd] + _launch_args
                            _launch_opts = {k: v for k, v in ctx_options.items()
                                           if k in ("headless", "channel", "executable_path",
                                                    "slow_mo", "timeout", "devtools")}
                            _launch_opts["args"] = _launch_args
                            _browser_obj = await playwright.chromium.launch(**_launch_opts)
                            _ctx_opts_clean = {k: v for k, v in ctx_options.items()
                                              if k not in ("headless", "channel", "executable_path",
                                                           "slow_mo", "timeout", "devtools", "args")}
                            context = await _browser_obj.new_context(**_ctx_opts_clean)
                            context._s2c_browser = _browser_obj
                        else:
                            context = await playwright.chromium.launch_persistent_context(temp_dir, **ctx_options)
                        launched_channel = "playwright-chromium"
                        self.log("[SYS] 🌐 Browser launched: playwright-chromium (auto-installed)")
                    except Exception as e:
                        self.log(f"[SYS] ⚠ Playwright Chromium fallback also failed: {str(e)[:80]}")

                if context is None:
                    raise RuntimeError(f"Browser launch failed: {'; '.join(launch_errors[-3:])}")


            # ── Get the page (persistent context opens with one blank page) ──
            page = context.pages[0] if context.pages else await context.new_page()
            # v208 NATIVE ENGINE MODE: one CDP call here is ALL the request
            # shaping this visit will ever get — Chromium's own network stack
            # blocks the media patterns; every other request flows straight
            # to the network with no Python in the loop. This page object
            # (and any popup tabs, see the popup handler) keeps this block
            # for its whole life.
            if self.native_engine:
                _blk_ok = await self._apply_native_media_block(page)
                self.log("[BW] 🧠 Native Engine Mode ON — zero request interception" +
                         (" | media blocked at kernel level" if _blk_ok else " | full native load (no CDP on this engine)"))
            # v1.89: Popunder ads stay open naturally — no auto-close (user request)
            # Ad networks' popunders are part of natural browsing behavior

            # ── v20.2: popup/new-tab capture (see fix note above) ──
            # Registered ONCE for the whole visit (covers the smartlink chain
            # AND any later ad-click flow) so a window.open() landing is
            # never missed, no matter when it fires.
            _popup_pages = []
            def _on_new_page(_new_page):
                try:
                    _popup_pages.append(_new_page)
                    # v20.4 DIAGNOSTIC: this is the single most useful log
                    # line for the "blank page, no visible new tab" report —
                    # it proves definitively whether the browser context
                    # EVER created a second page object at all. If this line
                    # never appears in a run that still ends up on
                    # about:blank, the cause is NOT a hidden/background tab —
                    # it's a same-tab dead-end (anti-fraud soft block,
                    # proxy-side issue, or the smartlink chain genuinely
                    # breaking), and the popup-follow logic is not the fix.
                    self.log(f"[NAV] 🆕 New page/tab opened by the browser (url so far: {_new_page.url[:60] or 'not navigated yet'})")
                    # Apply the same light "target" resource blocking (video/
                    # audio/fonts blocked, JS+CSS+tracking intact) + FB IAB
                    # Sec-CH-UA stripping to the new tab too — without this,
                    # a popped-out landing tab would load with ZERO blocking
                    # rules (inconsistent fingerprint behavior vs the rest of
                    # the visit, and heavier bandwidth use).
                    if not self.native_engine:
                        asyncio.create_task(_setup_resource_blocking(
                            _new_page, target_domain, mode="target",
                            strip_chua=bool(fingerprint.get("is_fb_iab", False))))
                    else:
                        # v208: popup tabs in native mode get the same
                        # kernel-level media block, no interception.
                        asyncio.create_task(self._apply_native_media_block(_new_page))
                except Exception:
                    pass
            try:
                context.on("page", _on_new_page)
            except Exception:
                pass

            async def _follow_popup_if_blanked(cur_page, cur_url):
                """If cur_page went to about:blank/empty and a NEW tab/window
                opened on this context meanwhile, that new tab is the REAL
                landing (the original was deliberately abandoned). Switch
                tracking to the newest live popup page and bring it to front.
                Returns (page, url) — unchanged if no popup is waiting."""
                if cur_url not in ("about:blank", "", "chrome-error://chromewebdata", "about:neterror"):
                    return cur_page, cur_url
                # v20.4 DIAGNOSTIC: show exactly what we're checking —
                # how many secondary pages this context has ever opened,
                # and each one's current url. If _popup_pages is empty here,
                # no tab/window was ever opened for this visit at all.
                self.log(f"[NAV] 🔍 On about:blank — checking {len(_popup_pages)} tracked popup page(s) for the real landing...")
                for _pp in _popup_pages:
                    try:
                        self.log(f"[NAV]    ↳ popup candidate: closed={_pp.is_closed()} url={_pp.url[:70]}")
                    except Exception as _pp_err:
                        self.log(f"[NAV]    ↳ popup candidate: error reading state ({str(_pp_err)[:40]})")
                for _candidate in reversed(_popup_pages):
                    try:
                        if _candidate.is_closed() or _candidate == cur_page:
                            continue
                        _cand_url = _candidate.url
                        if _cand_url and _cand_url not in ("about:blank", "chrome-error://chromewebdata"):
                            try:
                                await _candidate.bring_to_front()
                            except Exception:
                                pass
                            return _candidate, _cand_url
                    except Exception:
                        continue
                return cur_page, cur_url

            # ── v16: NATIVE per-visit UA/Client-Hints override (CDP) ──
            # Now that v15 forces the REAL installed Chrome binary for every
            # visit, that one real binary would otherwise natively report
            # the SAME Chrome version on navigator.userAgentData + wire
            # Sec-CH-UA headers for every single visit (same engine on
            # disk), independent of whatever random Chrome version our
            # fingerprint picked for the UA string. Network.setUserAgentOverride
            # rewrites the browser's own internal UA-metadata state — not a
            # JS patch — so navigator.userAgentData and every Sec-CH-UA
            # header the real engine sends from here on genuinely agree
            # with THIS visit's randomized fingerprint, with no JS-patch
            # forensic trace. Only applies to the Chromium engine (Firefox/
            # Safari paths use their own real engines and never had this
            # false-consistency problem in the first place).
            # v16 FIX: FB IAB must stay with ZERO Client Hints (real Meta
            # WebView never sends Sec-CH-UA at all — that's exactly what
            # makes Adsterra/etc. fall through to UA-string parsing and see
            # the FB_IAB/FBAN token). Applying the native override here
            # would make the real Chrome engine start generating genuine
            # Sec-CH-UA headers on every request, undoing that fix.
            _is_chromium_engine = (not fingerprint.get("is_firefox", False)
                                   and not fingerprint.get("is_safari", False)
                                   and not fingerprint.get("is_fb_iab", False))
            if _is_chromium_engine:
                try:
                    _cdp = await context.new_cdp_session(page)
                    _ua_meta = self._build_native_ua_metadata(fingerprint)
                    await _cdp.send("Network.setUserAgentOverride", _ua_meta)
                    try:
                        await _cdp.detach()
                    except Exception:
                        pass
                except Exception as _ua_override_err:
                    self.log(f"[SYS] ⚠ Native UA override failed (non-fatal): {str(_ua_override_err)[:100]}")

            # ── Set extra HTTP headers (full Client Hints) ──
            # Kept as a pre-navigation safety net (same values as the native
            # override above, built from the exact same fingerprint fields)
            # — belt-and-suspenders in case the CDP call above raced with
            # the very first request on some slow connections.
            extra_headers = self._build_headers(fingerprint)
            if extra_headers:
                await context.set_extra_http_headers(extra_headers)

            # ── Apply playwright-stealth (Chromium ONLY — breaks Firefox/Safari/Webkit) ──
            # v14.0 said "also skip for FB IAB" in this comment but the actual
            # condition below never included is_fb_iab — a real bug (v17 fix):
            # the stealth lib was silently running on every FB IAB visit the
            # whole time, injecting generic "full Chrome" evasions (window.
            # chrome.runtime, plugin lists, etc.) that fight against the
            # deliberately stripped-down FB-IAB identity we build elsewhere.
            _skip_stealth_lib = (fingerprint.get("is_firefox", False) or
                                 fingerprint.get("is_safari", False) or
                                 fingerprint.get("is_fb_iab", False))
            if not _skip_stealth_lib:
                try:
                    if _stealth_async:
                        await _stealth_async(page)
                    elif _stealth_v2:
                        await _stealth_v2.apply_stealth_async(page)
                except Exception:
                    pass

            # ── Inject stealth init script via context (cleaner than CDP) ──
            # Pass the actual viewport height into fingerprint so the stealth
            # script's innerHeight override EXACTLY matches Playwright's viewport
            # (fixing the previous viewport/innerHeight mismatch leak).
            fp_for_stealth = dict(fingerprint)
            fp_for_stealth["viewport_height"] = ctx_options["viewport"]["height"]
            # NOTE: referer is built AFTER this point (line ~1244).
            # Pass None here — stealth script will be re-injected or referer
            # is set via goto(referer=...) / extra_http_headers later.
            # Using None avoids "cannot access local variable 'referer'" UnboundLocalError.
            # v1.89: Anti-DevTools-detection + debugger trap neutralizer
            # Many ad-network pages detect bots via:
            # 1. window.outerHeight - innerHeight > 160 → clear body → redirect
            # 2. setInterval(() => { debugger; }, 200) → pause execution
            # 3. window.outerWidth - innerWidth > 160 → clear body
            # This script neutralizes all 3 BEFORE page scripts run.
            _anti_devtools_js = """
            (function(){
                try {
                    // 1. Neutralize debugger trap — override setInterval to skip debugger
                    const _origSetInterval = window.setInterval;
                    window.setInterval = function(fn, delay, ...args) {
                        try {
                            const fnStr = (typeof fn === 'function') ? fn.toString() : String(fn);
                            // Skip any interval that contains 'debugger' statement
                            if (fnStr.includes('debugger')) {
                                return _origSetInterval(function(){}, delay, ...args);
                            }
                            // Skip DevTools dimension check intervals that clear body
                            if (fnStr.includes('innerHTML') && (fnStr.includes('outerWidth') || fnStr.includes('outerHeight'))) {
                                return _origSetInterval(function(){}, delay, ...args);
                            }
                        } catch(e) {}
                        return _origSetInterval(fn, delay, ...args);
                    };
                    // 2. Also neutralize the direct body clearing
                    const _origInnerHTML = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
                    let _bodyClearCount = 0;
                    Object.defineProperty(Element.prototype, 'innerHTML', {
                        set: function(val) {
                            // Block clearing body.innerHTML (anti-bot detection)
                            if (this === document.body && val === '' && _bodyClearCount < 3) {
                                _bodyClearCount++;
                                return; // silently block the clear
                            }
                            return _origInnerHTML.set.call(this, val);
                        },
                        get: function() { return _origInnerHTML.get.call(this); }
                    });
                } catch(e) {}
            })();
            """
            try:
                context.add_init_script(_anti_devtools_js)
            except Exception:
                pass

            stealth_script = build_stealth_init_script(fp_for_stealth, target_domain, referer_url=None)
            try:
                await context.add_init_script(stealth_script)
            except Exception:
                pass

            # ── v5.0 EXTRA: Additional anti-detection init scripts ──
            # These cover detection vectors that ad networks check in 2026
            # v5.1: Only apply to Chromium-based browsers (Firefox/Safari have different internals)
            if not fingerprint.get("is_firefox", False) and not fingerprint.get("is_safari", False):
                extra_stealth = """() => {
                // 1. Fix navigator.permissions.query for notifications
                // Real Chrome returns 'prompt' for notifications, not 'denied'
                if (navigator.permissions && navigator.permissions.query) {
                    const origQuery = navigator.permissions.query.bind(navigator.permissions);
                    navigator.permissions.query = (params) => {
                        if (params && params.name === 'notifications') {
                            return Promise.resolve({state: 'prompt', onchange: null});
                        }
                        return origQuery(params);
                    };
                }

                // 2. Fix navigator.plugins — real Chrome has 5 plugins
                // Headless/automated Chrome shows 0 plugins = instant detection
                if (navigator.plugins.length === 0) {
                    Object.defineProperty(navigator, 'plugins', {
                        get: () => {
                            const plugins = [
                                {name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format'},
                                {name: 'Chrome PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format'},
                                {name: 'Chromium PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format'},
                                {name: 'Microsoft Edge PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format'},
                                {name: 'WebKit built-in PDF', filename: 'internal-pdf-viewer', description: 'Portable Document Format'},
                            ];
                            const arr = plugins;
                            arr.length = plugins.length;
                            arr.item = (i) => plugins[i] || null;
                            arr.namedItem = (n) => plugins.find(p => p.name === n) || null;
                            arr.refresh = () => {};
                            return arr;
                        }
                    });
                }

                // 3. Fix navigator.mimeTypes
                if (navigator.mimeTypes && navigator.mimeTypes.length === 0) {
                    Object.defineProperty(navigator, 'mimeTypes', {
                        get: () => {
                            const mimes = [
                                {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format'},
                                {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format'},
                            ];
                            const arr = mimes;
                            arr.length = mimes.length;
                            arr.item = (i) => mimes[i] || null;
                            arr.namedItem = (n) => mimes.find(m => m.type === n) || null;
                            return arr;
                        }
                    });
                }

                // 4. Fix window.chrome object — ONLY for real Chrome/Edge fingerprints
                // v14.0 CRITICAL: Skip for FB IAB, Firefox, Safari — these browsers
                // do NOT have window.chrome. If we inject it, ad networks detect
                // Chrome APIs → classify as Chrome → FB IAB shows as "Others" not "Facebook"
                var _fp_is_fb_iab = /FBAN|FBAV|FB_IAB|Instagram/i.test(navigator.userAgent);
                var _fp_is_firefox = /Firefox\//.test(navigator.userAgent) && !/Seamonkey\//.test(navigator.userAgent);
                var _fp_is_safari = /Safari\//.test(navigator.userAgent) && !/Chrome\//.test(navigator.userAgent) && !/CriOS\//.test(navigator.userAgent);
                if (!_fp_is_fb_iab && !_fp_is_firefox && !_fp_is_safari && !window.chrome) {
                    window.chrome = {
                        runtime: {
                            onConnect: {addListener: () => {}},
                            onMessage: {addListener: () => {}},
                            connect: () => {},
                            sendMessage: () => {},
                            id: undefined,
                        },
                        csi: () => ({startE: Date.now(), onloadT: Date.now(), pageT: 0, tran: 15}),
                        loadTimes: () => ({
                            commitLoadTime: Date.now() / 1000,
                            connectionInfo: 'h2',
                            finishDocumentLoadTime: Date.now() / 1000,
                            finishLoadTime: Date.now() / 1000,
                            firstPaintAfterLoadTime: 0,
                            firstPaintTime: Date.now() / 1000,
                            navigationType: 'Other',
                            npnNegotiatedProtocol: 'h2',
                            requestTime: Date.now() / 1000 - 0.16,
                            startDnsTime: Date.now() / 1000 - 0.16,
                            startLoadTime: Date.now() / 1000,
                            wasAlternateProtocolAvailable: false,
                            wasFetchedViaSpdy: true,
                            wasNpnNegotiated: true,
                        }),
                    };
                }
                // v14.0: For FB IAB — ensure window.chrome is COMPLETELY absent
                if (_fp_is_fb_iab) {
                    try { delete window.chrome; } catch(e) {}
                    try { Object.defineProperty(window, 'chrome', {get: () => undefined, configurable: true}); } catch(e) {}
                }
                // v14.0: For Firefox — ensure no Chrome-specific APIs
                if (_fp_is_firefox) {
                    try { delete window.chrome; } catch(e) {}
                    try { if (navigator.userAgentData) { delete navigator.userAgentData; } } catch(e) {}
                    try { Object.defineProperty(navigator, 'userAgentData', {get: () => undefined, configurable: true}); } catch(e) {}
                }
                // v14.0: For Safari — ensure no Chrome-specific APIs
                if (_fp_is_safari) {
                    try { delete window.chrome; } catch(e) {}
                    try { if (navigator.userAgentData) { delete navigator.userAgentData; } catch(e) {}
                    try { Object.defineProperty(navigator, 'userAgentData', {get: () => undefined, configurable: true}); } catch(e) {}
                }

                // 5. Fix Notification.permission — real Chrome returns 'default' not 'denied'
                if ('Notification' in window && Notification.permission === 'denied') {
                    try {
                        Object.defineProperty(Notification, 'permission', {get: () => 'default'});
                    } catch(e) {}
                }

                // 6. Fix screen.availWidth/availHeight — headless shows 0
                if (screen.availWidth === 0 || screen.availHeight === 0) {
                    Object.defineProperty(screen, 'availWidth', {get: () => screen.width});
                    Object.defineProperty(screen, 'availHeight', {get: () => Math.round(screen.height * 0.92)});
                }

                // 7. Fix window.outerWidth/outerHeight — headless shows 0
                if (window.outerWidth === 0 || window.outerHeight === 0) {
                    Object.defineProperty(window, 'outerWidth', {get: () => window.innerWidth});
                    Object.defineProperty(window, 'outerHeight', {get: () => window.innerHeight + 88});
                }

                // 8. Prevent CDP detection — remove debug-related properties
                // Some anti-bot scripts check for window.cdc_ADOUE or similar
                try {
                    const props = Object.getOwnPropertyNames(window).filter(p => p.startsWith('cdc_') || p.startsWith('cdc'));
                    props.forEach(p => { try { delete window[p]; } catch(e) {} });
                } catch(e) {}

                // 9. Fix SpeechSynthesis — real Chrome has voices
                // Headless Chrome has empty voices array
                if (window.speechSynthesis && window.speechSynthesis.getVoices().length === 0) {
                    try {
                        const fakeVoices = [
                            {name: 'Google US English', lang: 'en-US', voiceURI: 'Google US English', localService: false, default: true},
                            {name: 'Google UK English Male', lang: 'en-GB', voiceURI: 'Google UK English Male', localService: false, default: false},
                        ];
                        Object.defineProperty(window.speechSynthesis, 'getVoices', {get: () => () => fakeVoices});
                    } catch(e) {}
                }
            }"""
                try:
                    await context.add_init_script(extra_stealth)
                except Exception:
                    pass

            # ── v10.1 WebRTC: ICE candidate spoofing (Option C) ──
            # PREVIOUS approach (v10.0) was WRONG — it cleared iceServers=[]
            # and forced iceTransportPolicy:'relay'. Both are massive red
            # flags: real devices NEVER have empty ICE servers, and relay-
            # only policy is an explicit "I'm on a VPN" signal that ad
            # networks specifically check for.
            #
            # CORRECT approach (Option C): keep everything looking 100%
            # normal — RTCPeerConnection exists, iceTransportPolicy stays
            # 'all' (default), real STUN servers stay, onicecandidate fires
            # normally. We ONLY intercept the ICE candidate strings and
            # replace the IP address inside them with the proxy IP. So:
            #   - host candidates: local IP → proxy IP
            #   - srflx candidates: public IP → proxy IP
            #   - relay candidates: already show proxy/TURN IP (untouched)
            # WebRTC leak test sites see the proxy IP. No VPN flag. 100%
            # indistinguishable from a real device on that proxy IP.
            # ── WebRTC proxy IP for ICE candidate spoofing ──
            # For DIRECT ip:port proxies, proxy["ip"] is a real IPv4 — perfect.
            # For GATEWAY proxies (NodeMaven etc.), proxy["ip"] is a HOSTNAME
            # (gate.nodemaven.com), NOT an IP. Putting a hostname into an ICE
            # candidate string is invalid and instantly detectable. So for
            # gateway proxies we generate a plausible residential IPv4 from
            # common residential ISP ranges (not datacenter ranges like
            # 10.x.x.x or 192.168.x.x which would also look wrong).
            import re as _re_ip
            # ── v11.1: GEO-CONSISTENT plausible residential IP ──
            # The old version picked from a hardcoded set of US-only
            # residential ISP ranges regardless of the proxy's actual
            # confirmed country. That's a real mismatch leak: if the exit
            # IP geolocates to, say, Bangladesh or Germany, but the WebRTC
            # ICE candidate looks like a US Comcast/AT&T range, an anti-fraud
            # check that cross-references "HTTP exit country" vs "WebRTC
            # candidate country" would flag it as a spoofed/VPN connection.
            # Now we pick a first-octet range that plausibly belongs to the
            # SAME country/region as the confirmed proxy_country, falling
            # back to the generic pool only when the country is unknown or
            # not in the map.
            _RESIDENTIAL_RANGES_BY_COUNTRY = {
                # ── North America ──
                "US": [24, 47, 63, 65, 66, 67, 68, 71, 72, 73, 74, 75, 76, 96, 97, 98, 99, 100, 104, 108],
                "CA": [24, 47, 65, 70, 99, 142, 174, 184, 206],
                "PR": [24, 47, 66, 72, 73, 74, 75, 76, 96, 97, 98, 99, 100, 104, 108],
                # ── Western / Northern Europe ──
                "GB": [2, 5, 25, 31, 78, 79, 81, 82, 86, 87, 90, 92, 94],
                "UK": [2, 5, 25, 31, 78, 79, 81, 82, 86, 87, 90, 92, 94],
                "IE": [2, 5, 31, 37, 46, 78, 79, 81, 82, 83, 84, 86, 87, 88, 89, 90, 91, 92, 193, 194],
                "DE": [2, 5, 46, 78, 79, 84, 85, 87, 88, 91, 93, 95],
                "FR": [2, 5, 37, 46, 78, 79, 80, 81, 82, 83, 86, 88, 90, 91],
                "NL": [2, 5, 37, 46, 62, 77, 78, 80, 82, 83, 84, 85, 87],
                "BE": [2, 5, 37, 46, 62, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 193, 194, 195],
                "LU": [2, 5, 37, 46, 62, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 193, 194, 195],
                "CH": [2, 5, 31, 37, 46, 62, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 193, 194, 195],
                "AT": [2, 5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 193, 194, 195],
                "SE": [2, 5, 31, 37, 46, 62, 78, 79, 81, 82, 83, 84, 85, 88, 90, 91, 92, 94, 95],
                "NO": [2, 5, 31, 37, 46, 77, 78, 79, 80, 81, 84, 85, 88, 90, 91, 92, 94],
                "DK": [2, 5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 87, 88, 90, 91],
                "FI": [2, 5, 31, 37, 46, 62, 77, 78, 79, 80, 81, 82, 83, 84, 85, 87, 88, 91, 193, 194, 195],
                "IS": [5, 31, 37, 46, 78, 82, 85, 88, 89, 157, 193],
                # ── Southern Europe ──
                "ES": [2, 5, 37, 62, 79, 80, 81, 83, 84, 88, 95],
                "IT": [2, 5, 37, 62, 79, 80, 82, 83, 87, 89, 93, 95],
                "PT": [2, 5, 37, 62, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 193, 194, 195],
                "GR": [2, 5, 31, 37, 46, 62, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                "MT": [2, 5, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 93, 94, 95],
                "CY": [5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                # ── Central / Eastern Europe ──
                "PL": [5, 31, 37, 46, 77, 78, 79, 80, 83, 85, 86, 87, 88, 89, 91, 93, 94, 95, 176, 178, 185, 188, 193, 194, 213],
                "CZ": [2, 5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 193, 194, 195],
                "SK": [2, 5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                "HU": [2, 5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                "RO": [2, 5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 109, 141, 176, 178, 185, 188, 193, 194, 195],
                "BG": [2, 5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                "HR": [2, 5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                "RS": [2, 5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                "SI": [2, 5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                "LT": [5, 31, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 193, 194, 195],
                "LV": [5, 31, 46, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 193, 194, 195],
                "EE": [5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 90, 91, 193, 194, 195],
                "RU": [5, 31, 37, 46, 62, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 109, 141, 178, 185, 188, 193, 194, 195, 213, 217],
                "UA": [5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 109, 141, 176, 178, 185, 193, 194, 195],
                # ── Middle East / Caucasus / Central Asia ──
                "TR": [5, 31, 37, 45, 78, 81, 85, 88, 94, 95, 176, 178, 185, 188, 195, 212, 213],
                "AE": [5, 31, 37, 46, 77, 78, 80, 84, 86, 91, 94, 95, 176, 185, 188, 194],
                "SA": [5, 31, 37, 46, 77, 78, 80, 81, 84, 86, 91, 94, 95, 176, 178, 185, 188, 194, 212, 213],
                "IL": [5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 84, 85, 86, 87, 89, 91, 93, 94, 95, 109, 141, 178, 185, 188],
                "IQ": [5, 37, 46, 78, 80, 84, 86, 93, 94, 95, 176, 178, 185, 188],
                "KW": [5, 37, 46, 77, 78, 80, 81, 84, 86, 91, 94, 95, 176, 185, 188, 194, 212, 213],
                "QA": [5, 37, 46, 77, 78, 80, 81, 84, 86, 91, 94, 95, 176, 185, 188, 194],
                "JO": [5, 37, 46, 77, 78, 80, 81, 84, 86, 91, 94, 95, 176, 185, 188],
                "GE": [5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                "AM": [5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                "AZ": [5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                "KZ": [5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                "UZ": [5, 31, 37, 46, 77, 78, 79, 80, 81, 82, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95],
                # ── South Asia ──
                "IN": [1, 14, 27, 39, 42, 43, 45, 49, 59, 61, 101, 103, 106, 110, 111, 112, 113, 115, 117, 122, 123, 124, 125, 152, 157, 171, 175, 180, 182, 183, 202, 203, 210, 211, 220, 223],
                "BD": [1, 27, 36, 43, 45, 58, 103, 110, 113, 114, 115, 116, 118, 119, 123, 125, 175, 180, 182, 202, 203],
                "PK": [1, 14, 27, 39, 42, 43, 58, 59, 101, 103, 110, 111, 112, 115, 116, 117, 118, 119, 175, 182, 202, 203],
                "LK": [1, 14, 27, 42, 43, 58, 59, 101, 110, 112, 114, 115, 116, 175, 180, 202, 203],
                "NP": [1, 14, 27, 36, 42, 43, 49, 58, 59, 101, 103, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 175, 180, 182, 202, 203],
                # ── Southeast Asia ──
                "TH": [1, 14, 27, 42, 49, 58, 61, 101, 110, 113, 115, 118, 119, 124, 125, 171, 180, 182, 183, 203, 210, 223],
                "ID": [1, 27, 36, 39, 42, 43, 49, 58, 101, 103, 110, 111, 112, 114, 115, 118, 119, 121, 125, 139, 175, 180, 182, 202, 203],
                "PH": [1, 27, 36, 42, 49, 58, 101, 110, 112, 113, 114, 118, 119, 120, 121, 122, 124, 175, 180, 182, 203, 210],
                "SG": [1, 8, 27, 42, 43, 58, 59, 101, 103, 110, 111, 116, 118, 119, 121, 122, 124, 175, 180, 202, 203],
                "MY": [1, 14, 27, 42, 43, 58, 59, 101, 103, 110, 111, 113, 115, 116, 118, 119, 122, 124, 175, 180, 182, 202, 203],
                "VN": [1, 14, 27, 42, 43, 58, 59, 101, 103, 110, 111, 113, 115, 116, 118, 119, 123, 125, 171, 175, 180, 182, 203],
                "MM": [1, 14, 27, 36, 42, 43, 58, 59, 101, 103, 110, 112, 113, 114, 115, 116, 118, 119, 175, 180, 182, 203],
                "KH": [1, 14, 27, 36, 42, 43, 58, 59, 101, 103, 110, 112, 113, 114, 115, 116, 118, 119, 175, 180, 182, 203],
                "LA": [1, 14, 27, 36, 42, 43, 58, 59, 101, 103, 110, 112, 113, 114, 115, 116, 118, 119, 175, 180, 182, 203],
                "MN": [1, 14, 27, 36, 42, 43, 58, 59, 101, 103, 110, 112, 113, 114, 115, 116, 118, 119, 175, 180, 202, 203],
                # ── East Asia ──
                "JP": [1, 27, 36, 42, 43, 49, 58, 59, 60, 61, 101, 106, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 125, 126, 133, 150, 153, 157, 163, 175, 180, 182, 183, 202, 203, 210, 211, 218, 219, 220, 221, 222, 223],
                "KR": [1, 14, 27, 39, 42, 49, 58, 59, 61, 101, 103, 106, 110, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 125, 175, 180, 182, 183, 202, 203, 210, 211, 218, 219, 220, 221, 222, 223],
                "CN": [1, 14, 27, 36, 39, 42, 43, 49, 58, 59, 60, 61, 101, 103, 106, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 175, 180, 182, 183, 202, 203, 210, 211, 218, 219, 220, 221, 222, 223],
                "HK": [1, 14, 27, 42, 43, 58, 59, 101, 103, 110, 113, 115, 116, 118, 119, 175, 180, 202, 203, 210, 211, 218, 219, 220, 221, 222, 223],
                "TW": [1, 14, 27, 36, 42, 43, 58, 59, 60, 61, 101, 106, 110, 111, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 175, 180, 182, 183, 202, 203, 210, 211, 218, 219, 220, 221, 222, 223],
                # ── Africa ──
                "EG": [41, 102, 105, 154, 156, 160, 163, 195, 196, 197],
                "NG": [41, 62, 102, 105, 154, 196, 197],
                "ZA": [41, 62, 102, 105, 154, 160, 165, 168, 169, 196, 197],
                "KE": [41, 102, 105, 154, 160, 196, 197],
                "GH": [41, 102, 105, 154, 196, 197],
                "MA": [41, 102, 105, 154, 160, 196, 197],
                "TN": [41, 102, 105, 154, 160, 196, 197],
                "DZ": [41, 102, 105, 154, 160, 196, 197],
                # ── Oceania ──
                "AU": [1, 14, 27, 42, 43, 49, 58, 59, 60, 101, 103, 110, 111, 113, 114, 115, 118, 119, 120, 121, 122, 124, 125, 138, 144, 150, 175, 180, 202, 203, 210, 211],
                "NZ": [14, 27, 43, 49, 58, 101, 103, 110, 111, 118, 119, 120, 121, 122, 124, 125, 175, 180, 202, 203, 210, 211],
                # ── Latin America / Caribbean ──
                "BR": [17, 20, 45, 63, 131, 138, 143, 152, 168, 177, 179, 186, 187, 189, 191, 192, 200, 201],
                "MX": [45, 62, 66, 67, 132, 148, 187, 189, 190, 191, 200, 201, 216],
                "CO": [45, 66, 130, 152, 177, 181, 186, 190, 191, 200, 201],
                "CL": [45, 64, 152, 179, 181, 186, 190, 191, 200, 201],
                "AR": [45, 64, 131, 152, 179, 181, 186, 190, 191, 200, 201],
                "PE": [45, 64, 132, 152, 181, 186, 187, 190, 191, 200, 201],
                "VE": [45, 64, 131, 152, 179, 181, 186, 190, 191, 200, 201],
                "EC": [45, 64, 131, 152, 179, 181, 186, 190, 191, 200, 201],
                "BO": [45, 64, 131, 152, 179, 181, 186, 190, 191, 200, 201],
                "PY": [45, 64, 131, 152, 179, 181, 186, 190, 191, 200, 201],
                "UY": [45, 64, 131, 152, 179, 181, 186, 190, 191, 200, 201],
                "PA": [45, 64, 131, 152, 179, 181, 186, 187, 190, 191, 200, 201],
                "CR": [45, 64, 131, 152, 179, 181, 186, 187, 190, 191, 200, 201],
                "DO": [45, 63, 64, 131, 152, 179, 181, 186, 187, 190, 191, 200, 201],
                "CU": [45, 152, 179, 181, 186, 190, 191, 200, 201],
                "JM": [24, 66, 72, 74, 142, 173, 206],
            }
            def _gen_residential_ip(country_code=None):
                """Generate a plausible public residential IPv4, matching the
                confirmed exit country's typical residential ISP ranges when
                known — keeps the WebRTC candidate geo-consistent with the
                real proxy exit IP (avoids a country-mismatch red flag).
                v12.0: this is now ONLY a last-resort fallback — see the
                real exit-IP capture in the preflight step below, which
                tries to get the ACTUAL exit IP first (works for both free
                scraped proxies and paid residential gateways alike)."""
                pool = _RESIDENTIAL_RANGES_BY_COUNTRY.get((country_code or "").upper())
                if not pool:
                    # Unknown/unmapped country — fall back to the generic
                    # (mostly US/EU-leaning) pool rather than guessing wrong.
                    pool = _RESIDENTIAL_RANGES_BY_COUNTRY["US"]
                first = random.choice(pool)
                return f"{first}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"

            raw_proxy_ip = proxy["ip"] if proxy else "127.0.0.1"

            # ── v12.0: Real browser-level preflight + REAL exit-IP capture ──
            # Provider-agnostic — works IDENTICALLY whether "proxy" came from
            # the free scraper/harvester or a paid residential gateway
            # (NodeMaven, BrightData, IPRoyal, Smartproxy, etc). Nothing here
            # is hardcoded to any one provider; the behavior below emerges
            # naturally from real network conditions.
            #
            # We navigate the EXACT Chrome+proxy tunnel that will be used for
            # the real visit to a small set of IP-echo endpoints. A
            # successful load BOTH (a) confirms the tunnel is alive — same
            # job the old connectivity-only preflight did — AND (b) hands us
            # the tunnel's REAL, actual exit IP in the same request. Zero
            # extra round trips vs the old preflight, and far stronger than
            # the old "geo-matched IP guess" for gateway proxies whose
            # advertised IP is really just a hostname.
            #
            # If every echo endpoint is blocked (some proxies/networks
            # specifically block known IP-checker domains to stop leechers
            # probing them) we transparently fall back to the old plain
            # connectivity-only endpoints so a perfectly good proxy is never
            # wrongly discarded just because ipify-style domains happen to
            # be blocked on it. If we still can't capture a real IP, WebRTC
            # falls back to the geo-matched guess (old v10.4 behavior) —
            # always a valid value, never a raw hostname, never crashes.
            preflight_ok = False
            preflight_err_msg = ""
            real_exit_ip = None
            is_mobile_proxy = False  # FIX: define before conditional so later unconditional uses never crash

            if proxy:
                is_mobile_proxy = self._is_mobile_proxy(proxy, _proxy_validation)
                _nav_to, preflight_timeout, _retry_to = self._get_mobile_timeouts(is_mobile_proxy)
                if is_mobile_proxy:
                    self.log("[PROXY] 📱 Mobile proxy detected — using extended timeouts (90s nav, 25s preflight, 60s retry)")

                ip_echo_urls = [
                    "https://api.ipify.org",
                    "https://icanhazip.com",
                    "https://checkip.amazonaws.com",
                    "https://ifconfig.me/ip",
                ]
                for check_url in ip_echo_urls:
                    if not self.is_running:
                        raise _StopRequested("STOP_REQUESTED: during preflight (echo)")
                    try:
                        # v207.1: interruptible — this loop previously had
                        # NO is_running check at all; Stop could not abort
                        # a stuck preflight check (up to 4 URLs x 25s mobile
                        # timeout = 100s) before the main nav even started.
                        resp = await self._interruptible_goto(page, check_url, wait_until="domcontentloaded", timeout=preflight_timeout)
                        if resp and resp.status < 500:
                            preflight_ok = True
                            try:
                                body_text = (await page.inner_text("body")).strip()
                                ip_match = _re_ip.search(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b", body_text)
                                if ip_match:
                                    real_exit_ip = ip_match.group(1)
                                    break  # real IP captured — no need to try more endpoints
                            except Exception:
                                pass
                            # Loaded fine but no parseable IP in the body
                            # (odd/blocked response) — connectivity is still
                            # confirmed; keep trying remaining echo
                            # endpoints in case one of them gives a real IP.
                    except Exception as pf_err:
                        preflight_err_msg = str(pf_err)
                        continue

                if not preflight_ok:
                    # Echo endpoints unreachable entirely on this tunnel —
                    # fall back to plain connectivity-only endpoints before
                    # giving up on the proxy (old v10.4 endpoint list).
                    fallback_urls = [
                        "https://detectportal.firefox.com/canonical.html",
                        "https://www.gstatic.com/generate_204",
                        "https://connectivitycheck.gstatic.com/generate_204",
                        "https://www.apple.com/library/test/success.html",
                    ]
                    for check_url in fallback_urls:
                        if not self.is_running:
                            raise _StopRequested("STOP_REQUESTED: during preflight (fallback)")
                        try:
                            # v207.1: interruptible — same fix as the echo loop above.
                            resp = await self._interruptible_goto(page, check_url, wait_until="domcontentloaded", timeout=preflight_timeout)
                            if resp and resp.status < 500:
                                preflight_ok = True
                                break
                        except Exception as pf_err:
                            preflight_err_msg = str(pf_err)
                            continue

                if not preflight_ok:
                    self.log(f"[PROXY] ⚠ Pre-flight check FAILED — {_friendly_error(preflight_err_msg)} — discarding this IP BEFORE it ever touches the target link")
                    self.proxy_manager.mark_failed(proxy)
                    self.ip_callback(proxy, "failed", {"reason": "pre-flight connectivity check failed"})
                    raise _PreflightIPDead(f"PREFLIGHT_IP_DEAD: {proxy_ip} failed real browser connectivity check — {preflight_err_msg[:100]}")

                if real_exit_ip:
                    self.log(f"[PROXY] ✅ Pre-flight passed — {proxy_ip} tunnel confirmed alive | real exit IP captured: {real_exit_ip}")
                else:
                    self.log(f"[PROXY] ✅ Pre-flight passed — {proxy_ip} tunnel confirmed alive (echo endpoints blocked on this tunnel — using geo-matched fallback for WebRTC)")

                # Reset page to about:blank so there's no leftover content
                # from the preflight that could interfere with the target
                # navigation or leak a referrer to the smartlink.
                try:
                    await page.goto("about:blank", wait_until="domcontentloaded", timeout=3000)
                except Exception:
                    pass

            # ── Resolve final WebRTC IP: real captured IP > direct proxy IP > geo-matched guess ──
            if real_exit_ip:
                webrtc_proxy_ip = real_exit_ip
            elif _re_ip.match(r"^\d{1,3}(\.\d{1,3}){3}$", raw_proxy_ip):
                webrtc_proxy_ip = raw_proxy_ip  # Direct IP proxy — use real IP
            else:
                webrtc_proxy_ip = _gen_residential_ip(proxy_country)  # Gateway w/ no captured real IP — geo-matched guess
            # Also stash it for logging
            if proxy:
                proxy["_webrtc_ip"] = webrtc_proxy_ip
            try:
                await context.add_init_script("""
                    // ── WebRTC ICE candidate spoofing (Option C) ──
                    // Keep RTCPeerConnection 100% normal. Only intercept
                    // candidate strings and replace the IP with proxy IP.
                    (function() {
                        const PROXY_IP = "__PROXY_IP__";
                        const _RTC = window.RTCPeerConnection || window.webkitRTCPeerConnection;
                        if (!_RTC) return;

                        const _origRTC = _RTC;
                        const _patched = function(config) {
                            // DON'T touch iceServers or iceTransportPolicy —
                            // keep them exactly as the caller passed them
                            // (default 'all', real STUN servers). We only
                            // intercept the candidate output.
                            const pc = new _origRTC(config);

                            // Hook addEventListener for 'icecandidate'
                            const _origAddEL = pc.addEventListener.bind(pc);
                            pc.addEventListener = function(type, listener, opts) {
                                if (type === 'icecandidate' && listener) {
                                    const wrapped = function(event) {
                                        if (event && event.candidate && event.candidate.candidate) {
                                            event.candidate.candidate = event.candidate.candidate.replace(
                                                                /(\\d+\\.\\d+\\.\\d+\\.\\d+|[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{0,4}){2,7}(?::[0-9a-fA-F]{1,4})?)/g,
                                                                function(match, ip) {
                                                                    // Replace ALL IPv4 AND IPv6 addresses in the
                                                                    // candidate string with the proxy IP.
                                                                    // IPv4: host (local) + srflx (public) candidates
                                                                    // IPv6: host + srflx IPv6 candidates (LEAK FIX)
                                                                    // Relay candidates point to TURN server —
                                                                    // they use relay IPs we don't touch.
                                                                    return PROXY_IP;
                                                                }
                                                            );
                                        }
                                        return listener(event);
                                    };
                                    return _origAddEL(type, wrapped, opts);
                                }
                                return _origAddEL(type, listener, opts);
                            };

                            // Hook onicecandidate property setter
                            let _onIce = null;
                            Object.defineProperty(pc, 'onicecandidate', {
                                get: function() { return _onIce; },
                                set: function(fn) {
                                    _onIce = fn ? function(event) {
                                        if (event && event.candidate && event.candidate.candidate) {
                                            event.candidate.candidate = event.candidate.candidate.replace(
                                                                /(\\d+\\.\\d+\\.\\d+\\.\\d+|[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{0,4}){2,7}(?::[0-9a-fA-F]{1,4})?)/g,
                                                                function(match, ip) {
                                                                    return PROXY_IP;
                                                                }
                                                            );
                                        }
                                        return fn(event);
                                    } : fn;
                                },
                                configurable: true,
                            });

                            return pc;
                        };
                        _patched.prototype = _origRTC.prototype;
                        window.RTCPeerConnection = _patched;
                        if (window.webkitRTCPeerConnection) {
                            window.webkitRTCPeerConnection = _patched;
                        }
                    })();
                    // ── Remove automation markers ──
                    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
                    try { delete window.__playwright__script; } catch(e) {}
                    try { delete window.__pwInitScripts; } catch(e) {}
                """.replace("__PROXY_IP__", webrtc_proxy_ip))
            except Exception:
                pass

            # v14.0: FB IAB — CDP-level navigator.userAgentData removal
            # Meta's FB IAB strips this at the Chromium engine level, not just JS.
            # Using CDP to override the property at the V8 level.
            if fingerprint.get("is_fb_iab", False):
                try:
                    await page.evaluate("""() => {
                        // Aggressively remove ALL Chrome-specific APIs for FB IAB
                        try { delete navigator.userAgentData; } catch(e) {}
                        try { Object.defineProperty(navigator, 'userAgentData', {get: () => undefined, configurable: true}); } catch(e) {}
                        try { if (window.chrome) { delete window.chrome; } } catch(e) {}
                        try { Object.defineProperty(window, 'chrome', {get: () => undefined, configurable: true}); } catch(e) {}
                    }""")
                except Exception:
                    pass

            # v20.1 REMOVED: setting Sec-CH-UA to EMPTY STRING makes Chromium
            # send literal zero-length headers ("Sec-CH-UA: ") if any request
            # slips past the route stripper — a zero-length header value is
            # something NO real browser ever produces. Real FB IAB simply omits
            # these headers entirely, which the per-request route handler
            # (_setup_resource_blocking strip_chua) already guarantees.

            # ── v12.0: navigator.userAgentData Client Hints JS override ──
            # HTTP headers (Sec-CH-UA*) already match the spoofed device
            # (see _build_headers) but real Chromium's OWN JS-level
            # navigator.userAgentData object still reports the REAL server
            # OS/arch regardless of the spoofed HTTP headers — a well-known
            # signal some anti-bot scripts read directly (getHighEntropyValues
            # etc) bypassing HTTP headers entirely. This patches it to match
            # each device's own spoofed values. Every device profile is
            # different (Chrome version, OS, mobile/desktop, model), and this
            # is fully wrapped at both the Python and JS level so a malformed
            # or unusual fingerprint can NEVER crash or break the page load —
            # it just silently skips the override for that one device.
            try:
                client_hints_js = self._build_client_hints_js(fingerprint)
                if client_hints_js:
                    await context.add_init_script(client_hints_js)
            except Exception:
                pass

            # ── Pre-seed cookies (returning visitor illusion) ──
            await self._seed_storage(context, fingerprint, target_domain)


            # ── Pre-browse a search/social page before target (natural flow) ──
            # v10.4: increased to 60% (was 30%) — a real user almost always
            # has a search or social page open before clicking a smartlink.
            # This also gives the browser a real page history (not about:blank)
            # which makes the target navigation look more organic.
            if self.config.get("pre_browse_google", True) and random.random() < self.config.get("pre_browse_chance", 0.6):
                await self._pre_browse_google(page, nav_timeout=15000)

            # ── Set referer — authentic, unique-per-visit click-through ──
            # v10.4: default is now "random" (was "direct") — every visit
            # gets a fresh random source from the full pool (Google, Bing,
            # Facebook, Instagram, Twitter, Reddit, YouTube, TikTok, LinkedIn,
            # Referral), each with unique tokens/hashes/post-ids.
            # v13.3 — When FB IAB device type is active, force the matching
            # referer source so UA and Referer header are always consistent
            # (e.g. fb_iab_instagram device → l.instagram.com referer, not FB shim).
            raw_traffic_source = self.config.get("traffic_source", "random")
            device_type_cfg = self.config.get("device_type", "random")
            # v13.4 — Facebook Browser ALWAYS gets facebook referer, no matter
            # what traffic source / custom mix the user selected. This covers both:
            #   a) device_type="facebook_browser" (explicit FB mode)
            #   b) device_type="random" and this visit happened to pick FB Browser
            #      from the 3-way weighted roll (fingerprint.is_fb_iab will be True)
            if device_type_cfg == "facebook_browser" or fingerprint.get("is_fb_iab"):
                # v20.3 FIX: this used to ALWAYS force "social_facebook"
                # (organic), silently throwing away an explicit
                # "paid_facebook_ads" selection — a user who deliberately
                # picked paid FB ads traffic would get organic referers on
                # every FB IAB visit instead, without any indication the
                # system had overridden their choice. Now it only forces a
                # facebook-flavored source for UA/Referer consistency (an
                # FB-embedded browser can't show a Google/TikTok referer —
                # that mismatch alone is a detection flag) while RESPECTING
                # which flavor (organic vs paid) was actually selected.
                if raw_traffic_source == "paid_facebook_ads":
                    effective_traffic_source = "paid_facebook_ads"
                elif raw_traffic_source == "custom_mix":
                    _fb_allowed = [s for s in (self.config.get("custom_traffic_sources") or [])
                                   if s in ("social_facebook", "paid_facebook_ads")]
                    effective_traffic_source = random.choice(_fb_allowed) if _fb_allowed else "social_facebook"
                else:
                    # "social_facebook" explicitly, "random", or any other
                    # non-facebook source → organic facebook (the common
                    # real-world default for an FB in-app-browser visit).
                    effective_traffic_source = "social_facebook"
            else:
                effective_traffic_source = raw_traffic_source
            _campaign_cfg = getattr(self, 'campaign_config', None)
            # v13.7.2: Pass is_mobile flag to FB Ads referer builder for authentic fbclid format
            if _campaign_cfg is None:
                _campaign_cfg = {}
            _campaign_cfg["is_mobile"] = bool(fingerprint.get("is_mobile", False)) if fingerprint else False
            # Pass campaign config through get_referer → _ref_facebook_ads
            _is_mobile = bool(fingerprint.get("is_mobile", False)) if fingerprint else False
            referer, referer_source, tagged_url = FingerprintGenerator.get_referer(
                effective_traffic_source, url,
                allowed_sources=self.config.get("custom_traffic_sources"),
                keywords=self.config.get("seo_keywords") if self.config.get("keyword_system_enabled") else None,
                campaign_config=_campaign_cfg,
                is_mobile=_is_mobile
            )
            # v13.7.1: For paid ads, navigate to the UTM-tagged URL (UTM in address bar → GA sees paid)
            # For organic/social, tagged_url is None → navigate to the plain URL
            nav_url = tagged_url if tagged_url else url
            # v13.7.7 — FB IAB mibextid: append to nav_url for authentic address bar
            # Real Facebook mobile app clicks always have mibextid in the destination URL
            _fb_mibextid = fingerprint.get("fb_mibextid", "") if fingerprint else ""
            if _fb_mibextid and fingerprint and fingerprint.get("is_fb_iab"):
                _mib_sep = "&" if "?" in nav_url else "?"
                if "mibextid=" not in nav_url:  # avoid double-append
                    nav_url = f"{nav_url}{_mib_sep}mibextid={_fb_mibextid}"
                    self.log(f"[REF] 📱 FB IAB mibextid={_fb_mibextid} appended to nav_url")
            if referer:
                self.log(f"[REF] 🔗 Referer: {referer_source} — {referer[:70]}")
            if tagged_url:
                # v20.3 LOG FIX: tagged_url being non-None does NOT mean this
                # was paid traffic — organic Facebook l.php/lm.facebook.com
                # referers ALSO return a tagged destination URL (with a real
                # fbclid attached, exactly like authentic organic FB clicks
                # do in real life). Only sources whose key actually starts
                # with "paid_" (paid_facebook_ads / paid_google_ads /
                # paid_tiktok_ads) are genuinely paid-ads traffic with UTM/
                # gclid/ttclid params. The old log unconditionally printed
                # "Paid ads" here, which made 100% organic FB visits (with a
                # perfectly normal fbclid) look like misrouted paid traffic —
                # the traffic_source selection itself was always correct,
                # only this log line was mislabeling it.
                if referer_source.startswith("paid_"):
                    self.log(f"[REF] 📊 Paid ads — navigating to tagged URL (UTM/click-id in address bar): ...{tagged_url[-80:]}")
                else:
                    self.log(f"[REF] 🔗 Organic ({referer_source}) — destination has authentic tracking param (fbclid etc.): ...{tagged_url[-80:]}")

            # v13.7.9 — Inject document.referrer override AFTER referer is known
            # (stealth script was built with referer_url=None because referer
            # wasn't assigned yet at that point). This patch ensures
            # document.referrer matches the HTTP Referer header.
            if referer:
                import json as _json_ref
                _ref_escaped = _json_ref.dumps(referer)
                _ref_override_js = (
                    "try{Object.defineProperty(document,'referrer',"
                    "{get:function(){return " + _ref_escaped + ";},configurable:true});"
                    "}catch(e){}"
                )
                try:
                    await context.add_init_script(_ref_override_js)
                except Exception:
                    pass

            # ── v13.6: Switch resource blocking from prebrowse→target mode ──
            # Remove heavy prebrowse blocking, apply light target blocking.
            # Target page gets: JS ✅ CSS ✅ XHR/fetch ✅ tracking pixels ✅
            # Blocked on target: video/audio streams ❌ font files ❌
            # v208: in Native Engine Mode there is nothing to switch —
            # no route handler was ever installed; the kernel-level media
            # block (applied at page creation) carries over to the target
            # navigation unchanged. AdsPower-style: zero interference.
            if not self.native_engine:
                await _remove_resource_blocking(page)
                # v1.89: No window.open block — ads work naturally (user request)
                await _setup_resource_blocking(page, target_domain, mode="target",
                                              strip_chua=bool(fingerprint.get("is_fb_iab", False)))
            else:
                self.log("[BW] 🧠 Native Engine — target navigation runs with zero interception (media block stays at kernel level)")
            self.log("[BW] 🔀 Resource mode: target (video/audio/fonts blocked, JS+CSS+tracking intact)")

            # ── v10.5: Landing Page + Button Click Mode ──
            visit_mode = self.config.get("visit_mode", "direct")
            landing_url = self.config.get("landing_url", "")
            redirect_count = 0
            final_url = url
            nav_timeout = self.config.get("nav_timeout_ms", 60000)
            last_nav_error = None

            if visit_mode in ("button_click", "fb_embed") and landing_url:
                # ═══ LANDING PAGE + BUTTON CLICK MODE ═══
                self.log(f"[NAV] 🌐 Opening landing page: {landing_url[:60]}...")
                landing_goto = {"wait_until": "domcontentloaded", "timeout": nav_timeout}
                if referer:
                    landing_goto["referer"] = referer
                await page.goto(landing_url, **landing_goto)
                try:
                    _l_ni = 25000 if is_mobile_proxy else 12000
                    _l_load = 15000 if is_mobile_proxy else 8000
                    await page.wait_for_load_state("networkidle", timeout=_l_ni)
                except Exception:
                    try:
                        await page.wait_for_load_state("load", timeout=_l_load)
                    except Exception:
                        pass
                self.log(f"[PAGE] ✅ Landing page loaded — {page.url[:70]}")

                # Pre-click wait (simulate reading)
                pw_min = self.config.get("pre_click_wait_min", 2)
                pw_max = self.config.get("pre_click_wait_max", 5)
                pw = max(pw_min, min(pw_max, random.gauss((pw_min+pw_max)/2, (pw_max-pw_min)/4)))  # v13.7.4 Gaussian
                self.log(f"[HUMAN] ⏳ Waiting {pw:.1f}s before clicking...")
                await asyncio.sleep(pw)
                try:
                    await page.mouse.wheel(0, random.randint(200, 400))
                    await asyncio.sleep(max(0.2, min(1.2, random.gauss(0.5, 0.15))))  # v13.7.4 Gaussian
                except Exception:
                    pass

                # Find and click button/embed
                clicked = await self._find_and_click_target(page, visit_mode)
                if clicked:
                    self.log("[NAV] ↪ Button clicked — following redirect to target...")
                    _click_to = 30000 if is_mobile_proxy else 15000
                    try:
                        await page.wait_for_load_state("domcontentloaded", timeout=_click_to)
                    except Exception:
                        pass
                    final_url = page.url
                    redirect_count += 1
                    self.log(f"[NAV] ↪ Arrived at: {final_url[:60]}...")
                    # v11.2: Follow redirect chain — mobile-aware
                    _lc_budget = 30.0 if is_mobile_proxy else 12.0
                    _lc_poll = 1.5 if is_mobile_proxy else 1.0
                    _lc_hop_to = 10000 if is_mobile_proxy else 5000
                    chain_deadline = time.time() + _lc_budget
                    stable_checks = 0
                    while time.time() < chain_deadline and stable_checks < 3:
                        await asyncio.sleep(_lc_poll)
                        try:
                            current_url = page.url
                        except Exception:
                            break
                        # v20.2: smartlink opened a NEW tab and abandoned
                        # this one to about:blank — follow into the new tab
                        # instead of wrongly declaring about:blank "landed".
                        if current_url in ("about:blank", "", "chrome-error://chromewebdata", "about:neterror"):
                            _followed_page, _followed_url = await _follow_popup_if_blanked(page, current_url)
                            if _followed_page is not page:
                                page = _followed_page
                                current_url = _followed_url
                                self.log(f"[NAV] 🔀 New tab opened (original left on about:blank) — following into: {current_url[:60]}...")
                            else:
                                continue  # still genuinely blank — keep polling, don't count as stable
                        if current_url.rstrip("/") != final_url.rstrip("/"):
                            redirect_count += 1
                            final_url = current_url
                            stable_checks = 0
                            self.log(f"[NAV] ↪ Chain hop -> {final_url[:60]}...")
                            try:
                                await page.wait_for_load_state("domcontentloaded", timeout=_lc_hop_to)
                            except Exception:
                                pass
                        else:
                            stable_checks += 1
                else:
                    self.log("[CLICK] ⚠ No clickable element found — staying on landing page")

            elif visit_mode == "search_click":
                # ═══ v13.2 — SEARCH CLICK MODE ═══
                # Opens a REAL Google search results page for a keyword, and
                # if the target domain actually appears in the results,
                # clicks through it like a genuine organic visitor. Works
                # great for indexed pages (e.g. the user's own blog); for
                # un-indexed pages (most smartlinks) it gracefully falls
                # back to a normal direct visit — never blocks the run.
                target_domain = urlparse(url).netloc
                kw_pool = self.config.get("seo_keywords") or []
                keyword = random.choice(kw_pool) if kw_pool else random.choice(SEARCH_QUERIES)
                search_url = f"https://www.google.com/search?q={quote_plus(keyword)}&ie=UTF-8"
                self.log(f"[NAV] 🔎 Search Click — opening Google search for '{keyword}'...")
                search_click_success = False
                try:
                    await page.goto(search_url, wait_until="domcontentloaded", timeout=nav_timeout)
                    await asyncio.sleep(max(0.5, min(2.0, random.gauss(1.2, 0.3))))  # v13.7.4 Gaussian
                    search_click_success = await self._search_click_target(page, target_domain, nav_timeout=12000)
                except Exception as e:
                    self.log(f"[SEARCH] ⚠ Google search navigation failed: {str(e)[:80]}")

                if search_click_success:
                    self.log("[NAV] ↪ Clicked through from Google — following redirect chain...")
                    try:
                        await page.wait_for_load_state("domcontentloaded", timeout=15000)
                    except Exception:
                        pass
                    final_url = page.url
                    redirect_count = 1
                    chain_deadline = time.time() + 12.0
                    stable_checks = 0
                    while time.time() < chain_deadline and stable_checks < 3:
                        await asyncio.sleep(1.0)
                        try:
                            current_url = page.url
                        except Exception:
                            break
                        if current_url in ("about:blank", "", "chrome-error://chromewebdata", "about:neterror"):
                            _followed_page, _followed_url = await _follow_popup_if_blanked(page, current_url)
                            if _followed_page is not page:
                                page = _followed_page
                                current_url = _followed_url
                                self.log(f"[NAV] 🔀 New tab opened (original left on about:blank) — following into: {current_url[:60]}...")
                            else:
                                continue
                        if current_url.rstrip("/") != final_url.rstrip("/"):
                            redirect_count += 1
                            final_url = current_url
                            stable_checks = 0
                            self.log(f"[NAV] ↪ Chain hop -> {final_url[:60]}...")
                            try:
                                await page.wait_for_load_state("domcontentloaded", timeout=5000)
                            except Exception:
                                pass
                        else:
                            stable_checks += 1
                else:
                    self.log("[NAV] ↪ No indexed match — falling back to a direct visit (referer still shows as this search query)")
                    redirect_count = 0
                    final_url = nav_url
                    try:
                        await page.goto(nav_url, wait_until="domcontentloaded", timeout=nav_timeout, referer=search_url)
                        final_url = page.url
                        if final_url.rstrip("/") != nav_url.rstrip("/"):
                            redirect_count += 1
                    except Exception as e:
                        last_nav_error = str(e)
                        self.log(f"[NAV] ⚠ Fallback direct visit failed: {str(e)[:80]}")

            else:
                # ═══ DIRECT MODE (original behavior) ═══
                # v20.7: removed a duplicate self.log() left over from an
                # earlier edit — it printed the identical "Opening {url}"
                # line twice in a row for every single visit (harmless, but
                # confusing to read in the live console).
                self.log(f"[NAV] 🌐 Opening {nav_url[:60]}...")
                redirect_count = 0
                final_url = nav_url
                # v11.0: mobile-aware nav timeout
                if is_mobile_proxy:
                    nav_timeout, _, retry_timeout = self._get_mobile_timeouts(True)
                else:
                    nav_timeout = self.config.get("nav_timeout_ms", 60000)
                    _, _, retry_timeout = self._get_mobile_timeouts(False)
                # v10.2: rotating gateway proxies get more retry attempts —
                # each retry opens a fresh connection through the gateway and
                # gets a brand new random backend IP, so it's worth trying a
                # couple extra times before giving up. Direct/sticky proxies
                # keep the original 2 (retrying the same dead IP twice is enough
                # to confirm it's truly dead).
                is_rotating_gw = bool(proxy and proxy.get("is_gateway") and not proxy.get("sticky_session"))
                max_retries = 6 if (is_rotating_gw and is_mobile_proxy) else (4 if is_rotating_gw else 2)
                last_nav_error = None

                # ── v18: main-frame response recorder (diagnostics) ──
                # Records every top-level navigation response (url, status,
                # response headers, request headers) so that when a smartlink
                # returns Access Denied we can see EXACTLY what the server
                # said and what we sent — instead of guessing which
                # anti-fraud signal tripped. Lightweight: only main-frame
                # navigations are recorded, never subresources.
                _main_frame_responses = []

                def _make_main_frame_recorder(target_page):
                    # v20.2 FIX: bound to the EXPLICIT page passed in, not the
                    # outer `page` variable — needed because `page` gets
                    # reassigned mid-visit when a smartlink pops the real
                    # landing into a NEW tab (see _follow_popup_if_blanked).
                    # A closure over the outer name would silently stop
                    # matching once `page` pointed at the new tab.
                    def _recorder(resp):
                        try:
                            # v20.1 FIX: is_navigation_request() is also True
                            # for SUBFRAME navigations — ad iframes returning
                            # 403/429 (very common on legit pages) were
                            # recorded and corrupted the final-hop deny
                            # decision below. Only a top-level (main-frame)
                            # response proves the smartlink itself denied us.
                            if resp.request.is_navigation_request() and resp.frame == target_page.main_frame:
                                _main_frame_responses.append({
                                    "url": resp.url[:300],
                                    "status": resp.status,
                                    "response_headers": dict(resp.headers),
                                    "request_headers": dict(resp.request.headers),
                                })
                        except Exception:
                            pass
                    return _recorder
                try:
                    page.on("response", _make_main_frame_recorder(page))
                except Exception:
                    pass

                for attempt in range(1, max_retries + 1):
                    if not self.is_running:
                        raise _StopRequested("STOP_REQUESTED: during nav retry")
                    try:
                        # Retry attempt gets a shorter timeout — if the proxy
                        # didn't respond within the full timeout once, waiting
                        # the full duration again rarely helps.
                        attempt_timeout = nav_timeout if attempt == 1 else retry_timeout
                        goto_kwargs = {"wait_until": "domcontentloaded", "timeout": attempt_timeout}
                        if referer:
                            goto_kwargs["referer"] = referer
                        # v207.1: interruptible — Stop now aborts THIS single
                        # attempt within ~0.4s instead of waiting out the
                        # full attempt_timeout (60-90s on mobile proxies).
                        await self._interruptible_goto(page, nav_url, **goto_kwargs)
                        final_url = page.url
                        if final_url.rstrip("/") != nav_url.rstrip("/"):
                            redirect_count += 1
                            self.log(f"[NAV] ↪ Redirected to {final_url[:60]}...")

                        # ── Actively follow smartlink chain until it STABILIZES ──
                        # v10.4: extended chain-follow to 12s (was 9s) with 3
                        # stable checks (was 2). Smartlink/click.php hops often
                        # do multiple JS/meta redirects with delays between them
                        # (anti-fraud verification, tracking pixel fire, server-
                        # side redirect, etc.). The old 9s/2-check budget was
                        # sometimes cutting the chain short on slower proxies,
                        # leaving the visit stuck on an intermediary
                        # "Redirecting..." page instead of the real ad/offer
                        # landing page. Now we poll every ~1s for up to 12s,
                        # requiring 3 consecutive stable checks (URL unchanged
                        # for ~3s) before declaring we've landed.
                        chain_budget = 30.0 if is_mobile_proxy else 12.0
                        chain_poll = 1.5 if is_mobile_proxy else 1.0
                        chain_hop_to = 10000 if is_mobile_proxy else 5000
                        chain_deadline = time.time() + chain_budget
                        stable_checks = 0
                        while time.time() < chain_deadline and stable_checks < 3:
                            if not self.is_running:
                                raise _StopRequested("STOP_REQUESTED: during chain-follow")
                            await asyncio.sleep(chain_poll)
                            try:
                                current_url = page.url
                            except Exception:
                                break
                            # v20.2: smartlink chain popped the real landing
                            # into a NEW tab and abandoned this one to
                            # about:blank — follow it instead of wrongly
                            # declaring about:blank "landed" (which was
                            # causing good visits to look like dead ones and
                            # get retried, burning an extra rotating-gateway
                            # IP on an already-successful visit).
                            if current_url in ("about:blank", "", "chrome-error://chromewebdata", "about:neterror"):
                                _followed_page, _followed_url = await _follow_popup_if_blanked(page, current_url)
                                if _followed_page is not page:
                                    page = _followed_page
                                    current_url = _followed_url
                                    self.log(f"[NAV] 🔀 Smartlink opened a NEW tab (original left on about:blank) — following into: {current_url[:60]}...")
                                    try:
                                        page.on("response", _make_main_frame_recorder(page))
                                    except Exception:
                                        pass
                                else:
                                    continue  # still genuinely blank — keep polling, don't count as stable
                            if current_url.rstrip("/") != final_url.rstrip("/"):
                                redirect_count += 1
                                final_url = current_url
                                stable_checks = 0
                                self.log(f"[NAV] ↪ Chain hop -> {final_url[:60]}...")
                                # Give the new hop a moment to start executing its
                                # own JS/meta redirect before we poll again.
                                try:
                                    await page.wait_for_load_state("domcontentloaded", timeout=chain_hop_to)
                                except Exception:
                                    pass
                            else:
                                stable_checks += 1
                        last_nav_error = None
                        break
                    except Exception as retry_err:
                        last_nav_error = retry_err
                        err_str = str(retry_err)

                        # v11.1: browser/context itself died (crash, force-
                        # close, CDP disconnect) — completely different from
                        # a proxy/network error. Retrying page.goto() on this
                        # SAME dead page object is pointless (instant repeat
                        # failure forever). Bail out of the retry loop RIGHT
                        # NOW and raise _BrowserCrashed so _single_visit()'s
                        # wrapper throws away this whole browser and launches
                        # a completely fresh one (fresh IP + fresh device +
                        # fresh Chromium process) instead of wasting the
                        # remaining retry budget hammering a corpse.
                        if _is_browser_dead_error(err_str):
                            self.log(f"[NAV] 💥 Browser/context died mid-retry (attempt {attempt}) — discarding this browser, launching a fresh one")
                            raise _BrowserCrashed(f"BROWSER_CRASHED: browser died mid-visit — {err_str[:100]}")

                        fatal = _is_fatal_proxy_error(err_str, proxy)
                        is_net_err = "net::ERR" in err_str or "Timeout" in err_str

                        if fatal:
                            # v13.1.1: ERR_TUNNEL_CONNECTION_FAILED has TWO very
                            # different real causes that look identical to
                            # Chrome/Playwright (same net-error code either way):
                            #   1) the exit-node/proxy itself is actually dead
                            #   2) the proxy PROVIDER is alive and fine, but its
                            #      gateway explicitly refuses to tunnel to THIS
                            #      target domain (many providers — confirmed on
                            #      Decodo — return "403 restricted target" for
                            #      known ad/smartlink domains as an abuse-
                            #      prevention policy; this is a domain-level
                            #      block, not a dead IP).
                            # We can't see the proxy's actual CONNECT response
                            # body from here (Chrome collapses it to one net
                            # error code), but preflight_ok having JUST
                            # succeeded moments earlier on this exact same
                            # proxy (generic IP-echo sites reachable) is strong
                            # evidence the tunnel itself is alive — so this
                            # specific link's domain is very likely the one
                            # being blocked, not the exit node. Surface that
                            # distinction so the owner doesn't waste time
                            # thinking the IP/proxy is bad.
                            is_tunnel_fail = "net::err_tunnel_connection_failed" in err_str.lower()
                            if is_tunnel_fail and preflight_ok:
                                self.log(f"[NAV] ⛔ Tunnel refused for THIS link only (proxy passed pre-flight moments ago on generic sites) "
                                         f"— looks like the proxy provider is blocking this specific target domain (abuse-prevention policy), "
                                         f"not a dead IP. Try a different proxy provider for this link, or skip it for this proxy type.")
                            else:
                                self.log(f"[NAV] ⛔ {_friendly_error(err_str)} — proxy is dead, skipping retry (saved {nav_timeout/1000:.0f}s)")
                            # This exact proxy/exit-node is dead (or a direct IP
                            # / sticky-session proxy that failed) — no point
                            # retrying the same connection, mark it failed now.
                            if is_net_err and proxy:
                                self.proxy_manager.mark_failed(proxy)
                                self.ip_callback(proxy, "failed", {"reason": "navigation error"})
                            break

                        if attempt < max_retries:
                            # Not fatal (rotating gateway) — DON'T mark_failed
                            # yet, we're about to retry with a fresh connection
                            # through the same gateway line, which will likely
                            # get handed a different, healthy backend IP.
                            reason = "rotating gateway — trying a fresh backend IP" if is_rotating_gw else _friendly_error(err_str)
                            _retry_sleep = 4.0 if is_mobile_proxy else 2.0
                            self.log(f"[NAV] 🔁 Retry {attempt} — {reason}")
                            await asyncio.sleep(_retry_sleep)
                        elif is_net_err and proxy:
                            # Out of retries and still failing — NOW mark it failed.
                            self.proxy_manager.mark_failed(proxy)
                            self.ip_callback(proxy, "failed", {"reason": "navigation error (all retries exhausted)"})

                if last_nav_error:
                    raise last_nav_error

            # ── Wait for page to FULLY load (ads need this) ──
            _is_mob = proxy and self._is_mobile_proxy(proxy, _proxy_validation)
            _ni_to = 35000 if _is_mob else 15000
            _load_to = 15000 if _is_mob else 8000
            _settle = 4.0 if _is_mob else 2.5
            try:
                await page.wait_for_load_state("networkidle", timeout=_ni_to)
            except Exception:
                try:
                    await page.wait_for_load_state("load", timeout=_load_to)
                except Exception:
                    pass
            # Extra settle time for dynamic ad content to render
            await asyncio.sleep(_settle + max(0, min(2.0, random.gauss(1.0, 0.5))))

            # ── Natural fresh-browser load — no scripted "ad detection" ──
            # Per explicit instruction: the bot should behave EXACTLY like a
            # normal fresh browser opening the link — that natural load IS
            # the impression/click, nothing more needs to be checked.
            #
            # Previously this ran a 3-pass loop that scripted
            # document.querySelectorAll() to hunt for ad iframes/scripts/
            # pixels and scanned page text for "bot wall" phrases — ~6-9
            # extra seconds of DOM probing a real visitor's browser never
            # does. Worse, it was non-functional: the "bot wall detected —
            # visit will NOT count" message never actually excluded anything
            # below (success/proxy-consumption always proceeded the same),
            # so it only produced misleading logs without changing behavior.
            # Removed entirely — we just let the page settle naturally and
            # move straight into normal human browsing behavior.
            if page.url.rstrip("/") != final_url.rstrip("/"):
                redirect_count += 1
                final_url = page.url
                self.log(f"[NAV] ↪ Late redirect (post-settle) -> {final_url[:60]}...")
            self.log(f"[PAGE] ✅ Loaded naturally — {page.url[:70]}")

            # ── Smartlink Error-Page Smart Retry (v13.6.1) ──────────────────
            # chrome-error://chromewebdata বা about:blank detect করলে:
            # 1. Proxy type অনুযায়ী smart wait — mobile proxy slow হয়
            #    তাই বেশি সময় দেওয়া হয় proxy এর connection settle করতে
            # 2. Retry 1: হালকা wait — proxy just timed out হতে পারে
            # 3. Retry 2: বেশি wait — rotating proxy নতুন IP নিতে সময় লাগে
            # 4. chain follow করে — redirect পুরো settle হতে দেয়
            # 5. Success হলেই থামে — unnecessary reload নেই
            # Ad network দেখে: normal user এর network lag → F5 press
            _error_urls = ("chrome-error://", "chromewebdata", "about:blank", "about:neterror")
            _final_check_url = page.url.lower()
            _smartlink_retry_done = False
            if any(e in _final_check_url for e in _error_urls):
                # v20.2: before burning a FULL fresh navigation (which, on a
                # rotating gateway, grabs a brand new backend IP — exactly
                # the "same device, multiple IPs in one visit" pattern that
                # looks suspicious to anti-fraud systems) check if the real
                # landing is already sitting in a popped-out tab we just
                # haven't switched to yet. If so, that visit already
                # succeeded — just start tracking it, no re-navigation.
                _followed_page, _followed_url = await _follow_popup_if_blanked(page, page.url)
                if _followed_page is not page:
                    page = _followed_page
                    final_url = _followed_url
                    _final_check_url = final_url.lower()
                    self.log(f"[NAV] 🔀 Real landing was already open in a NEW tab — switching to it instead of re-navigating: {final_url[:60]}...")
            if any(e in _final_check_url for e in _error_urls):
                # Proxy type বুঝে wait time ঠিক করো
                # Mobile proxy: slow rotation (4-8s wait)
                # Desktop/datacenter: fast (1.5-3s wait)
                _base_wait = (3.5, 7.0) if is_mobile_proxy else (1.5, 3.0)
                _retry_nav_to = nav_timeout  # same timeout — proxy may just need time

                for _sr in range(1, 3):
                    if not self.is_running:
                        raise _StopRequested("STOP_REQUESTED: during error-page retry")
                    # Retry 2 তে একটু বেশি wait — proxy IP rotation settle হতে দাও
                    _wait_lo = _base_wait[0] * (1.0 if _sr == 1 else 1.4)
                    _wait_hi = _base_wait[1] * (1.0 if _sr == 1 else 1.4)
                    _actual_wait = max(_wait_lo, min(_wait_hi, random.gauss((_wait_lo+_wait_hi)/2, (_wait_hi-_wait_lo)/4)))
                    self.log(f"[NAV] ⏳ Error page detected — waiting {_actual_wait:.1f}s before retry {_sr}/2...")
                    await asyncio.sleep(_actual_wait)
                    try:
                        _rg = {"wait_until": "domcontentloaded", "timeout": _retry_nav_to}
                        if referer:
                            _rg["referer"] = referer
                        # v207.1: interruptible — same Stop-latency fix as
                        # the main retry loop above.
                        await self._interruptible_goto(page, nav_url, **_rg)

                        # Redirect chain পুরো follow করতে দাও
                        # Mobile proxy তে chain settle হতে বেশি সময় লাগে
                        _chain_budget = 15.0 if is_mobile_proxy else 8.0
                        _chain_deadline = time.time() + _chain_budget
                        _chain_stable = 0
                        _sf = page.url
                        while time.time() < _chain_deadline and _chain_stable < 2:
                            if not self.is_running:
                                raise _StopRequested("STOP_REQUESTED: during error-page retry chain-follow")
                            await asyncio.sleep(1.2 if is_mobile_proxy else 0.8)
                            try:
                                _cu = page.url
                            except Exception:
                                break
                            if _cu in ("about:blank", "", "chrome-error://chromewebdata", "about:neterror"):
                                _fp2, _fu2 = await _follow_popup_if_blanked(page, _cu)
                                if _fp2 is not page:
                                    page = _fp2
                                    _cu = _fu2
                                    _sf = _cu
                                    self.log(f"[NAV] 🔀 New tab opened during retry — following into: {_cu[:60]}...")
                                else:
                                    continue
                            if _cu.rstrip("/") != _sf.rstrip("/"):
                                _sf = _cu
                                _chain_stable = 0
                            else:
                                _chain_stable += 1

                        final_url = page.url
                        _final_check_url = final_url.lower()
                        if not any(e in _final_check_url for e in _error_urls):
                            _smartlink_retry_done = True
                            self.log(f"[PAGE] ✅ Retry {_sr} success — {final_url[:60]}")
                            break
                        else:
                            self.log(f"[NAV] 🔁 Retry {_sr} — still on error page: {final_url[:50]}")
                    except Exception as _sre:
                        _se = str(_sre)[:70]
                        self.log(f"[NAV] ⚠ Retry {_sr} exception: {_se}")
                        # Browser died mid-retry — no point continuing
                        if _is_browser_dead_error(_se):
                            raise _BrowserCrashed(f"BROWSER_CRASHED during error-retry: {_se}")
                        continue

                if not _smartlink_retry_done and any(e in _final_check_url for e in _error_urls):
                    # 2 retry তেও fail — এই IP দিয়ে কাজ হচ্ছে না।
                    # mark_failed করো যাতে proxy_manager পরের visit এ
                    # নতুন IP/line দেয়। _PreflightIPDead raise করলে
                    # _single_visit() fresh browser + fresh proxy নিয়ে
                    # পুরো visit টা নতুনভাবে শুরু করবে।
                    self.log(f"[PAGE] ❌ 2 retries failed — marking IP dead, rotating to fresh proxy")
                    if proxy:
                        self.proxy_manager.mark_failed(proxy)
                        self.ip_callback(proxy, "failed", {"reason": "error-page after 2 retries — IP rotated"})
                    # v20.5 DIAGNOSTIC: summarize WHY this visit went blank
                    # using the main-frame response recorder — this answers
                    # the recurring "blank ashar karon ki?" question with
                    # evidence instead of guesses. Three distinct shapes:
                    #   A) zero recorded responses → the smartlink chain
                    #      NEVER answered on this IP/tunnel (timeout or the
                    #      gateway silently dropped the request) — a proxy/
                    #      network failure, NOT a detection block.
                    #   B) responses recorded but final URL is still blank →
                    #      the smartlink answered then deliberately served
                    #      an empty/JS-killed page — classic anti-fraud
                    #      soft-block on this IP reputation (dud response
                    #      instead of an offer, exactly how smartlinks
                    #      filter suspicious clicks).
                    #   C) chain started hopping then died mid-way → one of
                    #      the hops (tracking/pre-filter) rejected this
                    #      IP/device combo; the offer never got served.
                    try:
                        _mfr = _main_frame_responses or []
                        if _mfr:
                            _last = _mfr[-1]
                            _srv = _last.get("response_headers", {}).get("server", "?")
                            self.log(
                                f"[NAV] 🩺 BLANK root-cause: {len(_mfr)} main-frame response(s) recorded — "
                                f"last hop status={_last.get('status')} server={_srv} url={(_last.get('url') or '')[:70]}"
                            )
                            self.log("[NAV] 🩺 → smartlink DID answer this IP but served an empty/dead end (soft-block) — IP marked dead, rotating")
                        else:
                            self.log("[NAV] 🩺 BLANK root-cause: ZERO main-frame responses — smartlink never answered on this IP (timeout/dropped request)")
                            self.log("[NAV] 🩺 → network/proxy-side failure, not detection — IP marked dead, rotating")
                    except Exception as _diag_err:
                        pass
                    raise _PreflightIPDead(
                        f"PREFLIGHT_IP_DEAD: error page persisted after 2 retries on {proxy.get('host','?') if proxy else 'direct'}"
                    )
            # ────────────────────────────────────────────────────────────────────

            # ── v19: Access-Denied detection + full evidence dump ──────────
            # v18 bug (found live): if the page kept redirecting right after
            # our "retry success", a bare page.title() throws "Execution
            # context was destroyed" and the WHOLE block aborted silently —
            # denial was clearly visible on screen but zero diagnostics got
            # written. v19 fixes this three ways:
            #   1. Give any trailing redirect a moment to settle first.
            #   2. Determine "denied" from HTTP status codes + final URL
            #      FIRST — that never throws, so detection itself is solid
            #      even if title/text reads keep failing.
            #   3. Title/text/JS-fingerprint reads each get their own
            #      try/except with a one-shot retry — a failure there
            #      degrades gracefully (field just says "unavailable"),
            #      it NEVER skips writing the diagnostics file.
            try:
                # Let a possible trailing client-side redirect finish before
                # we start reading anything from the page.
                try:
                    await page.wait_for_load_state("load", timeout=3000)
                except Exception:
                    pass
                await asyncio.sleep(0.6)

                async def _safe_read(coro_factory, label, retries=1):
                    """Run an async page-read; retry once after a short wait
                    if it fails with a context-destroyed-style error (page
                    was mid-navigation); never raises."""
                    last_err = None
                    for _attempt in range(retries + 1):
                        try:
                            return await coro_factory()
                        except Exception as _e:
                            last_err = _e
                            if _attempt < retries:
                                await asyncio.sleep(0.8)
                                continue
                    self.log(f"[DIAG] ⚠ Could not read {label}: {str(last_err)[:80]}")
                    return None

                _page_title = await _safe_read(lambda: page.title(), "page title")
                _page_title = (_page_title or "(unavailable)")[:150]

                _page_text = await _safe_read(
                    lambda: page.evaluate("() => document.body ? document.body.innerText.slice(0, 2000) : ''"),
                    "page text"
                )
                _page_text = _page_text or ""

                try:
                    _final_landed_url = page.url
                except Exception:
                    _final_landed_url = nav_url

                _text_l = _page_text.lower()
                _title_l = _page_title.lower()
                _url_l = _final_landed_url.lower()
                _deny_markers = (
                    "access denied", "access to this page has been denied",
                    "zugriff verweigert", "zugriff wurde verweigert", "kein zugriff",  # German denial phrases
                    "403 forbidden", "you have been blocked",
                    "request unsuccessful", "unusual traffic",
                    "verify you are a human", "attention required",
                    "blocked: proxy detected", "your access has been blocked",
                    "error 403", "http error 403",
                )
                _url_deny_markers = ("access-denied", "accessdenied", "/403", "error403", "blocked")
                # v20 EVIDENCE FIX: the live diagnostics JSON proved that a
                # smartlink visit can hit 403 on INTERMEDIATE hops (Adsterra's
                # /api/users fstu checkpoint fraud-gates the first attempt)
                # while the page's own JS regenerates fstu and retries — and
                # the visit still LANDS on the final offer (hop 7: 200,
                # vidox.net with real content). Flagging ANY-hop 403 as
                # "ACCESS DENIED" produced false denials for visits that
                # actually succeeded. Decision now uses the FINAL hop's
                # status + the landing page's actual text:
                #   - final 40x/503  -> denied (server won)
                #   - final 200 + denial text on page -> denied (JS wall)
                #   - final 200 + real content -> LANDED (not denied), even
                #     if intermediate checkpoints 403'd along the way.
                _final_status = _main_frame_responses[-1]["status"] if _main_frame_responses else 0
                _intermediate_40x = sum(1 for r in _main_frame_responses[:-1] if r["status"] in (403, 406, 429, 451, 503))
                _page_has_deny_text = any(m in _text_l or m in _title_l for m in _deny_markers) or any(m in _url_l for m in _url_deny_markers)
                _denied = (_final_status in (403, 406, 429, 451, 503)) or (_final_status == 200 and _page_has_deny_text)
                self.log(f"[DIAG] 📄 Landed: HTTP {'/'.join(str(r['status']) for r in _main_frame_responses[-3:]) or '?'} | {_final_landed_url[:70]} | title: {_page_title[:50]}")
                if not _denied and _intermediate_40x:
                    self.log(f"[DIAG] ✅ Final page OK ({_final_status}) — {_intermediate_40x} intermediate fraud-checkpoint 403s were retried by the page's own JS and PASSED (normal smartlink behavior, visit counted)")

                if _denied:
                    # ── what does the PAGE think we are? (JS-level truth) ──
                    _js_self = await _safe_read(lambda: page.evaluate("""() => {
                            try {
                                return {
                                    ua: navigator.userAgent,
                                    uad: (typeof navigator.userAgentData === 'undefined') ? null
                                         : {brands: navigator.userAgentData.brands,
                                            mobile: navigator.userAgentData.mobile,
                                            platform: navigator.userAgentData.platform},
                                    platform: navigator.platform,
                                    languages: navigator.languages,
                                    tz: Intl.DateTimeFormat().resolvedOptions().timeZone,
                                    screen: [screen.width, screen.height, screen.colorDepth, devicePixelRatio],
                                    cores: navigator.hardwareConcurrency,
                                    mem: navigator.deviceMemory || null,
                                    webdriver: navigator.webdriver,
                                    touchPoints: navigator.maxTouchPoints,
                                    plugins_count: navigator.plugins ? navigator.plugins.length : -1,
                                };
                            } catch(e) { return {err: String(e)}; }
                        }"""), "page JS fingerprint")
                    _js_self = _js_self or {"err": "unavailable (page kept navigating)"}

                    _diag = {
                        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "proxy": {"ip": proxy.get("host") if proxy else "direct",
                                  "country": proxy_country,
                                  "label": (proxy or {}).get("label", "") if proxy else ""},
                        "fingerprint_planned": {
                            "user_agent": fingerprint.get("user_agent"),
                            "platform": fingerprint.get("platform"),
                            "timezone": fingerprint.get("timezone"),
                            "locale": fingerprint.get("locale"),
                            "languages": fingerprint.get("languages"),
                            "screen": fingerprint.get("screen"),
                            "device_model": fingerprint.get("device_model"),
                            "is_fb_iab": fingerprint.get("is_fb_iab"),
                            "is_firefox": fingerprint.get("is_firefox"),
                            "is_safari": fingerprint.get("is_safari"),
                        },
                        "fingerprint_as_page_sees_it": _js_self,
                        "navigation": {
                            "requested_url": nav_url[:300],
                            "final_url": _final_landed_url[:300],
                            "redirect_hops": redirect_count,
                            "referer": (referer or "")[:200],
                        },
                        "main_frame_responses": _main_frame_responses[-8:],
                        "page_title": _page_title,
                        "page_text_first_2000": _page_text,
                    }
                    try:
                        import json as _diag_json
                        import os as _diag_os
                        _diag_dir = _diag_os.path.join(_diag_os.getcwd(), "diagnostics")
                        _diag_os.makedirs(_diag_dir, exist_ok=True)
                        _ts = time.strftime("%Y%m%d_%H%M%S") + f"_{int((time.time() % 1) * 1000):03d}"
                        _diag_path = _diag_os.path.join(_diag_dir, f"denied_{_ts}.json")
                        with open(_diag_path, "w", encoding="utf-8") as _df:
                            _df.write(_diag_json.dumps(_diag, indent=2, ensure_ascii=False))
                        try:
                            _shot_path = _diag_os.path.join(_diag_dir, f"denied_{_ts}.png")
                            await page.screenshot(path=_shot_path)
                        except Exception:
                            _shot_path = "(screenshot failed)"
                        self.log(f"[DIAG] 🔍 ACCESS DENIED detected — evidence saved:")
                        self.log(f"[DIAG]    📁 {_diag_path}")
                        self.log(f"[DIAG]    🖼  {_shot_path}")
                        self.log(f"[DIAG] Please zip the diagnostics folder and send it to your developer for exact-cause analysis.")
                    except Exception as _diag_err:
                        self.log(f"[DIAG] ⚠ Could not save diagnostics: {str(_diag_err)[:100]}")
            except Exception as _denied_check_err:
                # Last-resort fallback: even if the whole check blew up,
                # still write a minimal diagnostics file from whatever we
                # captured in _main_frame_responses (that part never throws)
                # so a denied visit NEVER leaves zero evidence behind.
                self.log(f"[DIAG] ⚠ Denial check hit an error: {str(_denied_check_err)[:100]} — writing minimal fallback evidence")
                try:
                    import json as _diag_json
                    import os as _diag_os
                    try:
                        _safe_page_url = page.url
                    except Exception:
                        _safe_page_url = "(unavailable)"
                    _diag_dir = _diag_os.path.join(_diag_os.getcwd(), "diagnostics")
                    _diag_os.makedirs(_diag_dir, exist_ok=True)
                    _ts = time.strftime("%Y%m%d_%H%M%S") + f"_{int((time.time() % 1) * 1000):03d}"
                    _diag_path = _diag_os.path.join(_diag_dir, f"denied_fallback_{_ts}.json")
                    _fallback = {
                        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "note": "Full denial check failed (page likely kept navigating) — minimal evidence only.",
                        "error": str(_denied_check_err)[:300],
                        "proxy": {"ip": proxy.get("host") if proxy else "direct", "country": proxy_country},
                        "fingerprint_planned": {
                            "user_agent": fingerprint.get("user_agent"),
                            "is_fb_iab": fingerprint.get("is_fb_iab"),
                        },
                        "navigation": {"requested_url": nav_url[:300], "redirect_hops": redirect_count},
                        "main_frame_responses": _main_frame_responses[-8:],
                        "last_known_url": _safe_page_url,
                    }
                    with open(_diag_path, "w", encoding="utf-8") as _df:
                        _df.write(_diag_json.dumps(_fallback, indent=2, ensure_ascii=False))
                    self.log(f"[DIAG] 📁 Fallback evidence saved: {_diag_path}")
                except Exception as _fallback_err:
                    self.log(f"[DIAG] ⚠ Even fallback evidence save failed: {str(_fallback_err)[:80]}")

            # ────────────────────────────────────────────────────────────────────

            # ── Clear any text selection / link focus (natural browser state) ──
            # After page.goto(), sometimes links or text remain focused/selected
            # (blue highlight). Real users never land with text selected — this
            # is an automation tell. We clear it immediately.
            try:
                await page.evaluate("""() => {
                    // Clear text selection
                    if (window.getSelection) { window.getSelection().removeAllRanges(); }
                    if (document.selection) { document.selection.empty(); }
                    // Remove focus from any active element (link highlight)
                    if (document.activeElement && document.activeElement !== document.body) {
                        document.activeElement.blur();
                    }
                    // Clear any CSS ::selection highlighting
                    try { document.documentElement.style.setProperty('-webkit-tap-highlight-color', 'transparent'); } catch(e) {}
                }""")
            except Exception:
                pass

            # ── Human behavior — respects user-defined visit duration ──
            actions_config = {
                "scroll": self.config.get("scroll", True),
                "click": self.config.get("click", False),  # v1.87: default OFF — dashboard controls this
                "mouse_movement": self.config.get("mouse_movement", True),
                "form_fill": self.config.get("form_fill", False),  # v5.3.1: default OFF — user enables from dashboard
                "multi_page": self.config.get("multi_page", False),  # v5.3.1: default OFF — user enables from dashboard
                "min_dwell": self.config.get("min_dwell", 3),
                "max_dwell": self.config.get("max_dwell", 6),
                "min_visit_time": self.config.get("min_visit_time", 15),
                "max_visit_time": self.config.get("max_visit_time", 45),
                "quick_impression": self.config.get("quick_impression", False),
            }

            # ── v213.2: the visit window starts NOW — target page is loaded,
            # all scroll/click/mouse/multipage action runs against THIS
            # absolute deadline, so the dashboard's min/max visit-time is
            # the real on-page time, immune to launch/proxy overhead. ──
            _engagement_started_at = time.time()
            _visit_deadline = _engagement_started_at + _visit_len
            self.log(f"[HUMAN] ⏱ target ready in {time.time() - start_time:.1f}s — on-page window: {_visit_len:.1f}s (set {int(_vt_min)}-{int(_vt_max)}s)")

            # ── Smarter bot: organic tab focus + viewport jitter ──
            # Real users switch tabs, lose focus, come back — this simulates that
            # v1.89: Only if mouse_movement is enabled (human behavior feature)
            try:
                if actions_config.get("mouse_movement", True) and random.random() < 0.3:
                    await page.evaluate("() => { Object.defineProperty(document, 'hidden', {get: () => true, configurable: true}); Object.defineProperty(document, 'visibilityState', {get: () => 'hidden', configurable: true}); document.dispatchEvent(new Event('visibilitychange')); }")
                    await asyncio.sleep(max(0.3, min(1.2, _visit_len * 0.10)))  # v210: proportional, never eats a short visit
                    await page.evaluate("() => { Object.defineProperty(document, 'hidden', {get: () => false, configurable: true}); Object.defineProperty(document, 'visibilityState', {get: () => 'visible', configurable: true}); document.dispatchEvent(new Event('visibilitychange')); window.dispatchEvent(new Event('focus')); }")
                    self.log("[HUMAN] 🔄 Tab focus/blur simulated")
            except: pass

            # ── Smarter bot: random viewport scroll position reset ──
            # Real users sometimes scroll back up before leaving
            # v1.89: Only if scroll is enabled in config
            try:
                if actions_config.get("scroll", True) and random.random() < 0.25:
                    await page.evaluate("window.scrollTo({top: 0, behavior: 'smooth'})")
                    await asyncio.sleep(max(0.15, min(0.8, _visit_len * 0.08)))  # v210: proportional
            except: pass

            human = HumanBehavior(page, fingerprint)
            human.used_behavior_sigs = self._used_behavior_sigs  # v211: per-visit unique behavior
            # v210 LIVE ENGAGEMENT: the session runs against THIS visit's
            # absolute deadline (set at visit start from the user's duration
            # setting). Actions begin the moment the page is loaded; when the
            # deadline hits, the session returns and the page closes — even
            # mid-scroll. Hard cap is only a 2s safety margin on top.
            _hard_cap = max(2.0, _visit_deadline - time.time() + 2.0)
            try:
                await asyncio.wait_for(
                    human.simulate_session(actions_config, deadline=_visit_deadline),
                    timeout=_hard_cap,
                )
            except asyncio.TimeoutError:
                self.log(f"[HUMAN] ⚠ session hit hard cap ({_hard_cap:.1f}s) — closing")
            _engaged = ", ".join(human.actions_log) if getattr(human, "actions_log", None) else "impression only"
            _persona = (getattr(human, "personality", None) or {}).get("archetype", "visitor")
            self.log(f"[HUMAN] 🎭 {time.time() - start_time:.1f}s visit [{_persona}] — engaged: {_engaged}")

            # ── Smarter bot: organic exit — pause briefly on page before close ──
            # v210: only if the visit's own budget still allows it; a visit
            # whose time is up closes IMMEDIATELY (user requirement).
            try:
                _exit_left = _visit_deadline - time.time()
                if _exit_left > 0.2:
                    await asyncio.sleep(min(0.5, _exit_left))
            except: pass

            # ── Success — IP is consumed & removed from the pool IMMEDIATELY ──
            if proxy:
                self.proxy_manager.mark_used(proxy)
                self.log(f"[PROXY] 🏁 IP consumed — {proxy_ip} (1 IP = 1 visit)")
                self.ip_callback(proxy, "used", {"country": proxy_country, "quality": ip_quality})
            # v213.2: report the ON-PAGE duration so the results table and
            # logs match the dashboard setting (was: whole attempt incl.
            # proxy/launch/nav overhead, which looked like a broken setting).
            duration = time.time() - (_engagement_started_at or start_time)
            fp_label = fingerprint.get("device_model", fingerprint["browser_key"])
            return VisitResult(
                url=url, success=True, proxy_ip=proxy_ip,
                fingerprint_id=fp_label, duration=duration,
                redirects=redirect_count,
                final_url=final_url if final_url != url else None,
                proxy_country=proxy_country, ip_quality=ip_quality,
            )

        except _StopRequested as e:
            # v20.7: Stop was clicked mid-visit — unwind cleanly right here
            # instead of letting the current attempt run to completion.
            # Not counted as a failure (it isn't one); _single_visit's own
            # is_running check will see the flag is False and return
            # immediately without consuming another retry attempt.
            self.log(f"[SYS] 🛑 Visit aborted — stop requested mid-flight")
            return VisitResult(url, False, proxy_ip, fingerprint.get("device_model", fingerprint.get("browser_key", "N/A")),
                             time.time() - start_time, error="STOP_REQUESTED", proxy_country=proxy_country)

        except _PreflightIPDead as e:
            # Already marked failed + ip_callback fired at the raise site
            # above — don't re-mark. The "PREFLIGHT_IP_DEAD" marker in the
            # error message tells _single_visit()'s wrapper to retry with a
            # fresh IP, so the target/smartlink URL was NEVER touched.
            return VisitResult(url, False, proxy_ip, fingerprint.get("device_model", fingerprint.get("browser_key", "N/A")),
                             time.time() - start_time, error=str(e)[:200], proxy_country=proxy_country)

        except _BrowserCrashed as e:
            # v11.1: browser/context died mid-retry (not a proxy/network
            # issue — the Chromium process itself is gone). The "BROWSER_
            # CRASHED" marker in the error message tells _single_visit()'s
            # wrapper to throw away this browser and launch a completely
            # fresh one (fresh IP + fresh device) — same recovery path as
            # PREFLIGHT_IP_DEAD. Don't mark the proxy failed here since the
            # crash may not be the proxy's fault (could be a Chromium
            # resource hiccup) — the fresh browser will re-validate the
            # SAME proxy from scratch via its own preflight check anyway.
            return VisitResult(url, False, proxy_ip, fingerprint.get("device_model", fingerprint.get("browser_key", "N/A")),
                             time.time() - start_time, error=str(e)[:200], proxy_country=proxy_country)

        except Exception as e:
            error_msg = str(e)[:200]
            # v11.1: even in code paths NOT covered by the DIRECT-mode retry
            # loop's own browser-dead check (e.g. landing-page/button-click
            # mode, or a crash during human-behavior simulation after a
            # successful nav), tag the error with the BROWSER_CRASHED marker
            # so _single_visit()'s wrapper still recognizes it as recoverable
            # and swaps in a fresh browser+IP instead of just giving up.
            if _is_browser_dead_error(error_msg):
                error_msg = f"BROWSER_CRASHED: {error_msg}"
            # This is the outer catch-all (browser launch failures, etc. —
            # not just navigation, which already handled its own retry/mark
            # logic above). mark_failed() is safe to call again here since
            # it just adds to a set (no duplicate side effects).
            elif proxy and (_is_fatal_proxy_error(error_msg, proxy) or "ERR_PROXY" in error_msg or "ERR_TIMED_OUT" in error_msg or "ERR_CONNECTION" in error_msg):
                self.proxy_manager.mark_failed(proxy)
                self.ip_callback(proxy, "failed", {"reason": "visit error"})
            return VisitResult(url, False, proxy_ip, fingerprint.get("device_model", fingerprint.get("browser_key", "N/A")),
                             time.time() - start_time, error=error_msg, proxy_country=proxy_country)

        finally:
            # ── Capture window position for this lane (concurrent mode) ──
            # Before closing, grab window.screenX/screenY so the next visit
            # in this lane opens at the same screen position the user chose.
            try:
                if page and not page.is_closed() and lane_id is not None:
                    pos = await page.evaluate("() => [window.screenX || 0, window.screenY || 0]")
                    if pos and isinstance(pos, list) and len(pos) == 2:
                        self._lane_positions[lane_id] = (int(pos[0]), int(pos[1]))
            except Exception:
                pass
            # v1.81 FIX: Wrap cleanup in 15s timeout — if context.close() hangs
            # (Firefox/Gecko engine known issue), we still return so the next
            # visit can start. The browser process will be orphaned but the
            # temp_dir is force-removed so no resource leak.
            try:
                await asyncio.wait_for(
                    self._full_cleanup(page if 'page' in dir() else None, context, temp_dir),
                    timeout=15.0
                )
            except asyncio.TimeoutError:
                self.log("[CLEANUP] ⚠ Full cleanup timed out (15s) — orphaning browser, removing temp_dir")
                # Force remove temp_dir even if cleanup didn't finish
                if temp_dir:
                    try:
                        import shutil as _sh, subprocess as _sp
                        _sh.rmtree(temp_dir, ignore_errors=True)
                        if os.path.exists(temp_dir):
                            _sp.run(["rm", "-rf", temp_dir], capture_output=True, timeout=3)
                    except Exception:
                        pass

    def _build_context_options(self, fingerprint, temp_dir, headless_mode):
        """Build all options for launch_persistent_context.
        Combines browser launch args + context settings."""
        is_mobile = fingerprint["is_mobile"]

        # Screen dimensions — use EXACT device CSS pixels
        # Real Chrome on mobile: viewport = device CSS width, height = device CSS height minus browser UI
        # But window.screen reports full device CSS dimensions
        sw = fingerprint["screen"]["width"]
        sh = fingerprint["screen"]["height"]

        # For mobile: viewport width = screen width, height = screen height
        # (Chrome's UI bar overlays content, doesn't reduce viewport in CSS pixels)
        # For desktop: viewport = screen minus taskbar/tabbar (real ~90%)
        if is_mobile:
            # CRITICAL FIX: real Android Chrome's visible viewport (innerHeight)
            # is ~70-78% of screen.height — the rest is consumed by the address
            # bar + bottom navigation bar. Previously viewport was set to full
            # screen height (sh) while the stealth script overrode innerHeight
            # to sh*0.7 — creating a huge mismatch between the ACTUAL rendered
            # viewport (sh pixels) and what JS reported (0.7*sh). Any ad script
            # that measures element.getBoundingClientRect().bottom vs
            # window.innerHeight would instantly detect the contradiction.
            # Fix: set viewport to the REAL visible height, and the stealth
            # script's innerHeight override must match this exactly.
            vp_width = sw
            vp_height = int(sh * random.uniform(0.70, 0.78))
        else:
            vp_width = sw
            vp_height = int(sh * random.uniform(0.88, 0.93))

        options = {
            # Browser launch options
            "headless": headless_mode,
            "args": self._get_browser_args(fingerprint, temp_dir, headless_mode, lane_id=self._current_lane_id),

            # ── CRITICAL FIX ──
            # Playwright ALWAYS injects "--enable-automation" into Chrome's
            # launch args by default (even in launch_persistent_context).
            # THIS is exactly what produces the big yellow/gray infobar:
            #   "Chrome is being controlled by automated test software"
            # That infobar is not just cosmetic — it:
            #   1) Physically shrinks the visible viewport (adds a bar),
            #      throwing off our carefully-matched viewport/screen ratio
            #      and creating a real, measurable device inconsistency.
            #   2) Sets navigator.webdriver / automation internals at the
            #      Chrome level BEFORE our stealth init-scripts even run,
            #      so JS-level patches can't fully undo it.
            #   3) Some ad-network anti-fraud scripts explicitly probe for
            #      window.outerHeight vs innerHeight deltas and known
            #      automation banner heights — an instant "bot" flag.
            # Removing it via ignore_default_args is the real fix — this is
            # the standard Playwright-stealth technique, not a hack.
            "ignore_default_args": [
                "--enable-automation",
                "--enable-blink-features=IdleDetection",
            ],

            # Context options — these define the device identity
            "user_agent": fingerprint["user_agent"],
            "viewport": {"width": vp_width, "height": vp_height},
            "screen": {"width": sw, "height": sh},
            "locale": fingerprint["locale"],
            "timezone_id": fingerprint["timezone"],
            "has_touch": fingerprint["touch_support"],
            "device_scale_factor": fingerprint["pixel_ratio"],
            # v13.7.8 FIX: color_scheme derived deterministically from the
            # fingerprint's canvas_seed — same device always gets the same
            # color scheme (a real user doesn't switch light/dark mid-session).
            # ~75% light / ~25% dark matches real-world browser stats.
            "color_scheme": "dark" if (fingerprint.get("canvas_seed", 0) % 4 == 0) else "light",
            "java_script_enabled": True,
            "ignore_https_errors": True,
            # NOTE: Do NOT set is_mobile=True — it's a Playwright-specific flag
            # that changes internal behavior in detectable ways. We emulate
            # mobile via viewport + UA + touch + DPR instead.
        }

        return options

    def _compute_lane_position(self, lane_id, fingerprint):
        """Compute --window-position arg for a concurrent lane.

        Layout: browsers overlap side-by-side in the LEFT 40% of the screen,
        in a 2-row grid (5 per row, max 10):
          Row 0 (top)    → lane_id 0..4  (left to right)
          Row 1 (bottom) → lane_id 5..9  (left to right)

        Each browser opens at its FULL device size (mobile or desktop).
        Browsers overlap so only the left ~40% of each is visible.
        Step = (screen_width × 0.40) / 5 → ~40% of a mobile browser visible.

        Slot reuse: each lane has a FIXED position. When a visit finishes
        and the lane restarts, the browser opens at the same position.
        Default order is serial (lane 0 → pos 0, lane 1 → pos 1, etc.)

        If the user manually moved a lane, that remembered position
        overrides the auto-grid placement.

        Returns --window-position=X,Y string, or None (filtered later).
        """
        if lane_id is None:
            return None  # single-visit mode — no placement override

        # ── 1. User-remembered position (manual drag takes priority) ────
        if hasattr(self, '_lane_positions') and lane_id in self._lane_positions:
            x, y = self._lane_positions[lane_id]
            return f"--window-position={x},{y}"

        # ── 2. Auto-grid placement in left 40% of screen ────────────────
        try:
            import ctypes
            user32 = ctypes.windll.user32
            try:
                user32.SetProcessDPIAware()
            except Exception:
                pass
            screen_w = user32.GetSystemMetrics(0)   # SM_CXSCREEN
            screen_h = user32.GetSystemMetrics(1)   # SM_CYSCREEN
        except Exception:
            screen_w, screen_h = 1920, 1080

        total_lanes = getattr(self, '_concurrent_count', 1)
        if total_lanes < 1:
            total_lanes = 1

        lanes_per_row = 5

        # Row (0 = top, 1 = bottom)
        row = lane_id // lanes_per_row
        col = lane_id  % lanes_per_row

        # Placement zone = left 40% of screen
        zone_w = int(screen_w * 0.40)

        # Step between browsers = zone_width / 5
        # → each browser's left portion visible (≈40% for mobile)
        step_x = zone_w // lanes_per_row

        # Row height = half of screen (2 rows max), leave 40px for taskbar
        row_h = (screen_h - 40) // 2

        pos_x = col * step_x
        pos_y = row * row_h

        # Safety: clamp to non-negative
        pos_x = max(0, int(pos_x))
        pos_y = max(0, int(pos_y))

        return f"--window-position={pos_x},{pos_y}"

    def _get_browser_args(self, fingerprint, temp_dir, headless_mode=True, lane_id=None):
        """Clean, standard Chrome args — no non-standard flags that real
        Chrome users don't have. Only essential automation-hiding args."""
        args = [
            # Essential: hide automation
            "--disable-blink-features=AutomationControlled",

            # CRITICAL FIX: any non-default Chrome command-line flag (like the
            # one above) makes Chromium show a big top-of-window warning bar:
            #   "You are using an unsupported command-line flag: --disa..."
            # Real users NEVER see this — it's an instant automation tell,
            # AND (just like the "controlled by automated test software"
            # banner) it eats into the visible viewport, throwing off our
            # screen/viewport ratio matching.
            # Chromium's own source (bad_flags_prompt.cc) explicitly skips
            # showing this warning when --test-type is present — this is the
            # standard, safe way real stealth-browser setups suppress it.
            # It has no JS-visible side effects (not readable via navigator/
            # window), it just tells Chrome's internal UI code "don't warn".
            "--test-type",

            # v213: unlocks Chromium's Input.synthesize*Gesture CDP family
            # (touch swipe/pinch). Without this flag synthesizeScrollGesture
            # is a SILENT no-op — the page never moved, which is why mobile
            # visits showed taps but no scrolling. Not JS-visible.
            "--enable-gpu-benchmarking",

            # v213: unlocks Chromium's Input.synthesize*Gesture CDP family
            # (touch swipe/pinch). Without this flag synthesizeScrollGesture
            # is a SILENT no-op — the page never moved, which is why mobile
            # visits showed taps but no scrolling. Not JS-visible.
            "--enable-gpu-benchmarking",

            # Standard sandbox flags (needed on Linux servers)
            "--no-sandbox",
            "--disable-setuid-sandbox",
            "--disable-dev-shm-usage",

            # Fresh session flags (real Chrome first-run behavior)
            "--no-first-run",
            "--no-default-browser-check",

            # Window size — FULL device CSS size (mobile/desktop same as before)
            # Browser window keeps its natural device dimensions.
            # Overlap/placement handled by --window-position only.
            f"--window-size={fingerprint['screen']['width']},{fingerprint['screen']['height']}",

            # ── Concurrent lane auto-grid placement (v14) ──────────────
            # Browsers are placed on the LEFT 40% of the primary display,
            # in a 2-row grid so all lanes stay visible simultaneously:
            #   Top row   : lanes 0-4   (up to 5 browsers, side by side)
            #   Bottom row: lanes 5-9   (up to 5 browsers, side by side)
            # If the user has manually moved a lane window to a custom position
            # (captured at close time), that remembered position is used instead.
            self._compute_lane_position(lane_id, fingerprint),

            # Cache/crash dirs in temp (per-visit isolation)
            f"--disk-cache-dir={temp_dir}/cache",
            f"--crash-dumps-dir={temp_dir}/crashes",

            # NOTE: --ignore-certificate-errors REMOVED
            # Real Chrome users never have this flag — anti-fraud
            # systems detect it as an automation signal.

            # WebRTC disable — prevents real IP leak through STUN
            "--enforce-webrtc-ip-permission-check",
            "--disable-webrtc-multiple-routes",
            "--disable-webrtc-ipv6-on-ipv4-socket",
            "--force-webrtc-ip-handling-policy=disable_non_proxied_udp",

            # v15: DNS leak protection — disable DoH (DNS over HTTPS) which
            # could bypass the proxy and resolve via Google/Cloudflare,
            # leaking the real server location. With this disabled, Chrome
            # uses the system DNS (which for a proxy connection goes through
            # the proxy tunnel), keeping DNS consistent with the proxy IP.
            # v20.1 FIX: this flag was duplicated below with a different
            # feature list — Chromium keeps only the LAST --disable-features,
            # so the DoH disable was silently cancelled. Merged into one flag.
            "--disable-features=DnsOverHttps,RelaxThirdPartyCookieBlocking",

            # Language
            "--lang=" + fingerprint.get("locale", "en-US"),

            # Password store (don't use system keychain)
            "--password-store=basic",
            "--use-mock-keychain",

            # v1.85: TLS/HTTP2 fingerprint consistency — ensure Chrome's
            # BoringSSL sends the same JA3/JA4 hash as real Chrome.
            # These are Chrome defaults but some Playwright configs strip them.
            # QUIC: real Chrome prefers QUIC (HTTP/3) when available —
            # disabling it creates a detectable difference in connection behavior.
            # HTTP/2: real Chrome always negotiates h2 via ALPN.
            # TLS 1.3: real Chrome prefers TLS 1.3 hybrid Kyber.
            "--enable-quic",
            "--quic-version=h3-29",
            "--enable-features=TLSKeyUpdateKTopLevel,PostQuantumKyber",
        ]

        # Mobile-specific
        if fingerprint["is_mobile"]:
            args.extend([
                "--use-mobile-user-agent",
                "--enable-touch-events",
            ])

        # v13.7.9: --disable-gpu REMOVED from headless mode.
        # It causes WebGL to fall back to SwiftShader (software renderer),
        # which is detectable by advanced anti-fraud (SwiftShader has
        # different shader precision + extension list than real GPUs).
        # Chrome 109+ new headless mode works fine with GPU enabled.
        # If GPU crashes occur on headless servers, Xvfb handles display.
        # The stealth script already overrides WebGL renderer strings at
        # the JS level, but keeping GPU enabled means the ACTUAL WebGL
        # rendering behavior (extensions, precision, canvas output) also
        # matches a real GPU, not a software fallback.

        # NOTE: We deliberately do NOT disable:
        # - AcceptCHFrame (Client Hints — real Chrome sends these)
        # - Translate (real Chrome has translate)
        # - OptimizationHints (real Chrome has this)
        # - MediaRouter/DialMediaRouteProvider (real Chrome has cast)
        # - BackgroundNetworking (real Chrome does background requests)
        # - Site isolation (real Chrome has this ON)
        # - Sync (real Chrome has sync)
        # These were previously disabled and made the browser look non-standard.

        # Filter out None entries (window-position placeholder when no saved position)
        args = [a for a in args if a is not None]
        return args

    def _build_headers(self, fingerprint):
        """Build full HTTP headers including complete Client Hints.
        Real Chrome 131+ sends Sec-CH-UA-Full-Version-List and
        Sec-CH-UA-Platform-Version headers."""
        import re as _re
        ua = fingerprint["user_agent"]
        chrome_ver = "150"
        chrome_full = "150.0.0.0"  # FIX: was missing, caused NameError crash
        m = _re.search(r"Chrome/(\d+)\.(\d+)\.(\d+)\.(\d+)", ua)
        if m:
            chrome_ver  = m.group(1)
            chrome_full = f"{m.group(1)}.{m.group(2)}.{m.group(3)}.{m.group(4)}"
        else:
            m = _re.search(r"Chrome/(\d+)", ua)
            if m:
                chrome_ver  = m.group(1)
                chrome_full = f"{m.group(1)}.0.0.0"

        is_edge = fingerprint.get("is_edge", False)
        is_mobile = fingerprint["is_mobile"]
        
        # v13.7.5 — Firefox + Safari + FB IAB do NOT send Client Hints or Sec-CH-UA
        # Firefox: no Sec-CH-UA, no navigator.userAgentData, different Accept header
        # Safari: no Sec-CH-UA, no navigator.userAgentData, Safari-specific Accept
        # FB IAB (Facebook in-app browser): Meta strips navigator.userAgentData
        #   and does NOT send Sec-CH-UA headers. If we send Sec-CH-UA="Google Chrome"
        #   + navigator.userAgentData, Adsterra classifies the visit as Chrome
        #   instead of Facebook (which is what the UA string says via FBAN/FBAV).
        #   Real FB IAB: no Client Hints at all → Adsterra falls through to UA
        #   string parsing → sees FBAN → classifies as "Facebook" browser. ✅
        is_firefox = fingerprint.get("is_firefox", False)
        is_safari = fingerprint.get("is_safari", False)
        is_fb_iab = fingerprint.get("is_fb_iab", False)
        
        if is_firefox:
            # Firefox Accept header (no image/avif, no image/webp priority)
            return {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": ", ".join(
                    f"{lang};q={round(1.0 - i * 0.1, 1)}" for i, lang in enumerate(fingerprint["languages"])
                ),
                "Accept-Encoding": "gzip, deflate, br",
                "Connection": "keep-alive",
                # Firefox does NOT send any Sec-CH-UA headers
                # Firefox does NOT send Upgrade-Insecure-Requests (it handles it differently)
                "Upgrade-Insecure-Requests": "1",
            }
        
        if is_safari:
            # Safari Accept header (slightly different from Chrome)
            return {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": ", ".join(
                    f"{lang};q={round(1.0 - i * 0.1, 1)}" for i, lang in enumerate(fingerprint["languages"])
                ),
                "Accept-Encoding": "gzip, deflate, br",
                "Connection": "keep-alive",
                # Safari does NOT send any Sec-CH-UA headers
                "Upgrade-Insecure-Requests": "1",
            }
        
        if is_fb_iab:
            # v14.0 — Facebook in-app browser: FULLY authentic headers
            # Meta's embedded Chromium strips:
            #   - navigator.userAgentData (no Client Hints at all)
            #   - Sec-CH-UA headers (all variants)
            #   - Sec-Fetch-Site, Sec-Fetch-Mode, Sec-Fetch-Dest (Meta strips these)
            # Without ANY Client Hints, Adsterra falls through to UA parsing →
            # sees FBAN/FBAV → correctly classifies as "Facebook" browser. ✅
            return {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
                "Accept-Language": ", ".join(
                    f"{lang};q={round(1.0 - i * 0.1, 1)}" for i, lang in enumerate(fingerprint["languages"])
                ),
                "Accept-Encoding": "gzip, deflate, br, zstd",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
                # v14.0: NO Sec-CH-UA headers — real FB IAB doesn't send them
                # v14.0: NO Sec-Fetch-* headers — Meta strips these from FB IAB
            }

        # Sec-CH-UA — short form
        is_samsung = fingerprint.get("is_samsung_internet", False)
        samsung_ver_str = fingerprint.get("samsung_browser_ver", "25.0")
        samsung_major = samsung_ver_str.split(".")[0] if samsung_ver_str else "25"
        
        if is_edge:
            brands = f'"Not.A/Brand";v="24", "Chromium";v="{chrome_ver}", "Microsoft Edge";v="{chrome_ver}"'
            full_brands = f'"Not.A/Brand";v="24.0.0.0", "Chromium";v="{chrome_full}", "Microsoft Edge";v="{chrome_full}"'
        elif is_samsung:
            brands = f'"Samsung Internet";v="{samsung_major}", "Chromium";v="{chrome_ver}", "Not;A=Brand";v="99"'
            full_brands = f'"Samsung Internet";v="{samsung_ver_str}", "Chromium";v="{chrome_full}", "Not;A=Brand";v="99.0.0.0"'
        else:
            brands = f'"Google Chrome";v="{chrome_ver}", "Chromium";v="{chrome_ver}", "Not?A_Brand";v="99"'
            full_brands = f'"Google Chrome";v="{chrome_full}", "Chromium";v="{chrome_full}", "Not?A_Brand";v="99.0.0.0"'

        # Platform
        # v13.0 FIX: platform_version is now decided ONCE by fingerprint.py
        # (per-visit, with real OS-version variety) and threaded through —
        # this HTTP header MUST use that exact same value that the JS-level
        # navigator.userAgentData override uses (_build_client_hints_js
        # below), otherwise the HTTP Sec-CH-UA-Platform-Version header and
        # the JS getHighEntropyValues() result would silently disagree,
        # which is a detectable client-hints mismatch. Falls back to a
        # sane fixed default only if an older/foreign fingerprint dict
        # happens not to carry the field.
        fp_plat_ver = fingerprint.get("platform_version")
        if fingerprint["platform"] == "Win32":
            plat = '"Windows"'
            plat_ver = f'"{fp_plat_ver}"' if fp_plat_ver else '"15.0.0"'
        elif fingerprint["platform"] == "MacIntel":
            plat = '"macOS"'
            plat_ver = f'"{fp_plat_ver}"' if fp_plat_ver else '"14.0.0"'
        elif fingerprint["platform"] == "Linux x86_64":
            plat = '"Linux"'
            plat_ver = f'"{fp_plat_ver}"' if fp_plat_ver else '"6.5.0"'
        elif fingerprint["platform"] == "Linux armv8l":
            plat = '"Android"'
            if fp_plat_ver:
                plat_ver = f'"{fp_plat_ver}"'
            else:
                # Android version from UA
                av_match = _re.search(r"Android (\d+)", ua)
                av = av_match.group(1) if av_match else "13"
                plat_ver = f'"{av}.0.0"'
        elif fingerprint["platform"] == "iPhone":
            plat = '"iOS"'
            plat_ver = f'"{fp_plat_ver}"' if fp_plat_ver else '"17.5.0"'
        else:
            plat = '"Windows"'
            plat_ver = f'"{fp_plat_ver}"' if fp_plat_ver else '"15.0.0"'

        # ── CRITICAL FIX: removed Sec-Fetch-* + Upgrade-Insecure-Requests ──
        # context.set_extra_http_headers() applies these headers to EVERY
        # request from this browser context — NOT just the main page
        # navigation, but every single image, script, CSS, and XHR request
        # too. Real Chrome varies Sec-Fetch-Dest per request type
        # automatically (document nav -> "document", <img> -> "image",
        # <script> -> "script", fetch/XHR -> "empty", etc). By forcing
        # "Sec-Fetch-Dest: document" as a blanket header, EVERY image
        # request on the page was claiming to be a top-level navigation —
        # a real browser never does this. Many ad-image CDNs (hotlink/anti-
        # bot protected, common on adult/gambling ad campaigns) explicitly
        # check this header and reject image requests that don't look like
        # real <img> fetches — which is exactly why images were rendering
        # as broken icons while the page HTML/layout loaded fine.
        # Chromium's own network stack ALREADY sets these headers correctly
        # per-request-type natively — we don't need to (and shouldn't)
        # override them with a single static value for the whole context.
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": ", ".join(
                f"{lang};q={round(1.0 - i * 0.1, 1)}" for i, lang in enumerate(fingerprint["languages"])
            ),
            "Accept-Encoding": "gzip, deflate, br, zstd",  # v13.7.7: Chromium/Chrome 120+ sends zstd
            "Connection": "keep-alive",
            # Client Hints — these MUST match the spoofed UA
            "Sec-CH-UA": brands,
            "Sec-CH-UA-Mobile": "?1" if is_mobile else "?0",
            "Sec-CH-UA-Platform": plat,
            # Full version list (Chrome 131+ sends this)
            "Sec-CH-UA-Full-Version-List": full_brands,
            # Platform version
            "Sec-CH-UA-Platform-Version": plat_ver,
        }

        if is_mobile:
            headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            # Sec-CH-UA-Model: real Android Chrome sends the device model name
            # in this header (e.g. "Samsung Galaxy S21"). Its absence on a
            # mobile UA is a detection signal — ad networks know no real
            # Android Chrome omits it.
            model = fingerprint.get("device_model", "")
            if model:
                headers["Sec-CH-UA-Model"] = f'"{model}"'

        return headers

    def _build_native_ua_metadata(self, fingerprint):
        """v16 — Build the CDP Network.setUserAgentOverride payload.

        WHY THIS EXISTS: v15 forced every ads/smartlink visit onto the
        REAL installed Chrome binary (fixes the bundled-Chromium TLS/H2
        fingerprint mismatch). But that creates a NEW problem: Chromium's
        OWN internal Client Hints engine natively reports the ONE true
        installed Chrome version in navigator.userAgentData AND in the
        Sec-CH-UA family of headers for every single request — UNLESS
        something overrides it. Since it's the same real binary on every
        visit, without this override EVERY visit from this machine would
        report the exact same Chrome build, and (worse) our separately
        spoofed UA string / Sec-CH-UA headers (which DO vary per visit per
        fingerprint.generate()) would silently disagree with the real
        browser's own native navigator.userAgentData — a classic UA vs
        Client-Hints MISMATCH that is the single most reliable automated-
        traffic signal used by modern anti-fraud gates (exactly the kind
        of gate guarding a smartlink's /api/users?token=... endpoint).

        Network.setUserAgentOverride is a native CDP command — Chromium's
        own C++ layer regenerates navigator.userAgentData AND the wire
        Sec-CH-UA headers from the values given here, for every future
        request on this page. This is NOT a JS Object.defineProperty patch
        (which leaves forensic fingerprints — toString mismatches, extra
        prototype properties, etc.) — the browser's real internal state is
        changed, so every surface (JS object + HTTP headers) agrees
        automatically and natively, with no detectable patch artifact.

        This also directly satisfies "every visit's Chrome version must be
        unique" — each visit calls fingerprint_gen.generate() independently
        (picks its own random Chrome major/full version, platform version,
        device model), and THIS override makes the one real Chrome binary
        faithfully present that random identity on every surface a site
        can inspect — real engine, unique self-reported version per visit."""
        import re as _re
        ua = fingerprint.get("user_agent", "")
        is_mobile = fingerprint.get("is_mobile", False)
        is_edge = fingerprint.get("is_edge", False)
        is_samsung = fingerprint.get("is_samsung_internet", False)

        # v209: prefer the fingerprint's own realistic full build (e.g.
        # '142.0.7442.24'). Since UA strings are reduced to 'x.0.0.0',
        # parsing the UA for a full version now yields the useless
        # '142.0.0.0' — real Chromium reports its true full build ONLY in
        # the high-entropy hints, which is exactly what we mirror here.
        _fp_full = fingerprint.get("chrome_full_version") or ""
        m = _re.search(r"Chrome/(\d+)\.(\d+)\.(\d+)\.(\d+)", ua)
        if m:
            chrome_ver = m.group(1)
            # keep the UA's major — the full build MUST share it
            if _fp_full.startswith(chrome_ver + "."):
                chrome_full = _fp_full
            else:
                chrome_full = f"{m.group(1)}.{m.group(2)}.{m.group(3)}.{m.group(4)}"
        else:
            m2 = _re.search(r"Chrome/(\d+)", ua)
            chrome_ver = m2.group(1) if m2 else "131"
            if _fp_full.startswith(chrome_ver + "."):
                chrome_full = _fp_full
            else:
                chrome_full = f"{chrome_ver}.0.0.0"

        samsung_ver_str = fingerprint.get("samsung_browser_ver", "25.0")
        samsung_major = samsung_ver_str.split(".")[0] if samsung_ver_str else "25"

        if is_edge:
            brands = [
                {"brand": "Not.A/Brand", "version": "24"},
                {"brand": "Chromium", "version": chrome_ver},
                {"brand": "Microsoft Edge", "version": chrome_ver},
            ]
            full_brands = [
                {"brand": "Not.A/Brand", "version": "24.0.0.0"},
                {"brand": "Chromium", "version": chrome_full},
                {"brand": "Microsoft Edge", "version": chrome_full},
            ]
        elif is_samsung:
            brands = [
                {"brand": "Samsung Internet", "version": samsung_major},
                {"brand": "Chromium", "version": chrome_ver},
                {"brand": "Not;A=Brand", "version": "99"},
            ]
            full_brands = [
                {"brand": "Samsung Internet", "version": samsung_ver_str},
                {"brand": "Chromium", "version": chrome_full},
                {"brand": "Not;A=Brand", "version": "99.0.0.0"},
            ]
        else:
            brands = [
                {"brand": "Google Chrome", "version": chrome_ver},
                {"brand": "Chromium", "version": chrome_ver},
                {"brand": "Not?A_Brand", "version": "99"},
            ]
            full_brands = [
                {"brand": "Google Chrome", "version": chrome_full},
                {"brand": "Chromium", "version": chrome_full},
                {"brand": "Not?A_Brand", "version": "99.0.0.0"},
            ]

        fp_plat_ver = fingerprint.get("platform_version")
        plat_raw = fingerprint.get("platform", "Win32")
        if plat_raw == "Win32":
            cdp_platform, arch, bitness = "Windows", "x86", "64"
            plat_ver = fp_plat_ver or "15.0.0"
        elif plat_raw == "MacIntel":
            cdp_platform, arch, bitness = "macOS", "arm", "64"
            plat_ver = fp_plat_ver or "14.0.0"
        elif plat_raw == "Linux x86_64":
            cdp_platform, arch, bitness = "Linux", "x86", "64"
            plat_ver = fp_plat_ver or "6.5.0"
        elif plat_raw == "Linux armv8l":
            cdp_platform, arch, bitness = "Android", "arm", "64"
            if fp_plat_ver:
                plat_ver = fp_plat_ver
            else:
                av_match = _re.search(r"Android (\d+)", ua)
                plat_ver = f"{av_match.group(1) if av_match else '13'}.0.0"
        else:
            cdp_platform, arch, bitness = "Windows", "x86", "64"
            plat_ver = fp_plat_ver or "15.0.0"

        model = fingerprint.get("device_model", "") if is_mobile else ""

        return {
            "userAgent": ua,
            "platform": cdp_platform,
            "userAgentMetadata": {
                "brands": brands,
                "fullVersionList": full_brands,
                "fullVersion": chrome_full,
                "platform": cdp_platform,
                "platformVersion": plat_ver,
                "architecture": arch,
                "model": model,
                "mobile": bool(is_mobile),
                "bitness": bitness,
            },
        }

    def _build_client_hints_js(self, fingerprint):
        """v12.0 — build a JS snippet overriding navigator.userAgentData so
        it matches the SAME brands/platform/mobile values already sent in
        the HTTP Sec-CH-UA headers (_build_headers above).
        
        v13.7.5 — Firefox + Safari do NOT have navigator.userAgentData.
        Returning None skips the init script entirely, which is correct
        (real Firefox/Safari don't expose this API at all)."""

        # v13.7.5 — Firefox + Safari genuinely never shipped navigator.
        # userAgentData at all (totally different real engines) — None
        # (no init script) is correct and already matches real behavior.
        if fingerprint.get("is_firefox", False) or fingerprint.get("is_safari", False):
            return None

        # v17 BUG FOUND — this was the actual reason Adsterra NEVER showed
        # a single "Facebook" row despite every UA/header fix: the old
        # v13.7.6 code (just below, now removed) assumed returning None
        # here meant navigator.userAgentData would simply be "absent", like
        # real Meta WebView. That's false on a REAL Chrome binary (forced
        # since v15) — real Chrome ALWAYS natively implements
        # navigator.userAgentData (standard API since Chrome 89), so
        # returning None left it fully intact, truthfully reporting
        # "Google Chrome" brands straight from the real engine. Any ad
        # script that checks `if (navigator.userAgentData)` before falling
        # back to UA-string parsing sees a real, defined object → classifies
        # as Chrome Mobile, completely ignoring the FBAN/FB4A token in the
        # UA string. This explains the exact symptom: Chrome Mobile +
        # Mobile Safari show up on Adsterra, "Facebook" never does.
        # Fix: explicitly shadow it to `undefined` for FB IAB, so a page
        # script's `navigator.userAgentData` check is false and it falls
        # through to UA-string parsing (which now correctly says Facebook).
        if fingerprint.get("is_fb_iab", False):
            return """
            (function(){
                try {
                    Object.defineProperty(navigator, 'userAgentData', {
                        get: function(){ return undefined; },
                        configurable: true
                    });
                } catch(e) {}
            })();
            """

        # Why this is needed: real Chromium's OWN navigator.userAgentData
        import re as _re
        import json as _json
        try:
            ua = fingerprint.get("user_agent", "")
            _fp_full = fingerprint.get("chrome_full_version") or ""
            chrome_ver = "150"
            chrome_full = "150.0.0.0"
            m = _re.search(r"Chrome/(\d+)\.(\d+)\.(\d+)", ua)
            if m:
                chrome_ver = m.group(1)
                # v209: UA is reduced ('x.0.0.0') so the full version must
                # come from the fingerprint's own realistic build, and it
                # must carry the same major as the UA.
                if _fp_full.startswith(chrome_ver + "."):
                    chrome_full = _fp_full
                else:
                    chrome_full = f"{chrome_ver}.0.0.0"
            else:
                m2 = _re.search(r"Chrome/(\d+)", ua)
                if m2:
                    chrome_ver = m2.group(1)
                    if _fp_full.startswith(chrome_ver + "."):
                        chrome_full = _fp_full
                    else:
                        chrome_full = f"{chrome_ver}.0.0.0"
            is_edge = fingerprint.get("is_edge", False)
            is_mobile = bool(fingerprint.get("is_mobile", False))

            # v13.0 FIX: same single-source-of-truth platform_version used by
            # _build_headers above — guarantees the JS-level
            # navigator.userAgentData.getHighEntropyValues() result can never
            # drift out of sync with the real HTTP Sec-CH-UA-Platform-Version
            # header sent for this exact visit.
            fp_plat_ver = fingerprint.get("platform_version")
            plat_map = {
                "Win32": ("Windows", "15.0.0"),
                "MacIntel": ("macOS", "14.0.0"),
                "Linux x86_64": ("Linux", "6.5.0"),
                "Linux armv8l": ("Android", None),  # version resolved from UA below
                "iPhone": ("iOS", "17.5.0"),
            }
            plat, plat_ver_default = plat_map.get(fingerprint.get("platform", ""), ("Windows", "15.0.0"))
            if fp_plat_ver:
                plat_ver = fp_plat_ver
            elif plat == "Android":
                av_match = _re.search(r"Android (\d+)", ua)
                plat_ver = f"{av_match.group(1)}.0.0" if av_match else "13.0.0"
            else:
                plat_ver = plat_ver_default

            is_samsung = fingerprint.get("is_samsung_internet", False)
            samsung_ver_str = fingerprint.get("samsung_browser_ver", "25.0")
            samsung_major = samsung_ver_str.split(".")[0] if samsung_ver_str else "25"
            
            if is_edge:
                brands_list = [
                    {"brand": "Not.A/Brand", "version": "24"},
                    {"brand": "Chromium", "version": chrome_ver},
                    {"brand": "Microsoft Edge", "version": chrome_ver},
                ]
            elif is_samsung:
                brands_list = [
                    {"brand": "Samsung Internet", "version": samsung_major},
                    {"brand": "Chromium", "version": chrome_ver},
                    {"brand": "Not;A=Brand", "version": "99"},
                ]
            else:
                brands_list = [
                    {"brand": "Google Chrome", "version": chrome_ver},
                    {"brand": "Chromium", "version": chrome_ver},
                    {"brand": "Not?A_Brand", "version": "99"},
                ]

            model = fingerprint.get("device_model", "") if is_mobile else ""
            architecture = "" if is_mobile else ("arm" if plat == "macOS" else "x86")
            bitness = "" if is_mobile else "64"

            # v209: build the real fullVersionList here (Python side) — each
            # REAL brand carries the full build; the "Not" placeholder brand
            # keeps its own frozen version. The old JS-side hack appended
            # '.0.0.0' to every major, which reported '142.0.0.0' where real
            # Chromium reports e.g. '142.0.7442.24'.
            _full_brand_ver = chrome_full
            full_version_list = [
                {"brand": b["brand"],
                 "version": _full_brand_ver if b["version"] == chrome_ver and not b["brand"].startswith("Not")
                 else b["version"] + ".0.0.0"}
                for b in brands_list
            ]
            payload = _json.dumps({
                "brands": brands_list,
                "mobile": is_mobile,
                "platform": plat,
                "platformVersion": plat_ver,
                "architecture": architecture,
                "bitness": bitness,
                "model": model,
                "uaFullVersion": chrome_full,
                "fullVersionList": full_version_list,
            })

            return """
            (function() {
                try {
                    const HINTS = """ + payload + """;
                    const uaData = {
                        brands: HINTS.brands,
                        mobile: HINTS.mobile,
                        platform: HINTS.platform,
                        toJSON: function() {
                            return { brands: HINTS.brands, mobile: HINTS.mobile, platform: HINTS.platform };
                        },
                        getHighEntropyValues: function(hints) {
                            const full = {
                                brands: HINTS.brands,
                                mobile: HINTS.mobile,
                                platform: HINTS.platform,
                                platformVersion: HINTS.platformVersion,
                                architecture: HINTS.architecture,
                                bitness: HINTS.bitness,
                                model: HINTS.model,
                                uaFullVersion: HINTS.uaFullVersion,
                                fullVersionList: HINTS.fullVersionList,
                            };
                            const result = {};
                            const keys = (hints && hints.length) ? hints : Object.keys(full);
                            keys.forEach(function(k) { if (k in full) result[k] = full[k]; });
                            return Promise.resolve(result);
                        },
                    };
                    if (navigator.userAgentData) {
                        Object.defineProperty(navigator, 'userAgentData', { get: function() { return uaData; }, configurable: true });
                    }
                } catch (e) { /* never break the page over a client-hints patch */ }
            })();
            """
        except Exception:
            # Any unexpected fingerprint shape — skip the override entirely
            # rather than risk crashing the visit over a cosmetic patch.
            return ""

    async def _find_and_click_target(self, page, visit_mode):
        """v10.5 — Find and click a button, link, or Facebook embed on the
        landing page. Returns True if something was clicked, False otherwise.
        Tries multiple strategies in order:
          1. Facebook embed selectors (if fb_embed mode)
          2. Button text match (if button_text configured)
          3. Custom CSS selector (if button_selector configured)
          4. Generic CTA fallback (any btn/button/cta/download element)"""
        button_text = self.config.get("button_text", "")
        button_selector = self.config.get("button_selector", "")

        # ── Strategy 1: Facebook Embed ──
        if visit_mode == "fb_embed":
            self.log("[CLICK] 🔍 Looking for Facebook embed element...")
            fb_selectors = [
                "iframe[src*='facebook.com']",
                ".fb-post a",
                ".fb-post",
                "iframe[src*='plugins']",
                "a[href*='facebook.com']",
                "a[href*='l.facebook.com']",
                "div[class*='fb-'] a",
                "blockquote[class*='fb-'] a",
            ]
            for sel in fb_selectors:
                try:
                    el = await page.wait_for_selector(sel, timeout=5000)
                    if el:
                        self.log(f"[CLICK] ✅ Found FB embed: {sel}")
                        await el.scroll_into_view_if_needed()
                        await asyncio.sleep(max(0.2, min(0.8, random.gauss(0.45, 0.1))))
                        await el.click()
                        return True
                except Exception:
                    continue
            self.log("[CLICK] ⚠ No Facebook embed found, trying button text...")

        # ── Strategy 2: Button Text Match ──
        if button_text:
            self.log(f"[CLICK] 🔍 Looking for button/link: '{button_text}'...")
            try:
                found = await page.evaluate("""(btnText) => {
                    const lower = btnText.toLowerCase().trim();
                    const elements = document.querySelectorAll(
                        'a, button, span, div, input[type=submit], input[type=button], [role=button]'
                    );
                    // Exact match first
                    for (const el of elements) {
                        const text = (el.textContent || el.value || '').trim().toLowerCase();
                        if (text === lower) {
                            el.setAttribute('data-bot-target', 'true');
                            return 'exact';
                        }
                    }
                    // Contains match
                    for (const el of elements) {
                        const text = (el.textContent || el.value || '').trim().toLowerCase();
                        if (text && text.includes(lower) && text.length < 100) {
                            el.setAttribute('data-bot-target', 'true');
                            return 'contains';
                        }
                    }
                    return null;
                }""", button_text)
                if found:
                    el = await page.query_selector('[data-bot-target="true"]')
                    if el:
                        await el.scroll_into_view_if_needed()
                        await asyncio.sleep(max(0.2, min(0.8, random.gauss(0.45, 0.1))))
                        await el.click()
                        self.log(f"[CLICK] ✅ Clicked button: '{button_text}' ({found} match)")
                        return True
            except Exception as e:
                self.log(f"[CLICK] ⚠ Button text search error: {str(e)[:60]}")

        # ── Strategy 3: Custom CSS Selector ──
        if button_selector:
            self.log(f"[CLICK] 🔍 Looking for CSS selector: '{button_selector}'...")
            try:
                el = await page.wait_for_selector(button_selector, timeout=8000)
                if el:
                    await el.scroll_into_view_if_needed()
                    await asyncio.sleep(max(0.2, min(0.8, random.gauss(0.45, 0.1))))
                    await el.click()
                    self.log(f"[CLICK] ✅ Clicked selector: '{button_selector}'")
                    return True
            except Exception as e:
                self.log(f"[CLICK] ⚠ CSS selector not found: {str(e)[:60]}")

        # ── Strategy 4: Generic CTA Fallback ──
        self.log("[CLICK] 🔍 Trying generic CTA elements...")
        cta_selectors = [
            "a[class*='btn']", "button[class*='btn']",
            "a[class*='button']", "button[class*='button']",
            ".cta", "#cta", ".download-btn", ".watch-btn",
            ".continue-btn", ".play-btn", ".start-btn",
            "input[type=submit]", "input[type=button]",
            "a[href*='continue']", "a[href*='download']", "a[href*='watch']",
        ]
        for sel in cta_selectors:
            try:
                el = await page.query_selector(sel)
                if el:
                    await el.scroll_into_view_if_needed()
                    await asyncio.sleep(max(0.2, min(0.8, random.gauss(0.45, 0.1))))
                    await el.click()
                    self.log(f"[CLICK] ✅ Clicked CTA: {sel}")
                    return True
            except Exception:
                continue

        self.log("[CLICK] ❌ No clickable element found on landing page")
        return False

    @staticmethod
    def _domain_matches(href, target_domain):
        """v13.2 — Search Click domain matcher. Compares a SERP result's
        href against the target domain (e.g. "elitecaresolutions.blogspot.com").
        Matches on exact host or host-ending (covers subdomains), never on
        substring-of-path (avoids false positives from query strings).
        Also unwraps Google's older "/url?q=<real_url>" redirect format —
        some result types (ads-adjacent, cached, etc.) still use it even
        though most organic results now link directly."""
        def _host_of(u):
            try:
                h = urlparse(u).netloc.lower().split(":")[0]
                return h[4:] if h.startswith("www.") else h
            except Exception:
                return ""

        try:
            parsed = urlparse(href)
            host = _host_of(href)
            target = target_domain.lower()
            if target.startswith("www."):
                target = target[4:]

            if host and (host == target or host.endswith("." + target)):
                return True

            # Unwrap /url?q=<real> style Google redirect links
            if "google." in host:
                from urllib.parse import parse_qs
                qs = parse_qs(parsed.query)
                real = (qs.get("q") or qs.get("url") or [None])[0]
                if real:
                    real_host = _host_of(real)
                    return bool(real_host) and (real_host == target or real_host.endswith("." + target))
            return False
        except Exception:
            return False

    async def _search_click_target(self, page, target_domain, nav_timeout=15000):
        """v13.2 — Search Click mode. On an already-loaded real Google SERP,
        scans every result link for one whose domain matches `target_domain`,
        scrolls it into view, and does a real human-like click. Returns True
        if a match was found and clicked, False otherwise (caller falls back
        to the normal direct-referer flow — this only works reliably for
        pages that are ACTUALLY indexed by Google, e.g. the user's own blog;
        smartlinks/redirect links are almost never indexed, so a miss here
        is expected and handled gracefully, not an error)."""
        try:
            # Google sometimes shows a cookie/consent wall first (mostly EU
            # IPs) — try to dismiss it so it doesn't block the result links.
            for consent_sel in ["#L2AGLb", "button:has-text('Accept all')", "button:has-text('I agree')"]:
                try:
                    btn = await page.query_selector(consent_sel)
                    if btn:
                        await btn.click()
                        await asyncio.sleep(max(0.2, min(1.0, random.gauss(0.6, 0.15))))
                        break
                except Exception:
                    continue

            try:
                await page.wait_for_selector("#search a, #rso a", timeout=nav_timeout)
            except Exception:
                self.log("[SEARCH] ⚠ Google results didn't load in time (possible CAPTCHA/consent wall)")
                return False

            hrefs = await page.eval_on_selector_all(
                "#search a[href], #rso a[href]",
                "els => els.map(e => e.href)"
            )
            match_href = next((h for h in hrefs if self._domain_matches(h, target_domain)), None)

            if not match_href:
                self.log(f"[SEARCH] ⚠ '{target_domain}' not found in top results — not indexed for this keyword, falling back")
                return False

            el = await page.query_selector(f"a[href='{match_href}']")
            if not el:
                return False
            self.log(f"[SEARCH] ✅ Found target in results — clicking through: {match_href[:70]}")
            await el.scroll_into_view_if_needed()
            await asyncio.sleep(max(0.3, min(1.5, random.gauss(0.8, 0.2))))
            await el.click()
            return True
        except Exception as e:
            self.log(f"[SEARCH] ⚠ Search-click error: {str(e)[:80]}")
            return False

    async def _pre_browse_google(self, page, nav_timeout=15000):
        """Briefly visit google.com before the real target — makes the
        browser history look organic (real users come from search, not
        about:blank). v10.4: now waits for full load + adds human-like
        mouse movement + short scroll, and doesn't log failure loudly.
        v13.6: heavy resource blocking active — saves ~70% bandwidth."""
        if self.native_engine:
            # v208: native mode — the pre-browse page loads fully like a
            # real browser; the kernel media block (already applied to this
            # page at creation) is all the protection we need.
            self.log("[NAV] 🔎 Pre-browsing google.com (native mode, zero interception)...")
        try:
            if not self.native_engine:
                await _setup_resource_blocking(page, "google.com", mode="prebrowse")
            await page.goto("https://www.google.com/", wait_until="domcontentloaded", timeout=nav_timeout)
            # Wait a moment for the page to settle
            await asyncio.sleep(max(0.5, min(2.5, random.gauss(1.2, 0.3))))
            try:
                # Human-like: move mouse to search area, maybe scroll
                await page.mouse.move(random.randint(200, 600), random.randint(150, 400))
                await asyncio.sleep(max(0.1, min(0.7, random.gauss(0.35, 0.1))))
                if random.random() < 0.5:
                    await page.mouse.wheel(0, random.randint(150, 300))
                    await asyncio.sleep(max(0.2, min(1.2, random.gauss(0.5, 0.15))))  # v13.7.4 Gaussian
            except Exception:
                pass
            await asyncio.sleep(max(0.2, min(1.2, random.gauss(0.5, 0.15))))  # v13.7.4 Gaussian
        except Exception:
            # Pre-browse is optional — if it fails (e.g. proxy blocks Google),
            # we just skip it silently and go straight to the target. The
            # preflight already confirmed the tunnel works.
            pass

    async def _seed_storage(self, context, fingerprint, target_domain):
        """Pre-seed cookies on target domain for returning visitor illusion."""
        try:
            if random.random() > 0.4 or not target_domain:
                return
            if not target_domain.startswith("."):
                if target_domain.count(".") > 1:
                    parts = target_domain.split(".")
                    cookie_domain = "." + ".".join(parts[-2:])
                else:
                    cookie_domain = "." + target_domain
            else:
                cookie_domain = target_domain

            await context.add_cookies([{
                "name": "_ga",
                "value": f"GA1.2.{random.randint(100000000, 999999999)}.{random.randint(1000000000, 1999999999)}",
                "domain": cookie_domain,
                "path": "/",
                "expires": int(time.time()) + 86400 * 365,
            }])
        except Exception:
            pass

    async def _full_cleanup(self, page, context, temp_dir):
        """Complete cleanup — close context/browser + wipe temp_dir.
        v1.82 FIX: Force-kill browser process by PID if context.close() hangs.
        Windows headed Chrome/Edge commonly blocks on CDP graceful close —
        we now capture the PID up-front and use taskkill /F as guarantee."""

        # ── 0. Capture browser PID + browser object before any close attempt ──
        # For launch() mode: context._s2c_browser is the Browser object (has .process.pid)
        # For launch_persistent_context mode: try internal attrs as fallback
        _browser_pid = None
        _s2c_browser = None  # v1.84: unused (launch_persistent_context)
        try:
            if context:
                # v1.82: launch() mode → explicit _s2c_browser attr
                _s2c_browser = getattr(context, "_s2c_browser", None)
                if _s2c_browser:
                    _proc = getattr(_s2c_browser, "process", None)
                    if _proc and hasattr(_proc, "pid"):
                        _browser_pid = _proc.pid
                else:
                    # launch_persistent_context mode → dig into internals
                    _bp = getattr(context, "_browser", None) or getattr(context, "browser", None)
                    if _bp:
                        _proc = getattr(_bp, "process", None)
                        if _proc and hasattr(_proc, "pid"):
                            _browser_pid = _proc.pid
        except Exception:
            pass

        # ── 1. Clear cookies and storage (best-effort) ────────────────────
        try:
            if context:
                await context.clear_cookies()
        except Exception:
            pass

        # ── 2. Clear page state (best-effort) ────────────────────────────
        try:
            if page and not page.is_closed():
                await page.evaluate("() => { try { localStorage.clear(); sessionStorage.clear(); } catch(e) {} }")
        except Exception:
            pass

        # ── 3. Close context with 4s timeout → force-kill on hang ────────
        # NOTE: This runs ONLY after the visit is fully complete (after
        # human.simulate_session finishes + dwell time). It does NOT
        # affect the visit duration — it's purely cleanup.
        # Windows headed Chrome/Edge blocks context.close() waiting for UI.
        # We use a 4s timeout then hard-kill the process.
        try:
            if context:
                try:
                    await asyncio.wait_for(context.close(), timeout=4.0)
                except (asyncio.TimeoutError, Exception) as _ce:
                    self.log(f"[CLEANUP] context.close() hung ({type(_ce).__name__}) — force-killing (PID={_browser_pid})")
                    await self._force_kill_browser(_browser_pid, temp_dir)

            # (launch_persistent_context mode — no separate browser object to close)
        except Exception:
            await self._force_kill_browser(_browser_pid, temp_dir)

        # ── 4. Force-remove user data directory ───────────────────────────
        if temp_dir:
            for _attempt in range(3):
                try:
                    shutil.rmtree(temp_dir, ignore_errors=True)
                    if not os.path.exists(temp_dir):
                        break
                    import subprocess as _sp2
                    if sys.platform.startswith("win"):
                        _sp2.run(["cmd", "/c", "rd", "/s", "/q", temp_dir],
                                 capture_output=True, timeout=5)
                    else:
                        _sp2.run(["rm", "-rf", temp_dir], capture_output=True, timeout=5)
                except Exception:
                    pass
                await asyncio.sleep(0.3)

    async def _force_kill_browser(self, pid=None, temp_dir=None):
        """v1.82: Hard-kill browser process.
        Strategy (in order):
        1. If PID known: taskkill /F /PID (Windows) or SIGKILL (Linux)
        2. If temp_dir known: use psutil to find process with --user-data-dir=temp_dir
        3. Last resort: nothing (don't kill by name — too aggressive)
        psutil match is 100% safe — only kills the EXACT browser that owns this temp_dir."""
        import subprocess as _sp
        import signal as _signal

        killed = False

        # ── Strategy 1: Kill by PID ──
        if pid:
            try:
                if sys.platform.startswith("win"):
                    _r = _sp.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                                 capture_output=True, timeout=5)
                    killed = _r.returncode == 0
                else:
                    os.kill(pid, _signal.SIGKILL)
                    killed = True
            except Exception:
                pass

        # ── Strategy 2: Find by user-data-dir via psutil ──
        if not killed and temp_dir:
            try:
                import psutil as _ps
                _browser_names = {"chrome.exe", "msedge.exe", "firefox.exe",
                                  "chromium.exe", "chrome", "firefox", "chromium"}
                for _proc in _ps.process_iter(["pid", "name", "cmdline"]):
                    try:
                        _pname = (_proc.info.get("name") or "").lower()
                        _pname_base = _pname.replace(".exe", "")
                        if _pname_base not in {"chrome", "msedge", "firefox", "chromium"}:
                            continue
                        _cmdline = " ".join(_proc.info.get("cmdline") or [])
                        # Match: --user-data-dir exactly contains our temp_dir
                        if temp_dir in _cmdline:
                            try:
                                if sys.platform.startswith("win"):
                                    _sp.run(["taskkill", "/F", "/T", "/PID", str(_proc.info["pid"])],
                                            capture_output=True, timeout=5)
                                else:
                                    _proc.kill()
                                self.log(f"[CLEANUP] 🔪 Force-killed {_pname} (PID={_proc.info['pid']}) via psutil")
                                killed = True
                            except Exception:
                                pass
                    except (_ps.NoSuchProcess, _ps.AccessDenied):
                        pass
            except ImportError:
                pass  # psutil not installed — skip

    def stop(self):
        self.is_running = False
        self.log("[SYS] 🛑 Stopping bot...")

    def pause(self):
        self.is_paused = True
        self.log("[SYS] ⏸ Bot paused")

    def resume(self):
        self.is_paused = False
        self.log("[SYS] ▶ Bot resumed")
