"""
Proxy Manager Module v5.0 — 1 IP = 1 Visit = 1 Device
Handles residential proxy rotation with strict single-use policy.

v5.0 fix:
- Gateway-style proxies (NodeMaven, Bright Data, Oxylabs etc.) all share ONE
  hostname (e.g. gate.nodemaven.com) but carry a unique session id inside the
  username (sid-xxxxx). The old version deduped purely by "ip", which for
  gateway proxies is the same hostname for every line — collapsing 10 unique
  session proxies down to just 1. Fixed by deriving a "unique_key" that uses
  the session id (or full username) when the host is a gateway domain, and
  falls back to the literal IP for direct ip:port proxies.

Key features:
- 1 unique proxy (by session/IP) = 1 visit only (no reuse)
- Duplicate detection that works for BOTH direct IPs and gateway proxies
- Auto-remove used proxies from pool
- Geo country tracking for fingerprint matching
- Proxy health scoring
- Real-time stats for UI
"""

import random
import asyncio
import re
from typing import Optional


class ProxyManager:
    """Manages proxy rotation — strict 1 unique-proxy = 1 visit policy."""

    def __init__(self, proxy_list: list):
        self.proxies = []          # Available (not yet used)
        self.used_proxies = []     # Successfully used
        self.failed_proxies = set() # Failed/broken (by unique_key)
        self.used_ips = set()      # Set of unique_keys already used (for dedup)
        self.consumed_ips = []     # List of IPs consumed (for UI sync, newest first)
        # v12.0: proxies "checked out" but not yet marked used/failed. Needed
        # for concurrent visits (multiple lanes running at once) — get_proxy()
        # has an async validation step AFTER it returns a proxy but BEFORE
        # mark_used()/mark_failed() is called, so without this a second
        # concurrent lane could grab the SAME proxy while the first lane is
        # still mid-validation. In sequential mode (1 lane) this is always
        # empty by the time the next get_proxy() call happens, so it's a
        # complete no-op there — zero behavior change for existing usage.
        self.reserved_ips = set()

        seen_keys = set()
        for idx, proxy in enumerate(proxy_list):
            parsed = self._parse_proxy(proxy.strip(), line_index=idx)
            if parsed:
                # Dedup by unique_key (session id for gateway proxies, else ip).
                # NOTE: rotating-gateway lines with no sid pin get a per-line
                # unique_key from _parse_proxy itself (see there), so they are
                # NEVER collapsed here even if the raw text is byte-identical.
                if parsed["unique_key"] not in seen_keys:
                    self.proxies.append(parsed)
                    seen_keys.add(parsed["unique_key"])

        # Don't shuffle — use in order (UI shows numbered list)

    @staticmethod
    def _extract_session_id(username: str) -> Optional[str]:
        """Extract a sticky-session id from a gateway proxy username, if present.
        Supports common provider patterns: sid-xxxx, session-xxxx, session_id-xxxx.
        """
        if not username:
            return None
        m = re.search(r"(?:sid|session|session[_-]?id)[-_]([a-zA-Z0-9]+)", username, re.IGNORECASE)
        if m:
            return m.group(1)
        return None

    @staticmethod
    def _is_gateway_host(ip: str) -> bool:
        """Gateway-style hosts are hostnames (not raw IPv4), e.g. gate.nodemaven.com."""
        if not ip:
            return False
        # A raw IPv4 address means it's a direct proxy, not a shared gateway
        return not re.match(r"^\d{1,3}(\.\d{1,3}){3}$", ip)

    def _parse_proxy(self, proxy_str: str, line_index: int = 0) -> Optional[dict]:
        """Parse proxy string into structured format."""
        try:
            proxy_str = proxy_str.strip()
            if not proxy_str:
                return None

            protocol = "http"
            for proto in ["https://", "http://", "socks5://", "socks4://"]:
                if proxy_str.startswith(proto):
                    protocol = proto.replace("://", "")
                    proxy_str = proxy_str[len(proto):]
                    break

            parsed = None

            # host,port,user,pass — Bright Data / SuperProxy export format
            # (e.g. "brd.superproxy.io,33335,brd-customer-hl_xxx-zone-residential_proxy1,pass").
            # CRITICAL FIX: this format was NEVER recognized before — the
            # parser only understood colon-delimited forms. Since this line
            # has ZERO colons, _parse_proxy fell through every branch below
            # and returned None for EVERY pasted line, silently dropping the
            # whole pool (self.proxies ended up empty) with no error shown
            # to the user — the dashboard just showed all rows stuck on
            # "Checking" forever because zero proxies were ever actually
            # sent to the validator.
            if parsed is None and "," in proxy_str and ":" not in proxy_str:
                cparts = [p.strip() for p in proxy_str.split(",")]
                if len(cparts) == 4:
                    ip, port, user, pwd = cparts
                    if port.isdigit():
                        parsed = {
                            "server": f"{protocol}://{ip}:{port}",
                            "username": user,
                            "password": pwd,
                            "raw": proxy_str,
                            "ip": ip,
                            "port": int(port),
                            "protocol": protocol,
                            "country": None,
                            "line_index": line_index,
                        }
                elif len(cparts) == 2 and cparts[1].isdigit():
                    ip, port = cparts
                    parsed = {
                        "server": f"{protocol}://{ip}:{port}",
                        "username": None,
                        "password": None,
                        "raw": proxy_str,
                        "ip": ip,
                        "port": int(port),
                        "protocol": protocol,
                        "country": None,
                        "line_index": line_index,
                    }

            # user:pass@ip:port  (or user:pass@host:port) — and the
            # REVERSED form ip:port@user:pass (ProxyCompass export format,
            # e.g. "140.235.168.63:8080@USN4R9HZE:iPpvmIPq"). Previously only
            # the standard order was handled — the reversed form silently
            # parsed the credentials as if they were the host:port (port
            # became a non-numeric string like "iPpvmIPq"), int(port) then
            # raised ValueError which the outer try/except swallowed,
            # dropping every line and leaving the pool empty (same class of
            # bug as the earlier comma-format and Bright-Data fixes).
            if parsed is None and "@" in proxy_str:
                left, right = proxy_str.rsplit("@", 1)

                def _try_hostport(s):
                    parts = s.split(":")
                    if len(parts) == 2 and parts[1].isdigit():
                        return parts[0], parts[1]
                    return None

                # Standard order: user:pass@host:port (right side is host:port)
                hp = _try_hostport(right)
                if hp:
                    ip, port = hp
                    user, pwd = left.split(":", 1) if ":" in left else (left, "")
                # Reversed order: host:port@user:pass (left side is host:port)
                else:
                    hp = _try_hostport(left)
                    if hp:
                        ip, port = hp
                        user, pwd = right.split(":", 1) if ":" in right else (right, "")
                    else:
                        ip = port = user = pwd = None

                if ip and port:
                    parsed = {
                        "server": f"{protocol}://{ip}:{port}",
                        "username": user,
                        "password": pwd,
                        "raw": proxy_str,
                        "ip": ip,
                        "port": int(port),
                        "protocol": protocol,
                        "country": None,
                        "line_index": line_index,
                    }

            # ip:port:user:pass  (or host:port:user:pass — gateway style)
            if parsed is None:
                parts = proxy_str.split(":")
                if len(parts) == 4:
                    ip, port, user, pwd = parts
                    parsed = {
                        "server": f"{protocol}://{ip}:{port}",
                        "username": user,
                        "password": pwd,
                        "raw": proxy_str,
                        "ip": ip,
                        "port": int(port),
                        "protocol": protocol,
                        "country": None,
                        "line_index": line_index,
                    }

            # ip:port
            if parsed is None:
                parts = proxy_str.split(":")
                if len(parts) == 2:
                    ip, port = parts
                    parsed = {
                        "server": f"{protocol}://{ip}:{port}",
                        "username": None,
                        "password": None,
                        "raw": proxy_str,
                        "ip": ip,
                        "port": int(port),
                        "protocol": protocol,
                        "country": None,
                        "line_index": line_index,
                    }

            if parsed is None:
                return None

            # ── Determine unique_key: session id for gateway proxies, else ip ──
            session_id = self._extract_session_id(parsed.get("username") or "")
            is_gateway = self._is_gateway_host(parsed["ip"])
            parsed["is_gateway"] = is_gateway
            # v10.2: sticky_session = True only when a real sid-xxxx pin was
            # found. This tells bot_engine.py whether a validate-then-launch
            # sequence is safe to trust (sticky = same backend IP both times)
            # or NOT (rotating, no pin = validator and browser get DIFFERENT
            # backend IPs from the pool on their separate connections).
            parsed["sticky_session"] = bool(session_id)
            if session_id and is_gateway:
                parsed["unique_key"] = f"{parsed['ip']}::{session_id}"
                parsed["display_ip"] = f"{parsed['ip']} (sid:{session_id[:8]})"
            elif is_gateway and parsed.get("username"):
                # Gateway host but NO recognizable session id (no sid-xxxx pin).
                # CRITICAL FIX: this means the proxy is a pure ROTATING gateway
                # (NodeMaven, Smartproxy, Oxylabs, etc.) — every fresh connection
                # through this exact same host:port:user:pass gets handed a
                # DIFFERENT backend residential/mobile IP automatically. Pasting
                # the identical line N times is the correct, intended way to
                # request N separate rotations — it is NOT a duplicate.
                # Previously this used f"{ip}::{username}" as the key, which is
                # IDENTICAL for every pasted line -> silently collapsed 4 lines
                # down to 1 proxy in self.proxies (only line #1 ever got used).
                # Fix: make the key unique per pasted line (by position), so
                # every rotation the user asked for is actually kept and used.
                parsed["unique_key"] = f"{parsed['ip']}::{parsed['username']}::rot{line_index}"
                # v10.2: show a rotation marker so the dashboard/logs make it
                # visually obvious that each row is a DIFFERENT rotation
                # through the gateway (different real backend IP), even
                # though the literal host string is identical for all of
                # them. Without this, the UI looked like "same IP visited
                # 3 times" when really it was 3 different backend IPs.
                parsed["display_ip"] = f"{parsed['ip']} (rotation #{line_index + 1})"
            else:
                # Direct IP proxy — the IP itself is unique
                parsed["unique_key"] = parsed["ip"]
                parsed["display_ip"] = parsed["ip"]

            return parsed
        except Exception:
            return None

    def get_proxy(self) -> Optional[dict]:
        """Get next available proxy — 1 unique proxy = 1 visit, no reuse.
        v12.0: atomically reserves the proxy (synchronously, before any
        await can happen) so concurrent visit lanes can never both receive
        the same proxy, even though there's an async validation step
        between get_proxy() and mark_used()/mark_failed()."""
        available = [
            p for p in self.proxies
            if p["unique_key"] not in self.failed_proxies
            and p["unique_key"] not in self.used_ips
            and p["unique_key"] not in self.reserved_ips
        ]

        if not available:
            return None

        proxy = available[0]
        self.reserved_ips.add(proxy["unique_key"])
        return proxy

    def release_proxy(self, proxy: dict):
        """v12.0: release a reservation without marking used/failed (rarely
        needed — mark_used/mark_failed already supersede a reservation)."""
        if proxy:
            self.reserved_ips.discard(proxy.get("unique_key"))

    def mark_used(self, proxy: dict):
        """Mark a proxy as successfully used — remove from pool permanently."""
        if proxy:
            key = proxy["unique_key"]
            self.used_ips.add(key)
            self.reserved_ips.discard(key)
            self.used_proxies.append(proxy)
            self.consumed_ips.insert(0, proxy.get("display_ip", proxy["ip"]))
            self.proxies = [p for p in self.proxies if p["unique_key"] != key]

    def mark_failed(self, proxy: dict):
        """Mark a proxy as failed/broken — remove from pool."""
        if proxy:
            key = proxy["unique_key"]
            self.failed_proxies.add(key)
            self.used_ips.add(key)
            self.reserved_ips.discard(key)
            self.proxies = [p for p in self.proxies if p["unique_key"] != key]

    def get_consumed_ips(self) -> list:
        """Get list of IPs/session-keys that have been used (for UI sync)."""
        return self.consumed_ips[:20]

    def get_stats(self) -> dict:
        return {
            "total": len(self.proxies) + len(self.used_proxies) + len(self.failed_proxies),
            "used": len(self.used_proxies),
            "failed": len(self.failed_proxies),
            "available": len(self.proxies),
        }
