"""
Fingerprint Generation & Spoofing Module — v13.0
160+ Android models (2019-2025), weighted toward mid-old.
100% internally consistent. Real Chrome version sync. CSS pixel screen fix.
v13.0: WebGL renderer pools split PER-OS (Windows=D3D11, macOS=Metal,
Linux=native GL) — fixes a real cross-OS GPU/UA mismatch. Windows pool
expanded (more GPUs + resolutions + weighted OS-build variety). Desktop
platform_version is now a single source of truth shared by the HTTP
Sec-CH-UA-Platform-Version header AND the JS navigator.userAgentData
override, so they can never drift out of sync on any visit.
Each visit: unique device generated -> used -> destroyed.
"""

import random
import json
import hashlib
import uuid
import re
import subprocess
import platform

# ─── Detect real Chrome version (cross-platform: Windows/Mac/Linux) ────────
def _get_real_chrome_version():
    system = platform.system()

    if system == "Windows":
        try:
            import winreg
            for hive, path in [
                (winreg.HKEY_CURRENT_USER, r"Software\Google\Chrome\BLBeacon"),
                (winreg.HKEY_LOCAL_MACHINE, r"Software\Google\Chrome\BLBeacon"),
                (winreg.HKEY_LOCAL_MACHINE, r"Software\WOW6432Node\Google\Chrome\BLBeacon"),
            ]:
                try:
                    key = winreg.OpenKey(hive, path)
                    version, _ = winreg.QueryValueEx(key, "version")
                    m = re.match(r'(\d+)\.', version)
                    if m:
                        return int(m.group(1))
                except Exception:
                    continue
        except Exception:
            pass

    elif system == "Darwin":
        for p in ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]:
            try:
                out = subprocess.check_output([p, "--version"], stderr=subprocess.DEVNULL, timeout=5).decode()
                m = re.search(r'(\d+)\.', out)
                if m:
                    return int(m.group(1))
            except Exception:
                continue

    else:  # Linux and other Unix
        for cmd in ["google-chrome", "google-chrome-stable", "chromium-browser", "chromium"]:
            try:
                out = subprocess.check_output([cmd, "--version"], stderr=subprocess.DEVNULL, timeout=5).decode()
                m = re.search(r'(\d+)\.', out)
                if m:
                    return int(m.group(1))
            except Exception:
                continue

    return 150  # last-resort fallback if nothing above detects a real Chrome

REAL_CHROME_VER = _get_real_chrome_version()

# v5.3.1: Realistic Chrome version POOL (not unique per visit!)
# Real Chrome auto-updates ALL users to the SAME version. At any given time,
# 95%+ of users share one exact version. Only 2-3 versions exist in the wild
# due to staggered rollout. Generating 1000 unique versions for 1000 visits
# is UNREALISTIC and a detection red flag.
# Solution: pick 3-5 realistic versions at import time, reuse across visits.
_CHROME_VERSION_POOL = [
    f"{REAL_CHROME_VER}.5578.207",
    f"{REAL_CHROME_VER}.6918.95",
    f"{REAL_CHROME_VER}.6373.219",
    f"{REAL_CHROME_VER}.5495.192",
    f"{REAL_CHROME_VER}.6832.247",
]

# v1.84: Weighted Chrome version pool — realistic market share distribution.
# Real-world: NOT everyone uses the exact same Chrome version. During rollout
# periods, older versions coexist. Most-used version gets the most visits.
# Versions: current (detected), current-1, current-2, current-3, current-4
# Weights: 50%, 25%, 12%, 8%, 5%
_CHROME_MAJOR_WEIGHTS = [50, 25, 12, 8, 5]

def _gen_chrome_full_version():
    """v1.84: Return a realistic Chrome version with weighted distribution.
    Most visits use the latest stable (50%), rest spread across older versions.
    Build/patch numbers come from the realistic pool above."""
    # Pick a major version (weighted)
    major = REAL_CHROME_VER - random.choices(
        [0, 1, 2, 3, 4], weights=_CHROME_MAJOR_WEIGHTS, k=1
    )[0]
    if major < 100:
        major = REAL_CHROME_VER  # don't go too old
    # Pick a build/patch from the pool, but swap in the chosen major
    _build_patch = random.choice(["5578.207", "6918.95", "6373.219", "5495.192", "6832.247"])
    return f"{major}.{_build_patch}"

# Keep REAL_CHROME_FULL as fallback for module-level UA strings
REAL_CHROME_FULL = f"{REAL_CHROME_VER}.0.0.0"

# ─── Detect which browser channels are ACTUALLY installed on this machine ──
# (Item 2 fix: don't report "Edge" in the UA/fingerprint unless we can really
# launch real Edge for that visit — otherwise the declared UA/Sec-CH-UA won't
# match the real TLS/HTTP2 stack that Chromium serves, which is a detectable
# inconsistency.)
import shutil as _shutil

def _detect_edge_channel():
    for name in ("microsoft-edge-stable", "microsoft-edge", "microsoft-edge-dev", "msedge"):
        if _shutil.which(name):
            return name
    return None

EDGE_BINARY = _detect_edge_channel()
EDGE_AVAILABLE = EDGE_BINARY is not None

# ─── UA pools — ALL synced to real Chrome version ───────────────────────────
UA_CHROME_WIN = [
    f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{REAL_CHROME_FULL} Safari/537.36",
]
UA_CHROME_MAC = [
    f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{REAL_CHROME_FULL} Safari/537.36",
    f"Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{REAL_CHROME_FULL} Safari/537.36",
]
UA_CHROME_LINUX = [
    f"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{REAL_CHROME_FULL} Safari/537.36",
    f"Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{REAL_CHROME_FULL} Safari/537.36",
]
UA_EDGE_WIN = [
    f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{REAL_CHROME_FULL} Safari/537.36 Edg/{REAL_CHROME_FULL}",
]

# ─── v13.7.5 — Firefox + Safari desktop UA pools ──────────────────────────
# Real Firefox versions (current stable range)
FF_VER_POOL = random.choice([
    "133.0", "134.0", "135.0", "136.0", "137.0", "138.0", "139.0", "140.0"
])
UA_FIREFOX_WIN = [
    f"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{FF_VER_POOL}) Gecko/20100101 Firefox/{FF_VER_POOL}",
    f"Mozilla/5.0 (Windows NT 10.0; rv:{FF_VER_POOL}) Gecko/20100101 Firefox/{FF_VER_POOL}",
]
UA_FIREFOX_MAC = [
    f"Mozilla/5.0 (Macintosh; Intel Mac OS X 14.7; rv:{FF_VER_POOL}) Gecko/20100101 Firefox/{FF_VER_POOL}",
    f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:{FF_VER_POOL}) Gecko/20100101 Firefox/{FF_VER_POOL}",
]
UA_FIREFOX_LINUX = [
    f"Mozilla/5.0 (X11; Linux x86_64; rv:{FF_VER_POOL}) Gecko/20100101 Firefox/{FF_VER_POOL}",
    f"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:{FF_VER_POOL}) Gecko/20100101 Firefox/{FF_VER_POOL}",
]

# Safari desktop (Mac only — Safari doesn't exist on Windows/Linux)
# Real Safari versions track macOS releases
SAFARI_VER = random.choice(["17.4", "17.5", "17.6", "18.0", "18.1", "18.2"])
SAFARI_WEBKIT = random.choice([
    "605.1.15", "619.2.8", "619.1.26", "619.1.18", "619.1.15", "618.2.12"
])
UA_SAFARI_MAC = [
    f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/{SAFARI_WEBKIT} (KHTML, like Gecko) Version/{SAFARI_VER} Safari/605.1.15",
    f"Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7) AppleWebKit/{SAFARI_WEBKIT} (KHTML, like Gecko) Version/{SAFARI_VER} Safari/605.1.15",
    f"Mozilla/5.0 (Macintosh; Intel Mac OS X 15_1) AppleWebKit/{SAFARI_WEBKIT} (KHTML, like Gecko) Version/{SAFARI_VER} Safari/605.1.15",
]

# ─── Android profiles — 70+ models spanning 2019-2025 ──────────────────────
# Each entry: model, brand, gpu_vendor, gpu_renderer, mem(GB), cores, density(DPR), width(px), height(px), touch, year, tier
# tier: "budget" | "mid" | "flagship" — used for weighted selection

ANDROID_PROFILES = [
    # ===== 2019 (old) — budget + mid =====
    {"model":"SM-A107F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G72 MP3, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"SM-A207F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G71 MP2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"SM-A505F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G72 MP3, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2019,"tier":"mid"},
    {"model":"SM-A307FN","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G71 MP2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2019,"tier":"mid"},
    {"model":"SM-G970F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G76 MP12, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2019,"tier":"flagship"},
    {"model":"SM-G973F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G76 MP12, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2019,"tier":"flagship"},
    {"model":"Redmi 7","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 506, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"Redmi Note 7","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 512, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2019,"tier":"mid"},
    {"model":"Mi A2","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 512, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2160,"touch":5,"year":2019,"tier":"mid"},
    {"model":"realme C2","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"realme 5","brand":"realme","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"moto g7","brand":"motorola","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 506, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2270,"touch":5,"year":2019,"tier":"mid"},

    # ===== 2020 (old) — budget + mid + flagship =====
    {"model":"SM-A115F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"SM-A205F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"SM-A315F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2020,"tier":"mid"},
    {"model":"SM-A515F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MP5, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2020,"tier":"mid"},
    {"model":"SM-G780F","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 650, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2020,"tier":"flagship"},
    {"model":"SM-G998B","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G78 MP14, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.5,"width":1440,"height":3200,"touch":5,"year":2020,"tier":"flagship"},
    {"model":"SM-N986B","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G78 MP14, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2020,"tier":"flagship"},
    {"model":"Redmi 9","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2020,"tier":"budget"},
    {"model":"Redmi Note 9","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2020,"tier":"mid"},
    {"model":"Redmi Note 9 Pro","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 618, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2020,"tier":"mid"},
    {"model":"POCO X3 NFC","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 618, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2020,"tier":"mid"},
    {"model":"realme C25","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"realme 7","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2020,"tier":"mid"},
    {"model":"moto g9 play","brand":"motorola","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"Pixel 4a","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 618, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2020,"tier":"mid"},
    {"model":"Pixel 5","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 620, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2020,"tier":"mid"},

    # ===== 2021 (mid-old) — budget + mid + flagship =====
    {"model":"SM-A035F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"SM-A125F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"SM-A325F","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2021,"tier":"mid"},
    {"model":"SM-A525F","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},
    {"model":"SM-G991B","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G78 MP14, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"flagship"},
    {"model":"Redmi Note 10","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},
    {"model":"Redmi 10","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"Redmi Note 10 Pro","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 618, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},
    {"model":"realme C21","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"realme 8","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},
    {"model":"moto g31","brand":"motorola","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"budget"},
    {"model":"moto g50","brand":"motorola","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},
    {"model":"Pixel 6","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G78 MP20, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"flagship"},
    {"model":"Pixel 5a","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 620, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},

    # ===== 2022 (mid-old) — heaviest weight =====
    {"model":"SM-A145F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"SM-A235F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2022,"tier":"mid"},
    {"model":"SM-A546B","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 642L, OpenGL ES 3.1)","mem":6,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2022,"tier":"mid"},
    {"model":"SM-S908B","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 730, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2022,"tier":"flagship"},
    {"model":"2201117TI","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"22111317I","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"mid"},
    {"model":"Redmi Note 11","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"mid"},
    {"model":"realme C53","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"RMX3630","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"moto g73 5G","brand":"motorola","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"mid"},
    {"model":"moto g14","brand":"motorola","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"Pixel 7","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G710 MC10, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"flagship"},
    {"model":"Pixel 6a","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G78 MP23, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"mid"},

    # ===== 2023 (mid) =====
    {"model":"SM-A055F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},
    {"model":"SM-M145F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},
    {"model":"SM-S911B","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 740, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2023,"tier":"flagship"},
    {"model":"23106RN0BC","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},
    {"model":"23117RK66C","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},
    {"model":"realme C55","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},
    {"model":"realme 11","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G610 MC4, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2023,"tier":"mid"},
    {"model":"moto g84 5G","brand":"motorola","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"mid"},
    {"model":"Pixel 8","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G715 MC9, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"flagship"},
    {"model":"CPH2409","brand":"OPPO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},
    {"model":"V2250","brand":"vivo","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"mid"},
    {"model":"23143RN24L","brand":"Redmi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},

    # ===== 2024-2025 (new) — lowest weight =====
    {"model":"SM-S928B","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 750, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.5,"width":1440,"height":3120,"touch":5,"year":2024,"tier":"flagship"},
    {"model":"SM-S918B","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 740, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.5,"width":1440,"height":3120,"touch":5,"year":2024,"tier":"flagship"},
    {"model":"SM-A556B","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G715 MC9, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2024,"tier":"mid"},
    {"model":"SM-A356E","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2024,"tier":"mid"},
    {"model":"SM-A256E","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2024,"tier":"budget"},
    {"model":"Xiaomi 14","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 750, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.5,"width":1440,"height":3200,"touch":5,"year":2024,"tier":"flagship"},
    {"model":"23127PN0CC","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 720, OpenGL ES 3.1)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"flagship"},
    {"model":"realme 12","brand":"realme","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 710, OpenGL ES 3.1)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2024,"tier":"mid"},
    {"model":"Pixel 8a","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G715 MC9, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},
    {"model":"Pixel 8 Pro","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G715 MC9, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.25,"width":1344,"height":2992,"touch":5,"year":2024,"tier":"flagship"},
    {"model":"CPH2611","brand":"OPPO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 720, OpenGL ES 3.1)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2024,"tier":"mid"},
    {"model":"V2254","brand":"vivo","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 710, OpenGL ES 3.1)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},

    # ═══ EXPANDED POOL — more models within existing brands, weighted toward 2019-2024 mid/old devices ═══
    # ===== 2019 additions =====
    {"model":"SM-J415F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G71 MP2, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"SM-M105F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G72 MP3, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"Redmi 8","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"Redmi Y3","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 506, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"realme 3 Pro","brand":"realme","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 616, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2019,"tier":"mid"},
    {"model":"realme U1","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G72 MP3, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"moto e6 plus","brand":"motorola","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 308, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"moto g7 power","brand":"motorola","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 506, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"CPH1901","brand":"OPPO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 506, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"CPH1937","brand":"OPPO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 612, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2019,"tier":"mid"},
    {"model":"PD1901","brand":"vivo","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 506, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"PD1731","brand":"vivo","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 505, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2019,"tier":"mid"},
    {"model":"Pixel 3a","brand":"google","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 615, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2220,"touch":5,"year":2019,"tier":"mid"},

    # ===== 2020 additions =====
    {"model":"SM-A013F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1560,"touch":5,"year":2020,"tier":"budget"},
    {"model":"SM-M215F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G72 MP3, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2020,"tier":"mid"},
    {"model":"Redmi 9A","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC1, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"Redmi 9C","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"realme 6","brand":"realme","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 618, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2020,"tier":"mid"},
    {"model":"realme Narzo 10","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"moto e7 plus","brand":"motorola","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"moto g8 power","brand":"motorola","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2300,"touch":5,"year":2020,"tier":"mid"},
    {"model":"CPH2015","brand":"OPPO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1560,"touch":5,"year":2020,"tier":"budget"},
    {"model":"CPH2127","brand":"OPPO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2020,"tier":"mid"},
    {"model":"PD2034","brand":"vivo","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"PD2058","brand":"vivo","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},

    # ===== 2021 additions =====
    {"model":"SM-M127F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"SM-A225F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G68 MP4, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},
    {"model":"Redmi 9T","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 618, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"POCO M3","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},
    {"model":"realme 8i","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},
    {"model":"realme Narzo 30","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"moto g60","brand":"motorola","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 618, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},
    {"model":"moto e40","brand":"motorola","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"CPH2239","brand":"OPPO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"CPH2219","brand":"OPPO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},
    {"model":"PD2107","brand":"vivo","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"PD2109","brand":"vivo","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},

    # ===== 2022 additions =====
    {"model":"SM-A047F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G31 MP2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"SM-M336B","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"mid"},
    {"model":"Redmi 10C","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1650,"touch":5,"year":2022,"tier":"budget"},
    {"model":"POCO M4 Pro","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"mid"},
    {"model":"realme 9i","brand":"realme","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"mid"},
    {"model":"realme Narzo 50A","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"moto g52","brand":"motorola","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"mid"},
    {"model":"moto e22","brand":"motorola","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"CPH2385","brand":"OPPO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"CPH2363","brand":"OPPO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G68 MC4, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"mid"},
    {"model":"PD2196","brand":"vivo","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2022,"tier":"budget"},
    {"model":"PD2229","brand":"vivo","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2022,"tier":"budget"},

    # ===== 2023 additions =====
    {"model":"SM-A146B","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},
    {"model":"SM-M346B","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G68 MP2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2023,"tier":"mid"},
    {"model":"Redmi 12C","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC1, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1650,"touch":5,"year":2023,"tier":"budget"},
    {"model":"POCO M5","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"mid"},
    {"model":"realme Narzo 60","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G68 MC4, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"mid"},
    {"model":"realme C67","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},
    {"model":"moto g54","brand":"motorola","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G68 MC4, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"mid"},
    {"model":"moto e13","brand":"motorola","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},
    {"model":"CPH2565","brand":"OPPO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2023,"tier":"mid"},
    {"model":"PD2295","brand":"vivo","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2388,"touch":5,"year":2023,"tier":"mid"},
    {"model":"Pixel 7a","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G710 MC7, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"mid"},

    # ===== 2024 additions =====
    {"model":"SM-A057F","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2024,"tier":"budget"},
    {"model":"SM-M156B","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},
    {"model":"Redmi 13C","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2024,"tier":"budget"},
    {"model":"POCO M6","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},
    {"model":"realme Narzo 70","brand":"realme","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 710, OpenGL ES 3.1)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2024,"tier":"mid"},
    {"model":"realme C65","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2024,"tier":"budget"},
    {"model":"moto g05","brand":"motorola","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2024,"tier":"budget"},
    {"model":"moto g55","brand":"motorola","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G615 MC2, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},
    {"model":"CPH2591","brand":"OPPO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2024,"tier":"mid"},
    {"model":"PD2296","brand":"vivo","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},

    # ===== 2025 additions — newest/latest generation models =====
    {"model":"SM-S938B","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 830, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.5,"width":1440,"height":3120,"touch":5,"year":2025,"tier":"flagship"},
    {"model":"SM-S931B","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 830, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2025,"tier":"flagship"},
    {"model":"SM-A566B","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G615 MC2, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2025,"tier":"mid"},
    {"model":"Xiaomi 15","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 830, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.5,"width":1440,"height":3200,"touch":5,"year":2025,"tier":"flagship"},
    {"model":"Redmi Note 14","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"mid"},
    {"model":"realme 13 Pro","brand":"realme","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 710, OpenGL ES 3.1)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2025,"tier":"mid"},
    {"model":"CPH2641","brand":"OPPO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 710, OpenGL ES 3.1)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2025,"tier":"mid"},
    {"model":"V2309","brand":"vivo","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 720, OpenGL ES 3.1)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"mid"},
    {"model":"moto edge 50","brand":"motorola","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 710, OpenGL ES 3.1)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"mid"},
    {"model":"Pixel 9","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G715 MC7, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"flagship"},
    {"model":"Pixel 9 Pro","brand":"google","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G715 MC7, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"flagship"},
    # ===== HUAWEI =====
    {"model":"ELE-L29","brand":"HUAWEI","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G76 MC10, OpenGL ES 3.2)","mem":6,"cores":8,"density":3.0,"width":1080,"height":2340,"touch":5,"year":2019,"tier":"flagship"},
    {"model":"VOG-L29","brand":"HUAWEI","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G76 MC10, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2240,"touch":5,"year":2019,"tier":"flagship"},
    {"model":"ANA-NX9","brand":"HUAWEI","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G77 MC8, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.0,"width":1080,"height":2340,"touch":5,"year":2020,"tier":"flagship"},
    {"model":"JNY-LX1","brand":"HUAWEI","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G51 MP4, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1560,"touch":5,"year":2021,"tier":"budget"},
    {"model":"NEN-LX1","brand":"HUAWEI","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"CRT-LX1","brand":"HUAWEI","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},
    {"model":"RKY-LX1","brand":"HUAWEI","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2388,"touch":5,"year":2024,"tier":"mid"},

    # ===== HONOR =====
    {"model":"HRY-LX1","brand":"HONOR","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G51 MP4, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"DUA-LX9","brand":"HONOR","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G51 MP4, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"AKA-L29","brand":"HONOR","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G76 MC4, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2310,"touch":5,"year":2020,"tier":"mid"},
    {"model":"NTH-NX9","brand":"HONOR","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 660, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2376,"touch":5,"year":2021,"tier":"flagship"},
    {"model":"ANY-LX1","brand":"HONOR","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"REA-NX9","brand":"HONOR","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G610 MC6, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2376,"touch":5,"year":2023,"tier":"mid"},
    {"model":"CLK-LX1","brand":"HONOR","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G615 MC6, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2024,"tier":"mid"},
    {"model":"BVL-N49","brand":"HONOR","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G720 MC10, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.0,"width":1080,"height":2412,"touch":5,"year":2025,"tier":"flagship"},

    # ===== OnePlus =====
    {"model":"GM1910","brand":"OnePlus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 640, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2019,"tier":"flagship"},
    {"model":"HD1910","brand":"OnePlus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 650, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2020,"tier":"flagship"},
    {"model":"LE2115","brand":"OnePlus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 660, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"flagship"},
    {"model":"CPH2399","brand":"OnePlus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 660, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2022,"tier":"mid"},
    {"model":"CPH2449","brand":"OnePlus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 730, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2023,"tier":"mid"},
    {"model":"CPH2581","brand":"OnePlus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 750, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.5,"width":1440,"height":3168,"touch":5,"year":2024,"tier":"flagship"},
    {"model":"CPH2659","brand":"OnePlus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 830, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2025,"tier":"flagship"},

    # ===== Nokia =====
    {"model":"Nokia 4.2","brand":"Nokia","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 504, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"Nokia 6.2","brand":"Nokia","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2280,"touch":5,"year":2019,"tier":"mid"},
    {"model":"Nokia 5.3","brand":"Nokia","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"Nokia 3.4","brand":"Nokia","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 504, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1560,"touch":5,"year":2020,"tier":"budget"},
    {"model":"Nokia G20","brand":"Nokia","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"Nokia G21","brand":"Nokia","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"Nokia G42 5G","brand":"Nokia","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2408,"touch":5,"year":2023,"tier":"mid"},
    {"model":"Nokia G310","brand":"Nokia","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2408,"touch":5,"year":2024,"tier":"budget"},

    # ===== Tecno =====
    {"model":"TECNO KB8","brand":"TECNO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"TECNO LC7","brand":"TECNO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2021,"tier":"budget"},
    {"model":"TECNO BG6","brand":"TECNO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2022,"tier":"budget"},
    {"model":"TECNO BG7n","brand":"TECNO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2023,"tier":"budget"},
    {"model":"TECNO BH6","brand":"TECNO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2023,"tier":"budget"},
    {"model":"TECNO BH8n","brand":"TECNO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},
    {"model":"TECNO BI9n","brand":"TECNO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"mid"},

    # ===== Infinix =====
    {"model":"Infinix X655C","brand":"Infinix","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":2,"cores":8,"density":2.0,"width":720,"height":1560,"touch":5,"year":2020,"tier":"budget"},
    {"model":"Infinix X690B","brand":"Infinix","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2021,"tier":"budget"},
    {"model":"Infinix X6511","brand":"Infinix","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2022,"tier":"budget"},
    {"model":"Infinix X6525","brand":"Infinix","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2022,"tier":"budget"},
    {"model":"Infinix X6712","brand":"Infinix","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2023,"tier":"budget"},
    {"model":"Infinix X6835","brand":"Infinix","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},
    {"model":"Infinix X6881","brand":"Infinix","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"mid"},

    # ===== itel =====
    {"model":"itel A48","brand":"itel","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":2,"cores":4,"density":1.5,"width":480,"height":960,"touch":5,"year":2020,"tier":"budget"},
    {"model":"itel S16","brand":"itel","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":2,"cores":4,"density":2.0,"width":720,"height":1560,"touch":5,"year":2021,"tier":"budget"},
    {"model":"itel A23s","brand":"itel","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":2,"cores":4,"density":1.5,"width":480,"height":960,"touch":5,"year":2021,"tier":"budget"},
    {"model":"itel A70","brand":"itel","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2023,"tier":"budget"},
    {"model":"itel A80","brand":"itel","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2024,"tier":"budget"},
    {"model":"itel S25","brand":"itel","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2025,"tier":"budget"},

    # ===== ZTE =====
    {"model":"ZTE Blade V10","brand":"ZTE","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G72 MP3, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2019,"tier":"mid"},
    {"model":"ZTE Blade A71","brand":"ZTE","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"ZTE Blade A52","brand":"ZTE","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":2,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2022,"tier":"budget"},
    {"model":"ZTE Blade V41 Smart","brand":"ZTE","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2023,"tier":"budget"},
    {"model":"ZTE Blade A75","brand":"ZTE","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2024,"tier":"budget"},
    {"model":"ZTE Blade V60 Design","brand":"ZTE","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"mid"},

    # ===== Sony =====
    {"model":"XQ-AT52","brand":"Sony","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 640, OpenGL ES 3.2)","mem":6,"cores":8,"density":3.0,"width":1080,"height":2520,"touch":5,"year":2020,"tier":"flagship"},
    {"model":"XQ-BC72","brand":"Sony","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 660, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.0,"width":1080,"height":2520,"touch":5,"year":2021,"tier":"flagship"},
    {"model":"XQ-BE72","brand":"Sony","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 730, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.0,"width":1080,"height":2520,"touch":5,"year":2022,"tier":"flagship"},
    {"model":"XQ-DQ72","brand":"Sony","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 740, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.0,"width":1080,"height":2520,"touch":5,"year":2023,"tier":"flagship"},
    {"model":"XQ-EC72","brand":"Sony","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 750, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.0,"width":1080,"height":2520,"touch":5,"year":2024,"tier":"flagship"},
    {"model":"XQ-FV72","brand":"Sony","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 830, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.0,"width":1080,"height":2520,"touch":5,"year":2025,"tier":"flagship"},

    # ===== ASUS =====
    {"model":"ASUS_X00TD","brand":"asus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 506, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.75,"width":1080,"height":2160,"touch":5,"year":2019,"tier":"mid"},
    {"model":"ASUS_X01BDA","brand":"asus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"ASUS_I003D","brand":"asus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 650, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2021,"tier":"flagship"},
    {"model":"ASUS_AI2201","brand":"asus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 730, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2448,"touch":5,"year":2022,"tier":"flagship"},
    {"model":"ASUS_AI2302","brand":"asus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 740, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"flagship"},
    {"model":"ASUS_AI2401_B","brand":"asus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 750, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"flagship"},
    {"model":"ASUS_AI2501","brand":"asus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 830, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"flagship"},

    # ===== Lenovo =====
    {"model":"Lenovo K10 Plus","brand":"Lenovo","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 506, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1520,"touch":5,"year":2019,"tier":"budget"},
    {"model":"Lenovo K12 Pro","brand":"Lenovo","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2020,"tier":"budget"},
    {"model":"Lenovo K13 Note","brand":"Lenovo","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2021,"tier":"budget"},
    {"model":"Lenovo K14 Plus","brand":"Lenovo","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2022,"tier":"budget"},
    {"model":"Lenovo K15 Plus","brand":"Lenovo","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.0,"width":720,"height":1612,"touch":5,"year":2023,"tier":"budget"},
    {"model":"Lenovo K16","brand":"Lenovo","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},

    # ===== Meizu =====
    {"model":"Meizu Note 9","brand":"Meizu","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 512, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2244,"touch":5,"year":2019,"tier":"mid"},
    {"model":"Meizu 17","brand":"Meizu","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 650, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2020,"tier":"flagship"},
    {"model":"Meizu 18","brand":"Meizu","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 660, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"flagship"},
    {"model":"Meizu 20","brand":"Meizu","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 740, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"flagship"},
    {"model":"Meizu 21","brand":"Meizu","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 750, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"flagship"},

    # ===== Nothing =====
    {"model":"A063","brand":"Nothing","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 650, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"flagship"},
    {"model":"A065","brand":"Nothing","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 730, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"mid"},
    {"model":"A142","brand":"Nothing","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G610 MC6, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.625,"width":1080,"height":2412,"touch":5,"year":2023,"tier":"mid"},
    {"model":"A059","brand":"Nothing","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 750, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2412,"touch":5,"year":2025,"tier":"flagship"},
    {"model":"A166","brand":"Nothing","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 619, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2412,"touch":5,"year":2024,"tier":"mid"},
    {"model":"A067","brand":"Nothing","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 750, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2412,"touch":5,"year":2025,"tier":"flagship"},

    # ===== POCO (Xiaomi sub-brand — separate brand entry) =====
    {"model":"POCO X2","brand":"POCO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 620, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2020,"tier":"mid"},
    {"model":"POCO M2 Pro","brand":"POCO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 618, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2020,"tier":"mid"},
    {"model":"POCO X3 Pro","brand":"POCO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 650, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"mid"},
    {"model":"POCO F3","brand":"POCO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 650, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2021,"tier":"flagship"},
    {"model":"POCO X4 Pro 5G","brand":"POCO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 642L, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"mid"},
    {"model":"POCO F4","brand":"POCO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 650, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2022,"tier":"flagship"},
    {"model":"POCO X5 Pro 5G","brand":"POCO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 730, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"mid"},
    {"model":"POCO F5","brand":"POCO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 730, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"flagship"},
    {"model":"POCO X6 Pro 5G","brand":"POCO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G920 MC11, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},
    {"model":"POCO F6","brand":"POCO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 750, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"flagship"},
    {"model":"POCO X7 Pro","brand":"POCO","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G925 MC10, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"mid"},
    {"model":"POCO F7 Pro","brand":"POCO","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 830, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"flagship"},

    # ===== v14: HIGH-TRAFFIC POPULAR DEVICES (ad network trust + CPM) =====
    # These are the top-selling Android phones globally (50M+ units).
    # Ad networks trust traffic from these devices the most.
    # Samsung Galaxy A14 (2023) — #1 best-selling Android globally, 50M+ units
    {"model":"SM-A146P","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"budget"},
    {"model":"SM-A145M","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2023,"tier":"budget"},
    # Samsung Galaxy A15 (2024) — massive seller, ~40M+ units
    {"model":"SM-A155F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2340,"touch":5,"year":2024,"tier":"budget"},
    {"model":"SM-A156E","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},
    # Samsung Galaxy A05s (2024) — budget best-seller in developing markets
    {"model":"SM-A057M","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2024,"tier":"budget"},
    # Samsung Galaxy S24 (2024 flagship) — Exynos 2400 variant (global)
    {"model":"SM-S921B","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G720 MC4, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2024,"tier":"flagship"},
    # Samsung Galaxy S24+ (2024 flagship) — Exynos 2400 variant (global)
    {"model":"SM-S926B","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G720 MC4, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.5,"width":1440,"height":3120,"touch":5,"year":2024,"tier":"flagship"},
    # Samsung Galaxy S25+ (2025 flagship) — Snapdragon 8 Elite
    {"model":"SM-S936B","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 830, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.5,"width":1440,"height":3120,"touch":5,"year":2025,"tier":"flagship"},
    # Xiaomi Redmi Note 12 (2023) — top seller in Asia/India
    {"model":"23021RAA2Y","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":4,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2023,"tier":"mid"},
    # Xiaomi Redmi Note 13 (2024) — top seller
    {"model":"23090RA98C","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 610, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},
    # Xiaomi Redmi Note 13 Pro (2024) — top seller
    {"model":"23129RAA4G","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 710, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2024,"tier":"mid"},
    # Xiaomi Redmi Note 14 (2025) — latest best-seller
    {"model":"24116RA6EC","brand":"Xiaomi","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G57 MC2, OpenGL ES 3.2)","mem":6,"cores":8,"density":2.75,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"mid"},
    # Xiaomi 15 (2025 flagship) — Snapdragon 8 Elite
    {"model":"24129PN74C","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 830, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.0,"width":1200,"height":2670,"touch":5,"year":2025,"tier":"flagship"},
    # OnePlus 12 (2024 flagship)
    # OnePlus 13 (2025 flagship) — Snapdragon 8 Elite
    {"model":"CPH2691","brand":"OnePlus","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 830, OpenGL ES 3.2)","mem":8,"cores":8,"density":3.5,"width":1440,"height":3168,"touch":5,"year":2025,"tier":"flagship"},
    # Nothing Phone (2) (2023) — Snapdragon 8+ Gen 1
    # Nothing Phone (3) (2025) — Snapdragon 8 Gen 3
    # Samsung Galaxy A05 (2024) — ultra-budget best-seller in SEA/South Asia
    {"model":"SM-A052F","brand":"samsung","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G52 MC2, OpenGL ES 3.2)","mem":3,"cores":8,"density":2.0,"width":720,"height":1600,"touch":5,"year":2024,"tier":"budget"},
]

# ─── Weighted selection: old/mid-old models much more likely ────────────────
# Real-world distribution: most users have 2-4 year old mid-range phones
YEAR_WEIGHTS = {
    2019: 10,   # old — still many in use in developing markets
    2020: 15,   # old
    2021: 18,   # mid-old — heavy usage
    2022: 20,   # mid-old — heaviest
    2023: 17,   # mid
    2024: 13,   # new
    2025: 7,    # newest — few users
}

TIER_WEIGHTS = {
    "budget": 40,    # most common
    "mid": 35,       # second most common
    "flagship": 25,  # fewer users
}

# ─── Brand popularity multiplier (v14) ───────────────────────────────────────
# Real global Android market share weighting. Ad networks trust traffic from
# popular brands more. This multiplier adjusts device selection probability to
# match real-world traffic distribution, so the bot looks like organic traffic.
BRAND_POPULARITY = {
    "samsung":  1.25,  # 22% global share — largest Android brand
    "Xiaomi":   1.15,  # 14% global share — dominant in Asia/India
    "OPPO":     1.05,  # 8% global share — strong in China/SEA
    "vivo":     1.05,  # 8% global share — strong in China/SEA
    "realme":   0.85,  # 5% global share — growing but still niche
    "TECNO":    0.80,  # 4% global share — budget Africa/SEA
    "HUAWEI":   0.75,  # 4% global share — declining, China-focused
    "Infinix":  0.80,  # 3% global share — budget Africa/SEA
    "motorola": 0.70,  # 3% global share — niche in most markets
    "POCO":     0.80,  # 2% global share — Xiaomi sub-brand
    "HONOR":    0.75,  # 2% global share — China-focused
    "OnePlus":  0.70,  # 1% global share — premium niche
    "Redmi":    1.10,  # Xiaomi sub-brand, very popular in Asia
    "google":   0.50,  # 1% global share — premium niche, flag-like signal
    "Nokia":    0.65,  # 1% global share — budget Europe
    "itel":     0.80,  # 2% global share — ultra-budget Africa/SEA
    "asus":     0.45,  # <1% global share — gaming niche
    "ZTE":      0.50,  # <1% global share — budget China
    "Sony":     0.35,  # <1% global share — premium niche, very rare in traffic
    "Lenovo":   0.40,  # <1% global share — China-focused
    "Nothing":  0.45,  # <1% global share — enthusiast niche
    "Meizu":    0.35,  # <1% global share — China-focused
}

# Specific high-seller model boost — these are the top-selling phones globally
# (50M+ units). Ad networks see these devices constantly, so traffic from them
# is trusted and commands higher CPM.
TOP_SELLER_MODELS = {
    "SM-A146P", "SM-A145M", "SM-A052F", "SM-A057M",  # Galaxy A14, A05 series
    "SM-A155F", "SM-A156E", "SM-A115F", "SM-A145F",  # Galaxy A15, A11 series
    "23021RAA2Y", "23090RA98C", "23129RAA4G", "24116RA6EC",  # Redmi Note 12-14
    "SM-A505F", "SM-A515F", "SM-A525F", "SM-A546B",  # Galaxy A50/A51/A52/A54
}

def _build_android_weights():
    """Build weight list matching ANDROID_PROFILES order.
    Weight = year_factor × tier_factor × brand_popularity × seller_boost.
    This makes traffic distribution match real-world Android market share,
    so ad networks see organic-looking traffic from popular devices."""
    weights = []
    for p in ANDROID_PROFILES:
        y = p.get("year", 2022)
        t = p.get("tier", "mid")
        b = p.get("brand", "")
        m = p.get("model", "")
        base = YEAR_WEIGHTS.get(y, 10) * TIER_WEIGHTS.get(t, 20)
        brand_mult = BRAND_POPULARITY.get(b, 0.6)  # unknown brands get low weight
        seller_boost = 1.3 if m in TOP_SELLER_MODELS else 1.0
        w = int(base * brand_mult * seller_boost)
        weights.append(max(1, w))  # ensure minimum weight of 1
    return weights

ANDROID_WEIGHTS = _build_android_weights()

# ─── Android Build fingerprint generation (v14) ─────────────────────────────
# Real Android Chrome UA includes Build/XXXXX (e.g., "Build/TP1A.220624.014").
# Missing this is a well-known bot detection signal — real Android browsers
# ALWAYS include it. We generate per-device unique build hashes using the
# real Android release code format: [RELEASE_CODE].[YYMMDD].[PATCH]
ANDROID_BUILD_CODES = {
    "10": ("QQ1A", "200205", "011"),
    "11": ("RKQ1", "211001", "001"),
    "12": ("SP1A", "211205", "011"),
    "13": ("TP1A", "220624", "014"),
    "14": ("UP1A", "231005", "007"),
    "15": ("AP3A", "240905", "015"),
}

# Per-brand build code variations (Samsung uses different codes than Xiaomi, etc.)
BRAND_BUILD_PREFIX = {
    "samsung":  {"10": "QP1A", "11": "RP1A", "12": "SP1A", "13": "TP1A", "14": "UP1A", "15": "AP3A"},
    "Xiaomi":   {"10": "QKQ1", "11": "RKQ1", "12": "SKQ1", "13": "TKQ1", "14": "UKQ1", "15": "AKQ1"},
    "Redmi":    {"10": "QKQ1", "11": "RKQ1", "12": "SKQ1", "13": "TKQ1", "14": "UKQ1", "15": "AKQ1"},
    "POCO":     {"10": "QKQ1", "11": "RKQ1", "12": "SKQ1", "13": "TKQ1", "14": "UKQ1", "15": "AKQ1"},
    "google":   {"10": "QQ3A", "11": "RQ3A", "12": "SQ3A", "13": "TQ3A", "14": "UQ1A", "15": "AP3A"},
    "motorola": {"10": "QPI30", "11": "RPI31", "12": "S3RI31", "13": "T3RI31", "14": "U1RH30", "15": "AP3A"},
    "HUAWEI":   {"10": "HUAWEI", "11": "HUAWEI", "12": "HUAWEI", "13": "HUAWEI", "14": "HUAWEI", "15": "HUAWEI"},
    "OPPO":     {"10": "QKQ1", "11": "RKQ1", "12": "SKQ1", "13": "TP1A", "14": "UP1A", "15": "AP3A"},
    "vivo":     {"10": "QKQ1", "11": "RKQ1", "12": "SKQ1", "13": "TP1A", "14": "UP1A", "15": "AP3A"},
    "realme":   {"10": "QKQ1", "11": "RKQ1", "12": "SKQ1", "13": "TP1A", "14": "UP1A", "15": "AP3A"},
    "TECNO":    {"10": "QKQ1", "11": "RKQ1", "12": "SKQ1", "13": "TP1A", "14": "UP1A", "15": "AP3A"},
    "Infinix":  {"10": "QKQ1", "11": "RKQ1", "12": "SKQ1", "13": "TP1A", "14": "UP1A", "15": "AP3A"},
    "OnePlus":  {"10": "QKQ1", "11": "RKQ1", "12": "SKQ1", "13": "TP1A", "14": "UP1A", "15": "AP3A"},
    "Nothing":  {"10": "QKQ1", "11": "RKQ1", "12": "SKQ1", "13": "TP1A", "14": "UP1A", "15": "AP3A"},
    "HONOR":    {"10": "HONOR", "11": "HONOR", "12": "HONOR", "13": "HONOR", "14": "HONOR", "15": "HONOR"},
}

import hashlib as _hashlib

def _generate_build_hash(model, brand, android_version):
    """Generate a stable, realistic Android build fingerprint for a device.
    Uses device model + Android version as seed so each device gets a
    consistent (but unique-looking) build hash.
    Format: [RELEASE_CODE].[YYMMDD].[NNN]"""
    brand = brand if brand else "samsung"
    av = str(android_version)
    
    # Get brand-specific build code prefix, fall back to generic
    brand_prefixes = BRAND_BUILD_PREFIX.get(brand, {})
    if av in brand_prefixes:
        code_prefix = brand_prefixes[av]
    elif av in ANDROID_BUILD_CODES:
        code_prefix = ANDROID_BUILD_CODES[av][0]
    else:
        code_prefix = "TP1A"  # safe default
    
    # Generate deterministic date + patch from model hash
    seed_str = f"{model}_{brand}_{av}"
    hash_val = int(_hashlib.md5(seed_str.encode()).hexdigest()[:8], 16)
    
    # Date: YYMMDD (2019-2025 range)
    year = 2020 + (hash_val % 6)  # 2020-2025
    month = 1 + ((hash_val >> 4) % 12)
    day = 1 + ((hash_val >> 8) % 28)
    date_part = f"{year % 100:02d}{month:02d}{day:02d}"
    
    # Patch number: 001-019
    patch = 1 + ((hash_val >> 12) % 19)
    patch_part = f"{patch:03d}"
    
    return f"{code_prefix}.{date_part}.{patch_part}"


IPHONE_PROFILES = [
    {"model":"iPhone 15 Pro Max","gpu_vendor":"Apple Inc.","gpu_renderer":"Apple GPU","density":3.0,"width":1290,"height":2796,"touch":5},
    {"model":"iPhone 15 Pro","gpu_vendor":"Apple Inc.","gpu_renderer":"Apple GPU","density":3.0,"width":1179,"height":2556,"touch":5},
    {"model":"iPhone 15 Plus","gpu_vendor":"Apple Inc.","gpu_renderer":"Apple GPU","density":3.0,"width":1290,"height":2796,"touch":5},
    {"model":"iPhone 15","gpu_vendor":"Apple Inc.","gpu_renderer":"Apple GPU","density":3.0,"width":1179,"height":2556,"touch":5},
    {"model":"iPhone 14 Pro Max","gpu_vendor":"Apple Inc.","gpu_renderer":"Apple GPU","density":3.0,"width":1290,"height":2796,"touch":5},
    {"model":"iPhone 14","gpu_vendor":"Apple Inc.","gpu_renderer":"Apple GPU","density":3.0,"width":1170,"height":2532,"touch":5},
    {"model":"iPhone 13","gpu_vendor":"Apple Inc.","gpu_renderer":"Apple GPU","density":3.0,"width":1170,"height":2532,"touch":5},
    {"model":"iPhone SE (3rd gen)","gpu_vendor":"Apple Inc.","gpu_renderer":"Apple GPU","density":2.0,"width":750,"height":1334,"touch":5},
    {"model":"iPhone 12","gpu_vendor":"Apple Inc.","gpu_renderer":"Apple GPU","density":3.0,"width":1170,"height":2532,"touch":5},
    {"model":"SM-A366B","brand":"samsung","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 720, OpenGL ES 3.1)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2340,"touch":5,"year":2025,"tier":"midrange"},
    {"model":"24108PA6EG","brand":"Xiaomi","gpu_vendor":"Google Inc. (Qualcomm)","gpu_renderer":"ANGLE (Qualcomm, Adreno (TM) 750, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2400,"touch":5,"year":2025,"tier":"flagship"},
    {"model":"RMX5090","brand":"realme","gpu_vendor":"Google Inc. (ARM)","gpu_renderer":"ANGLE (ARM, Mali-G615 MC2, OpenGL ES 3.2)","mem":8,"cores":8,"density":2.625,"width":1080,"height":2412,"touch":5,"year":2025,"tier":"midrange"},
    {"model":"iPhone 11","gpu_vendor":"Apple Inc.","gpu_renderer":"Apple GPU","density":2.0,"width":828,"height":1792,"touch":5},
]

# v15: OS-specific desktop screen pools (realistic distribution)
SCREEN_DESKTOP_WIN = [
    {"width":1920,"height":1080},{"width":1920,"height":1080},{"width":1920,"height":1080},
    {"width":1366,"height":768},{"width":1366,"height":768},
    {"width":1536,"height":864},{"width":1536,"height":864},
    {"width":1280,"height":720},{"width":1600,"height":900},
    {"width":2560,"height":1440},{"width":1920,"height":1200},
    {"width":1360,"height":768},{"width":1024,"height":768},
]
SCREEN_DESKTOP_MAC = [
    {"width":1440,"height":900},{"width":1440,"height":900},
    {"width":1680,"height":1050},{"width":2560,"height":1600},
    {"width":1920,"height":1080},{"width":1280,"height":800},
    {"width":1512,"height":982},  # MacBook Pro 14"
    {"width":1728,"height":1117}, # MacBook Pro 16"
    {"width":2560,"height":1440},
]
SCREEN_DESKTOP_LINUX = [
    {"width":1920,"height":1080},{"width":1920,"height":1080},
    {"width":1366,"height":768},{"width":1600,"height":900},
    {"width":2560,"height":1440},{"width":1280,"height":1024},
    {"width":1440,"height":900},
]
# Legacy pool kept for backward compatibility
SCREEN_DESKTOP = SCREEN_DESKTOP_WIN + SCREEN_DESKTOP_MAC + SCREEN_DESKTOP_LINUX

# ─── WebGL renderer pools — SPLIT PER OS (v13.0 critical fix) ──────────────
# BUG FIXED: previously ALL desktop OS (Windows/macOS/Linux) drew from one
# shared "WEBGL_DESKTOP" pool of Direct3D11 ANGLE renderer strings. But
# ANGLE's D3D11 backend is WINDOWS-ONLY — real Chrome on macOS reports a
# Metal-backend renderer string, and real Chrome on Linux reports a native
# GL/Mesa renderer string with NO "Direct3D11"/"D3D11" substring at all.
# A macOS or Linux visit reporting "...Direct3D11..." in WebGL is an
# immediate, well-known desktop/OS mismatch signature that anti-fraud
# scripts specifically check for (WebGL renderer vs UA/platform). Each OS
# now draws ONLY from its own physically-consistent renderer pool.
WEBGL_WIN = [
    {"vendor":"Google Inc. (AMD)","renderer":"ANGLE (AMD, AMD Radeon RX 6700 XT Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (AMD)","renderer":"ANGLE (AMD, AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (AMD)","renderer":"ANGLE (AMD, AMD Radeon RX 5700 XT Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (AMD)","renderer":"ANGLE (AMD, AMD Radeon RX 6600 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (AMD)","renderer":"ANGLE (AMD, AMD Radeon RX 7600 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (AMD)","renderer":"ANGLE (AMD, AMD Radeon RX 6800 XT Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (AMD)","renderer":"ANGLE (AMD, AMD Radeon(TM) Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (NVIDIA)","renderer":"ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (NVIDIA)","renderer":"ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (NVIDIA)","renderer":"ANGLE (NVIDIA, NVIDIA GeForce GTX 1650 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (NVIDIA)","renderer":"ANGLE (NVIDIA, NVIDIA GeForce RTX 3070 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (NVIDIA)","renderer":"ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 Laptop GPU Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (NVIDIA)","renderer":"ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 Ti Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (NVIDIA)","renderer":"ANGLE (NVIDIA, NVIDIA GeForce RTX 2060 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (NVIDIA)","renderer":"ANGLE (NVIDIA, NVIDIA GeForce MX450 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (Intel)","renderer":"ANGLE (Intel, Intel(R) HD Graphics 630 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (Intel)","renderer":"ANGLE (Intel, Intel(R) Iris(R) Xe Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (Intel)","renderer":"ANGLE (Intel, Intel(R) UHD Graphics 770 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (Intel)","renderer":"ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (Intel)","renderer":"ANGLE (Intel, Intel(R) UHD Graphics 730 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
    {"vendor":"Google Inc. (Intel)","renderer":"ANGLE (Intel, Intel(R) Arc(TM) A750 Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)"},
]

WEBGL_MAC = [
    {"vendor":"Apple Inc.","renderer":"ANGLE (Apple, ANGLE Metal Renderer: Apple M1, Unspecified Version)"},
    {"vendor":"Apple Inc.","renderer":"ANGLE (Apple, ANGLE Metal Renderer: Apple M1 Pro, Unspecified Version)"},
    {"vendor":"Apple Inc.","renderer":"ANGLE (Apple, ANGLE Metal Renderer: Apple M2, Unspecified Version)"},
    {"vendor":"Apple Inc.","renderer":"ANGLE (Apple, ANGLE Metal Renderer: Apple M2 Pro, Unspecified Version)"},
    {"vendor":"Apple Inc.","renderer":"ANGLE (Apple, ANGLE Metal Renderer: Apple M3, Unspecified Version)"},
    {"vendor":"Apple Inc.","renderer":"ANGLE (Apple, ANGLE Metal Renderer: Apple M3 Pro, Unspecified Version)"},
    {"vendor":"Google Inc. (Intel)","renderer":"ANGLE (Intel, ANGLE Metal Renderer: Intel(R) Iris(TM) Plus Graphics, Unspecified Version)"},
    {"vendor":"Google Inc. (AMD)","renderer":"ANGLE (AMD, ANGLE Metal Renderer: AMD Radeon Pro 5500M, Unspecified Version)"},
]

WEBGL_LINUX = [
    {"vendor":"Google Inc. (NVIDIA Corporation)","renderer":"ANGLE (NVIDIA Corporation, NVIDIA GeForce GTX 1650/PCIe/SSE2, OpenGL 4.6.0 NVIDIA 535.183.01)"},
    {"vendor":"Google Inc. (NVIDIA Corporation)","renderer":"ANGLE (NVIDIA Corporation, NVIDIA GeForce RTX 3060/PCIe/SSE2, OpenGL 4.6.0 NVIDIA 545.29.06)"},
    {"vendor":"Google Inc. (Mesa)","renderer":"ANGLE (Mesa, Mesa Intel(R) UHD Graphics 620 (KBL GT2), OpenGL 4.6)"},
    {"vendor":"Google Inc. (Mesa)","renderer":"ANGLE (Mesa, Mesa Intel(R) HD Graphics 530 (SKL GT2), OpenGL 4.6)"},
    {"vendor":"Google Inc. (Mesa)","renderer":"ANGLE (Mesa, Mesa Intel(R) Iris(R) Xe Graphics (TGL GT2), OpenGL 4.6)"},
    {"vendor":"Google Inc. (AMD)","renderer":"ANGLE (AMD, AMD Radeon RX 580 Series (radeonsi, polaris10, LLVM 15.0.7), OpenGL 4.6)"},
]

# ─── v13.7.5 — Firefox WebGL renderer pools (no ANGLE, no "Google Inc.") ──
WEBGL_FIREFOX_WIN = [
    {"vendor":"NVIDIA Corporation","renderer":"NVIDIA GeForce RTX 3060/PCIe/SSE2"},
    {"vendor":"NVIDIA Corporation","renderer":"NVIDIA GeForce RTX 4060/PCIe/SSE2"},
    {"vendor":"NVIDIA Corporation","renderer":"NVIDIA GeForce GTX 1650/PCIe/SSE2"},
    {"vendor":"AMD","renderer":"AMD Radeon RX 6700 XT"},
    {"vendor":"AMD","renderer":"AMD Radeon RX 580"},
    {"vendor":"Intel","renderer":"Intel(R) UHD Graphics 630"},
    {"vendor":"Intel","renderer":"Intel(R) Iris(R) Xe Graphics"},
]
WEBGL_FIREFOX_MAC = [
    {"vendor":"Intel Inc.","renderer":"Intel(R) Iris(TM) Plus Graphics 645"},
    {"vendor":"Intel Inc.","renderer":"Intel(R) UHD Graphics 630"},
    {"vendor":"Apple Inc.","renderer":"Apple M1"},
    {"vendor":"Apple Inc.","renderer":"Apple M2"},
    {"vendor":"Apple Inc.","renderer":"Apple M3"},
]
WEBGL_FIREFOX_LINUX = [
    {"vendor":"NVIDIA Corporation","renderer":"NVIDIA GeForce RTX 3060/PCIe/SSE2"},
    {"vendor":"Mesa","renderer":"Mesa Intel(R) UHD Graphics 620 (KBL GT2)"},
    {"vendor":"Mesa","renderer":"Mesa Intel(R) HD Graphics 530 (SKL GT2)"},
    {"vendor":"Mesa","renderer":"llvmpipe (LLVM 15.0.7, 256 bits)"},
]
# Safari masks GPU info completely — shows "Apple GPU" with no model
WEBGL_SAFARI_MAC = [
    {"vendor":"Apple Inc.","renderer":"Apple GPU"},
    {"vendor":"Apple Inc.","renderer":"Apple GPU"},
]

# Backward-compat alias (some older helper code may still reference this name)
WEBGL_DESKTOP = WEBGL_WIN

FONTS_WIN = ["Arial","Calibri","Cambria","Candara","Consolas","Constantia","Corbel","Courier New","Ebrima","Franklin Gothic Medium","Gabriola","Gadugi","Georgia","Impact","Javanese Text","Leelawadee UI","Lucida Console","Lucida Sans Unicode","Malgun Gothic","Microsoft Himalaya","Microsoft JhengHei","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Sans Serif","Microsoft YaHei","MingLiU","Mongolian Baiti","MS Gothic","MV Boli","Myanmar Text","Nirmala UI","Palatino Linotype","Segoe Print","Segoe Script","Segoe UI","Segoe UI Emoji","Segoe UI Historic","Segoe UI Symbol","SimSun","Sitka Banner","Sylfaen","Tahoma","Times New Roman","Trebuchet MS","Verdana","Webdings","Wingdings","Yu Gothic"]
FONTS_MAC = ["Arial","Arial Black","Arial Hebrew","Avenir","Avenir Next","Camino","Comic Sans MS","Courier","Courier New","Geneva","Georgia","Helvetica","Helvetica Neue","Hiragino Sans","Lucida Grande","Marker Felt","Menlo","Monaco","Optima","Palatino","Papyrus","Skia","Times","Times New Roman","Trebuchet MS","Verdana","Zapfino"]
FONTS_LINUX = ["Arial","Bitstream Charter","Bitstream Vera Sans","Bitstream Vera Sans Mono","Bitstream Vera Serif","Cantarell","Century Schoolbook L","Courier 10 Pitch","Cursor","DejaVu Sans","DejaVu Sans Condensed","DejaVu Sans Mono","DejaVu Serif","DejaVu Serif Condensed","Dingbats","FreeMono","FreeSans","FreeSerif","Garuda","Georgia","KacstArt","Khmer OS","Khmer OS System","Kinnari","Liberation Mono","Liberation Sans","Liberation Serif","Lohit Bengali","Lohit Devanagari","Loma","Mukti Narrow","Nimbus Mono L","Nimbus Roman No9 L","Nimbus Sans L","Norasi","Padauk","Pothana","Purusa","Sawasdee","Sans serif","Symbol","Takao Gothic","Takao Mincho","Takao P Gothic","TakaoEx Gothic","TharLon","Tibetan Machine Uni","TlwgMono","TlwgTypewriter","Tlwg Typist","Tlwg Typo","Tunga","Ubuntu","Ubuntu Condensed","Ubuntu Mono","URW Bookman L","URW Chancery L","URW Gothic L","URW Palladio L","Untutfa","Vemana2000","Waree","WenQuanYi Bitmap Song","WenQuanYi Micro Hei","WenQuanYi Zen Hei"]
FONTS_ANDROID = ["Roboto","Noto Sans","Noto Serif","Droid Sans Mono","Cutive Mono","Coming Soon","Carrois Gothic SC","Audiowide","Roboto Condensed","Dancing Script","Old Standard TT","PT Sans","PT Sans Narrow","PT Serif","PT Serif Caption","Exo 2","Source Sans Pro","Ubuntu","Noto Color Emoji","Noto Sans Bengali","Noto Sans Devanagari","Noto Sans Arabic","Noto Sans Thai","Noto Sans Vietnamese","Noto Sans CJK JP","Noto Sans CJK SC","Noto Sans CJK KR","Mukti Narrow","Lohit Bengali","Lohit Tamil","Lohit Devanagari","Sans-serif","Serif","Monospace"]
FONTS_IOS = ["Arial","Arial Hebrew","Avenir","Avenir Next","Courier","Courier New","Georgia","Helvetica","Helvetica Neue","Marker Felt","Palatino","Times New Roman","Trebuchet MS","Verdana","SF Pro","SF Pro Display","SF Pro Text","SF Pro Rounded","SF Pro Icons","Apple Color Emoji"]

GEO_DATA = [
    {"tz":"America/New_York","langs":["en-US","en"],"locale":"en-US","country":"United States"},
    {"tz":"America/Los_Angeles","langs":["en-US","en"],"locale":"en-US","country":"United States"},
    {"tz":"America/Chicago","langs":["en-US","en"],"locale":"en-US","country":"United States"},
    {"tz":"America/Denver","langs":["en-US","en"],"locale":"en-US","country":"United States"},
    {"tz":"Europe/London","langs":["en-GB","en"],"locale":"en-GB","country":"United Kingdom"},
    {"tz":"Europe/Berlin","langs":["de-DE","de"],"locale":"de-DE","country":"Germany"},
    {"tz":"Europe/Paris","langs":["fr-FR","fr"],"locale":"fr-FR","country":"France"},
    {"tz":"Europe/Madrid","langs":["es-ES","es"],"locale":"es-ES","country":"Spain"},
    {"tz":"Europe/Rome","langs":["it-IT","it"],"locale":"it-IT","country":"Italy"},
    {"tz":"Europe/Amsterdam","langs":["nl-NL","nl"],"locale":"nl-NL","country":"Netherlands"},
    {"tz":"Europe/Istanbul","langs":["tr-TR","tr"],"locale":"tr-TR","country":"Turkey"},
    {"tz":"Asia/Dubai","langs":["ar-AE","ar"],"locale":"ar-AE","country":"UAE"},
    {"tz":"Asia/Tokyo","langs":["ja-JP","ja"],"locale":"ja-JP","country":"Japan"},
    {"tz":"Asia/Kolkata","langs":["hi-IN","en-IN","en"],"locale":"hi-IN","country":"India"},
    {"tz":"Asia/Dhaka","langs":["bn-BD","en"],"locale":"bn-BD","country":"Bangladesh"},
    {"tz":"Asia/Bangkok","langs":["th-TH","th"],"locale":"th-TH","country":"Thailand"},
    {"tz":"Asia/Jakarta","langs":["id-ID","id"],"locale":"id-ID","country":"Indonesia"},
    {"tz":"Asia/Manila","langs":["fil-PH","en-PH","en"],"locale":"fil-PH","country":"Philippines"},
    {"tz":"Asia/Karachi","langs":["ur-PK","en"],"locale":"ur-PK","country":"Pakistan"},
    {"tz":"Asia/Seoul","langs":["ko-KR","ko"],"locale":"ko-KR","country":"South Korea"},
    {"tz":"America/Sao_Paulo","langs":["pt-BR","pt"],"locale":"pt-BR","country":"Brazil"},
    {"tz":"America/Mexico_City","langs":["es-MX","es"],"locale":"es-MX","country":"Mexico"},
    {"tz":"America/Bogota","langs":["es-CO","es"],"locale":"es-CO","country":"Colombia"},
    {"tz":"America/Santiago","langs":["es-CL","es"],"locale":"es-CL","country":"Chile"},
    {"tz":"America/Buenos_Aires","langs":["es-AR","es"],"locale":"es-AR","country":"Argentina"},
    {"tz":"Africa/Cairo","langs":["ar-EG","ar"],"locale":"ar-EG","country":"Egypt"},
    {"tz":"Africa/Lagos","langs":["en-NG","en"],"locale":"en-NG","country":"Nigeria"},
    {"tz":"Africa/Johannesburg","langs":["en-ZA","en"],"locale":"en-ZA","country":"South Africa"},
    {"tz":"Australia/Sydney","langs":["en-AU","en"],"locale":"en-AU","country":"Australia"},
    {"tz":"Pacific/Auckland","langs":["en-NZ","en"],"locale":"en-NZ","country":"New Zealand"},
]

# v11.0 — COMPREHENSIVE country-code -> geo mapping (fixes the bug where
# proxies from countries NOT in the old 30-country GEO_DATA/country_map
# silently fell back to a random country, e.g. a Sweden IP getting a
# US/India timezone because "SE" wasn't in the lookup table at all).
# Keyed directly by ISO 2-letter country code (matches ip-api/ipwho.is/
# ipinfo's countryCode field exactly — no more name-matching indirection).
COUNTRY_GEO = {
    "US": {"tz":"America/New_York","langs":["en-US","en"],"locale":"en-US","country":"United States"},
    "GB": {"tz":"Europe/London","langs":["en-GB","en"],"locale":"en-GB","country":"United Kingdom"},
    "UK": {"tz":"Europe/London","langs":["en-GB","en"],"locale":"en-GB","country":"United Kingdom"},
    "DE": {"tz":"Europe/Berlin","langs":["de-DE","de"],"locale":"de-DE","country":"Germany"},
    "FR": {"tz":"Europe/Paris","langs":["fr-FR","fr"],"locale":"fr-FR","country":"France"},
    "ES": {"tz":"Europe/Madrid","langs":["es-ES","es"],"locale":"es-ES","country":"Spain"},
    "IT": {"tz":"Europe/Rome","langs":["it-IT","it"],"locale":"it-IT","country":"Italy"},
    "NL": {"tz":"Europe/Amsterdam","langs":["nl-NL","nl"],"locale":"nl-NL","country":"Netherlands"},
    "TR": {"tz":"Europe/Istanbul","langs":["tr-TR","tr"],"locale":"tr-TR","country":"Turkey"},
    "AE": {"tz":"Asia/Dubai","langs":["ar-AE","ar"],"locale":"ar-AE","country":"UAE"},
    "JP": {"tz":"Asia/Tokyo","langs":["ja-JP","ja"],"locale":"ja-JP","country":"Japan"},
    "IN": {"tz":"Asia/Kolkata","langs":["hi-IN","en-IN","en"],"locale":"hi-IN","country":"India"},
    "BD": {"tz":"Asia/Dhaka","langs":["bn-BD","en"],"locale":"bn-BD","country":"Bangladesh"},
    "TH": {"tz":"Asia/Bangkok","langs":["th-TH","th"],"locale":"th-TH","country":"Thailand"},
    "ID": {"tz":"Asia/Jakarta","langs":["id-ID","id"],"locale":"id-ID","country":"Indonesia"},
    "PH": {"tz":"Asia/Manila","langs":["fil-PH","en-PH","en"],"locale":"fil-PH","country":"Philippines"},
    "PK": {"tz":"Asia/Karachi","langs":["ur-PK","en"],"locale":"ur-PK","country":"Pakistan"},
    "KR": {"tz":"Asia/Seoul","langs":["ko-KR","ko"],"locale":"ko-KR","country":"South Korea"},
    "BR": {"tz":"America/Sao_Paulo","langs":["pt-BR","pt"],"locale":"pt-BR","country":"Brazil"},
    "MX": {"tz":"America/Mexico_City","langs":["es-MX","es"],"locale":"es-MX","country":"Mexico"},
    "CO": {"tz":"America/Bogota","langs":["es-CO","es"],"locale":"es-CO","country":"Colombia"},
    "CL": {"tz":"America/Santiago","langs":["es-CL","es"],"locale":"es-CL","country":"Chile"},
    "AR": {"tz":"America/Buenos_Aires","langs":["es-AR","es"],"locale":"es-AR","country":"Argentina"},
    "EG": {"tz":"Africa/Cairo","langs":["ar-EG","ar"],"locale":"ar-EG","country":"Egypt"},
    "NG": {"tz":"Africa/Lagos","langs":["en-NG","en"],"locale":"en-NG","country":"Nigeria"},
    "ZA": {"tz":"Africa/Johannesburg","langs":["en-ZA","en"],"locale":"en-ZA","country":"South Africa"},
    "AU": {"tz":"Australia/Sydney","langs":["en-AU","en"],"locale":"en-AU","country":"Australia"},
    "NZ": {"tz":"Pacific/Auckland","langs":["en-NZ","en"],"locale":"en-NZ","country":"New Zealand"},
    "SA": {"tz":"Asia/Riyadh","langs":["ar-SA","ar"],"locale":"ar-SA","country":"Saudi Arabia"},
    "CA": {"tz":"America/Toronto","langs":["en-CA","en"],"locale":"en-CA","country":"Canada"},
    "SG": {"tz":"Asia/Singapore","langs":["en-SG","en"],"locale":"en-SG","country":"Singapore"},
    "MY": {"tz":"Asia/Kuala_Lumpur","langs":["ms-MY","en"],"locale":"ms-MY","country":"Malaysia"},
    "VN": {"tz":"Asia/Ho_Chi_Minh","langs":["vi-VN","vi"],"locale":"vi-VN","country":"Vietnam"},
    # ── Nordic countries (previously completely missing — root cause bug) ──
    "SE": {"tz":"Europe/Stockholm","langs":["sv-SE","sv","en"],"locale":"sv-SE","country":"Sweden"},
    "NO": {"tz":"Europe/Oslo","langs":["nb-NO","no","en"],"locale":"nb-NO","country":"Norway"},
    "DK": {"tz":"Europe/Copenhagen","langs":["da-DK","da","en"],"locale":"da-DK","country":"Denmark"},
    "FI": {"tz":"Europe/Helsinki","langs":["fi-FI","fi","en"],"locale":"fi-FI","country":"Finland"},
    "IS": {"tz":"Atlantic/Reykjavik","langs":["is-IS","is","en"],"locale":"is-IS","country":"Iceland"},
    # ── Rest of Europe ──
    "PL": {"tz":"Europe/Warsaw","langs":["pl-PL","pl"],"locale":"pl-PL","country":"Poland"},
    "PT": {"tz":"Europe/Lisbon","langs":["pt-PT","pt"],"locale":"pt-PT","country":"Portugal"},
    "CH": {"tz":"Europe/Zurich","langs":["de-CH","de","fr"],"locale":"de-CH","country":"Switzerland"},
    "AT": {"tz":"Europe/Vienna","langs":["de-AT","de"],"locale":"de-AT","country":"Austria"},
    "BE": {"tz":"Europe/Brussels","langs":["nl-BE","fr-BE","en"],"locale":"nl-BE","country":"Belgium"},
    "IE": {"tz":"Europe/Dublin","langs":["en-IE","en"],"locale":"en-IE","country":"Ireland"},
    "CZ": {"tz":"Europe/Prague","langs":["cs-CZ","cs"],"locale":"cs-CZ","country":"Czech Republic"},
    "RO": {"tz":"Europe/Bucharest","langs":["ro-RO","ro"],"locale":"ro-RO","country":"Romania"},
    "GR": {"tz":"Europe/Athens","langs":["el-GR","el"],"locale":"el-GR","country":"Greece"},
    "HU": {"tz":"Europe/Budapest","langs":["hu-HU","hu"],"locale":"hu-HU","country":"Hungary"},
    "RU": {"tz":"Europe/Moscow","langs":["ru-RU","ru"],"locale":"ru-RU","country":"Russia"},
    "UA": {"tz":"Europe/Kyiv","langs":["uk-UA","uk","ru"],"locale":"uk-UA","country":"Ukraine"},
    "HR": {"tz":"Europe/Zagreb","langs":["hr-HR","hr"],"locale":"hr-HR","country":"Croatia"},
    "RS": {"tz":"Europe/Belgrade","langs":["sr-RS","sr"],"locale":"sr-RS","country":"Serbia"},
    "BG": {"tz":"Europe/Sofia","langs":["bg-BG","bg"],"locale":"bg-BG","country":"Bulgaria"},
    "SK": {"tz":"Europe/Bratislava","langs":["sk-SK","sk"],"locale":"sk-SK","country":"Slovakia"},
    "SI": {"tz":"Europe/Ljubljana","langs":["sl-SI","sl"],"locale":"sl-SI","country":"Slovenia"},
    "LT": {"tz":"Europe/Vilnius","langs":["lt-LT","lt"],"locale":"lt-LT","country":"Lithuania"},
    "LV": {"tz":"Europe/Riga","langs":["lv-LV","lv"],"locale":"lv-LV","country":"Latvia"},
    "EE": {"tz":"Europe/Tallinn","langs":["et-EE","et"],"locale":"et-EE","country":"Estonia"},
    "LU": {"tz":"Europe/Luxembourg","langs":["fr-LU","de-LU","en"],"locale":"fr-LU","country":"Luxembourg"},
    "MT": {"tz":"Europe/Malta","langs":["mt-MT","en"],"locale":"en-MT","country":"Malta"},
    "CY": {"tz":"Asia/Nicosia","langs":["el-CY","en"],"locale":"el-CY","country":"Cyprus"},
    # ── Middle East / Central Asia ──
    "IL": {"tz":"Asia/Jerusalem","langs":["he-IL","en"],"locale":"he-IL","country":"Israel"},
    "IQ": {"tz":"Asia/Baghdad","langs":["ar-IQ","ar"],"locale":"ar-IQ","country":"Iraq"},
    "KW": {"tz":"Asia/Kuwait","langs":["ar-KW","ar"],"locale":"ar-KW","country":"Kuwait"},
    "QA": {"tz":"Asia/Qatar","langs":["ar-QA","ar"],"locale":"ar-QA","country":"Qatar"},
    "JO": {"tz":"Asia/Amman","langs":["ar-JO","ar"],"locale":"ar-JO","country":"Jordan"},
    "GE": {"tz":"Asia/Tbilisi","langs":["ka-GE","en"],"locale":"ka-GE","country":"Georgia"},
    "AM": {"tz":"Asia/Yerevan","langs":["hy-AM","en"],"locale":"hy-AM","country":"Armenia"},
    "AZ": {"tz":"Asia/Baku","langs":["az-AZ","en"],"locale":"az-AZ","country":"Azerbaijan"},
    "KZ": {"tz":"Asia/Almaty","langs":["kk-KZ","ru"],"locale":"kk-KZ","country":"Kazakhstan"},
    "UZ": {"tz":"Asia/Tashkent","langs":["uz-UZ","ru"],"locale":"uz-UZ","country":"Uzbekistan"},
    # ── South / East Asia ──
    "LK": {"tz":"Asia/Colombo","langs":["si-LK","ta-LK","en"],"locale":"en-LK","country":"Sri Lanka"},
    "NP": {"tz":"Asia/Kathmandu","langs":["ne-NP","en"],"locale":"ne-NP","country":"Nepal"},
    "MM": {"tz":"Asia/Yangon","langs":["my-MM","en"],"locale":"my-MM","country":"Myanmar"},
    "KH": {"tz":"Asia/Phnom_Penh","langs":["km-KH","en"],"locale":"km-KH","country":"Cambodia"},
    "LA": {"tz":"Asia/Vientiane","langs":["lo-LA","en"],"locale":"lo-LA","country":"Laos"},
    "MN": {"tz":"Asia/Ulaanbaatar","langs":["mn-MN","en"],"locale":"mn-MN","country":"Mongolia"},
    "CN": {"tz":"Asia/Shanghai","langs":["zh-CN","zh"],"locale":"zh-CN","country":"China"},
    "HK": {"tz":"Asia/Hong_Kong","langs":["zh-HK","en"],"locale":"zh-HK","country":"Hong Kong"},
    "TW": {"tz":"Asia/Taipei","langs":["zh-TW","zh"],"locale":"zh-TW","country":"Taiwan"},
    # ── Africa (more) ──
    "KE": {"tz":"Africa/Nairobi","langs":["sw-KE","en"],"locale":"en-KE","country":"Kenya"},
    "GH": {"tz":"Africa/Accra","langs":["en-GH","en"],"locale":"en-GH","country":"Ghana"},
    "MA": {"tz":"Africa/Casablanca","langs":["ar-MA","fr"],"locale":"ar-MA","country":"Morocco"},
    "TN": {"tz":"Africa/Tunis","langs":["ar-TN","fr"],"locale":"ar-TN","country":"Tunisia"},
    "DZ": {"tz":"Africa/Algiers","langs":["ar-DZ","fr"],"locale":"ar-DZ","country":"Algeria"},
    # ── Latin America (more) ──
    "PE": {"tz":"America/Lima","langs":["es-PE","es"],"locale":"es-PE","country":"Peru"},
    "VE": {"tz":"America/Caracas","langs":["es-VE","es"],"locale":"es-VE","country":"Venezuela"},
    "EC": {"tz":"America/Guayaquil","langs":["es-EC","es"],"locale":"es-EC","country":"Ecuador"},
    "BO": {"tz":"America/La_Paz","langs":["es-BO","es"],"locale":"es-BO","country":"Bolivia"},
    "PY": {"tz":"America/Asuncion","langs":["es-PY","es"],"locale":"es-PY","country":"Paraguay"},
    "UY": {"tz":"America/Montevideo","langs":["es-UY","es"],"locale":"es-UY","country":"Uruguay"},
    "PA": {"tz":"America/Panama","langs":["es-PA","es"],"locale":"es-PA","country":"Panama"},
    "CR": {"tz":"America/Costa_Rica","langs":["es-CR","es"],"locale":"es-CR","country":"Costa Rica"},
    "DO": {"tz":"America/Santo_Domingo","langs":["es-DO","es"],"locale":"es-DO","country":"Dominican Republic"},
    "PR": {"tz":"America/Puerto_Rico","langs":["es-PR","en"],"locale":"es-PR","country":"Puerto Rico"},
    "CU": {"tz":"America/Havana","langs":["es-CU","es"],"locale":"es-CU","country":"Cuba"},
    "JM": {"tz":"America/Jamaica","langs":["en-JM","en"],"locale":"en-JM","country":"Jamaica"},
}

SEARCH_QUERIES = ["best smartphones 2026","how to make money online 2026","free movies streaming","mobile games download","news today","weather forecast","tech reviews 2026","crypto news","buy cheap electronics","best travel deals","free music download","online shopping deals","fitness tips","recipe ideas","movie trailers 2026","football scores","celebrity news","stock market today","crypto trading","VPN free download","ai tools 2026","best laptops 2026","side hustle ideas","freelance jobs online","passive income ideas"]

# v13.7.3: Authentic Facebook referer module (organic + paid ads)
try:
    from fb_ads_authentic import build_facebook_ads_referer, build_facebook_organic_referer
except ImportError:
    pass

# ─── Authentic per-visit referer generation (v10.0) ─────────────────────────
# Each source below mimics the REAL referer format a browser actually sends
# when a user clicks through from that platform — not just a static domain.
# Every call generates a fresh, unique "click id" (token/hash/post id/etc.)
# so no two visits ever share the exact same referer string, matching how
# real traffic looks (each click has its own tracking id).
#
# NOTE: keys match the dashboard's <select id="trafficSource"> option values
# exactly (organic_google, social_facebook, ...) — previously this dict used
# short keys ("google","facebook") that never matched what the frontend sent,
# so get_referer() silently returned None for every source except "direct"/
# "email". Fixed here.

def _rand_token(length=10, alphabet="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"):
    return "".join(random.choice(alphabet) for _ in range(length))

def _rand_id(digits_min=15, digits_max=17):
    n = random.randint(digits_min, digits_max)
    return str(random.randint(10 ** (n - 1), 10 ** n - 1))

def _slugify_keyword(kw):
    s = re.sub(r"[^a-z0-9]+", "-", kw.strip().lower()).strip("-")
    return s or "post"

def _rand_slug(keywords=None):
    if keywords:
        return _slugify_keyword(random.choice(keywords)) + "-" + str(random.randint(100, 999))
    words = ["ultimate-guide","top-tips","how-to","best-of-2026","review","explained","step-by-step","case-study","secrets-revealed","full-breakdown"]
    return random.choice(words) + "-" + str(random.randint(100, 999))

def _quote(s):
    from urllib.parse import quote
    return quote(s, safe="")

def _ref_organic_google(url, keywords=None):
    q = (random.choice(keywords) if keywords else random.choice(SEARCH_QUERIES)).replace(" ", "+")
    ei = _rand_token(22, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-")
    return f"https://www.google.com/search?q={q}&ei={ei}&sourceid=chrome&ie=UTF-8"

def _ref_organic_bing(url, keywords=None):
    q = (random.choice(keywords) if keywords else random.choice(SEARCH_QUERIES)).replace(" ", "+")
    return f"https://www.bing.com/search?q={q}&form=QBLH&sp=-1&pq={q}"

def _ref_social_facebook(url, keywords=None):
    """
    v13.7.3 — Authentic organic Facebook click referer.

    Based on real Facebook click captures. Uses the same l.php link shim format
    as real FB clicks, with authentic fbclid in the destination URL.

    Domain variants (device-aware):
      Desktop: 75% l.facebook.com, 15% www.facebook.com, 10% l.facebook.com (no-shim)
      Mobile:  50% l.facebook.com, 30% lm.facebook.com, 10% m.facebook.com, 10% l.facebook.com (no-shim)

    Returns (referer, tagged_url) tuple — tagged_url has fbclid for l.php variants,
    None for page-URL variants (www.facebook.com / m.facebook.com).
    """
    from fb_ads_authentic import build_facebook_organic_referer
    return build_facebook_organic_referer(url, is_mobile=False)

def _ref_social_instagram(url, keywords=None):
    """
    v13.7.3 — Authentic Instagram (Meta) click referer.
    Instagram outbound clicks go through l.instagram.com/l.php (same shim as FB).
    Includes fbclid in destination URL (Meta tracking param).
    """
    from fb_ads_authentic import _gen_fbclid, _gen_h, _gen_c0, _rand_b64u
    from urllib.parse import quote as _q
    fbclid = _gen_fbclid(is_mobile=True)  # Instagram is primarily mobile
    h = _gen_h(is_paid=False)  # AUD prefix (organic)
    c0 = _gen_c0(is_paid=False)  # AUC prefix, organic length
    tagged_url = f"{url}{'&' if '?' in url else '?'}fbclid={fbclid}"
    referer = (
        f"https://l.instagram.com/l.php?u={_q(tagged_url, safe='')}"
        f"&h={h}&tn=H-R"
        f"&c%5B0%5D={c0}"
    )
    return (referer, tagged_url)

def _ref_social_twitter(url, keywords=None):
    # Real X/Twitter outbound clicks always show as a shortened t.co link,
    # never the actual tweet URL — this IS the authentic referer format.
    return f"https://t.co/{_rand_token(10, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')}"

def _ref_social_reddit(url, keywords=None):
    subs = ["technology","MoneyMaking","AskReddit","InternetIsBeautiful","SideHustle","de_IT","webdev","Entrepreneur","GetMotivated"]
    sub = random.choice(subs)
    post_id = _rand_token(7, "0123456789abcdefghijklmnopqrstuvwxyz")
    return f"https://www.reddit.com/r/{sub}/comments/{post_id}/{_rand_slug(keywords)}/"

def _ref_social_youtube(url, keywords=None):
    vid = _rand_token(11, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-")
    return f"https://www.youtube.com/watch?v={vid}&feature=youtu.be"

def _ref_social_tiktok(url, keywords=None):
    user = "user" + str(random.randint(100000, 999999))
    vid = _rand_id(18, 19)
    return f"https://www.tiktok.com/@{user}/video/{vid}"

def _ref_social_linkedin(url, keywords=None):
    user = "user-" + _rand_token(8, "abcdefghijklmnopqrstuvwxyz0123456789")
    aid = _rand_id(18, 19)
    return f"https://www.linkedin.com/posts/{user}-activity-{aid}"

def _ref_referral(url, keywords=None):
    if random.random() < 0.5:
        user = _rand_token(8, "abcdefghijklmnopqrstuvwxyz")
        aid = _rand_token(12, "0123456789abcdef")
        return f"https://medium.com/@{user}/{_rand_slug(keywords)}-{aid}"
    return f"https://news.ycombinator.com/item?id={_rand_id(8, 8)}"

# ═══════════════════════════════════════════════════════════════════
# v13.7 — Paid Ads Referrer Builders (Facebook Ads, Google Ads, TikTok Ads)
# Authentic campaign-aware referrer injection with real click-ID formats
# ═══════════════════════════════════════════════════════════════════

def _ref_facebook_ads(url, campaign=None, keywords=None):
    """
    v13.7.2 — Authentic Facebook/Meta Ads click referrer (100% real format).

    Based on real FB Ads click captures from desktop + mobile.
    Key differences from old implementation:
      - utm_source = "fb" (was "facebook")
      - utm_medium = "paid" (was "cpc")
      - utm_id = "{campaign_id}_v{ver}_s{seq}" format
      - utm_term = adset_id (was missing)
      - utm_campaign = numeric campaign_id (was campaign name)
      - FBAudience = engaged_audience (was missing)
      - fbclid = ~160 char structured base64url with IwZXh0bgNhZW0 prefix + _aem_ suffix
      - l.php h = ~134 chars starting with AUC (was 32 hex chars)
      - l.php tn = H-R (was -UK-R)
      - l.php c[0] = ~170 chars starting with AUC (was AT + 20 chars)

    Returns: (referer, tagged_destination_url)
    """
    from fb_ads_authentic import build_facebook_ads_referer
    is_mobile = bool(campaign and campaign.get("is_mobile", False)) if campaign else False
    return build_facebook_ads_referer(url, is_mobile=is_mobile, campaign_config=campaign)


def _ref_google_ads(url, campaign=None, keywords=None):
    """
    Authentic Google Ads click referrer.
    Real format: www.google.com/aclk referer + gclid on destination URL
    Analytics sees: Source=google / Medium=cpc / Campaign=<name>

    v13.7.1 FIX: Returns (referer, tagged_destination_url). Real Google Ads
    redirect to url?gclid=... — GA reads gclid from the address bar to mark
    it as paid/cpc. The referer is google.com/aclk (Google's ad click tracker).
    """
    _b64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
    gclid = _rand_token(100, _b64chars)

    campaign_name = "none"
    keyword = random.choice(SEARCH_QUERIES) if keywords else random.choice(SEARCH_QUERIES)

    if campaign and isinstance(campaign, dict):
        campaign_name = campaign.get("name", "s2c_google_campaign")
        keyword = campaign.get("keyword", keyword)

    # ── TAGGED DESTINATION URL (gclid goes in ADDRESS BAR) ──
    import urllib.parse as _up
    utm_params = {
        "utm_source": "google",
        "utm_medium": "cpc",
        "utm_campaign": campaign_name,
        "gclid": gclid,
    }
    tagged_url = url + ("&" if "?" in url else "?") + _up.urlencode(utm_params)

    # ── REFERER: google.com/aclk (Google's ad redirect URL) ──
    sa = "l"
    ved = "2ahUKEwi" + _rand_token(16, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789") + "EgQIBhAD"
    ref = (
        f"https://www.google.com/aclk?sa={sa}"
        f"&ai={_rand_token(68, _b64chars)}"
        f"&sig={_rand_token(16, '0123456789abcdef')}"
        f"&q={_rand_token(0)}"
        f"&ved={ved}"
        f"&adurl="
    )
    return (ref, tagged_url)


def _ref_tiktok_ads(url, campaign=None, keywords=None):
    """
    Authentic TikTok Ads click referrer.
    Real format: tiktok.com referer + ttclid on destination URL
    Analytics sees: Source=tiktok / Medium=cpc / Campaign=<name>

    v13.7.1 FIX: Returns (referer, tagged_destination_url). ttclid goes in
    the ADDRESS BAR (GA reads it there), referer is the TikTok video page.
    """
    ttclid = _rand_token(64, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_")

    campaign_name = "none"
    ad_id = _rand_token(19, "0123456789")

    if campaign and isinstance(campaign, dict):
        campaign_name = campaign.get("name", "s2c_tiktok_campaign")
        ad_id = campaign.get("ad_id", ad_id)

    # ── TAGGED DESTINATION URL (ttclid + UTM in ADDRESS BAR) ──
    import urllib.parse as _up
    utm_params = {
        "utm_source": "tiktok",
        "utm_medium": "cpc",
        "utm_campaign": campaign_name,
        "ttclid": ttclid,
    }
    tagged_url = url + ("&" if "?" in url else "?") + _up.urlencode(utm_params)

    # ── REFERER: TikTok video page ──
    user = "brand" + _rand_token(6, "abcdefghijklmnopqrstuvwxyz0123456789")
    vid = _rand_id(18, 19)
    ref = f"https://www.tiktok.com/@{user}/video/{vid}"
    return (ref, tagged_url)



# Sources actually eligible for "Random" mode (no-referer sources excluded —
# picking "direct"/"email" for a "random referer" visit would defeat the point).

# ─────────────────────────────────────────────────────────────────
# v13.3 — Facebook In-App Browser (IAB) variant data
# Every variant has: package name, app_name, realistic version pool,
# and whether to add extras (FB for Business, FB Lite, Messenger etc.)
# Sources: real UA logs from hotjar/mixpanel public datasets + apkmirror.
# ─────────────────────────────────────────────────────────────────
FB_IAB_VARIANTS = {
    "fb_main": {
        "label": "Facebook App (main)",
        "fban_key": "FBANDROID",
        "versions": [
            "462.0.0.37.110","461.0.0.30.107","460.0.0.27.108","459.0.0.45.109",
            "458.0.0.31.114","457.0.0.28.110","456.0.0.48.107","455.0.0.25.109",
            "575.1.0.55.73","530.0.0.31.108","520.0.0.27.108","510.0.0.30.109","505.1.0.32.112","500.0.0.29.106","495.0.0.29.108","490.1.0.35.111","485.0.0.39.103","480.0.0.28.107","475.1.0.31.110","470.0.0.30.105","450.1.0.34.105","449.0.0.46.108","445.0.0.37.119","440.0.0.43.109",
            "435.0.0.31.110","430.1.0.29.120","425.0.0.43.116","420.2.0.37.119",
            "415.0.0.28.110","410.0.0.31.107","405.1.0.35.119","400.0.0.25.112",
            "395.0.0.12.105","390.1.0.37.110","385.0.0.18.103","380.0.0.35.108",
        ],
        "extras": ";FBOP/5",
        "fbrv_range": (2040000, 2069999),
    },
    "fb_lite": {
        "label": "Facebook Lite",
        "fban_key": "FBANDROID",
        "versions": [
            "384.0.0.3.103","382.0.0.2.101","380.0.0.3.102","378.0.0.2.101",
            "376.0.0.3.100","374.0.0.2.103","372.0.0.3.102","370.0.0.2.101",
            "368.0.0.3.100","365.0.0.2.102","362.0.0.3.101","358.0.0.2.100",
            "354.0.0.3.103","350.0.0.2.101","346.0.0.3.100","342.0.0.2.101",
        ],
        "extras": ";FBOP/2",
        "fbrv_range": (1010000, 1049999),
        "lite": True,
    },
    "fb_messenger": {
        "label": "Messenger",
        "fban_key": "MESSENGER",
        "versions": [
            "455.1.0.38.107","450.0.0.23.107","445.0.0.29.108","440.1.0.31.117",
            "435.0.0.14.107","430.0.0.30.114","425.0.0.29.113","420.0.0.36.112",
            "415.0.0.27.108","410.1.0.32.106","405.0.0.26.108","400.0.0.22.109",
        ],
        "extras": ";FBOP/1",
        "fbrv_range": (2000000, 2039999),
    },
    "fb_business": {
        "label": "Facebook for Business",
        "fban_key": "FBANDROID",
        "versions": [
            "290.0.0.41.119","285.0.0.37.116","280.1.0.37.119","275.0.0.51.111",
            "270.0.0.42.107","265.1.0.44.108","260.0.0.38.118","255.0.0.41.115",
        ],
        "extras": ";FBOP/6",
        "fbrv_range": (1200000, 1239999),
    },
    "fb_marketplace": {
        "label": "Facebook Marketplace",
        "fban_key": "FBANDROID",
        "versions": [
            "462.0.0.37.110","458.0.0.31.114","455.0.0.25.109","450.1.0.34.105",
            "445.0.0.37.119","440.0.0.43.109","435.0.0.31.110","430.1.0.29.120",
        ],
        "extras": ";FBOP/5;FBBV/462",
        "fbrv_range": (2040000, 2069999),
    },
    "fb_groups": {
        "label": "Facebook Groups App",
        "fban_key": "FBANDROID",
        "versions": [
            "72.0.0.19.115","70.0.0.31.107","68.0.0.17.103","65.0.0.22.108",
            "62.0.0.30.118","58.0.0.27.103","55.0.0.25.105","52.0.0.29.114",
        ],
        "extras": ";FBOP/3",
        "fbrv_range": (1100000, 1139999),
    },
    "instagram": {
        "label": "Instagram (IAB)",
        "fban_key": "IGANDROID",
        "versions": [
            "448.0.0.23.58","445.0.0.18.55","438.0.0.28.88","432.0.0.22.51","430.0.0.25.56","327.0.0.41.91","325.0.0.35.90","322.0.0.31.89","320.0.0.28.90",
            "317.0.0.39.88","315.0.0.33.91","312.0.0.41.87","310.0.0.29.88",
            "307.0.0.42.87","305.0.0.35.86","302.0.0.42.85","299.0.0.29.84",
        ],
        "extras": "",
        "fbrv_range": (1500000, 1549999),
        "ig": True,
    },
    "threads": {
        "label": "Threads (Meta)",
        "fban_key": "THREADSANDROID",
        "versions": [
            "35.1.0.14.113","34.0.0.19.112","33.0.0.16.113","32.0.0.14.108",
            "31.0.0.21.107","30.0.0.14.109","29.0.0.31.108","28.0.0.22.107",
        ],
        "extras": "",
        "fbrv_range": (700000, 739999),
    },
    "whatsapp": {
        "label": "WhatsApp IAB",
        "fban_key": "WHATSAPP",
        "versions": [
            "2.24.20.75","2.24.19.81","2.24.18.76","2.24.17.73",
            "2.24.16.76","2.24.15.75","2.24.14.73","2.24.13.71",
            "2.24.12.78","2.24.11.80","2.24.10.78","2.24.9.77",
        ],
        "extras": "",
        "fbrv_range": (900000, 939999),
        "wa": True,
    },
}

# Weighted pick — Facebook main is most common in the wild
# v20.1: only variants whose REAL modern wire format is verified.
# fb_lite/threads/whatsapp/business/groups removed from the pool — their
# current UA formats could not be verified against live samples, so they
# were a fake-UA risk. fb_marketplace/groups/business were never separate
# browsers anyway (in-app tabs of the main app).
FB_IAB_WEIGHTS = {
    "fb_main": 45, "fb_messenger": 30, "instagram": 15, "fb_marketplace": 10,
}

def _build_fb_iab_ua(base_android_ua, device_model, android_version, variant_key=None):
    """Build a real-format Facebook/Meta IAB User-Agent string.

    Real modern formats (verified against live 2024-2026 samples):
      FB main:    <Chrome-WebView-UA> [FB_IAB/FB4A;FBAV/<ver>;]         (~70%)
                  <Chrome-WebView-UA> [FB_IAB/FB4A;FBAV/<ver>;IABMV/1;]  (~30%)
      Messenger:  [FB_IAB/Orca-Android;FBAV/<ver>;]
      Instagram:  <Chrome-WebView-UA> Instagram <ver> Android
    """
    if variant_key and variant_key != "random" and variant_key in FB_IAB_VARIANTS:
        variant = FB_IAB_VARIANTS[variant_key]
    else:
        # Weighted random pick (either variant_key=None, "random", or unknown key)
        keys = list(FB_IAB_WEIGHTS.keys())
        weights = [FB_IAB_WEIGHTS[k] for k in keys]
        variant_key = random.choices(keys, weights=weights, k=1)[0]
        variant = FB_IAB_VARIANTS[variant_key]

    app_version = random.choice(variant["versions"])

    # v20.1 EVIDENCE-BASED FIX: the old [FBAN/FBANDROID;FBDV/...;FBMD/...;
    # FBSS/...;FBLC/...;FBOP/...;FBRV/...] long block died with FB app
    # ~270 (2020). Every real modern FB app UA (verified against live
    # 2024-2026 samples) uses the SHORT block. Pairing modern 400+ FBAV
    # versions with the dead long format is an instant fake-UA tell AND
    # analytics classifiers (incl. Adsterra) match "FB_IAB/FB4A" to label
    # traffic "Facebook Browser" — the old format wasn't recognized.
    if variant.get("ig"):
        # Instagram webview: no bracket block, plain "Instagram <v> Android"
        # suffix (verified real samples: "... Mobile Safari/537.36
        # Instagram 444.0.0.28.88 Android").
        fban_block = f"Instagram {app_version} Android"
    elif variant_key == "fb_messenger":
        # Messenger: [FB_IAB/Orca-Android;FBAV/<ver>;] (verified)
        fban_block = f"[FB_IAB/Orca-Android;FBAV/{app_version};]"
    else:
        # fb_main / fb_marketplace / fb_groups / fb_business — all the main
        # Facebook for Android app (Marketplace & Groups are in-app tabs;
        # standalone apps discontinued). Real format:
        #   [FB_IAB/FB4A;FBAV/<ver>;]  (~70%)
        #   [FB_IAB/FB4A;FBAV/<ver>;IABMV/1;]  (~30%, newer builds)
        if random.random() < 0.3:
            fban_block = f"[FB_IAB/FB4A;FBAV/{app_version};IABMV/1;]"
        else:
            fban_block = f"[FB_IAB/FB4A;FBAV/{app_version};]"

    # v13.7.7: generate mibextid matching the variant (real FB mobile app click)
    _mibextid_pools = {
        "fb_main": ["JJWH9B","cr9h03","S17X4N","aYedtS","6HCLMF","rjt7Vl","PKnXoh"],
        "fb_messenger": ["S17X4N","JJWH9B","cr9h03","PKnXoh"],
        "fb_marketplace": ["JJWH9B","cr9h03","aYedtS"],
        "instagram": ["S17X4N","rjt7Vl","natr3t","Ib8wlB"],
    }
    mibextid = random.choice(_mibextid_pools.get(variant_key, ["JJWH9B","cr9h03","S17X4N"]))
    return f"{base_android_ua} {fban_block}", variant_key, variant["label"], mibextid


def _ref_fb_iab(url, keywords=None):
    """v13.3 — Facebook IAB referer. When a user taps a link inside the
    Facebook app (any Meta app), the outbound referer is ALWAYS the
    l.facebook.com link-shim — identical to a web browser Facebook click.
    v1.83 FIX: Now delegates to fb_ads_authentic.py for authentic h/tn/c[0] format.
    Old format (__tn__=-UK-R, 32-hex h, AT c[0]) was detectable as fake."""
    from fb_ads_authentic import build_facebook_organic_referer
    return build_facebook_organic_referer(url, is_mobile=True)

def _ref_ig_iab(url, keywords=None):
    """v1.83 FIX: Instagram IAB referer — now delegates to _ref_social_instagram
    for authentic l.instagram.com/l.php format with fbclid."""
    return _ref_social_instagram(url, keywords=keywords)

def _ref_wa_iab(url, keywords=None):
    """WhatsApp IAB — WhatsApp itself doesn't add a referer header when
    opening a link (stripped for privacy), so this returns None (direct)."""
    return None

_REFERER_BUILDERS = {
    "organic_google": _ref_organic_google,
    "organic_bing": _ref_organic_bing,
    "social_facebook": _ref_social_facebook,
    "social_instagram": _ref_social_instagram,
    "social_twitter": _ref_social_twitter,
    "social_reddit": _ref_social_reddit,
    "social_youtube": _ref_social_youtube,
    "social_tiktok": _ref_social_tiktok,
    "social_linkedin": _ref_social_linkedin,
    "referral": _ref_referral,
    # v13.3 — Facebook / Meta In-App Browser variants (each generates real IAB UA)
    "fb_iab_main":       _ref_fb_iab,
    "fb_iab_lite":       _ref_fb_iab,
    "fb_iab_messenger":  _ref_fb_iab,
    "fb_iab_business":   _ref_fb_iab,
    "fb_iab_marketplace":_ref_fb_iab,
    "fb_iab_groups":     _ref_fb_iab,
    "fb_iab_instagram":  _ref_ig_iab,
    "fb_iab_threads":    _ref_fb_iab,
    "fb_iab_whatsapp":   _ref_wa_iab,
    "fb_iab_random":     _ref_fb_iab,   # random Meta app every visit
    # v13.7 — Paid Ads sources (campaign-aware)
    "paid_facebook_ads":  _ref_facebook_ads,
    "paid_google_ads":    _ref_google_ads,
    "paid_tiktok_ads":    _ref_tiktok_ads,
}

# FB IAB source key → FB_IAB_VARIANTS key mapping
FB_IAB_SOURCE_MAP = {
    "fb_iab_main":        "fb_main",
    "fb_iab_lite":        "fb_main",        # v20.1: lite retired -> main app
    "fb_iab_messenger":   "fb_messenger",
    "fb_iab_business":    "fb_main",        # v20.1: business retired -> main app
    "fb_iab_marketplace": "fb_marketplace", # in-app tab of the main FB app
    "fb_iab_groups":      "fb_main",        # v20.1: groups retired -> main app
    "fb_iab_instagram":   "instagram",
    "fb_iab_threads":     "instagram",      # v20.1: threads retired -> instagram
    "fb_iab_whatsapp":    "fb_messenger",   # v20.1: whatsapp retired -> messenger
    "fb_iab_random":      "random",  # "random" = weighted random pick inside _build_fb_iab_ua
}

# Normal pool stays as-is (no IAB entries here — they're opt-in only)
_RANDOM_POOL = [k for k in _REFERER_BUILDERS if not k.startswith("fb_iab_")]



# v10.10/v11.3: Country-aware device mix — real-world mobile-vs-desktop and
# Android-vs-iPhone usage share varies A LOT by country. Using one flat
# global 55%/45% mobile/desktop + 75%/25% Android/iPhone split for EVERY
# country was unrealistic and a fraud-detection red flag (e.g. a "visitor
# from Bangladesh" pulling up on a desktop Windows Chrome nearly half the
# time is statistically absurd — real BD traffic is ~85%+ mobile). Each
# entry is (mobile_probability, ios_share_within_mobile).
COUNTRY_DEVICE_MIX = {
    # South Asia — extremely mobile-heavy, Android dominant
    "BD": (0.90, 0.03), "IN": (0.88, 0.05), "PK": (0.88, 0.04), "NP": (0.88, 0.03),
    "LK": (0.85, 0.05), "MM": (0.85, 0.02), "AF": (0.85, 0.02),
    # Southeast Asia — mobile-heavy, low-mid iOS
    "ID": (0.85, 0.10), "PH": (0.85, 0.12), "VN": (0.82, 0.10), "TH": (0.78, 0.15),
    "MY": (0.75, 0.20), "KH": (0.85, 0.05), "LA": (0.85, 0.05), "SG": (0.60, 0.45),
    # Africa — mobile-heavy, very low iOS
    "NG": (0.88, 0.06), "EG": (0.85, 0.08), "KE": (0.85, 0.05), "ZA": (0.75, 0.15),
    "GH": (0.85, 0.05), "TZ": (0.88, 0.03), "UG": (0.88, 0.03), "MA": (0.80, 0.12),
    "DZ": (0.82, 0.08), "TN": (0.80, 0.10),
    # Middle East / Gulf — high mobile AND high iOS (wealthy, iPhone-favoring)
    "AE": (0.70, 0.55), "SA": (0.72, 0.50), "QA": (0.68, 0.55), "KW": (0.70, 0.50),
    "BH": (0.70, 0.50), "OM": (0.72, 0.45), "JO": (0.75, 0.30), "LB": (0.72, 0.35),
    "TR": (0.70, 0.25), "IR": (0.75, 0.15), "IQ": (0.80, 0.15), "IL": (0.65, 0.40),
    # East Asia — Japan/Korea skew high iOS, China/etc more Android
    "JP": (0.60, 0.55), "KR": (0.62, 0.35), "CN": (0.65, 0.20), "HK": (0.65, 0.55),
    "TW": (0.65, 0.45),
    # Latin America — mobile-heavy, low-mid iOS
    "BR": (0.78, 0.20), "MX": (0.75, 0.22), "CO": (0.78, 0.15), "AR": (0.72, 0.20),
    "CL": (0.70, 0.25), "PE": (0.78, 0.12), "VE": (0.80, 0.10),
    # North America — balanced, high iOS share
    "US": (0.55, 0.55), "CA": (0.55, 0.50),
    # Western/Northern Europe — balanced-ish, mid-high iOS
    "GB": (0.58, 0.45), "UK": (0.58, 0.45), "DE": (0.52, 0.35), "FR": (0.55, 0.40),
    "ES": (0.60, 0.35), "IT": (0.58, 0.40), "NL": (0.55, 0.40), "SE": (0.55, 0.40),
    "NO": (0.55, 0.45), "DK": (0.55, 0.45), "FI": (0.55, 0.35), "BE": (0.55, 0.35),
    "CH": (0.55, 0.50), "AT": (0.55, 0.35), "IE": (0.58, 0.45), "PT": (0.62, 0.25),
    # Eastern Europe — mobile-leaning, low-mid iOS
    "PL": (0.62, 0.20), "RO": (0.65, 0.20), "HU": (0.60, 0.20), "CZ": (0.58, 0.25),
    "GR": (0.62, 0.25), "UA": (0.65, 0.15), "RU": (0.60, 0.15),
    # Oceania — balanced, high iOS
    "AU": (0.58, 0.50), "NZ": (0.58, 0.45),
}
_DEFAULT_DEVICE_MIX = (0.65, 0.25)  # unmapped country fallback


# v13.4 — Fixed internal Facebook Browser app split (hidden from user)
# v20.1: lite/groups/business retired (unverifiable or merged into the
# main FB app) — realistic modern Meta IAB distribution is FB main,
# Messenger, Instagram.
_FB_BROWSER_SPLIT = {
    "fb_iab_main":        55,
    "fb_iab_messenger":   25,
    "fb_iab_instagram":   15,
    "fb_iab_marketplace": 5,
}
_FB_BROWSER_KEYS    = list(_FB_BROWSER_SPLIT.keys())
_FB_BROWSER_WEIGHTS = [_FB_BROWSER_SPLIT[k] for k in _FB_BROWSER_KEYS]

class FingerprintGenerator:
    def __init__(self, preferred_browser=None, device_type=None, proxy_geo=None,
                 android_pct=None, fb_browser_pct=None, desktop_pct=None):
        self.preferred_browser = preferred_browser
        self.device_type = device_type
        self.proxy_geo = proxy_geo or {}
        # v13.4 — 3-way weighted mix: android / facebook_browser / desktop
        # These are only used when device_type is None (random mode)
        # v5.3: Reduced FB IAB to 15% (was 40%) — too much FB traffic is suspicious
        # Real ad network traffic is mostly Chrome (mobile + desktop), not Facebook
        self.android_pct    = android_pct    if android_pct    is not None else 55
        self.fb_browser_pct = fb_browser_pct if fb_browser_pct is not None else 15
        self.desktop_pct    = desktop_pct    if desktop_pct    is not None else 30

    def _get_device_mix(self):
        """v10.10/v11.3: Look up (mobile_probability, ios_share) for the
        current proxy country, falling back to a sane global default."""
        country = (self.proxy_geo or {}).get("country", "").upper()
        return COUNTRY_DEVICE_MIX.get(country, _DEFAULT_DEVICE_MIX)

    def generate(self):
        session_id = str(uuid.uuid4())
        seed = int(hashlib.md5(session_id.encode()).hexdigest()[:8], 16)
        # v13.4 — Explicit device type overrides
        if self.device_type == "android":
            _, ios_share = self._get_device_mix()
            return self._gen_mobile(session_id, seed, force_android=False, ios_share=ios_share)
        if self.device_type == "desktop":
            return self._gen_desktop(session_id, seed)
        # v13.4 — Facebook Browser: pick from fixed internal 5-app split
        if self.device_type == "facebook_browser":
            chosen_key = random.choices(_FB_BROWSER_KEYS, weights=_FB_BROWSER_WEIGHTS, k=1)[0]
            variant_key = FB_IAB_SOURCE_MAP.get(chosen_key, "fb_main")
            return self._gen_mobile(session_id, seed, force_android=True, fb_iab_variant=variant_key)
        # v13.4 — Random mode: 3-way weighted pick (android / facebook_browser / desktop)
        total_w = self.android_pct + self.fb_browser_pct + self.desktop_pct
        if total_w <= 0:
            total_w = 100; self.android_pct = 55; self.fb_browser_pct = 15; self.desktop_pct = 30
        roll = random.uniform(0, total_w)
        if roll < self.android_pct:
            # Pure mobile visit (Android + iOS)
            mobile_prob, ios_share = self._get_device_mix()
            return self._gen_mobile(session_id, seed, force_android=False, ios_share=ios_share)
        elif roll < self.android_pct + self.fb_browser_pct:
            # Facebook Browser visit
            chosen_key = random.choices(_FB_BROWSER_KEYS, weights=_FB_BROWSER_WEIGHTS, k=1)[0]
            variant_key = FB_IAB_SOURCE_MAP.get(chosen_key, "fb_main")
            return self._gen_mobile(session_id, seed, force_android=True, fb_iab_variant=variant_key)
        else:
            # Desktop visit
            return self._gen_desktop(session_id, seed)

    def _get_geo(self):
        # v11.0 — direct country-code lookup via COUNTRY_GEO (80+ countries).
        # Previously this went through a small 30-country name-matching map;
        # any proxy country NOT in that map (e.g. Sweden/SE, Poland/PL,
        # Israel/IL, etc.) silently fell through to a fully RANDOM country
        # choice — meaning a validated Swedish IP could get a US or Indian
        # timezone/locale on the actual browser fingerprint. That mismatch
        # is exactly what ad-network anti-fraud systems flag as suspicious.
        proxy_country = (self.proxy_geo or {}).get("country", "").upper().strip()
        if proxy_country and proxy_country in COUNTRY_GEO:
            rc = COUNTRY_GEO[proxy_country]
            return {"timezone":rc["tz"],"languages":rc["langs"],"locale":rc["locale"],"_country":rc["country"]}
        if proxy_country:
            # Country code confirmed by proxy validation but not in our table
            # (rare/small country) — log-worthy but not fatal. Fall back to
            # random rather than silently mismatching; caller can see this
            # via _country field not matching intended proxy_country.
            pass
        rc = random.choice(GEO_DATA)
        return {"timezone":rc["tz"],"languages":rc["langs"],"locale":rc["locale"],"_country":rc["country"]}

    def _gen_mobile(self, session_id, seed, force_android=False, ios_share=0.25, fb_iab_variant=None):
        """fb_iab_variant: if set, forces Android and wraps the UA in the
        correct Facebook/Meta IAB bracket (FBAN/...) for the chosen app.
        Pass None for the weighted-random IAB pick, or a specific key like
        'fb_main', 'fb_lite', 'fb_messenger' etc."""
        is_android = force_android or (fb_iab_variant is not None) or random.random() >= ios_share
        if is_android:
            # Weighted selection — mid-old models much more likely
            d = random.choices(ANDROID_PROFILES, weights=ANDROID_WEIGHTS, k=1)[0]
            # Android version correlates with device year
            yr = d.get("year", 2022)
            if yr <= 2019: av = random.choice(["10","11","11","12"])
            elif yr == 2020: av = random.choice(["11","12","12","13"])
            elif yr == 2021: av = random.choice(["11","12","13","13"])
            elif yr == 2022: av = random.choice(["12","13","13","14"])
            elif yr == 2023: av = random.choice(["13","14","14","15"])
            else: av = random.choice(["14","15","15"])
            # v14: Add Build/XXXXX fingerprint — real Android Chrome always includes this
            _build_hash = _generate_build_hash(d['model'], d.get('brand',''), av)
            _chrome_full = _gen_chrome_full_version()
            base_ua = f"Mozilla/5.0 (Linux; Android {av}; {d['model']} Build/{_build_hash}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{_chrome_full} Mobile Safari/537.36"
            bk = "chrome_android"  # default — Samsung Internet may override below
            _samsung_ver = None
            # v5.1: Samsung Internet variant (Chromium-based, ~15% of Android traffic)
            if random.random() < 0.15:
                _samsung_ver = random.choice(["23.0", "24.0", "25.0", "26.0", "27.0"])
                base_ua = f"Mozilla/5.0 (Linux; Android {av}; {d['model']} Build/{_build_hash}) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/{_samsung_ver} Chrome/{_chrome_full} Mobile Safari/537.36"
                bk = "samsung_internet"
            # v13.3 — FB IAB: wrap UA in real FBAN/... block
            if fb_iab_variant is not None:
                # v5.3 FIX: Real FB IAB uses WebView — UA MUST include "wv" + "Version/4.0"
                base_ua = f"Mozilla/5.0 (Linux; Android {av}; {d['model']} Build/{_build_hash}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{_chrome_full} Mobile Safari/537.36"
                ua, _used_variant, _label, _fb_mibextid = _build_fb_iab_ua(base_ua, d['model'], av, variant_key=fb_iab_variant)
                _fb_mibextid_store = _fb_mibextid
            else:
                ua = base_ua
            platform = "Linux armv8l"; fonts = FONTS_ANDROID
            webgl = {"vendor": d["gpu_vendor"], "renderer": d["gpu_renderer"]}
            density = d.get("density", 2.0)
            css_w = int(d["width"] / density)
            css_h = int(d["height"] / density)
            platform_version = f"{av}.0.0"  # single source of truth — HTTP + JS both read this
        else:
            d = random.choice(IPHONE_PROFILES)
            iv = random.choice(["16_5","16_6","17_1","17_2","17_3","17_4","17_5"])
            ua = f"Mozilla/5.0 (iPhone; CPU iPhone OS {iv} like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1"
            bk = "safari_iphone"; platform = "iPhone"; fonts = FONTS_IOS
            webgl = {"vendor": d["gpu_vendor"], "renderer": d["gpu_renderer"]}
            density = d.get("density", 2.0)
            css_w = int(d["width"] / density)
            css_h = int(d["height"] / density)
            platform_version = iv.replace("_", ".") + ".0"  # e.g. "17_5" -> "17.5.0" — matches UA's iOS version exactly
        geo = self._get_geo()
        screen = {"width": css_w, "height": css_h}
        canvas_seed = (seed * 31 + 7) & 0xFFFFFFFF
        audio_seed = (seed * 17 + 13) & 0xFFFFFFFF
        orientation = random.choice(["portrait-primary","portrait-primary","portrait-primary","landscape-primary"])
        # v5.3: Realistic mobile connection — ~60% WiFi (very common), ~40% cellular
        connection = random.choice([
            {"effectiveType":"4g","downlink":round(random.uniform(8,30),1),"rtt":random.choice([0,20,50]),"type":"wifi"},
            {"effectiveType":"4g","downlink":round(random.uniform(8,30),1),"rtt":random.choice([0,20,50]),"type":"wifi"},
            {"effectiveType":"4g","downlink":round(random.uniform(8,30),1),"rtt":random.choice([0,20,50]),"type":"wifi"},
            {"effectiveType":"4g","downlink":round(random.uniform(5,15),1),"rtt":random.choice([50,100,150]),"type":"cellular"},
            {"effectiveType":"4g","downlink":round(random.uniform(2,8),1),"rtt":random.choice([100,200]),"type":"cellular"},
        ])
        battery = {"level": random.choice([0.15,0.23,0.35,0.47,0.58,0.67,0.73,0.82,0.91,1.0]), "charging": random.random() > 0.6}
        return {
            "session_id":session_id,"browser_key":bk,"user_agent":ua,"playwright_channel":"chrome","is_mobile":True,"is_firefox":False,"is_safari":bk=="safari_iphone","fb_mibextid":locals().get("_fb_mibextid_store",""),
            "platform":platform,"screen":screen,"screen_avail":{"width":css_w,"height":css_h},
            "color_depth":24,"pixel_ratio":density,"timezone":geo["timezone"],
            "languages":geo["languages"],"locale":geo["locale"],"fonts":fonts,"webgl":webgl,
            "hardware_concurrency":max(2,d.get("cores",8)+random.choice([-1,0,0,0,1])),"device_memory":min(max(2,d.get("mem",4)+random.choice([0,0,0,2])),8),"touch_support":True,
            "max_touch_points":d.get("touch",5),"device_model":d.get("model",""),
            "canvas_seed":canvas_seed,"audio_seed":audio_seed,"is_android":is_android,"is_ios":not is_android,
            "battery":battery,"connection":connection,"orientation":orientation,
            "do_not_track":random.choice([None,"1","0","unset"]),"geo_country":geo.get("_country"),
            "platform_version":platform_version,
            "is_fb_iab": fb_iab_variant is not None,
            "is_samsung_internet": bk == "samsung_internet",
            "samsung_browser_ver": _samsung_ver if bk == "samsung_internet" else None,
        }

    def _gen_desktop(self, session_id, seed):
        # v13.7.5 — Realistic worldwide browser mix
        # Chrome ~65%, Edge ~5%, Firefox ~3%, Safari ~18% (mobile-heavy),
        # but on DESKTOP the split is: Chrome ~70%, Edge ~8%, Firefox ~5%, Safari ~15%
        # We simulate Firefox + Safari by spoofing UA + removing Chrome-specific
        # APIs (navigator.userAgentData, Sec-CH-UA headers, window.chrome).
        # Under the hood we still use Chromium engine, but we strip ALL
        # Chrome-specific signals so ad networks see a genuine Firefox/Safari.
        
        # Build the weighted choice list (only include edge if installed)
        # v5.1: Diverse browser pool for natural traffic distribution
        # Chrome = most common (real Chrome via channel="chrome" on RDP)
        # Edge = Chromium-based, pre-installed on Windows
        # Firefox = Gecko engine, different TLS/JA3, different JS engine
        #   → launched via playwright.firefox (NOT chromium)
        # v15: Safari now uses playwright.webkit (real WebKit engine) — no longer excluded
        # FIX v16.1: safari_mac REMOVED from pool — WebKit engine looks like
        # old Safari model + detectable TLS mismatch vs claimed UA.
        # Replaced with extra chrome_mac for realistic modern browser mix.
        browsers = [
            "chrome_win", "chrome_win", "chrome_win", "chrome_win",  # 40% Chrome Windows
            "chrome_mac", "chrome_mac", "chrome_mac",  # 20% Chrome Mac (was 13%, added safari slot)
            "chrome_linux",  # 6% Chrome Linux
            "edge_win", "edge_win",  # 13% Edge Windows
            # v1.83 FIX: Firefox engine disabled (Gecko context.close() hangs on RDP)
            # Firefox UAs still run on Chromium engine — same as Safari.
            # "firefox_win", "firefox_win",
            # "firefox_mac",
            # "firefox_linux",
            # safari_mac REMOVED — WebKit detection risk, old rendering engine
        ]
        # v5.3: Each browser entry gets weight=1 (duplicate count = natural weighting)
        # Firefox now uses playwright.firefox (Gecko engine) — no TLS mismatch
        weights = [1] * len(browsers)
        
        bc = random.choices(browsers, weights=weights)[0]
        is_edge = "edge" in bc
        is_firefox = "firefox" in bc
        is_safari = "safari" in bc
        
        _cfv = _gen_chrome_full_version()
        if bc=="chrome_win": ua=f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{_cfv} Safari/537.36"; platform="Win32"; fonts=FONTS_WIN; os_name="Windows"
        elif bc=="chrome_mac": ua=f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{_cfv} Safari/537.36"; platform="MacIntel"; fonts=FONTS_MAC; os_name="macOS"
        elif bc=="chrome_linux": ua=f"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{_cfv} Safari/537.36"; platform="Linux x86_64"; fonts=FONTS_LINUX; os_name="Linux"
        elif bc=="firefox_win": ua=random.choice(UA_FIREFOX_WIN); platform="Win32"; fonts=FONTS_WIN; os_name="Windows"
        elif bc=="firefox_mac": ua=random.choice(UA_FIREFOX_MAC); platform="MacIntel"; fonts=FONTS_MAC; os_name="macOS"
        elif bc=="firefox_linux": ua=random.choice(UA_FIREFOX_LINUX); platform="Linux x86_64"; fonts=FONTS_LINUX; os_name="Linux"
        elif bc=="safari_mac":
            # FALLBACK: safari_mac removed from pool above, but keep handler for safety
            # Use Chrome Mac UA instead of Safari WebKit UA
            _cfv2 = _gen_chrome_full_version()
            ua=f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{_cfv2} Safari/537.36"
            platform="MacIntel"; fonts=FONTS_MAC; os_name="macOS"
        else: ua=f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{_cfv} Safari/537.36 Edg/{_cfv}"; platform="Win32"; fonts=FONTS_WIN; os_name="Windows"

        # v13.0 CRITICAL FIX: WebGL renderer must come from the SAME os's own
        # physically-consistent pool (D3D11 strings only exist on Windows;
        # Metal strings only on macOS; native GL/Mesa strings only on Linux).
        # Previously every OS drew from one shared Windows-only pool.
        # v13.7.5 — Firefox/Safari use different WebGL vendor strings (no ANGLE)
        if is_firefox:
            if os_name == "Windows": webgl = random.choice(WEBGL_FIREFOX_WIN)
            elif os_name == "macOS": webgl = random.choice(WEBGL_FIREFOX_MAC)
            else: webgl = random.choice(WEBGL_FIREFOX_LINUX)
        elif is_safari:
            webgl = random.choice(WEBGL_SAFARI_MAC)  # Safari Mac-only
        elif os_name == "Windows": webgl = random.choice(WEBGL_WIN)
        elif os_name == "macOS": webgl = random.choice(WEBGL_MAC)
        else: webgl = random.choice(WEBGL_LINUX)

        # v13.0: OS build/version variety threaded as a SINGLE source of
        # truth (fingerprint.py decides it once here) — bot_engine.py's HTTP
        # header builder AND its navigator.userAgentData JS override both
        # read this exact same value, so Sec-CH-UA-Platform-Version (header)
        # can never drift out of sync with the JS-level getHighEntropyValues()
        # result. Windows gets the widest spread since it's the most common
        # + most requested OS; still weighted toward the newest, most common
        # real-world builds.
        if os_name == "Windows":
            platform_version = random.choices(
                ["10.0.19045.4046", "10.0.19045.5011", "13.0.0", "14.0.0", "15.0.0", "16.0.0"],
                weights=[10, 8, 12, 18, 30, 22],
            )[0]
        elif os_name == "macOS":
            platform_version = random.choices(
                ["14.0.0", "14.4.0", "14.6.0", "15.0.0", "15.1.0"],
                weights=[10, 15, 20, 30, 25],
            )[0]
        else:  # Linux
            platform_version = random.choices(["6.2.0", "6.5.0", "6.6.0", "6.8.0"], weights=[15, 30, 30, 25])[0]

        if os_name == "macOS":
            screen = random.choice(SCREEN_DESKTOP_MAC)
        elif os_name == "Linux":
            screen = random.choice(SCREEN_DESKTOP_LINUX)
        else:
            screen = random.choice(SCREEN_DESKTOP_WIN)
        geo = self._get_geo()
        canvas_seed = (seed * 31 + 7) & 0xFFFFFFFF
        audio_seed = (seed * 17 + 13) & 0xFFFFFFFF
        pixel_ratio = 1.0 if random.random() > 0.25 else random.choice([1.25,1.5,1.75,1.0,1.25])  # v5.3.1: more variety
        connection = random.choice([
            {"effectiveType":"4g","downlink":round(random.uniform(8,20),1),"rtt":random.choice([0,50,100]),"type":"wifi"},
            {"effectiveType":"4g","downlink":round(random.uniform(10,30),1),"rtt":0,"type":"wifi"},
        ])
        battery = {"level": random.choice([0.15,0.23,0.35,0.47,0.58,0.67,0.73,0.82,0.91,1.0]), "charging": random.random() > 0.6}
        return {
            "session_id":session_id,"browser_key":bc if not is_edge else "edge_windows","user_agent":ua,
            "playwright_channel": (EDGE_BINARY if is_edge and EDGE_AVAILABLE else "chrome"),
            "is_mobile":False,"is_firefox":is_firefox,"is_safari":is_safari,"is_edge":is_edge,"platform":platform,"screen":screen,
            "screen_avail":{"width":screen["width"],"height":int(screen["height"]*0.92)},
            "color_depth":random.choice([24,24,24,24,24,24,24,24,30,30,32]),
            "pixel_ratio":pixel_ratio,
            "timezone":geo["timezone"],"languages":geo["languages"],"locale":geo["locale"],
            "fonts":fonts,"webgl":webgl,"hardware_concurrency":random.choice([4,8,8,12,16,8,6]),
            "device_memory":random.choice([4,8,8,8,8,4]),"touch_support":False,"max_touch_points":0,
            "device_model":"","canvas_seed":canvas_seed,"audio_seed":audio_seed,
            "is_android":False,"is_ios":False,"battery":battery,"connection":connection,
            "orientation":"landscape-primary","do_not_track":random.choice([None,"1","0","unset"]),
            "geo_country":geo.get("_country"),"os_name":os_name,"platform_version":platform_version,
        }

    # v13.2 — sources whose authentic real-world URL format has an actual
    # text/topic slot (search query or post slug) where a custom SEO keyword
    # can be inserted without breaking realism. The other 6 sources are
    # hash/ID-only in real life (Facebook, Instagram, Twitter, YouTube,
    # TikTok, LinkedIn) — forcing a keyword into those would make them look
    # FAKE, so they intentionally never receive `keywords`.
    KEYWORD_CAPABLE_SOURCES = {"organic_google", "organic_bing", "social_reddit", "referral"}

    @staticmethod
    def get_referer(traffic_source, url, allowed_sources=None, keywords=None, campaign_config=None, is_mobile=False):
        """Build an authentic, unique-per-visit referer header for the given
        traffic source. Returns (referer_url_or_None, resolved_source_label,
        tagged_destination_url_or_None).

        For organic/social sources: returns (referer, source, None) — the
        bot navigates to the plain URL with the referer set.

        For paid ads sources (paid_facebook_ads, paid_google_ads,
        paid_tiktok_ads): returns (referer, source, tagged_url) — the bot
        navigates to tagged_url (which has UTM/gclid/ttclid in the address
        bar) with the referer set. This is what makes GA see it as PAID (cpc),
        not organic — GA reads UTM params from location.search (address bar).

        "random" mode picks a fresh source from the FULL pool on EVERY call.
        "custom_mix" mode restricts the pick to only allowed_sources.
        """
        resolved = traffic_source
        if traffic_source == "random":
            resolved = random.choice(_RANDOM_POOL)
        elif traffic_source == "custom_mix":
            pool = [s for s in (allowed_sources or []) if s in _REFERER_BUILDERS]
            resolved = random.choice(pool) if pool else random.choice(_RANDOM_POOL)

        # WhatsApp IAB explicitly strips referer (real behavior)
        if resolved in ("direct", "email", "fb_iab_whatsapp") or resolved not in _REFERER_BUILDERS:
            return None, resolved, None

        kw = keywords if (keywords and resolved in FingerprintGenerator.KEYWORD_CAPABLE_SOURCES) else None
        try:
            if resolved.startswith("paid_") and campaign_config is not None:
                result = _REFERER_BUILDERS[resolved](url, campaign_config)
            elif resolved.startswith("paid_"):
                result = _REFERER_BUILDERS[resolved](url)
            elif resolved == "social_facebook" and is_mobile:
                # Mobile organic FB → use mobile-aware domain variants (lm.facebook.com, m.facebook.com)
                from fb_ads_authentic import build_facebook_organic_referer
                result = build_facebook_organic_referer(url, is_mobile=True)
            else:
                result = _REFERER_BUILDERS[resolved](url, kw)
        except Exception:
            result = None

        # Paid ads builders return (referer, tagged_url) tuple
        if isinstance(result, tuple) and len(result) == 2:
            return result[0], resolved, result[1]
        # Organic/social builders return a plain string (referer)
        return result, resolved, None


def build_stealth_init_script(fp, target_domain=None, referer_url=None):
    from build_script_helper import build_stealth_script
    return build_stealth_script(fp, target_domain, referer_url=referer_url)
