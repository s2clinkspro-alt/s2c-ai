"""
Visitor Bot v14.0 — Local Setup (Windows/Mac)
Run: python setup_local.py

Installs ALL three Playwright browser engines:
  - Chromium  → Chrome, Edge, Samsung Internet, Chrome Android
  - Firefox   → Firefox (real Gecko engine)
  - WebKit    → Safari iOS + Safari Mac (real WebKit engine)
"""
import subprocess
import sys
import os
import urllib.request
import platform

def run(cmd, check=True):
    print(f"  > {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0 and check:
        print(f"    WARNING: {result.stderr[:200]}")
    return result

def download(url, dest):
    try:
        urllib.request.urlretrieve(url, dest)
        print(f"    OK {os.path.basename(dest)}")
        return True
    except Exception as e:
        print(f"    FAILED: {e}")
        return False

print("=" * 50)
print("  Visitor Bot v14.0 — Local Setup")
print("  Windows / Mac")
print("  Engines: Chromium + Firefox + WebKit")
print("=" * 50)
print()

os_name = platform.system()
print(f"  OS: {os_name}")
print(f"  Python: {sys.version.split()[0]}")
print()

# ── 1. Install Python packages ──
print("[1/4] Installing Python packages...")
run(f'{sys.executable} -m pip install -r requirements.txt')
print("  Done")
print()

# ── 2. Install Playwright — ALL engines ──
print("[2/4] Installing Playwright browser engines...")

print("  [a] Chromium (Chrome, Edge, Samsung Internet)...")
run(f'{sys.executable} -m playwright install chromium')

print("  [b] Firefox (real Gecko engine)...")
run(f'{sys.executable} -m playwright install firefox')

print("  [c] WebKit (real Safari/WebKit engine)...")
run(f'{sys.executable} -m playwright install webkit')

print("  Done")
print()

# ── 3. Install system deps (Linux only — no-op on Windows/Mac) ──
print("[3/4] Installing system dependencies (if needed)...")
run(f'{sys.executable} -m playwright install-deps', check=False)
print("  Done")
print()

# ── 4. Download Android fonts ──
print("[4/4] Downloading Android fonts (Roboto, Noto Sans)...")
font_dir = os.path.join(os.path.dirname(__file__), "fonts")
os.makedirs(font_dir, exist_ok=True)

fonts = [
    ("https://github.com/googlefonts/roboto-3-classic/raw/main/src/hinted/Roboto-Regular.ttf", "Roboto-Regular.ttf"),
    ("https://github.com/googlefonts/roboto-3-classic/raw/main/src/hinted/Roboto-Bold.ttf", "Roboto-Bold.ttf"),
    ("https://github.com/googlefonts/roboto-3-classic/raw/main/src/hinted/Roboto-Medium.ttf", "Roboto-Medium.ttf"),
    ("https://github.com/googlefonts/roboto-3-classic/raw/main/src/hinted/Roboto-Light.ttf", "Roboto-Light.ttf"),
    ("https://github.com/notofonts/notofonts.github.io/raw/main/fonts/NotoSans/hinted/ttf/NotoSans-Regular.ttf", "NotoSans-Regular.ttf"),
    ("https://github.com/notofonts/notofonts.github.io/raw/main/fonts/NotoSans/hinted/ttf/NotoSans-Bold.ttf", "NotoSans-Bold.ttf"),
]

for url, name in fonts:
    dest = os.path.join(font_dir, name)
    if not os.path.exists(dest):
        download(url, dest)
    else:
        print(f"    OK {name} (already exists)")

print()
print("=" * 55)
print("  Setup Complete!")
print()
print("  Engines installed:")
print("    Chromium  -> Chrome, Edge, Samsung Internet")
print("    Firefox  -> real Gecko engine")
print("    WebKit   -> real Safari/WebKit engine")
print()
print("  Dashboard: http://localhost:5000")
print("=" * 55)
print()
print("IMPORTANT: fonts/ folder er sob .ttf file double-click")
print("kore install koro (Windows) ba Install Font (Mac)")
print("Android emulation e canvas/font rendering 100% real hobe.")
