"""
Flask Dashboard — Premium UI for Visitor Bot v14.0
Short visit mode (3-6 sec) for smartlink impressions.
"""

import asyncio
import threading
import json
import time
import csv
import io
import random
import sys
import warnings
import os

# Suppress pkg_resources deprecation warning from playwright_stealth (harmless)
warnings.filterwarnings("ignore", category=UserWarning)
os.environ.setdefault("PYTHONWARNINGS", "ignore::UserWarning")

from flask import Flask, render_template, request, jsonify, Response
from flask_socketio import SocketIO

from bot_engine import BotEngine
from proxy_validator import ProxyValidator, fraud_db_check, get_fraud_db_usage, NodeMavenConfig

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY', 'vb-v14-' + str(os.getpid()))
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading', ping_timeout=60, ping_interval=25)

bot_engine = None
bot_thread = None
log_buffer = []
proxy_validator = ProxyValidator()


def log_callback(msg):
    timestamp = time.strftime("%H:%M:%S")
    log_entry = {"time": timestamp, "msg": msg}
    log_buffer.append(log_entry)
    if len(log_buffer) > 500:
        log_buffer.pop(0)
    try:
        socketio.emit('log', log_entry)
    except Exception:
        pass


@app.route('/')
def dashboard():
    return render_template('dashboard.html')


@app.route('/api/start', methods=['POST'])
def start_bot():
    global bot_engine, bot_thread

    if bot_engine and bot_engine.is_running:
        return jsonify({"error": "Bot is already running"}), 400

    data = request.json

    # Parse links
    # v13.1 — accepts either the classic single textarea (comma/newline
    # separated) OR the new per-link dashboard rows as a JSON list in
    # `link_list` (each item: {"url": "...", "pct": 40}). If `link_list` is
    # present it takes priority; otherwise falls back to the old `links`
    # raw-text field so nothing existing breaks.
    link_list = data.get('link_list')
    link_percentages = None
    if isinstance(link_list, list) and link_list:
        links = [str(item.get('url', '')).strip() for item in link_list if str(item.get('url', '')).strip()]
        pcts = [item.get('pct') for item in link_list if str(item.get('url', '')).strip()]
        if len(links) > 1 and all(isinstance(p, (int, float)) for p in pcts) and sum(pcts) > 0:
            link_percentages = [float(p) for p in pcts]
    else:
        raw_links = data.get('links', '')
        links = [l.strip() for l in raw_links.replace(',', '\n').split('\n') if l.strip()]

    if not links:
        return jsonify({"error": "No links provided"}), 400

    # Parse proxies
    proxies = []
    nodemaven_config = data.get('nodemaven', {})
    if nodemaven_config.get('enabled') and nodemaven_config.get('username'):
        nm = NodeMavenConfig(
            username=nodemaven_config['username'],
            password=nodemaven_config.get('password', ''),
            proxy_type=nodemaven_config.get('proxy_type', 'residential'),
            port=int(nodemaven_config.get('port', 8080)),
        )
        countries = nodemaven_config.get('countries', '').split(',') if nodemaven_config.get('countries') else None
        countries = [c.strip() for c in countries if c.strip()] if countries else None
        proxy_count = int(nodemaven_config.get('proxy_count', 10))
        quality_filter = nodemaven_config.get('quality_filter', 'medium')
        nm_proxies = nm.generate_batch(count=proxy_count, countries=countries, quality_filter=quality_filter)
        proxies = [p["raw"] for p in nm_proxies]
        log_callback(f"NodeMaven: generated {len(proxies)} proxies (type: {nodemaven_config.get('proxy_type')}, filter: {quality_filter})")
    else:
        raw_proxies = data.get('proxies', '')
        proxies = [p.strip() for p in raw_proxies.split('\n') if p.strip()]

    quick_impression = data.get('quick_impression', False)

    # Short visit dwell times (3-6 sec)
    if quick_impression:
        min_dwell = int(data.get('min_dwell', 4))
        max_dwell = int(data.get('max_dwell', 8))
    else:
        min_dwell = int(data.get('min_dwell', 15))
        max_dwell = int(data.get('max_dwell', 45))

    config = {
        'links': links,
        'proxies': proxies,
        'visits_per_link': int(data.get('visits_per_link', 1)),
        # v13.1 — Per-Link Percentage Split (only meaningful when 2+ links
        # are configured with matching percentages from the dashboard rows).
        'link_percentages': link_percentages,
        'total_visits': int(data.get('total_visits')) if data.get('total_visits') else None,
        'min_delay': int(data.get('min_delay', 1)),
        'max_delay': int(data.get('max_delay', 2)),
        'scroll': data.get('scroll', True),
        'click': data.get('click', False),
        'mouse_movement': data.get('mouse_movement', True),
        'form_fill': data.get('form_fill', False),
        'multi_page': data.get('multi_page', False),
        'min_dwell': min_dwell,
        'max_dwell': max_dwell,
        'min_visit_time': int(data.get('min_visit_time', 3)),
        'max_visit_time': int(data.get('max_visit_time', 6)),
        'browser_type': data.get('browser_type', 'auto'),
        'device_type': data.get('device_type', 'random'),
        'android_pct': int(data.get('android_pct', 55)),
        'fb_browser_pct': int(data.get('fb_browser_pct', 15)),
        'desktop_pct': int(data.get('desktop_pct', 30)),
        'traffic_source': data.get('traffic_source', 'random'),
        # v13.1 — Custom Referrer Selection: when traffic_source=='custom_mix',
        # this holds the 2-5 sources the user picked on the dashboard, and
        # every visit's referer is randomly drawn from ONLY this list.
        'custom_traffic_sources': data.get('custom_traffic_sources') if data.get('traffic_source') == 'custom_mix' else None,
        # v13.2 — Custom SEO Keyword System: only applied to Google/Bing/Reddit/Referral
        # referer builders (the other sources have no real-world keyword slot).
        'keyword_system_enabled': bool(data.get('keyword_system_enabled')),
        'seo_keywords': [k.strip() for k in (data.get('seo_keywords') or []) if str(k).strip()][:10],
        'headless': data.get('headless', False) and not sys.platform.startswith('win'),  # Windows=always headed
        # v13.7 RDP Visual Mode — opens REAL Chrome/Edge on Windows (not Playwright Chromium)
        # auto-detected: if the runner is Windows, Chrome/Edge is tried first, always headed.
        # v13.7 RDP Visual Mode — opens REAL Chrome/Edge on Windows (not Playwright Chromium)
        # auto-detected: if the runner is Windows, Chrome/Edge is tried first, always headed.
        'real_browser_mode': data.get('real_browser_mode', False) or sys.platform.startswith('win'),
        'quick_impression': quick_impression,
        'validate_proxies': data.get('validate_proxies', True),
        'fraud_check_enabled': data.get('fraud_check_enabled', False),
        'pre_browse_google': data.get('pre_browse_google', True),
        'pre_browse_chance': float(data.get('pre_browse_chance', 0.6)),
        'nav_timeout_ms': 60000,

        # ── v10.5: Landing Page + Button Click Mode ──
        'visit_mode': data.get('visit_mode', 'direct'),  # 'direct' | 'button_click' | 'fb_embed'
        'landing_url': data.get('landing_url', ''),
        'button_selector': data.get('button_selector', ''),
        'button_text': data.get('button_text', ''),
        'pre_click_wait_min': float(data.get('pre_click_wait_min', 2)),
        'pre_click_wait_max': float(data.get('pre_click_wait_max', 5)),

        # ── v12.0: Concurrent visits (opt-in, manual/paid-proxy mode) ──
        # Default 1 = fully sequential (unchanged old behavior). Dashboard
        # only shows the input box when the toggle is switched ON; when OFF
        # this always resolves to 1 regardless of what was typed before.
        'concurrent_visits': max(1, min(10, int(data.get('concurrent_visits', 1) or 1))) if data.get('concurrent_mode_enabled') else 1,
    }

    # v10.0 — Real-time IP consumption callback: the instant a proxy is
    # used (visit succeeded) or discarded (validation failed / visit failed),
    # this fires and the dashboard removes that exact IP row live via socket.
    def ip_callback(proxy, status, extra=None):
        try:
            socketio.emit('ip_consumed', {
                "proxy": {
                    "raw": proxy.get("raw"),
                    "ip": proxy.get("ip"),
                    "display_ip": proxy.get("display_ip"),
                    "unique_key": proxy.get("unique_key"),
                },
                "status": status,  # "used" | "failed"
                "extra": extra or {},
            })
        except Exception:
            pass

    bot_engine = BotEngine(config, log_callback, ip_callback)

    def run_bot():
        global bot_loop
        bot_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(bot_loop)
        try:
            bot_loop.run_until_complete(bot_engine.run())
        except Exception as e:
            log_callback(f"Fatal error: {str(e)}")
        finally:
            bot_loop.close()

    bot_thread = threading.Thread(target=run_bot, daemon=True)
    bot_thread.start()

    mode_label = "Short Visit (3-6s)" if quick_impression else "Full Session"
    return jsonify({
        "status": "started", "links": len(links), "proxies": len(proxies), "mode": mode_label,
        "concurrent_visits": config['concurrent_visits'],
    })


@app.route('/api/stop', methods=['POST'])
def stop_bot():
    global bot_engine
    if bot_engine:
        bot_engine.stop()
        return jsonify({"status": "stopping"})
    return jsonify({"error": "Bot not running"}), 400


@app.route('/api/pause', methods=['POST'])
def pause_bot():
    global bot_engine
    if bot_engine and bot_engine.is_running:
        bot_engine.pause()
        return jsonify({"status": "paused"})
    return jsonify({"error": "Bot not running"}), 400


@app.route('/api/resume', methods=['POST'])
def resume_bot():
    global bot_engine
    if bot_engine:
        bot_engine.resume()
        return jsonify({"status": "resumed"})
    return jsonify({"error": "Bot not running"}), 400


@app.route('/api/status', methods=['GET'])
def get_status():
    global bot_engine
    if not bot_engine:
        return jsonify({
            "running": False,
            "stats": {"total_visits": 0, "successful": 0, "failed": 0, "remaining": 0,
                      "proxies_validated": 0, "proxies_rejected": 0},
            "proxy_stats": {"total": 0, "available": 0, "failed": 0},
            "proxy_validation": {"total_checked": 0, "valid": 0, "residential": 0, "datacenter": 0, "avg_score": 0},
            "logs": log_buffer[-50:]
        })

    return jsonify({
        "running": bot_engine.is_running,
        "paused": bot_engine.is_paused,
        "stats": bot_engine.stats,
        "proxy_stats": bot_engine.proxy_manager.get_stats(),
        "used_ips": bot_engine.proxy_manager.get_consumed_ips() if hasattr(bot_engine.proxy_manager, 'get_consumed_ips') else [],
        "proxy_validation": bot_engine.proxy_validator.get_stats() if hasattr(bot_engine, 'proxy_validator') else {},
        "logs": log_buffer[-50:]
    })


@app.route('/api/results', methods=['GET'])
def get_results():
    global bot_engine
    if not bot_engine:
        return jsonify({"results": []})

    results = []
    for r in bot_engine.results[-100:]:
        results.append({
            "url": r.url, "success": r.success, "proxy_ip": r.proxy_ip,
            "fingerprint": r.fingerprint_id[:20], "duration": round(r.duration, 1),
            "error": r.error, "timestamp": r.timestamp,
            "redirects": getattr(r, 'redirects', 0),
            "final_url": getattr(r, 'final_url', None),
            "country": getattr(r, 'proxy_country', None),
            "ip_quality": getattr(r, 'ip_quality', 0),
        })

    return jsonify({"results": results})


@app.route('/api/export/csv', methods=['GET'])
def export_csv():
    global bot_engine
    if not bot_engine or not bot_engine.results:
        return Response("No results to export", status=400)

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Timestamp', 'URL', 'Final URL', 'Success', 'Proxy IP', 'Country', 'IP Quality',
                     'Device', 'Duration (s)', 'Redirects', 'Error'])

    for r in bot_engine.results:
        writer.writerow([
            r.timestamp, r.url, getattr(r, 'final_url', '') or '',
            'Yes' if r.success else 'No', r.proxy_ip,
            getattr(r, 'proxy_country', '') or '', getattr(r, 'ip_quality', 0),
            r.fingerprint_id[:20], round(r.duration, 1),
            getattr(r, 'redirects', 0), r.error or ''
        ])

    output.seek(0)
    return Response(output.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': 'attachment; filename=visitor_bot_v9_results.csv'})


@app.route('/api/fraud/usage', methods=['GET'])
def fraud_usage():
    """Return fraud DB daily usage stats for dashboard."""
    return jsonify(get_fraud_db_usage())

@app.route('/api/proxy/validate', methods=['POST'])
def validate_proxies():
    """
    v9.0 — STREAMING validation (Item: real-time IP list).
    Instead of blocking until every proxy in the list is validated (which could
    take a while and previously left the whole IP list stuck on "Pending" until
    the entire batch finished — or forever, if the request timed out), this now
    kicks off a background task that emits one 'proxy_validated' socket event
    PER PROXY the instant its own result is ready. The HTTP response returns
    immediately so the UI never blocks waiting on a single giant response.
    """
    data = request.json
    raw_proxies = data.get('proxies', '')
    # FIX: the dashboard JS sends `proxies` as an already-split JSON array
    # (lines = textarea.value.split('\n')...), but this route assumed a raw
    # newline-delimited STRING and called raw_proxies.split('\n') on it —
    # which threw "AttributeError: 'list' object has no attribute 'split'"
    # on every single call, returning HTTP 500 before any validation ever
    # started. That's why every row stayed stuck on "Checking" forever: the
    # request failed instantly and no proxy_validated events were ever
    # emitted. Now we accept both a list (current client) and a string
    # (older client / direct API calls) for safety.
    if isinstance(raw_proxies, list):
        proxy_list = [str(p).strip() for p in raw_proxies if str(p).strip()]
    else:
        proxy_list = [p.strip() for p in str(raw_proxies).split('\n') if p.strip()]

    if not proxy_list:
        return jsonify({"error": "No proxies provided"}), 400

    from proxy_manager import ProxyManager
    pm = ProxyManager(proxy_list)
    total = len(pm.proxies)

    def _run_validation_batch(proxies_to_check):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        summary = {"checked": 0, "valid": 0, "residential": 0, "datacenter": 0}

        async def validate_one(p):
            try:
                from proxy_validator import _guess_proxy_timeout
                _tmo = _guess_proxy_timeout(p, base=10)
                result = await proxy_validator.validate_proxy(p, timeout=_tmo)
            except Exception as e:
                result = {"ip": p["ip"], "valid": False, "error": str(e)[:100], "quality_score": 0,
                          "residential": False, "mobile": False, "datacenter": False, "vpn": False,
                          "country": None, "country_code": None, "city": None, "isp": None}

            summary["checked"] += 1
            if result.get("valid"):
                summary["valid"] += 1
            if result.get("residential"):
                summary["residential"] += 1
            if result.get("datacenter"):
                summary["datacenter"] += 1

            # Emit the instant this ONE proxy finishes — matched by the exact
            # raw line + unique_key so gateway/session-style proxies (e.g.
            # NodeMaven "gate.xxx.com:port:user-sid-XXXX:pass") match correctly
            # even though they all share the same host.
            try:
                socketio.emit('proxy_validated', {
                    "raw": p.get("raw"), "unique_key": p.get("unique_key"), "display_ip": p.get("display_ip"),
                    "line_index": p.get("line_index"),
                    "ip": result.get("ip"), "valid": result.get("valid"),
                    "residential": result.get("residential"), "mobile": result.get("mobile"),
                    "datacenter": result.get("datacenter"), "vpn": result.get("vpn"),
                    "country": result.get("country"), "country_code": result.get("country_code"),
                    "city": result.get("city"), "isp": result.get("isp"),
                    "quality_score": result.get("quality_score"), "error": result.get("error"),
                    "checked": summary["checked"], "total": total,
                })
            except Exception:
                pass

        async def run_all():
            # v11.0 FIX: proxy_validator.py now has a 3-tier IP-info fallback
            # (ip-api.com -> ipwho.is -> ipinfo.io), so a single rate-limited
            # provider no longer stalls the whole batch. This lets us safely
            # run a small pool of proxies CONCURRENTLY instead of one at a
            # time, which was taking 10-20+ minutes for large batches (e.g.
            # premium gateway proxies pasted as N identical rotation lines).
            # Concurrency=5 balances speed vs not hammering the free geo APIs.
            sem = asyncio.Semaphore(5)

            async def _bounded(p):
                async with sem:
                    await validate_one(p)

            await asyncio.gather(*[_bounded(p) for p in proxies_to_check], return_exceptions=True)

        loop.run_until_complete(run_all())
        loop.close()

        try:
            socketio.emit('proxy_validate_done', {
                "total": total, "valid": summary["valid"],
                "residential": summary["residential"], "datacenter": summary["datacenter"],
            })
        except Exception:
            pass

    socketio.start_background_task(_run_validation_batch, pm.proxies)

    return jsonify({"started": True, "total": total})


@socketio.on('connect')
def handle_connect():
    for log in log_buffer[-20:]:
        try:
            socketio.emit('log', log)
        except Exception:
            pass



# ═══════════════════════════════════════════════════════════════
# PROXY HARVESTER INTEGRATION
# ═══════════════════════════════════════════════════════════════
import aiohttp
import re as _re
from aiohttp_socks import ProxyType, ProxyConnector

SOCKS_MAP = {"socks5": ProxyType.SOCKS5, "socks4": ProxyType.SOCKS4, "http": ProxyType.HTTP, "https": ProxyType.HTTP}

HARVEST_STATE = {
    "running": False, "phase": "idle",
    "scrape_progress": {"current": 0, "total": 0, "source": ""},
    "filter_progress": {"current": 0, "total": 0},
    "stats": {"raw_count": 0, "checked": 0, "passed": 0, "failed": 0},
    "passed": [], "log_buffer": [], "moved_count": 0,
}

# ── 24-hour proxy memory (disk-persistent) ──
import os as _os, json as _json_mod
PASSED_MEMORY_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "passed_memory.json")
_passed_keys_lock = threading.Lock()

def _load_passed_memory():
    """Load previously validated proxies from disk (24h cache)."""
    try:
        if _os.path.exists(PASSED_MEMORY_FILE):
            with open(PASSED_MEMORY_FILE, 'r') as f:
                data = _json_mod.load(f)
            # Filter out entries older than 24h
            now = time.time()
            fresh = [e for e in data if now - e.get("_ts", 0) < 86400]
            if len(fresh) < len(data):
                with open(PASSED_MEMORY_FILE, 'w') as f:
                    _json_mod.dump(fresh, f)
            return fresh
    except: pass
    return []

def _save_passed_memory(proxy_data):
    """Add a proxy to the 24h disk cache."""
    with _passed_keys_lock:
        try:
            existing = []
            if _os.path.exists(PASSED_MEMORY_FILE):
                with open(PASSED_MEMORY_FILE, 'r') as f:
                    existing = _json_mod.load(f)
            # Check if already exists (by ip:port:protocol)
            key = f"{proxy_data['ip']}:{proxy_data['port']}:{proxy_data['protocol']}"
            existing = [e for e in existing if f"{e.get('ip')}:{e.get('port')}:{e.get('protocol')}" != key]
            entry = dict(proxy_data)
            entry["_ts"] = time.time()
            existing.append(entry)
            with open(PASSED_MEMORY_FILE, 'w') as f:
                _json_mod.dump(existing, f)
        except: pass

def _is_in_passed_memory(ip, port, protocol):
    """Check if a proxy is in the 24h cache."""
    try:
        memory = _load_passed_memory()
        key = f"{ip}:{port}:{protocol}"
        return any(f"{e.get('ip')}:{e.get('port')}:{e.get('protocol')}" == key for e in memory)
    except: return False

# ── Rotating chunk cache for mega-sources (e.g. gfpcom's 469k+ line lists) ──
# Instead of randomly re-sampling the same-size slice every run (which can
# miss huge parts of the source forever, or waste time re-checking the same
# ones), we persist a rotation offset PER SOURCE on disk. Each run takes the
# next chunk in sequence and wraps back to the start once the whole source
# has been walked through — so over enough runs, 100% of a huge source gets
# scraped/validated eventually, with zero permanent blind spots.
SOURCE_ROTATION_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "source_rotation.json")

def _load_rotation():
    try:
        if _os.path.exists(SOURCE_ROTATION_FILE):
            with open(SOURCE_ROTATION_FILE, 'r') as f:
                return _json_mod.load(f)
    except: pass
    return {}

def _save_rotation(rotation):
    try:
        with open(SOURCE_ROTATION_FILE, 'w') as f:
            _json_mod.dump(rotation, f)
    except: pass

def _rotate_chunk(name, parsed, chunk_size):
    """Return the next rotating chunk_size-sized slice of `parsed` for
    source `name`, advancing (and persisting) the offset so the NEXT run
    picks up right where this one left off. Wraps around at the end."""
    total = len(parsed)
    if total <= chunk_size:
        return parsed
    rotation = _load_rotation()
    offset = rotation.get(name, 0) % total
    end = offset + chunk_size
    if end <= total:
        chunk = parsed[offset:end]
        next_offset = end % total
    else:
        chunk = parsed[offset:] + parsed[:end - total]
        next_offset = end - total
    rotation[name] = next_offset
    _save_rotation(rotation)
    coverage_pct = round(((offset + chunk_size) % total or total) / total * 100, 1)
    h_log(f"  ROTATE {name}: chunk {offset}-{offset+chunk_size} of {total} (full-source coverage progresses each run)")
    random.shuffle(chunk)  # keep some freshness/order variety within the chunk itself
    return chunk

def h_log(msg):
    entry = {"time": time.strftime("%H:%M:%S"), "msg": msg}
    HARVEST_STATE["log_buffer"].append(entry)
    if len(HARVEST_STATE["log_buffer"]) > 200:
        HARVEST_STATE["log_buffer"] = HARVEST_STATE["log_buffer"][-200:]
    try: socketio.emit("harvest_log", entry)
    except: pass


# ── AUTO PIPELINE STATE ──
AUTO_STATE = {
    "running": False,
    "phase": "idle",  # idle, harvesting, visiting, waiting, done
    "config": {},
    "worker_status": "stopped",
    "visits_done": 0,
    "visits_success": 0,
    "visits_failed": 0,
    "current_proxy": None,
    "current_visit_start": None,
    "log_buffer": [],
    "auto_thread": None,
    "auto_loop": None,
    "stop_flag": False,
    # Every proxy the Auto Start worker has picked up & used this session —
    # prevents the harvester's continuous re-scrape loop (+ 24h cache) from
    # ever reintroducing an already-used proxy into the passed pool.
    "used_keys": set(),
}

def auto_log(msg):
    entry = {"time": time.strftime("%H:%M:%S"), "msg": msg}
    AUTO_STATE["log_buffer"].append(entry)
    if len(AUTO_STATE["log_buffer"]) > 200:
        AUTO_STATE["log_buffer"] = AUTO_STATE["log_buffer"][-200:]
    try: socketio.emit("auto_log", entry)
    except: pass

def auto_emit_state():
    try:
        socketio.emit("auto_state", {
            "running": AUTO_STATE["running"],
            "phase": AUTO_STATE["phase"],
            "worker_status": AUTO_STATE["worker_status"],
            "visits_done": AUTO_STATE["visits_done"],
            "visits_success": AUTO_STATE["visits_success"],
            "visits_failed": AUTO_STATE["visits_failed"],
            "current_proxy": AUTO_STATE["current_proxy"],
            "passed_available": len(HARVEST_STATE.get("passed", [])),
            "harvest_running": HARVEST_STATE.get("running", False),
            "harvest_phase": HARVEST_STATE.get("phase", "idle"),
        })
    except: pass

def h_emit_state():
    try:
        socketio.emit("harvest_state", {
            "running": HARVEST_STATE["running"], "phase": HARVEST_STATE["phase"],
            "scrape_progress": HARVEST_STATE["scrape_progress"],
            "filter_progress": HARVEST_STATE["filter_progress"],
            "stats": HARVEST_STATE["stats"],
            "passed_count": len(HARVEST_STATE["passed"]),
            "moved_count": HARVEST_STATE.get("moved_count", 0),
        })
        # If Auto pipeline is running, also emit auto_state so the
        # dashboard auto-switches pages and shows visual progress
        if AUTO_STATE.get("running"):
            auto_emit_state()
    except: pass


# ── Scraper sources — 75 unique endpoints for high-volume harvesting ──
GITHUB_SOURCES = {
    "TheSpeedX_HTTP": "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
    "TheSpeedX_SOCKS4": "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt",
    "TheSpeedX_SOCKS5": "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
    "clarketm_HTTP": "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
    "monosans_HTTP": "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
    "monosans_SOCKS5": "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
    "monosans_SOCKS4": "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
    "roosterkid_HTTPS": "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
    "roosterkid_SOCKS5": "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt",
    "roosterkid_SOCKS4": "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt",
    "ShiftyTR_HTTP": "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
    "ShiftyTR_HTTPS": "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt",
    "ShiftyTR_SOCKS4": "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks4.txt",
    "ShiftyTR_SOCKS5": "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt",
    "MuRongPIxie_HTTP": "https://raw.githubusercontent.com/MuRongPIxie/proxy/master/proxy.txt",
    "fate0_HTTP": "https://raw.githubusercontent.com/fate0/proxylist/master/proxy.list",
    "ze314_HTTP": "https://raw.githubusercontent.com/ze314/proxy-list/main/http.txt",
    "B4RCMM_HTTP": "https://raw.githubusercontent.com/B4RCMM/proxylist/main/http.txt",
    "hookzof_SOCKS5": "https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt",
    "jetkai_HTTP": "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
    "jetkai_SOCKS4": "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks4.txt",
    "jetkai_SOCKS5": "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt",
    "mmpx12_HTTP": "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
    "mmpx12_HTTPS": "https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt",
    "mmpx12_SOCKS4": "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks4.txt",
    "mmpx12_SOCKS5": "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt",
    "sunny9577_HTTP": "https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt",
    "zloiuser_HTTP": "https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt",
    "zloiuser_SOCKS5": "https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks5.txt",
    "KangProxy_HTTP": "https://raw.githubusercontent.com/officialputuid/KangProxy/main/http/http.txt",
    "KangProxy_SOCKS4": "https://raw.githubusercontent.com/officialputuid/KangProxy/main/socks4/socks4.txt",
    "KangProxy_SOCKS5": "https://raw.githubusercontent.com/officialputuid/KangProxy/main/socks5/socks5.txt",
    "RX4096_HTTP": "https://raw.githubusercontent.com/RX4096/proxy-list/main/online/http.txt",
    "RX4096_SOCKS4": "https://raw.githubusercontent.com/RX4096/proxy-list/main/online/socks4.txt",
    "RX4096_SOCKS5": "https://raw.githubusercontent.com/RX4096/proxy-list/main/online/socks5.txt",
    "prxchk_HTTP": "https://raw.githubusercontent.com/prxchk/proxy-list/master/http.txt",
    "prxchk_SOCKS5": "https://raw.githubusercontent.com/prxchk/proxy-list/master/socks5.txt",
    "yemixzy_HTTP": "https://raw.githubusercontent.com/yemixzy/proxy-list/main/proxies/http.txt",
    "yemixzy_SOCKS4": "https://raw.githubusercontent.com/yemixzy/proxy-list/main/proxies/socks4.txt",
    "yemixzy_SOCKS5": "https://raw.githubusercontent.com/yemixzy/proxy-list/main/proxies/socks5.txt",
    "saschazesiger_HTTP": "https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/http.txt",
    "ALIILAPRO_HTTP": "https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt",
    "ALIILAPRO_SOCKS4": "https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/socks4.txt",
    "ALIILAPRO_SOCKS5": "https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/socks5.txt",
    "Zaeem20_HTTP": "https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/main/http.txt",
    "proxifly_HTTP": "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt",
    "proxifly_SOCKS4": "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/socks4/data.txt",
    "proxifly_SOCKS5": "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/socks5/data.txt",
    "vakhov_HTTP": "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt",
    "vakhov_SOCKS4": "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks4.txt",
    "vakhov_SOCKS5": "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks5.txt",
    "dpangestuw_HTTP": "https://raw.githubusercontent.com/dpangestuw/Free-Proxy/main/http_proxies.txt",
    "dpangestuw_SOCKS4": "https://raw.githubusercontent.com/dpangestuw/Free-Proxy/main/socks4_proxies.txt",
    "dpangestuw_SOCKS5": "https://raw.githubusercontent.com/dpangestuw/Free-Proxy/main/socks5_proxies.txt",
    "Anonym0usWork_HTTP": "https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt",
    "Anonym0usWork_SOCKS4": "https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/socks4_proxies.txt",
    "Anonym0usWork_SOCKS5": "https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/socks5_proxies.txt",
    "r00tee_HTTP": "https://raw.githubusercontent.com/r00tee/Proxy-List/main/Https.txt",
    "r00tee_SOCKS4": "https://raw.githubusercontent.com/r00tee/Proxy-List/main/Socks4.txt",
    "r00tee_SOCKS5": "https://raw.githubusercontent.com/r00tee/Proxy-List/main/Socks5.txt",
    "imrazvan_HTTP": "https://raw.githubusercontent.com/im-razvan/proxy_list/main/proxies.txt",
    "elliottophellia_HTTP": "https://raw.githubusercontent.com/elliottophellia/proxylist/master/results/http.txt",
    "elliottophellia_SOCKS4": "https://raw.githubusercontent.com/elliottophellia/proxylist/master/results/socks4.txt",
    "elliottophellia_SOCKS5": "https://raw.githubusercontent.com/elliottophellia/proxylist/master/results/socks5.txt",
    "HyperBeats_HTTP": "https://raw.githubusercontent.com/HyperBeats/proxy-list/main/http.txt",
    "rdavydov_HTTP": "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt",
    "rdavydov_SOCKS4": "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks4.txt",
    "rdavydov_SOCKS5": "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks5.txt",
    "casalsar_HTTP": "https://raw.githubusercontent.com/casals-ar/proxy-list/main/proxy_list.txt",
    "almroot_HTTP": "https://raw.githubusercontent.com/almroot/proxylist/master/proxylist.txt",
    "Tsprnay_HTTP": "https://raw.githubusercontent.com/Tsprnay/Proxy-lists/main/proxies/http.txt",
    "Tsprnay_SOCKS4": "https://raw.githubusercontent.com/Tsprnay/Proxy-lists/main/proxies/socks4.txt",
    "Tsprnay_SOCKS5": "https://raw.githubusercontent.com/Tsprnay/Proxy-lists/main/proxies/socks5.txt",
    "gnarlyBoi_HTTP": "https://raw.githubusercontent.com/gnarlyBoi/ProxyList2/master/proxy_list.txt",
    "Volodichev_HTTP": "https://raw.githubusercontent.com/Volodichev/proxy-list/main/http.txt",
    "opsxcq_HTTP": "https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt",
    "ECSOVIDAL_HTTP": "https://raw.githubusercontent.com/ECSOVIDAL/ProxyList/main/http.txt",
    "ECSOVIDAL_SOCKS5": "https://raw.githubusercontent.com/ECSOVIDAL/ProxyList/main/socks5.txt",
    # ── New high-value sources (deep-researched, verified live) ──
    "Thordata_HTTP": "https://raw.githubusercontent.com/Thordata/awesome-free-proxy-list/main/proxies/http.txt",
    "Thordata_HTTPS": "https://raw.githubusercontent.com/Thordata/awesome-free-proxy-list/main/proxies/https.txt",
    "Thordata_SOCKS4": "https://raw.githubusercontent.com/Thordata/awesome-free-proxy-list/main/proxies/socks4.txt",
    "Thordata_SOCKS5": "https://raw.githubusercontent.com/Thordata/awesome-free-proxy-list/main/proxies/socks5.txt",
    "VPSLab_HTTP_Elite": "https://raw.githubusercontent.com/VPSLabCloud/VPSLab-Free-Proxy-List/main/http_elite.txt",
    "VPSLab_ALL_Elite": "https://raw.githubusercontent.com/VPSLabCloud/VPSLab-Free-Proxy-List/main/all_elite.txt",
    "VPSLab_SOCKS4": "https://raw.githubusercontent.com/VPSLabCloud/VPSLab-Free-Proxy-List/main/socks4_all.txt",
    "VPSLab_SOCKS5": "https://raw.githubusercontent.com/VPSLabCloud/VPSLab-Free-Proxy-List/main/socks5_all.txt",
    "iplocate_HTTP": "https://raw.githubusercontent.com/iplocate/free-proxy-list/main/protocols/http.txt",
    "iplocate_HTTPS": "https://raw.githubusercontent.com/iplocate/free-proxy-list/main/protocols/https.txt",
    "iplocate_SOCKS4": "https://raw.githubusercontent.com/iplocate/free-proxy-list/main/protocols/socks4.txt",
    "iplocate_SOCKS5": "https://raw.githubusercontent.com/iplocate/free-proxy-list/main/protocols/socks5.txt",
    "gfpcom_HTTP": "https://raw.githubusercontent.com/wiki/gfpcom/free-proxy-list/lists/http.txt",
    "gfpcom_HTTPS": "https://raw.githubusercontent.com/wiki/gfpcom/free-proxy-list/lists/https.txt",
    "gfpcom_SOCKS4": "https://raw.githubusercontent.com/wiki/gfpcom/free-proxy-list/lists/socks4.txt",
    "gfpcom_SOCKS5": "https://raw.githubusercontent.com/wiki/gfpcom/free-proxy-list/lists/socks5.txt",
    "komutan234_HTTP": "https://raw.githubusercontent.com/komutan234/Proxy-List-Free/main/proxies/http.txt",
    "komutan234_SOCKS4": "https://raw.githubusercontent.com/komutan234/Proxy-List-Free/main/proxies/socks4.txt",
    "komutan234_SOCKS5": "https://raw.githubusercontent.com/komutan234/Proxy-List-Free/main/proxies/socks5.txt",
}
API_SOURCES = {
    "ProxyScrape_HTTP": "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=5000&country=all&ssl=all&anonymity=all",
    "ProxyScrape_SOCKS4": "https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks4&timeout=5000&country=all",
    "ProxyScrape_SOCKS5": "https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=5000&country=all",
    "Geonode_HTTP": "https://proxylist.geonode.com/api/proxy-list?protocols=http&limit=500&page=1&sort_by=lastChecked&sort_type=desc",
    "Geonode_SOCKS5": "https://proxylist.geonode.com/api/proxy-list?protocols=socks5&limit=500&page=1&sort_by=lastChecked&sort_type=desc",
    "ProxyListDownload_HTTP": "https://www.proxy-list.download/api/v1/get?type=http",
    "ProxyListDownload_HTTPS": "https://www.proxy-list.download/api/v1/get?type=https",
    "ProxyListDownload_SOCKS4": "https://www.proxy-list.download/api/v1/get?type=socks4",
    "ProxyListDownload_SOCKS5": "https://www.proxy-list.download/api/v1/get?type=socks5",
    "SpysMe_HTTP": "https://spys.me/proxy.txt",
    "SpysMe_SOCKS": "https://spys.me/socks.txt",
    "ProxyScan_HTTP": "https://www.proxyscan.io/api/proxy?format=txt&type=http",
    "ProxyScan_SOCKS5": "https://www.proxyscan.io/api/proxy?format=txt&type=socks5",
}

def _parse_ip_port(text):
    results = []
    for m in _re.finditer(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{2,5})', text):
        ip, port = m.group(1), m.group(2)
        parts = ip.split('.')
        if all(0 <= int(p) <= 255 for p in parts) and 1 <= int(port) <= 65535:
            results.append((ip, port))
    return results

def _parse_html_proxies(html):
    results = []
    rows = _re.findall(r'<tr[^>]*>(.*?)</tr>', html, _re.DOTALL)
    for row in rows:
        cells = _re.findall(r'<td[^>]*>(.*?)</td>', row, _re.DOTALL)
        if len(cells) >= 2:
            ip = _re.sub(r'<[^>]+>', '', cells[0]).strip()
            port = _re.sub(r'<[^>]+>', '', cells[1]).strip()
            if _re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', ip) and port.isdigit():
                results.append((ip, port))
    return results

async def _scrape_all_sources():
    """Scrape ALL sources concurrently with detailed per-source logging."""
    all_proxies = {}
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0"}
    timeout = aiohttp.ClientTimeout(total=25)
    total_sources = len(GITHUB_SOURCES) + len(API_SOURCES)
    sources_done = 0

    async def scrape_one(name, url, source_type):
        nonlocal sources_done
        if not HARVEST_STATE["running"]:
            return []
        proto = "socks5" if "SOCKS5" in name else "socks4" if "SOCKS4" in name else "http"
        results = []
        try:
            socketio.emit("harvest_source", {"name": name, "status": "scraping", "count": 0})
            async with aiohttp.ClientSession(headers=headers, timeout=timeout) as sess:
                async with sess.get(url) as resp:
                    if resp.status != 200:
                        h_log(f"  FAIL {name}: HTTP {resp.status}")
                        return []
                    ct = resp.headers.get("Content-Type", "")
                    if "json" in ct or "Geonode" in name:
                        data = await resp.json(content_type=None)
                        items = data.get("data", [])
                        for p in items:
                            ip = p.get("ip")
                            port = str(p.get("port"))
                            p_proto = (p.get("protocols") or [proto])[0].lower()
                            if p_proto not in ("http", "socks5", "socks4"):
                                p_proto = proto
                            if ip and port:
                                results.append({"ip": ip, "port": port, "protocol": p_proto, "source": name})
                        h_log(f"  + {name}: {len(results)} proxies")
                        socketio.emit("harvest_source", {"name": name, "status": "done", "count": len(results)})
                    else:
                        text = await resp.text()
                        parsed = _parse_ip_port(text)
                        # Cap mega-sources (e.g. gfpcom can return 400k+ lines) so
                        # one source can't dominate/explode the whole batch — but
                        # use a ROTATING chunk (not pure random) so across repeated
                        # scrapes the ENTIRE source eventually gets covered instead
                        # of the same random slice / permanently-missed proxies.
                        MAX_PER_SOURCE = 2500
                        if len(parsed) > MAX_PER_SOURCE:
                            parsed = _rotate_chunk(name, parsed, MAX_PER_SOURCE)
                        for ip, port in parsed:
                            results.append({"ip": ip, "port": port, "protocol": proto, "source": name})
                        h_log(f"  + {name}: {len(results)} proxies")
                        socketio.emit("harvest_source", {"name": name, "status": "done", "count": len(results)})
        except asyncio.TimeoutError:
            h_log(f"  FAIL {name}: Timeout (25s)")
            socketio.emit("harvest_source", {"name": name, "status": "fail", "error": "Timeout", "count": 0})
        except Exception as e:
            err = str(e)[:80]
            h_log(f"  FAIL {name}: {err}")
            socketio.emit("harvest_source", {"name": name, "status": "fail", "error": err, "count": 0})
        finally:
            sources_done += 1
            HARVEST_STATE["scrape_progress"] = {
                "current": sources_done, "total": total_sources, "source": name
            }
            h_emit_state()
        return results

    # Scrape all sources concurrently for speed
    h_log(f"=== SCRAPING {total_sources} SOURCES (concurrent) ===")
    h_emit_state()

    # Combine + shuffle so a different random source order is used every
    # single run — no fixed serial sequence, keeps things fresh and spreads
    # load differently across sources each time.
    all_sources = [(name, url, "github") for name, url in GITHUB_SOURCES.items()] + \
                  [(name, url, "api") for name, url in API_SOURCES.items()]
    random.shuffle(all_sources)
    all_tasks = [scrape_one(name, url, stype) for name, url, stype in all_sources]

    results = await asyncio.gather(*all_tasks, return_exceptions=True)

    # Deduplicate
    for source_list in results:
        if not isinstance(source_list, list):
            continue
        for p in source_list:
            key = f"{p['ip']}:{p['port']}"
            if key not in all_proxies:
                all_proxies[key] = p

    h_log(f"=== SCRAPE COMPLETE: {len(all_proxies)} unique proxies from {sources_done} sources ===")
    h_emit_state()
    return list(all_proxies.values())


# ── Per-provider token-bucket rate limiter ──────────────────────────
# Each free geo API has its own quota (ip-api.com=45/min, freeipapi.com=60/min).
# Instead of firing every request and eating 429s (which WASTES the check —
# the proxy gets marked "failed" even though it might be perfectly good, just
# unlucky on timing), we self-throttle per provider so we never exceed the
# safe budget. This lets Stage 1 (connectivity, proxy-bound not API-bound)
# scale to many more lanes, while Stage 2 (geo/ISP) gracefully queues.
class _RateLimiter:
    def __init__(self, max_per_minute):
        self.max_per_minute = max_per_minute
        self.window = []  # timestamps of calls in the last 60s
        self.lock = asyncio.Lock()

    async def acquire(self):
        async with self.lock:
            now = time.time()
            self.window = [t for t in self.window if now - t < 60]
            if len(self.window) >= self.max_per_minute:
                # Wait until the oldest call in the window ages out
                sleep_for = 60 - (now - self.window[0]) + 0.05
                if sleep_for > 0:
                    await asyncio.sleep(sleep_for)
                now = time.time()
                self.window = [t for t in self.window if now - t < 60]
            self.window.append(time.time())

_RATE_LIMITERS = {
    "ip-api": _RateLimiter(40),      # stay a bit under the hard 45/min cap
    "freeipapi": _RateLimiter(55),   # stay a bit under the 60/min cap
}

# ── Per-IP geo-lookup cache (disk-persistent, 6h TTL) ───────────────
# Same IP scraped again in a later cycle (very common — sources overlap,
# and the rotation loop revisits proxies) shouldn't burn API budget twice.
# ISP/country/hosting-type for a given IP essentially never changes within
# a few hours, so this is a safe, high-value cache.
GEO_CACHE_FILE = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "geo_cache.json")
GEO_CACHE_TTL = 6 * 3600
_geo_cache_mem = None
_geo_cache_lock = threading.Lock()

def _load_geo_cache():
    global _geo_cache_mem
    if _geo_cache_mem is not None:
        return _geo_cache_mem
    with _geo_cache_lock:
        if _geo_cache_mem is not None:
            return _geo_cache_mem
        try:
            if _os.path.exists(GEO_CACHE_FILE):
                with open(GEO_CACHE_FILE, 'r') as f:
                    _geo_cache_mem = _json_mod.load(f)
            else:
                _geo_cache_mem = {}
        except Exception:
            _geo_cache_mem = {}
        return _geo_cache_mem

def _geo_cache_get(ip):
    cache = _load_geo_cache()
    entry = cache.get(ip)
    if entry and (time.time() - entry.get("_ts", 0)) < GEO_CACHE_TTL:
        return entry["data"]
    return None

def _geo_cache_set(ip, data):
    cache = _load_geo_cache()
    cache[ip] = {"_ts": time.time(), "data": data}
    # Periodic trim so the file doesn't grow unbounded
    if len(cache) > 20000:
        newest = sorted(cache.items(), key=lambda kv: kv[1].get("_ts", 0), reverse=True)[:15000]
        cache = dict(newest)
        _geo_cache_mem_ref = cache
    try:
        with open(GEO_CACHE_FILE, 'w') as f:
            _json_mod.dump(cache, f)
    except Exception:
        pass


async def _detect_ip_type(session, ip):
    """Cross-verify residential status using up to 4 independent free APIs.
    Uses a per-IP 6h cache (skip live calls entirely for repeat IPs) and a
    per-provider rate limiter (self-throttles under each API's free-tier
    cap, so we never waste a check on a 429 rate-limit response)."""
    _cached = _geo_cache_get(ip)
    if _cached is not None:
        return _cached

    result = {
        "residential": False, "datacenter": False, "vpn": False,
        "mobile": False, "proxy": False,
        "country": None, "country_code": None, "isp": None,
        "residential_votes": 0, "dc_votes": 0, "total_votes": 0,
    }
    votes = []  # True = residential, False = datacenter/VPN

    # API 1: ip-api.com (free, 45 req/min — self-throttled to 40/min)
    try:
        await _RATE_LIMITERS["ip-api"].acquire()
        async with session.get(f"http://ip-api.com/json/{ip}?fields=status,country,countryCode,isp,org,as,proxy,hosting,mobile", timeout=aiohttp.ClientTimeout(total=8)) as resp:
            if resp.status == 200:
                data = await resp.json()
                if data.get("status") == "success":
                    result["country"] = data.get("country")
                    result["country_code"] = data.get("countryCode")
                    result["isp"] = data.get("isp")
                    is_proxy = data.get("proxy", False)
                    is_hosting = data.get("hosting", False)
                    is_mobile = data.get("mobile", False)
                    result["mobile"] = is_mobile
                    result["proxy"] = is_proxy
                    result["datacenter"] = is_hosting
                    # ip-api says residential if NOT hosting AND NOT proxy
                    is_res = not is_hosting and not is_proxy
                    votes.append(is_res)
                    if is_res: result["residential_votes"] += 1
                    else: result["dc_votes"] += 1
                    result["total_votes"] += 1
    except: pass

    # API 2: ipwho.is (free, no key, good for ISP/org detection)
    try:
        async with session.get(f"https://ipwho.is/{ip}", timeout=aiohttp.ClientTimeout(total=8)) as resp:
            if resp.status == 200:
                data = await resp.json()
                if data.get("success"):
                    if not result["country"]:
                        result["country"] = data.get("country")
                        result["country_code"] = data.get("country_code")
                    conn = data.get("connection", {})
                    if isinstance(conn, dict):
                        if not result["isp"]:
                            result["isp"] = conn.get("isp") or conn.get("org")
                        conn_type = (conn.get("type") or "").lower()
                        is_dc = "hosting" in conn_type or "datacenter" in conn_type
                    else:
                        is_dc = False
                    org_lower = (str(data.get("connection", {}).get("org") or "")).lower()
                    dc_kw = ["hosting", "cloud", "datacenter", "server", "ovh", "amazon", "google", "microsoft", "data center"]
                    if any(kw in org_lower for kw in dc_kw):
                        is_dc = True
                    is_res = not is_dc
                    votes.append(is_res)
                    if is_res: result["residential_votes"] += 1
                    else: result["dc_votes"] += 1
                    result["total_votes"] += 1
    except: pass

    # API 3: ipinfo.io (free 50k/month, good ASN-based detection)
    try:
        async with session.get(f"https://ipinfo.io/{ip}/json", timeout=aiohttp.ClientTimeout(total=8)) as resp:
            if resp.status == 200:
                data = await resp.json()
                if not result["country"]:
                    result["country"] = data.get("country")
                    result["country_code"] = data.get("country")
                if not result["isp"]:
                    result["isp"] = data.get("org")
                org_lower = (data.get("org") or "").lower()
                dc_kw = ["hosting", "cloud", "datacenter", "data center", "server", "ovh",
                         "amazon", "google", "microsoft", "azure", "linode", "vultr",
                         "hetzner", "digitalocean", "leaseweb", "contabo", "kimsufi"]
                is_dc = any(kw in org_lower for kw in dc_kw)
                is_res = not is_dc
                votes.append(is_res)
                if is_res: result["residential_votes"] += 1
                else: result["dc_votes"] += 1
                result["total_votes"] += 1
    except: pass

    # API 4: freeipapi.com (free, no key, 60 req/min — self-throttled to 55/min)
    try:
        await _RATE_LIMITERS["freeipapi"].acquire()
        async with session.get(f"https://freeipapi.com/api/json/{ip}", timeout=aiohttp.ClientTimeout(total=8)) as resp:
            if resp.status == 200:
                data = await resp.json()
                if not result["country"]:
                    result["country"] = data.get("countryName")
                    result["country_code"] = data.get("countryCode")
                if not result["isp"]:
                    result["isp"] = data.get("asnOrganization") or data.get("isp")
                is_dc = bool(data.get("isProxy")) or bool(data.get("isHosting"))
                org_lower = (str(data.get("asnOrganization") or "")).lower()
                dc_kw = ["hosting", "cloud", "datacenter", "data center", "server", "ovh",
                         "amazon", "google", "microsoft", "azure", "linode", "vultr",
                         "hetzner", "digitalocean", "leaseweb", "contabo", "kimsufi"]
                if any(kw in org_lower for kw in dc_kw):
                    is_dc = True
                is_res = not is_dc
                votes.append(is_res)
                if is_res: result["residential_votes"] += 1
                else: result["dc_votes"] += 1
                result["total_votes"] += 1
    except: pass

    # CONSENSUS: strict majority across however many APIs responded
    # (scales correctly whether 1, 2, 3, or 4 providers answered — a tie
    # is treated as a reject, staying conservative to protect quality).
    if result["total_votes"] >= 2:
        result["residential"] = result["residential_votes"] > result["dc_votes"]
    elif result["total_votes"] == 1:
        result["residential"] = votes[0]  # only 1 API responded, trust it
    else:
        result["residential"] = False  # no API responded, reject

    # If any API flagged it as datacenter, mark it
    result["datacenter"] = result["dc_votes"] > 0 and not result["residential"]
    # VPN if proxy flag was set by ip-api
    result["vpn"] = result["proxy"]

    _geo_cache_set(ip, result)
    return result


async def _validate_proxies(proxies, min_quality):
    """5-STAGE validation for AUTHENTIC RESIDENTIAL ONLY:
    Stage 1: Connectivity (HTTP + HTTPS with content verification)
    Stage 2: Triple cross-verify IP type (3 APIs must majority-confirm residential)
    Stage 3: Quality scoring (80+ required, consensus-weighted)
    Stage 4: Anti-flag check (reject VPN/proxy/tor/datacenter)
    Stage 5: Fresh re-check (proxy must still be alive right before output)
    Uses aiohttp_socks for SOCKS4/SOCKS5 support (fixes the old bug where
    SOCKS proxies were validated using aiohttp's built-in proxy= which only
    supports HTTP proxies — SOCKS proxies were ALWAYS failing Stage 1).
    """
    import time as _time
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0.0.0"}
    total = len(proxies)
    checked = 0
    # ── 7-LANE PARALLEL VALIDATION ──
    # Split proxies into 7 groups, each with Semaphore(8) = 56 concurrent total
    LANE_COUNT = 15
    LANE_CONCURRENCY = 8
    lanes = [[] for _ in range(LANE_COUNT)]
    for i, px in enumerate(proxies):
        lanes[i % LANE_COUNT].append(px)
    h_log(f"{LANE_COUNT}-LANE: {LANE_COUNT} lanes × {LANE_CONCURRENCY} concurrent = {LANE_COUNT * LANE_CONCURRENCY} total checks")
    h_emit_state()
    sem = asyncio.Semaphore(LANE_CONCURRENCY)

    # ── 24h INSTANT-PASS CACHE ──
    # Load the disk-persistent "passed" memory ONCE for this whole run (not
    # per-proxy — that would mean thousands of disk reads). Any proxy that
    # was already validated as a passing residential IP within the last 24h
    # gets instant-passed with zero re-checking — no Stage 1-5 network
    # calls at all. Only genuinely new/unknown proxies go through the full
    # 5-stage filter. This is what makes repeat "All" scrapes fast.
    _cache_list = _load_passed_memory()
    _passed_cache = {f"{e.get('ip')}:{e.get('port')}:{e.get('protocol')}": e for e in _cache_list}
    if _passed_cache:
        h_log(f"24h CACHE: {len(_passed_cache)} previously-passed proxies loaded — matches will instant-pass")
    h_emit_state()

    # Track keys already sitting in HARVEST_STATE["passed"] (relevant when
    # "Keep Existing" is enabled) so the same proxy can never be appended
    # twice into the results list.
    _existing_passed_keys = {
        f"{e.get('ip')}:{e.get('port')}:{e.get('protocol')}" for e in HARVEST_STATE["passed"]
    }

    # Build a session for IP-type detection (no proxy needed)
    async with aiohttp.ClientSession(headers=headers) as session:
        async def check_one(proxy_dict):
            nonlocal checked
            async with sem:
                if not HARVEST_STATE["running"]:
                    return None
                ip, port = proxy_dict["ip"], proxy_dict["port"]
                proto = proxy_dict["protocol"]

                # ── INSTANT-PASS: already validated within the last 24h? ──
                # Skip the entire 5-stage check — just re-emit it as passed.
                _cache_key = f"{ip}:{port}:{proto}"
                _cached_entry = _passed_cache.get(_cache_key)
                if _cached_entry is not None:
                    checked += 1
                    HARVEST_STATE["filter_progress"] = {"current": checked, "total": total}
                    HARVEST_STATE["stats"]["checked"] = checked
                    if _cache_key in _existing_passed_keys or _cache_key in AUTO_STATE.get("used_keys", ()):
                        # Already sitting in the kept list, OR already used by
                        # the Auto Start worker this session — never re-add it.
                        h_emit_state()
                        return None
                    HARVEST_STATE["stats"]["passed"] += 1
                    passed_data = dict(_cached_entry)
                    passed_data.pop("_ts", None)
                    passed_data["source"] = proxy_dict.get("source", passed_data.get("source", "?"))
                    passed_data["number"] = len(HARVEST_STATE["passed"]) + 1
                    passed_data["cached"] = True
                    HARVEST_STATE["passed"].append(passed_data)
                    _existing_passed_keys.add(_cache_key)
                    try: socketio.emit("harvest_proxy_passed", passed_data)
                    except: pass
                    h_emit_state()
                    return None

                proxy_url = f"{proto}://{ip}:{port}"
                start_ts = _time.time()

                # ── Stage 1: Connectivity with content verification ──
                # Use aiohttp_socks ProxyConnector for SOCKS support
                http_ok, https_ok = False, False
                exit_ip = None
                proxy_type = SOCKS_MAP.get(proto, ProxyType.HTTP)

                # Create a session WITH the proxy connector for this specific proxy
                try:
                    connector = ProxyConnector(
                        proxy_type=proxy_type,
                        host=ip, port=int(port),
                        rdns=True
                    )
                except Exception:
                    checked += 1
                    HARVEST_STATE["filter_progress"] = {"current": checked, "total": total}
                    HARVEST_STATE["stats"]["checked"] = checked
                    HARVEST_STATE["stats"]["failed"] += 1
                    h_emit_state()
                    return None

                timeout_8 = aiohttp.ClientTimeout(total=8)
                async with aiohttp.ClientSession(connector=connector, headers=headers, timeout=timeout_8) as psess:
                    # Test HTTP
                    try:
                        async with psess.get("http://httpbin.org/ip") as resp:
                            if resp.status == 200:
                                data = await resp.json(content_type=None)
                                origin = data.get("origin", "")
                                if origin and _re.match(r'^[\d.,\s]+$', origin):
                                    http_ok = True
                                    exit_ip = origin.split(",")[0].strip()
                    except: pass

                    # Test HTTPS
                    try:
                        async with psess.get("https://api.ipify.org?format=json") as resp:
                            if resp.status == 200:
                                data = await resp.json(content_type=None)
                                eip = data.get("ip", "")
                                if eip and _re.match(r'^\d{1,3}(\.\d{1,3}){3}$', eip):
                                    https_ok = True
                                    exit_ip = eip
                    except: pass

                latency_ms = int((_time.time() - start_ts) * 1000)

                if not http_ok and not https_ok:
                    checked += 1
                    HARVEST_STATE["filter_progress"] = {"current": checked, "total": total}
                    HARVEST_STATE["stats"]["checked"] = checked
                    HARVEST_STATE["stats"]["failed"] += 1
                    h_emit_state()
                    return None

                # ── Stage 2: Triple cross-verify IP type ──
                # Use EXIT IP if available (that's what ad networks actually see)
                check_ip = exit_ip or ip
                ip_type = await _detect_ip_type(session, check_ip)

                # ── Stage 4 (early): Hard reject datacenter/VPN/proxy/tor ──
                if ip_type["datacenter"] or ip_type["vpn"] or ip_type.get("proxy"):
                    checked += 1
                    HARVEST_STATE["filter_progress"] = {"current": checked, "total": total}
                    HARVEST_STATE["stats"]["checked"] = checked
                    HARVEST_STATE["stats"]["failed"] += 1
                    h_emit_state()
                    return None

                # Must be confirmed residential by majority vote
                if not ip_type["residential"]:
                    checked += 1
                    HARVEST_STATE["filter_progress"] = {"current": checked, "total": total}
                    HARVEST_STATE["stats"]["checked"] = checked
                    HARVEST_STATE["stats"]["failed"] += 1
                    h_emit_state()
                    return None

                # ── Stage 3: Quality scoring (consensus-weighted) ──
                score = 0
                if http_ok: score += 15
                if https_ok: score += 15
                # Residential confirmed by 3/3 APIs = highest confidence
                if ip_type["residential_votes"] >= 3:
                    score += 50  # Triple-confirmed residential
                elif ip_type["residential_votes"] >= 2:
                    score += 40  # Double-confirmed
                else:
                    score += 25  # Single API only (risky)
                if ip_type["mobile"] and not ip_type["datacenter"]:
                    score += 10  # mobile bonus (but not as high — mobile proxies are rare in free lists)
                if ip_type["country"]:
                    score += 10
                if not ip_type.get("proxy"):
                    score += 10
                if not ip_type["datacenter"]:
                    score += 10

                # Latency penalty — high latency = overloaded/dying proxy
                if latency_ms > 8000: score -= 25
                elif latency_ms > 5000: score -= 12
                elif latency_ms > 3000: score -= 5

                score = max(0, min(score, 100))

                if score < min_quality:
                    checked += 1
                    HARVEST_STATE["filter_progress"] = {"current": checked, "total": total}
                    HARVEST_STATE["stats"]["checked"] = checked
                    HARVEST_STATE["stats"]["failed"] += 1
                    h_emit_state()
                    return None

                # ── Stage 5: FRESH re-check — must be alive RIGHT NOW ──
                # Uses a NEW connection through the same proxy to verify
                # it's still alive. This catches proxies that died between
                # Stage 1 and now (seconds ago).
                re_ok = False
                try:
                    re_connector = ProxyConnector(
                        proxy_type=proxy_type,
                        host=ip, port=int(port),
                        rdns=True
                    )
                    async with aiohttp.ClientSession(connector=re_connector, headers=headers, timeout=aiohttp.ClientTimeout(total=8)) as rpsess:
                        try:
                            async with rpsess.get("https://api.ipify.org?format=json") as resp:
                                if resp.status == 200:
                                    d = await resp.json(content_type=None)
                                    if d.get("ip"): re_ok = True
                        except: pass
                        if not re_ok:
                            try:
                                async with rpsess.get("http://httpbin.org/ip") as resp:
                                    if resp.status == 200: re_ok = True
                            except: pass
                except: pass

                checked += 1
                HARVEST_STATE["filter_progress"] = {"current": checked, "total": total}
                HARVEST_STATE["stats"]["checked"] = checked

                if re_ok:
                    _fresh_key = f"{ip}:{port}:{proto}"
                    _already_used = _fresh_key in AUTO_STATE.get("used_keys", ())
                    passed_data = {
                        "ip": ip, "port": port, "protocol": proto,
                        "score": score, "country": ip_type.get("country_code", "?"),
                        "isp": (ip_type.get("isp") or "")[:25],
                        "mobile": ip_type.get("mobile", False),
                        "latency": latency_ms,
                        "source": proxy_dict.get("source", "?"),
                        "votes": f"{ip_type['residential_votes']}/{ip_type['total_votes']}",
                        "number": len(HARVEST_STATE["passed"]) + 1,
                    }
                    # Always save to the 24h disk cache (even if it's a dupe
                    # of the kept list this run — refreshes its cache TTL).
                    _save_passed_memory(passed_data)
                    if _fresh_key not in _existing_passed_keys and not _already_used:
                        HARVEST_STATE["stats"]["passed"] += 1
                        HARVEST_STATE["passed"].append(passed_data)
                        _existing_passed_keys.add(_fresh_key)
                        try: socketio.emit("harvest_proxy_passed", passed_data)
                        except: pass
                else:
                    HARVEST_STATE["stats"]["failed"] += 1
                h_emit_state()
                return None

        # ── 7-LANE parallel execution ──
        lane_tasks = []
        for lane_idx, lane_proxies in enumerate(lanes):
            async def _run_lane(lane_proxies, lane_idx):
                for px in lane_proxies:
                    if not HARVEST_STATE["running"]:
                        return
                    await check_one(px)
            lane_tasks.append(asyncio.create_task(_run_lane(lane_proxies, lane_idx)))
        await asyncio.gather(*lane_tasks, return_exceptions=True)


async def _harvest_pipeline(min_quality, max_proxies, keep_existing=False):
    HARVEST_STATE["phase"] = "scraping"
    HARVEST_STATE["stats"] = {"raw_count": 0, "checked": 0, "passed": 0, "failed": 0}
    if not keep_existing:
        HARVEST_STATE["passed"] = []
    else:
        h_log(f"Keep Existing enabled — preserving {len(HARVEST_STATE['passed'])} previously passed proxies")
    h_log("=== HARVEST STARTED ===")
    h_emit_state()

    proxies = await _scrape_all_sources()
    HARVEST_STATE["stats"]["raw_count"] = len(proxies)
    h_log(f"Scraped {len(proxies)} unique proxies")
    h_emit_state()

    # Shuffle before capping/filtering — ensures the max_proxies cutoff (and
    # the order proxies get filtered/logged in) isn't biased toward whichever
    # sources happened to respond fastest. A different source's proxies get
    # filtered first on every run.
    random.shuffle(proxies)

    if len(proxies) > max_proxies:
        h_log(f"Limiting to {max_proxies} for validation (randomly sampled)")
        proxies = proxies[:max_proxies]

    HARVEST_STATE["phase"] = "filtering"
    HARVEST_STATE["filter_progress"] = {"current": 0, "total": len(proxies)}
    h_log(f"=== 4-STAGE FILTER: {len(proxies)} proxies ===")
    h_emit_state()

    await _validate_proxies(proxies, min_quality)

    HARVEST_STATE["phase"] = "done"
    passed = HARVEST_STATE['stats']['passed']
    failed = HARVEST_STATE['stats']['failed']
    h_log(f"=== HARVEST COMPLETE ===")
    h_log(f"  Scraped: {len(proxies)} unique IPs")
    h_log(f"  Checked: {HARVEST_STATE['stats']['checked']}")
    h_log(f"  Passed: {passed} (residential {min_quality}+)")
    h_log(f"  Failed: {failed}")
    if passed > 0:
        # Log protocol breakdown
        http_n = sum(1 for p in HARVEST_STATE["passed"] if p["protocol"] == "http")
        socks5_n = sum(1 for p in HARVEST_STATE["passed"] if p["protocol"] == "socks5")
        socks4_n = sum(1 for p in HARVEST_STATE["passed"] if p["protocol"] == "socks4")
        h_log(f"  HTTP: {http_n} | SOCKS5: {socks5_n} | SOCKS4: {socks4_n}")
    h_emit_state()


@app.route('/api/harvest/start', methods=['POST'])
def harvest_start():
    if HARVEST_STATE["running"]:
        return jsonify({"error": "Already running"}), 400
    data = request.json or {}
    min_q = data.get("min_quality", 80)
    max_p = data.get("max_proxies", 500)
    keep = data.get("keep_existing", False)
    HARVEST_STATE["running"] = True
    def _run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try: loop.run_until_complete(_harvest_pipeline(min_q, max_p, keep_existing=keep))
        except Exception as e: h_log(f"FATAL: {str(e)[:150]}")
        finally:
            HARVEST_STATE["running"] = False
            HARVEST_STATE["phase"] = "done"
            h_emit_state()
            loop.close()
    socketio.start_background_task(_run)
    return jsonify({"started": True})


@app.route('/api/harvest/export/<fmt>')
def harvest_export(fmt):
    passed = HARVEST_STATE["passed"]
    if fmt == "txt":
        lines = [f"{p['protocol']}://{p['ip']}:{p['port']}" for p in passed]
        return Response("\n".join(lines), mimetype="text/plain",
                       headers={"Content-Disposition": "attachment; filename=residential_proxies.txt"})
    elif fmt == "csv":
        output = io.StringIO()
        w = csv.writer(output)
        w.writerow(["Protocol", "IP", "Port", "Score", "Country", "ISP", "Mobile", "Source"])
        for p in passed:
            w.writerow([p["protocol"], p["ip"], p["port"], p["score"], p.get("country","?"), p.get("isp",""), p.get("mobile",False), p.get("source","?")])
        return Response(output.getvalue(), mimetype="text/csv",
                       headers={"Content-Disposition": "attachment; filename=residential_proxies.csv"})
    return jsonify({"error": "Unknown format"}), 400



# ── HARVEST: Stop endpoint ──
@app.route('/api/harvest/stop', methods=['POST'])
def harvest_stop():
    HARVEST_STATE["running"] = False
    # Cascade: if Auto pipeline is currently running (it owns this harvester
    # run), stopping from the Harvester panel must fully stop Auto too —
    # otherwise the worker keeps consuming passed proxies and the floating
    # Start/Stop button stays stuck on "Stop" forever.
    if AUTO_STATE.get("running"):
        AUTO_STATE["stop_flag"] = True
        AUTO_STATE["phase"] = "stopping"
        AUTO_STATE["worker_status"] = "stopping"
        auto_log("[AUTO] 🛑 Stop requested via Harvester panel — stopping full pipeline...")
    h_log("=== HARVEST STOP REQUESTED ===")
    h_emit_state()
    auto_emit_state()  # keep the floating widget synced immediately
    return jsonify({"stopped": True})

# ── HARVEST: Get passed proxies ──
@app.route('/api/harvest/proxies')
def harvest_get_proxies():
    return jsonify({"proxies": HARVEST_STATE.get("passed", []), "count": len(HARVEST_STATE.get("passed", []))})

# ── HARVEST: Ping (health check) ──
@app.route('/api/harvest/ping')
def harvest_ping():
    return jsonify({
        "ok": True,
        "running": HARVEST_STATE.get("running", False),
        "phase": HARVEST_STATE.get("phase", "idle"),
        "total_sources": len(GITHUB_SOURCES) + len(API_SOURCES),
    })

# ── HARVEST: Move single proxy from passed → proxies ──
@app.route('/api/harvest/move', methods=['POST'])
def harvest_move_one():
    data = request.json or {}
    ip = data.get("ip")
    port = str(data.get("port"))
    protocol = data.get("protocol", "http")
    if not ip or not port:
        return jsonify({"error": "Missing ip/port"}), 400
    # Remove from passed list
    passed = HARVEST_STATE.get("passed", [])
    idx = None
    for i, p in enumerate(passed):
        if p["ip"] == ip and str(p["port"]) == port:
            idx = i
            break
    if idx is not None:
        removed = passed.pop(idx)
        HARVEST_STATE["stats"]["passed"] = len(passed)
        HARVEST_STATE["moved_count"] = HARVEST_STATE.get("moved_count", 0) + 1
        h_emit_state()
        return jsonify({"ok": True, "proxy": removed})
    return jsonify({"error": "Proxy not found in passed list"}), 404

# ── HARVEST: Move ALL passed proxies → proxies ──
@app.route('/api/harvest/move_all', methods=['POST'])
def harvest_move_all():
    passed = HARVEST_STATE.get("passed", [])
    if not passed:
        return jsonify({"ok": True, "proxies": []})
    moved = list(passed)
    HARVEST_STATE["passed"] = []
    HARVEST_STATE["stats"]["passed"] = 0
    HARVEST_STATE["moved_count"] = HARVEST_STATE.get("moved_count", 0) + len(moved)
    h_emit_state()
    return jsonify({"ok": True, "proxies": moved})

@app.route('/api/proxy/quickcheck', methods=['POST'])
def proxy_quickcheck():
    data = request.json or {}
    raw = data.get("proxy", "").strip()
    if not raw:
        return jsonify({"error": "No proxy given"}), 400
    proto = "http"
    for p in ["socks5://", "socks4://", "http://", "https://"]:
        if raw.startswith(p):
            proto = p.replace("://", "")
            raw = raw[len(p):]
            break
    parts = raw.split(":")
    if len(parts) < 2:
        return jsonify({"error": "Invalid format"}), 400
    ip, port = parts[0], parts[1]

    def _run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        async def _check():
            import time as _t
            headers = {"User-Agent": "Mozilla/5.0"}
            start_ts = _t.time()
            proxy_type = SOCKS_MAP.get(proto, ProxyType.HTTP)
            http_ok, https_ok = False, False
            try:
                connector = ProxyConnector(proxy_type=proxy_type, host=ip, port=int(port), rdns=True)
            except Exception as e:
                try: socketio.emit("quickcheck_result", {"ip":ip,"port":port,"protocol":proto,"valid":False,"score":0,"country":"?","isp":"","datacenter":False,"vpn":False,"latency":0,"error":f"Invalid proxy: {str(e)[:50]}"})
                except: pass
                return
            async with aiohttp.ClientSession(connector=connector, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as psess:
                try:
                    async with psess.get("http://httpbin.org/ip") as resp:
                        if resp.status == 200: http_ok = True
                except: pass
                try:
                    async with psess.get("https://api.ipify.org?format=json") as resp:
                        if resp.status == 200: https_ok = True
                except: pass
            latency_ms = int((_t.time() - start_ts) * 1000)
            # IP type detection (no proxy needed)
            async with aiohttp.ClientSession(headers=headers) as session:
                ip_type = await _detect_ip_type(session, ip)
                score = 0
                if http_ok: score += 15
                if https_ok: score += 15
                if ip_type["residential"]: score += 45
                if ip_type["country"]: score += 10
                if not ip_type.get("proxy"): score += 15
                if not ip_type["datacenter"]: score += 15
                valid = http_ok or https_ok
                result = {
                    "ip": ip, "port": port, "protocol": proto, "valid": valid,
                    "score": min(score, 100), "country": ip_type.get("country_code", "?"),
                    "isp": (ip_type.get("isp") or "")[:30], "datacenter": ip_type.get("datacenter", False),
                    "vpn": ip_type.get("proxy", False), "latency": latency_ms,
                    "error": None if valid else "Connection failed (dead/timeout)",
                }
                try: socketio.emit("quickcheck_result", result)
                except: pass
        loop.run_until_complete(_check())
        loop.close()
    socketio.start_background_task(_run)
    return jsonify({"started": True})


# ═════════════════════════════════════════════════════════════════════════════
# AUTO START PIPELINE — Endpoints + Worker
# ═════════════════════════════════════════════════════════════════════════════

def _auto_worker_pick_proxy():
    """Atomically pick ONE proxy from HARVEST_STATE['passed'] and treat it
    EXACTLY like a manual 'Move to Proxies' action:
      1) Pop it from the harvester's passed pool (already removed instantly
         so it can never be double-picked or re-shown as still "ready").
      2) Bump moved_count — previously ONLY the manual move/move_all
         endpoints incremented this, so the dashboard's MOVED stat stayed
         stuck at 0 forever while Auto Start was silently consuming
         proxies in the background. Now every auto-pick counts as a move,
         same as clicking the button by hand.
      3) Emit a dedicated 'harvest_proxy_moved' event carrying the exact
         proxy identity so the frontend's live 'Passed Proxies — Real-Time
         Results' list (a client-side array that only ever grows via
         harvest_proxy_passed) can splice this exact row out immediately —
         mirroring what already happens for manual moves. Without this the
         UI kept showing already-consumed proxies as "ready" forever.
      4) Emit BOTH harvest_state (updates the Harvester page's PASSED/
         MOVED boxes) and auto_state (updates the floating worker widget's
         'Passed' available count) right away instead of waiting for the
         next incidental phase-change emit.
    Returns the proxy dict or None if list is empty.
    Thread-safe via list pop(0) (GIL-protected in CPython)."""
    passed = HARVEST_STATE.get("passed", [])
    if not passed:
        return None
    # Pop from front — first-in-first-out
    proxy_data = passed.pop(0)
    HARVEST_STATE["stats"]["passed"] = len(passed)
    HARVEST_STATE["moved_count"] = HARVEST_STATE.get("moved_count", 0) + 1
    h_emit_state()
    try:
        socketio.emit("harvest_proxy_moved", {
            "ip": proxy_data.get("ip"),
            "port": proxy_data.get("port"),
            "protocol": proxy_data.get("protocol", "http"),
        })
    except Exception:
        pass
    auto_emit_state()
    return proxy_data

def _auto_proxy_to_bot_format(proxy_data):
    """Convert a harvester passed proxy dict to BotEngine proxy format."""
    proto = proxy_data.get("protocol", "http")
    ip = proxy_data["ip"]
    port = int(proxy_data["port"])
    raw = f"{proto}://{ip}:{port}"
    return {
        "raw": raw,
        "ip": ip,
        "port": port,
        "protocol": proto,
        "server": f"{proto}://{ip}:{port}",
        "display_ip": ip,
        "is_gateway": False,
        "sticky_session": None,
        "username": None,
        "password": None,
    }

async def _auto_pipeline_run(config):
    """Main auto pipeline: runs harvester + worker concurrently.
    Harvester scrapes & filters → passed proxies list.
    Worker picks proxies one-by-one, validates, visits target link.
    """
    AUTO_STATE["running"] = True
    AUTO_STATE["stop_flag"] = False
    AUTO_STATE["visits_done"] = 0
    AUTO_STATE["visits_success"] = 0
    AUTO_STATE["visits_failed"] = 0
    AUTO_STATE["used_keys"] = set()
    AUTO_STATE["config"] = config

    target_link = config.get("links", "").strip()
    if not target_link:
        auto_log("[AUTO] ❌ No target link configured!")
        AUTO_STATE["running"] = False
        AUTO_STATE["phase"] = "error"
        auto_emit_state()
        return

    links = [l.strip() for l in target_link.replace(',', '\n').split('\n') if l.strip()]
    min_quality = config.get("min_quality", 80)
    max_proxies = config.get("max_proxies", 500)

    auto_log(f"[AUTO] 🚀 Pipeline started — target: {links[0][:60]}...")
    auto_log(f"[AUTO] Harvesting: min_quality={min_quality}, max_proxies={max_proxies}")
    auto_emit_state()

    # ── Harvester runs in a CONTINUOUS LOOP for as long as Auto Start is
    # running — it never just "finishes" after one pass. Each cycle mixes
    # through ALL sources in a fresh random order (see _scrape_all_sources),
    # and huge sources (gfpcom etc.) advance their rotation chunk (2500 more
    # each cycle) so, given enough cycles, every source gets 100% covered.
    # Already-passed-and-used proxies are never re-added (see used_keys /
    # _existing_passed_keys checks inside _validate_proxies). This is what
    # lets a single "Start" press keep collecting from all sources — even
    # ones with 500k+ proxies — for as long as the user leaves it running.
    async def _run_harvester():
        cycle = 0
        auto_log("[AUTO] 📡 Harvester loop started — continuous mixed-source scraping until Stop is pressed")
        while not AUTO_STATE["stop_flag"]:
            cycle += 1
            AUTO_STATE["phase"] = "harvesting"
            HARVEST_STATE["running"] = True  # CRITICAL: must be True or scrape_one() short-circuits to 0 results
            auto_log(f"[AUTO] 📡 Harvest cycle #{cycle} — scraping {len(GITHUB_SOURCES)+len(API_SOURCES)} sources (random mixed order)...")
            auto_emit_state()
            try:
                # keep_existing=True: never wipe the passed pool between
                # cycles — the worker is draining it concurrently anyway.
                await _harvest_pipeline(min_quality, max_proxies, keep_existing=True)
            except Exception as e:
                auto_log(f"[AUTO] ❌ Harvester error (cycle #{cycle}): {str(e)[:120]}")
            finally:
                HARVEST_STATE["running"] = False
            if AUTO_STATE["stop_flag"]:
                break
            auto_log(f"[AUTO] 📡 Cycle #{cycle} done — {len(HARVEST_STATE.get('passed', []))} in pool. Starting next cycle...")
            auto_emit_state()
            await asyncio.sleep(3)  # brief cooldown, avoids hammering sources back-to-back
        auto_log("[AUTO] 📡 Harvester loop stopped.")
        auto_emit_state()

    # ── Worker: pick proxy → validate → visit → repeat ──
    async def _run_worker():
        from bot_engine import BotEngine, async_playwright
        auto_log("[AUTO] 🔧 Worker started — waiting for passed proxies...")

        _concurrent_n = config.get("concurrent_visits", 1)
        if _concurrent_n > 1:
            auto_log(f"[AUTO] ⚡ Concurrent mode ON — up to {_concurrent_n} visits in parallel")

        async def _do_single_visit(p, proxy_data, visit_num):
            """Run a single visit with a specific proxy. Returns VisitResult."""
            proxy_ip = f"{proxy_data['ip']}:{proxy_data['port']}"
            proxy_bot = _auto_proxy_to_bot_format(proxy_data)

            visit_config = {
                "links": links,
                "visits_per_link": 1,
                "device_type": config.get("device_type", "random"),
                "android_pct": config.get("android_pct", 55),
                "fb_browser_pct": config.get("fb_browser_pct", 15),
                "desktop_pct": config.get("desktop_pct", 30),
                "min_delay": 1,
                "max_delay": 2,
                "min_visit_time": config.get("min_visit_time", 3),
                "max_visit_time": config.get("max_visit_time", 6),
                "scroll": config.get("scroll", True),
                "click": config.get("click", False),
                "mouse_movement": config.get("mouse_movement", True),
                "headless": config.get("headless", True),
                "validate_proxies": True,
                "quick_impression": config.get("quick_impression", False),
                "pre_browse_google": config.get("pre_browse_google", True),
                "pre_browse_chance": config.get("pre_browse_chance", 0.6),
                "traffic_source": config.get("traffic_source", "random"),
                "campaign_config": CAMPAIGN_CONFIG.get(config.get("traffic_source",""), None),
                "visit_mode": config.get("visit_mode", "direct"),
                "landing_url": config.get("landing_url", ""),
                "button_text": config.get("button_text", ""),
                "pre_click_wait_min": config.get("pre_click_wait_min", 2),
                "pre_click_wait_max": config.get("pre_click_wait_max", 5),
                "nav_timeout_ms": config.get("nav_timeout_ms", 60000),
                "proxies": [proxy_bot["raw"]],
            }

            def _auto_ip_cb(proxy, status, extra=None):
                if status == "failed":
                    auto_log(f"[AUTO] ⚠ Proxy {proxy.get('display_ip','?')} failed during visit — will pick next")
                elif status == "used":
                    auto_log(f"[AUTO] 🏁 Proxy {proxy.get('display_ip','?')} consumed (visit done)")

            engine = BotEngine(visit_config, log_callback=auto_log, ip_callback=_auto_ip_cb)
            engine.is_running = True

            try:
                result = await engine._single_visit(p, links[0], visit_num)
                if result.success:
                    auto_log(f"[AUTO] ✅ Visit #{visit_num} SUCCESS — {result.proxy_ip} | {result.duration:.1f}s | Q:{result.ip_quality}")
                else:
                    auto_log(f"[AUTO] ❌ Visit #{visit_num} FAILED — {result.error[:80]}")
                try:
                    global bot_engine
                    if bot_engine is None:
                        bot_engine = BotEngine({"links": links}, lambda m: None, lambda p, s, e=None: None)
                    bot_engine.results.append(result)
                    if len(bot_engine.results) > 200:
                        bot_engine.results = bot_engine.results[-200:]
                except: pass
                try:
                    socketio.emit("auto_visit_done", {
                        "url": result.url, "success": result.success,
                        "proxy_ip": result.proxy_ip,
                        "fingerprint": (result.fingerprint_id or "")[:20],
                        "duration": round(result.duration, 1),
                        "error": result.error or "",
                        "timestamp": result.timestamp or "",
                        "redirects": getattr(result, "redirects", 0),
                        "country": getattr(result, "proxy_country", None),
                        "ip_quality": getattr(result, "ip_quality", 0),
                        "visit_num": visit_num,
                    })
                    socketio.emit("log", {"time": time.strftime("%H:%M:%S"),
                        "msg": f"[AUTO] Visit #{visit_num}: {'OK' if result.success else 'FAIL'} — {result.proxy_ip} ({round(result.duration,1)}s)"})
                except: pass
                return result
            except Exception as e:
                auto_log(f"[AUTO] ❌ Visit #{visit_num} error: {str(e)[:100]}")
                return None
            finally:
                engine.is_running = False

        async with async_playwright() as p:
            while not AUTO_STATE["stop_flag"]:
                if AUTO_STATE["stop_flag"]:
                    break

                if _concurrent_n > 1:
                    # ── CONCURRENT MODE: pick N proxies, run N visits in parallel ──
                    proxies_batch = []
                    for _ in range(_concurrent_n):
                        pd = _auto_worker_pick_proxy()
                        if pd is None:
                            break
                        proxies_batch.append(pd)

                    if not proxies_batch:
                        AUTO_STATE["phase"] = "waiting"
                        AUTO_STATE["worker_status"] = "waiting for proxies"
                        AUTO_STATE["current_proxy"] = None
                        auto_emit_state()
                        await asyncio.sleep(2)
                        continue

                    # Mark all proxies as used immediately
                    for pd in proxies_batch:
                        AUTO_STATE["used_keys"].add(f"{pd['ip']}:{pd['port']}:{pd.get('protocol','http')}")

                    AUTO_STATE["phase"] = "visiting"
                    AUTO_STATE["worker_status"] = f"visiting ({len(proxies_batch)} parallel)"
                    AUTO_STATE["current_proxy"] = f"{len(proxies_batch)} proxies"
                    auto_log(f"[AUTO] ⚡ Starting {len(proxies_batch)} concurrent visits...")
                    auto_emit_state()

                    # Launch all visits in parallel
                    tasks = []
                    for i, pd in enumerate(proxies_batch):
                        visit_num = AUTO_STATE["visits_done"] + i + 1
                        # Stagger start slightly so they don't fire in sync
                        async def _staggered_start(idx=i, proxy=pd, vn=visit_num):
                            await asyncio.sleep(0.5 * idx)
                            return await _do_single_visit(p, proxy, vn)
                        tasks.append(_staggered_start())

                    results = await asyncio.gather(*tasks, return_exceptions=True)

                    for r in results:
                        AUTO_STATE["visits_done"] += 1
                        if r is not None and hasattr(r, 'success') and r.success:
                            AUTO_STATE["visits_success"] += 1
                        else:
                            AUTO_STATE["visits_failed"] += 1

                    AUTO_STATE["current_proxy"] = None
                    AUTO_STATE["worker_status"] = "idle"
                    auto_emit_state()

                    if not AUTO_STATE["stop_flag"]:
                        delay = 1.5
                        auto_log(f"[AUTO] ⏳ {delay}s pause before next batch...")
                        await asyncio.sleep(delay)

                else:
                    # ── SEQUENTIAL MODE (original, 1 visit at a time) ──
                    proxy_data = _auto_worker_pick_proxy()
                    if proxy_data is None:
                        AUTO_STATE["phase"] = "waiting"
                        AUTO_STATE["worker_status"] = "waiting for proxies"
                        AUTO_STATE["current_proxy"] = None
                        auto_emit_state()
                        await asyncio.sleep(2)
                        continue

                    proxy_ip = f"{proxy_data['ip']}:{proxy_data['port']}"
                    proxy_bot = _auto_proxy_to_bot_format(proxy_data)
                    AUTO_STATE["used_keys"].add(f"{proxy_data['ip']}:{proxy_data['port']}:{proxy_data.get('protocol','http')}")
                    AUTO_STATE["phase"] = "visiting"
                    AUTO_STATE["worker_status"] = "visiting"
                    AUTO_STATE["current_proxy"] = proxy_ip
                    auto_log(f"[AUTO] 🔁 Picked proxy {proxy_ip} ({proxy_data.get('protocol','http')}, score {proxy_data.get('score','?')}) — starting visit")
                    auto_emit_state()

                    visit_num = AUTO_STATE["visits_done"] + 1
                    result = await _do_single_visit(p, proxy_data, visit_num)
                    AUTO_STATE["visits_done"] += 1
                    if result is not None and hasattr(result, 'success') and result.success:
                        AUTO_STATE["visits_success"] += 1
                    else:
                        AUTO_STATE["visits_failed"] += 1

                    AUTO_STATE["current_proxy"] = None
                    AUTO_STATE["worker_status"] = "idle"
                    auto_emit_state()

                    if not AUTO_STATE["stop_flag"]:
                        delay = 1.5
                        auto_log(f"[AUTO] ⏳ {delay}s pause before next proxy...")
                        await asyncio.sleep(delay)
        AUTO_STATE["worker_status"] = "stopped"
        auto_emit_state()

    # ── Run harvester + worker concurrently ──
    harvester_task = asyncio.create_task(_run_harvester())
    # Give harvester a small head start before worker starts polling
    await asyncio.sleep(3)
    worker_task = asyncio.create_task(_run_worker())

    # Wait for both to complete (or stop_flag)
    try:
        await asyncio.gather(harvester_task, worker_task, return_exceptions=True)
    except Exception as e:
        auto_log(f"[AUTO] ❌ Pipeline error: {str(e)[:120]}")

    AUTO_STATE["running"] = False
    AUTO_STATE["phase"] = "done"
    auto_log(f"[AUTO] 🏁 Pipeline complete — {AUTO_STATE['visits_success']} success / {AUTO_STATE['visits_failed']} failed / {AUTO_STATE['visits_done']} total")
    auto_emit_state()


@app.route('/api/auto/start', methods=['POST'])
def auto_start():
    if AUTO_STATE["running"]:
        return jsonify({"error": "Auto pipeline already running"}), 400
    if HARVEST_STATE.get("running"):
        return jsonify({"error": "Harvester is running — stop it first or use Auto Start"}), 400

    data = request.json or {}
    config = {
        "links": data.get("links", ""),
        "min_quality": int(data.get("min_quality", 80)),
        "max_proxies": int(data.get("max_proxies", 500)),
        "device_type": data.get("device_type", "random"),
        "android_pct": int(data.get("android_pct", 55)),
        "fb_browser_pct": int(data.get("fb_browser_pct", 15)),
        "desktop_pct": int(data.get("desktop_pct", 30)),
        "min_visit_time": float(data.get("min_visit_time", 3)),
        "max_visit_time": float(data.get("max_visit_time", 6)),
        "scroll": data.get("scroll", True),
        "click": data.get("click", False),
        "mouse_movement": data.get("mouse_movement", True),
        "form_fill": data.get("form_fill", False),
        "multi_page": data.get("multi_page", False),
        "headless": data.get("headless", True),
        "quick_impression": data.get("quick_impression", False),
        "pre_browse_google": data.get("pre_browse_google", True),
        "pre_browse_chance": float(data.get("pre_browse_chance", 0.6)),
        "traffic_source": data.get("traffic_source", "random"),
        "visit_mode": data.get("visit_mode", "direct"),
        "landing_url": data.get("landing_url", ""),
        "button_text": data.get("button_text", ""),
        "pre_click_wait_min": float(data.get("pre_click_wait_min", 2)),
        "pre_click_wait_max": float(data.get("pre_click_wait_max", 5)),
        "nav_timeout_ms": int(data.get("nav_timeout_ms", 60000)),
        "concurrent_mode_enabled": data.get("concurrent_mode_enabled", False),
        "concurrent_visits": max(1, min(10, int(data.get("concurrent_visits", 1) or 1))) if data.get("concurrent_mode_enabled") else 1,
    }

    AUTO_STATE["running"] = True
    AUTO_STATE["stop_flag"] = False

    def _run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        AUTO_STATE["auto_loop"] = loop
        try:
            loop.run_until_complete(_auto_pipeline_run(config))
        except Exception as e:
            auto_log(f"[AUTO] FATAL: {str(e)[:150]}")
        finally:
            AUTO_STATE["running"] = False
            AUTO_STATE["phase"] = "idle"
            auto_emit_state()
            loop.close()
            AUTO_STATE["auto_loop"] = None

    socketio.start_background_task(_run)
    return jsonify({"started": True})


@app.route('/api/auto/stop', methods=['POST'])
def auto_stop():
    AUTO_STATE["stop_flag"] = True
    AUTO_STATE["phase"] = "stopping"
    AUTO_STATE["worker_status"] = "stopping"
    HARVEST_STATE["running"] = False
    auto_log("[AUTO] 🛑 Stop requested — finishing current visit then stopping...")
    auto_emit_state()
    h_emit_state()  # keep Harvester panel's Start/Stop buttons synced too
    return jsonify({"stopped": True})


@app.route('/api/auto/status')
def auto_status():
    return jsonify({
        "running": AUTO_STATE["running"],
        "phase": AUTO_STATE["phase"],
        "worker_status": AUTO_STATE["worker_status"],
        "visits_done": AUTO_STATE["visits_done"],
        "visits_success": AUTO_STATE["visits_success"],
        "visits_failed": AUTO_STATE["visits_failed"],
        "current_proxy": AUTO_STATE["current_proxy"],
        "passed_available": len(HARVEST_STATE.get("passed", [])),
        "harvest_running": HARVEST_STATE.get("running", False),
    })

# ═══════════════════════════════════════════════════════════
# v13.7 — Campaign Config API (Paid Ads Referrer)
# ═══════════════════════════════════════════════════════════
CAMPAIGN_CONFIG = {}  # Stores per-source campaign params

@app.route('/api/campaign/save', methods=['POST'])
def save_campaign():
    global CAMPAIGN_CONFIG
    data = request.get_json() or {}
    source = data.get("source")
    if source:
        CAMPAIGN_CONFIG[source] = data
    return jsonify({"ok": True, "saved": source})

@app.route('/api/campaign/get', methods=['GET'])
def get_campaign():
    return jsonify(CAMPAIGN_CONFIG)


# ═══════════════════════════════════════════════════════════
# v13.7 — RDP Visual Mode Status API
# ═══════════════════════════════════════════════════════════
import platform as _platform

@app.route('/api/rdp/status', methods=['GET'])
def rdp_status():
    """Returns whether the server can run real Chrome/Edge (Windows headed)."""
    import sys as _sys
    is_windows = _sys.platform.startswith("win")
    has_display = bool(_os.environ.get("DISPLAY")) if not is_windows else True
    # Check if Chrome or Edge binary exists on this machine
    chrome_paths = []
    edge_paths = []
    chrome_found = False
    edge_found = False
    if is_windows:
        chrome_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
        edge_paths = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        ]
        chrome_found = any(_os.path.exists(p) for p in chrome_paths)
        edge_found   = any(_os.path.exists(p) for p in edge_paths)
    return jsonify({
        "is_windows": is_windows,
        "has_display": has_display,
        "chrome_installed": chrome_found,
        "edge_installed": edge_found,
        "rdp_mode_available": is_windows,
        "platform": _platform.system() + " " + _platform.release(),
        "recommended_channel": "chrome" if chrome_found else ("msedge" if edge_found else "playwright-chromium"),
    })

# ═══════════════════════════════════════════════════════════════
# START SERVER — must be LAST (all routes must be defined before this)
# ═══════════════════════════════════════════════════════════════
if __name__ == '__main__':
    print("S2C Flow v18.1 — Dashboard starting on http://localhost:5000")
    socketio.run(app, host='0.0.0.0', port=5000, debug=False, allow_unsafe_werkzeug=True)
