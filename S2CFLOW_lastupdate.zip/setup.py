"""
Visitor Bot — Auto Setup Script (v14.0)
Run once: installs Python packages + ALL Playwright browser engines.
After first run, START.bat will skip heavy steps.

Engines installed:
  - Chromium  -> Chrome, Edge, Samsung Internet, Chrome Android
  - Firefox   -> Firefox (real Gecko engine)
  - WebKit    -> Safari iOS + Safari Mac (real WebKit engine)
"""

import sys
import os
import subprocess
import json
import warnings
from pathlib import Path

# Suppress pkg_resources deprecation warning from playwright_stealth
warnings.filterwarnings("ignore", category=UserWarning, module="pkg_resources")
os.environ["PYTHONWARNINGS"] = "ignore"

DONE_FLAG = Path(".setup_done")
PYTHON = sys.executable
# Quote Python path for shell commands (handles spaces in directory names like "Update Traffic")
# We use list-form subprocess where possible, and quoted path in shell=True commands
PYTHON_Q = f'"{PYTHON}"' if " " in PYTHON else PYTHON


def run(cmd, desc="", check=True):
    if desc:
        print(f"\n[*] {desc}")
    # shell=True but wrap python paths in quotes to handle spaces in directory names
    result = subprocess.run(cmd, shell=True, env={**os.environ, "PYTHONWARNINGS": "ignore"})
    if check and result.returncode != 0:
        print(f"[ERROR] Failed: {cmd}")
        sys.exit(1)
    return result.returncode == 0


def pip_install(packages, desc=""):
    run(f'{PYTHON_Q} -m pip install --upgrade {packages} -q', desc)


def verify_imports():
    """Verify all required packages are importable."""
    packages = [
        ("playwright", "playwright"),
        ("flask", "flask"),
        ("flask_socketio", "flask_socketio"),
        ("eventlet", "eventlet"),
        ("aiohttp", "aiohttp"),
    ]
    all_ok = True
    for name, module in packages:
        try:
            __import__(module)
            print(f"  OK {name}")
        except ImportError:
            print(f"  MISSING {name}")
            all_ok = False
    # Optional
    try:
        import playwright_stealth
        print("  OK playwright-stealth")
    except ImportError:
        print("  (optional) playwright-stealth not installed")
    # v20.1: Patchright (CDP-hardened engine) — strongly recommended
    try:
        import patchright
        print("  OK patchright (CDP-hardened engine)")
    except ImportError:
        print("  (recommended) patchright not installed — bot falls back to Playwright (higher denial risk)")
    return all_ok


def main():
    print("\n" + "=" * 55)
    print("  VISITOR BOT v14.0 — AUTO SETUP")
    print("  Installing: Chromium + Firefox + WebKit")
    print("=" * 55)

    # ── Already set up? ──────────────────────────────────────────
    if DONE_FLAG.exists():
        print("\n[OK] Already set up. Starting bot directly...\n")
        # Use subprocess instead of os.execv — handles Python paths with spaces correctly
        result = subprocess.run([PYTHON, "app.py"])
        sys.exit(result.returncode)

    # ── Step 1: pip upgrade ──────────────────────────────────────
    print("\n[1/6] Upgrading pip...")
    run(f'{PYTHON_Q} -m pip install --upgrade pip -q', check=False)

    # ── Step 2: Install requirements ────────────────────────────
    print("\n[2/6] Installing Python packages...")
    req_file = Path("requirements.txt")
    if req_file.exists():
        run(f'{PYTHON_Q} -m pip install -r requirements.txt -q',
            "Installing from requirements.txt")
    else:
        pip_install(
            "playwright==1.49.0 playwright-stealth==1.0.6 "
            "flask==3.0.0 flask-socketio==5.3.6 eventlet==0.36.1 "
            "fake-useragent==1.5.1 aiohttp==3.10.11 "
            "aiohttp_socks==0.11.0 python_socks==2.8.2",
            "Installing all packages"
        )

    # ── Step 3: Playwright — Chromium ────────────────────────────
    print("\n[3/6] Installing Playwright Chromium (Chrome, Edge, Samsung)...")
    print("      [This may take 2-3 minutes on first run]")
    run(f'{PYTHON_Q} -m playwright install chromium', check=True)

    # ── v20.1: Patchright — CDP-hardened Chromium engine ──────────
    print("\n[3b/6] Installing Patchright (CDP-hardened engine — blocks fraud-gate bot detection)...")
    run(f'{PYTHON_Q} -m pip install "patchright>=1.49.0" -q', check=False, desc="Installing patchright")

    # ── Step 4: Playwright — Firefox (Gecko engine) ──────────────
    print("\n[4/6] Installing Playwright Firefox (real Gecko engine)...")
    run(f'{PYTHON_Q} -m playwright install firefox', check=False)

    # ── Step 5: Playwright — WebKit (Safari engine) ──────────────
    print("\n[5/6] Installing Playwright WebKit (real Safari/WebKit engine)...")
    print("      [Required for iOS Safari + macOS Safari fingerprints]")
    run(f'{PYTHON_Q} -m playwright install webkit', check=False)

    # ── Install system deps (Linux only — no-op on Windows/Mac) ──
    print("\n      Installing system dependencies...")
    run(f'{PYTHON_Q} -m playwright install-deps chromium', check=False)
    run(f'{PYTHON_Q} -m playwright install-deps firefox', check=False)
    run(f'{PYTHON_Q} -m playwright install-deps webkit', check=False)

    # ── Step 6: Verify core imports ─────────────────────────────
    print("\n[6/6] Verifying installation...")
    verify_imports()

    # ── Mark done ────────────────────────────────────────────────
    print("\n[*] Saving setup state...")
    DONE_FLAG.write_text(json.dumps({
        "setup": "complete",
        "version": "5.1",
        "engines": ["chromium", "firefox", "webkit"]
    }, indent=2))

    print("\n" + "=" * 55)
    print("  SETUP COMPLETE!")
    print("  Engines: Chromium + Firefox + WebKit")
    print("  Starting Visitor Bot...")
    print("  Dashboard -> http://localhost:5000")
    print("=" * 55 + "\n")

    # ── Launch app ───────────────────────────────────────────────
    # subprocess handles Python paths with spaces (e.g. "D:\Update Traffic\...")
    result = subprocess.run([PYTHON, "app.py"])
    sys.exit(result.returncode)


if __name__ == "__main__":
    main()
