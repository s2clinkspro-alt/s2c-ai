"""Font downloader — downloads Android fonts to fonts/ folder"""
import urllib.request, os

font_dir = os.path.join(os.path.dirname(__file__), "fonts")
os.makedirs(font_dir, exist_ok=True)

fonts = [
    "https://raw.githubusercontent.com/openmaptiles/fonts/master/roboto/Roboto-Regular.ttf",
    "https://raw.githubusercontent.com/openmaptiles/fonts/master/roboto/Roboto-Bold.ttf",
    "https://raw.githubusercontent.com/openmaptiles/fonts/master/roboto/Roboto-Medium.ttf",
    "https://raw.githubusercontent.com/openmaptiles/fonts/master/roboto/Roboto-Light.ttf",
    "https://raw.githubusercontent.com/openmaptiles/fonts/master/roboto/Roboto-Italic.ttf",
    "https://raw.githubusercontent.com/notofonts/notofonts.github.io/main/fonts/NotoSans/hinted/ttf/NotoSans-Regular.ttf",
    "https://raw.githubusercontent.com/notofonts/notofonts.github.io/main/fonts/NotoSans/hinted/ttf/NotoSans-Bold.ttf",
]

print("Downloading fonts to:", font_dir)
ok = 0
fail = 0
for url in fonts:
    name = url.split("/")[-1]
    dest = os.path.join(font_dir, name)
    if os.path.exists(dest) and os.path.getsize(dest) > 1000:
        print(f"  OK {name} (already exists)")
        ok += 1
        continue
    try:
        urllib.request.urlretrieve(url, dest)
        size = os.path.getsize(dest)
        if size > 1000:
            print(f"  OK {name} ({size//1024}KB)")
            ok += 1
        else:
            print(f"  FAIL {name} (too small)")
            fail += 1
    except Exception as e:
        print(f"  FAIL {name}: {e}")
        fail += 1

print(f"\nDone! {ok} downloaded, {fail} failed")
print(f"Fonts folder: {font_dir}")
if fail == 0:
    print("\nNow: open fonts/ folder -> select all .ttf -> right-click -> Install (Windows)")
    print("Or: double-click each -> Install Font (Mac)")
else:
    print("\nSome fonts failed. You can still run the bot without them,")
    print("but Android font rendering won't be 100% authentic.")
