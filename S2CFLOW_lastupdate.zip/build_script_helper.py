"""
Helper to build stealth init script without f-string brace issues.
Uses template replacement approach.
"""
import json, random, re

def build_stealth_script(fp, target_domain=None, referer_url=None):
    """
    v13.7.5 — Firefox/Safari stealth: removes Chrome-specific APIs.
    - navigator.userAgentData: deleted (Firefox/Safari don't have it)
    - window.chrome: deleted (Firefox/Safari don't have it)  
    - chrome.runtime: deleted
    - Sec-CH-UA related JS: skipped
    """
    is_firefox = fp.get("is_firefox", False)
    is_safari = fp.get("is_safari", False)
    """Build stealth init script using template replacement (no f-string)."""
    
    canvas_seed = fp.get("canvas_seed", 0)
    audio_seed = fp.get("audio_seed", 0)
    ua = fp["user_agent"]
    platform = fp["platform"]
    device_fonts = fp.get("fonts", [])
    if isinstance(device_fonts, str):
        device_fonts = [device_fonts]
    fonts_json = json.dumps(device_fonts)
    languages = json.dumps(fp["languages"])
    timezone = fp["timezone"]
    # v11.0 — compute UTC offset in minutes for getTimezoneOffset() spoofing
    # Maps timezone string to approximate UTC offset (standard time, no DST)
    _tz_offsets = {
        # North America
        "America/New_York":300,"America/Los_Angeles":480,"America/Chicago":360,"America/Denver":420,
        "America/Toronto":300,"America/Mexico_City":360,"America/Bogota":300,
        "America/Santiago":240,"America/Buenos_Aires":180,"America/Sao_Paulo":180,
        "America/Lima":300,"America/Caracas":240,"America/Guayaquil":300,
        "America/La_Paz":240,"America/Asuncion":240,"America/Montevideo":180,
        "America/Panama":300,"America/Costa_Rica":360,"America/Santo_Domingo":240,
        "America/Puerto_Rico":240,"America/Havana":300,"America/Jamaica":300,
        # Europe
        "Europe/London":0,"Europe/Dublin":0,"Europe/Berlin":-60,"Europe/Paris":-60,
        "Europe/Madrid":-60,"Europe/Rome":-60,"Europe/Amsterdam":-60,
        "Europe/Istanbul":-180,"Europe/Stockholm":-60,"Europe/Oslo":-60,
        "Europe/Copenhagen":-60,"Europe/Helsinki":-120,"Europe/Warsaw":-60,
        "Europe/Prague":-60,"Europe/Athens":-120,"Europe/Bucharest":-120,
        "Europe/Moscow":-180,"Europe/Kyiv":-120,"Europe/Vienna":-60,
        "Europe/Zurich":-60,"Europe/Brussels":-60,"Europe/Luxembourg":-60,
        "Europe/Malta":-60,"Europe/Lisbon":0,"Europe/Sofia":-120,
        "Europe/Zagreb":-60,"Europe/Belgrade":-60,"Europe/Budapest":-60,
        "Europe/Bratislava":-60,"Europe/Ljubljana":-60,"Europe/Vilnius":-120,
        "Europe/Riga":-120,"Europe/Tallinn":-120,"Europe/Nicosia":-120,
        # Middle East / Central Asia
        "Asia/Dubai":-240,"Asia/Riyadh":-180,"Asia/Jerusalem":-180,
        "Asia/Baghdad":-180,"Asia/Kuwait":-180,"Asia/Qatar":-180,"Asia/Amman":-180,
        "Asia/Tbilisi":-240,"Asia/Yerevan":-240,"Asia/Baku":-240,
        "Asia/Almaty":-360,"Asia/Tashkent":-300,"Asia/Kabul":-270,
        # South Asia
        "Asia/Tokyo":-540,"Asia/Kolkata":-330,"Asia/Dhaka":-360,
        "Asia/Karachi":-300,"Asia/Colombo":-330,"Asia/Kathmandu":-345,
        # Southeast Asia
        "Asia/Bangkok":-420,"Asia/Jakarta":-420,"Asia/Manila":-480,
        "Asia/Seoul":-540,"Asia/Singapore":-480,"Asia/Kuala_Lumpur":-480,
        "Asia/Ho_Chi_Minh":-420,"Asia/Shanghai":-480,"Asia/Hong_Kong":-480,
        "Asia/Taipei":-480,"Asia/Phnom_Penh":-420,"Asia/Vientiane":-420,
        "Asia/Yangon":-390,"Asia/Ulaanbaatar":-480,
        # Africa
        "Africa/Cairo":-120,"Africa/Lagos":-60,"Africa/Johannesburg":-120,
        "Africa/Nairobi":-180,"Africa/Accra":0,"Africa/Casablanca":0,
        "Africa/Tunis":-60,"Africa/Algiers":-60,
        # Oceania
        "Australia/Sydney":-600,"Pacific/Auckland":-720,
        # Atlantic
        "Asia/Nicosia":-120,"Atlantic/Reykjavik":0,
    }
    tz_offset_min = _tz_offsets.get(timezone, 0)
    tz_offset_hours = abs(tz_offset_min) // 60
    # v11.0 — approximate geo coordinates for the country (capital city area)
    _geo_coords = {
        # North America
        "United States":(38.9,-77.0,5000),"Canada":(45.42,-75.7,5000),"Mexico":(19.43,-99.13,5000),
        "Puerto Rico":(18.47,-66.12,5000),"Costa Rica":(9.93,-84.08,5000),"Panama":(8.98,-79.52,5000),
        "Dominican Republic":(18.49,-69.93,5000),"Cuba":(23.13,-82.38,5000),"Jamaica":(17.97,-76.79,5000),
        # South America
        "Brazil":(-23.55,-46.63,5000),"Colombia":(4.71,-74.07,5000),"Chile":(-33.45,-70.67,5000),
        "Argentina":(-34.6,-58.38,5000),"Peru":(-12.05,-77.04,5000),"Venezuela":(10.49,-66.88,5000),
        "Ecuador":(-0.18,-78.47,5000),"Bolivia":(-16.5,-68.15,5000),"Paraguay":(-25.26,-57.59,5000),
        "Uruguay":(-34.9,-56.16,5000),
        # Western/Northern Europe
        "United Kingdom":(51.5,-0.1,5000),"Ireland":(53.35,-6.26,5000),"Germany":(52.5,13.4,5000),
        "France":(48.85,2.35,5000),"Netherlands":(52.37,4.9,5000),"Belgium":(50.85,4.35,5000),
        "Luxembourg":(49.61,6.13,5000),"Switzerland":(46.95,7.45,5000),"Austria":(48.21,16.37,5000),
        "Portugal":(38.72,-9.14,5000),"Spain":(40.4,-3.7,5000),"Italy":(41.9,12.5,5000),
        "Sweden":(59.33,18.07,5000),"Norway":(59.91,10.75,5000),"Denmark":(55.68,12.57,5000),
        "Finland":(60.17,24.94,5000),"Iceland":(64.15,-21.94,5000),
        # Central/Eastern Europe
        "Poland":(52.23,21.01,5000),"Czech Republic":(50.08,14.44,5000),"Romania":(44.43,26.1,5000),
        "Greece":(37.98,23.73,5000),"Hungary":(47.5,19.04,5000),"Russia":(55.75,37.62,5000),
        "Ukraine":(50.45,30.52,5000),"Croatia":(45.81,16.0,5000),"Serbia":(44.79,20.45,5000),
        "Bulgaria":(42.7,23.32,5000),"Slovakia":(48.15,17.11,5000),"Slovenia":(46.06,14.51,5000),
        "Lithuania":(54.69,25.28,5000),"Latvia":(56.95,24.11,5000),"Estonia":(59.44,24.75,5000),
        "Cyprus":(35.17,33.36,5000),"Malta":(35.9,14.45,5000),
        # Middle East / Caucasus / Central Asia
        "Turkey":(41.0,28.98,5000),"UAE":(25.2,55.3,5000),"Saudi Arabia":(24.71,46.68,5000),
        "Israel":(31.78,35.22,5000),"Iraq":(33.32,44.36,5000),"Kuwait":(29.38,47.97,5000),
        "Qatar":(25.28,51.52,5000),"Jordan":(31.95,35.91,5000),"Georgia":(41.69,44.8,5000),
        "Armenia":(40.18,44.51,5000),"Azerbaijan":(40.4,49.87,5000),
        "Kazakhstan":(51.17,71.43,5000),"Uzbekistan":(41.31,69.24,5000),
        # South Asia
        "India":(28.61,77.2,5000),"Bangladesh":(23.81,90.41,5000),"Pakistan":(33.68,73.05,5000),
        "Sri Lanka":(6.93,79.86,5000),"Nepal":(27.71,85.32,5000),
        # Southeast Asia
        "Thailand":(13.75,100.5,5000),"Indonesia":(-6.2,106.85,5000),"Philippines":(14.6,120.98,5000),
        "Singapore":(1.35,103.82,5000),"Malaysia":(3.14,101.69,5000),"Vietnam":(21.03,105.85,5000),
        "Myanmar":(19.76,96.07,5000),"Cambodia":(11.56,104.93,5000),"Laos":(17.97,102.63,5000),
        "Mongolia":(47.92,106.92,5000),
        # East Asia
        "Japan":(35.68,139.69,5000),"South Korea":(37.56,126.99,5000),"China":(39.9,116.4,5000),
        "Hong Kong":(22.32,114.17,5000),"Taiwan":(25.03,121.57,5000),
        # Africa
        "Egypt":(30.04,31.24,5000),"Nigeria":(6.52,3.38,5000),"South Africa":(-25.75,28.19,5000),
        "Kenya":(-1.29,36.82,5000),"Ghana":(5.6,-0.19,5000),"Morocco":(34.02,-6.83,5000),
        "Tunisia":(36.8,10.18,5000),"Algeria":(36.75,3.06,5000),
        # Oceania
        "Australia":(-33.87,151.21,5000),"New Zealand":(-36.85,174.76,5000),
    }
    geo_country = fp.get("geo_country", "")
    _gc = _geo_coords.get(geo_country, (37.77, -122.42, 5000))  # fallback: SF
    geo_lat = _gc[0] + random.uniform(-0.3, 0.3)  # jitter around capital
    geo_lon = _gc[1] + random.uniform(-0.3, 0.3)
    geo_acc = random.choice([5000, 8000, 10000, 15000, 20000])  # IP-based accuracy
    locale = fp["locale"]
    sw = fp["screen"]["width"]; sh = fp["screen"]["height"]
    aw = fp["screen_avail"]["width"]; ah = fp["screen_avail"]["height"]
    cd = fp["color_depth"]; pr = fp["pixel_ratio"]
    hc = fp["hardware_concurrency"]; dm = fp["device_memory"]
    mtp = fp["max_touch_points"]
    wv = fp["webgl"]["vendor"].replace("'", "\\'")
    wr = fp["webgl"]["renderer"].replace("'", "\\'")
    bl = fp["battery"]["level"]
    bch = "true" if fp["battery"]["charging"] else "false"
    bct = "Infinity" if not fp["battery"]["charging"] else "3600"
    bdt = "Infinity" if fp["battery"]["charging"] else "7200"
    ct = fp["connection"]["effectiveType"]
    crtt = fp["connection"]["rtt"]
    cdn = fp["connection"]["downlink"]
    ctype = fp["connection"].get("type", "wifi")
    is_firefox = fp.get("is_firefox", False)
    is_edge = fp.get("is_edge", False)
    is_safari = fp.get("is_safari", False)  # v13.7.7 FIX: was incorrectly reading is_ios
    is_chrome = not is_firefox and not is_safari  # v13.7.7 FIX: derived from is_safari
    is_mobile = fp["is_mobile"]
    dnt = json.dumps(fp.get("do_not_track"))
    dm_model = fp.get("device_model", "").replace("'", "\\'")
    orientation = fp.get("orientation", "landscape-primary")
    mobile_str = "true" if is_mobile else "false"

    chrome_ver = "131"
    chrome_full = "131.0.0.0"
    if "Chrome/" in ua:
        m = re.search(r"Chrome/(\d+)\.(\d+)\.(\d+)", ua)
        if m:
            chrome_ver = m.group(1)
            chrome_full = m.group(0).replace("Chrome/", "")
        else:
            m2 = re.search(r"Chrome/(\d+)", ua)
            if m2: chrome_ver = m2.group(1)

    # Client hints
    is_samsung = fp.get("is_samsung_internet", False)
    samsung_ver_str = fp.get("samsung_browser_ver", "25.0")
    samsung_major = samsung_ver_str.split(".")[0] if samsung_ver_str else "25"
    
    if is_chrome and not is_firefox:
        if is_edge:
            brands = '[{"brand":"Not.A/Brand","version":"24"},{"brand":"Chromium","version":"' + chrome_ver + '"},{"brand":"Microsoft Edge","version":"' + chrome_ver + '"}]'
            fvl = '[{"brand":"Not.A/Brand","version":"24.0.0.0"},{"brand":"Chromium","version":"' + chrome_full + '"},{"brand":"Microsoft Edge","version":"' + chrome_full + '"}]'
        elif is_samsung:
            brands = '[{"brand":"Samsung Internet","version":"' + samsung_major + '"},{"brand":"Chromium","version":"' + chrome_ver + '"},{"brand":"Not;A=Brand","version":"99"}]'
            fvl = '[{"brand":"Samsung Internet","version":"' + samsung_ver_str + '"},{"brand":"Chromium","version":"' + chrome_full + '"},{"brand":"Not;A=Brand","version":"99.0.0.0"}]'
        else:
            brands = '[{"brand":"Google Chrome","version":"' + chrome_ver + '"},{"brand":"Chromium","version":"' + chrome_ver + '"},{"brand":"Not?A_Brand","version":"99"}]'
            fvl = '[{"brand":"Google Chrome","version":"' + chrome_full + '"},{"brand":"Chromium","version":"' + chrome_full + '"},{"brand":"Not?A_Brand","version":"99.0.0.0"}]'
        sch_m = "?1" if is_mobile else "?0"
        if platform == "Win32": sch_p = '"Windows"'
        elif platform == "MacIntel": sch_p = '"macOS"'
        elif platform == "Linux x86_64": sch_p = '"Linux"'
        else: sch_p = '"Android"' if is_mobile else '"Windows"'
        arch = '""' if is_mobile else '"x86"'
        _s = fp.get("canvas_seed", 0)
        pv = '"' + str(10 + (_s % 6)) + '.' + str((_s >> 4) % 10) + '.0"'
    else:
        brands = "[]"; fvl = "[]"; sch_m = '""'; sch_p = '""'; arch = '"x86"'; pv = '"15.0.0"'

    # Plugins block
    # CRITICAL FIX: Real mobile Chrome (Android) ALWAYS reports
    # navigator.plugins.length === 0 and navigator.mimeTypes.length === 0
    # — it does NOT expose the desktop PDF-viewer plugin list. Previously
    # this code gave the mobile Android profile the SAME 5-entry desktop
    # plugin list as a real desktop Chrome — a dead giveaway inconsistency
    # (mobile User-Agent + mobile viewport, but desktop-only plugins) that
    # fingerprinting/anti-fraud scripts specifically check for.
    if not is_safari and not is_firefox and not is_mobile:
        plugins_js = """
    try {
        const _pd = [
            {name:'PDF Viewer',filename:'internal-pdf-viewer',description:'Portable Document Format',length:1},
            {name:'Chrome PDF Viewer',filename:'internal-pdf-viewer',description:'Portable Document Format',length:1},
            {name:'Chromium PDF Viewer',filename:'internal-pdf-viewer',description:'Portable Document Format',length:1},
            {name:'Microsoft Edge PDF Viewer',filename:'internal-pdf-viewer',description:'Portable Document Format',length:1},
            {name:'WebKit built-in PDF',filename:'internal-pdf-viewer',description:'Portable Document Format',length:1}
        ];
        function FP(d){this.name=d.name;this.filename=d.filename;this.description=d.description;this.length=d.length;this[0]={type:'application/pdf',suffixes:'pdf',description:'Portable Document Format',enabledPlugin:this};}
        function FPA(){for(let i=0;i<_pd.length;i++){this[i]=new FP(_pd[i]);}this.length=_pd.length;this.item=function(i){return this[i]||null;};this.namedItem=function(n){for(let i=0;i<this.length;i++){if(this[i].name===n)return this[i];}return null;};this.refresh=function(){};}
        const _pa=new FPA();
        Object.defineProperty(navigator,'plugins',{get:()=>_pa});
        function FMA(){const mt={type:'application/pdf',suffixes:'pdf',description:'Portable Document Format'};mt.enabledPlugin=_pa[0];this[0]=mt;this.length=1;this.item=function(i){return this[i]||null;};this.namedItem=function(t){return this[0]&&this[0].type===t?this[0]:null;};}
        Object.defineProperty(navigator,'mimeTypes',{get:()=>new FMA()});
    } catch(e) {}
"""
    else:
        plugins_js = """
    try {
        function EPA(){this.length=0;this.item=function(){return null;};this.namedItem=function(){return null;};this.refresh=function(){};}
        Object.defineProperty(navigator,'plugins',{get:()=>new EPA()});
        function EMA(){this.length=0;this.item=function(){return null;};this.namedItem=function(){return null;};}
        Object.defineProperty(navigator,'mimeTypes',{get:()=>new EMA()});
    } catch(e) {}
"""

    # Sensor block (mobile only)
    if is_mobile:
        sensor_js = """
    try{Object.defineProperty(window,'DeviceMotionEvent',{get:()=>function DME(){this.acceleration=null;this.accelerationIncludingGravity=null;this.rotationRate=null;this.interval=16;}});}catch(e){}
    try{if(!('ontouchstart' in window))Object.defineProperty(window,'ontouchstart',{get:()=>null,configurable:true});}catch(e){}
    try{if(typeof TouchEvent==='undefined'){window.TouchEvent=function TE(t,i){this.type=t;this.touches=(i&&i.touches)||[];this.targetTouches=(i&&i.targetTouches)||[];this.changedTouches=(i&&i.changedTouches)||[];};window.TouchEvent.prototype=Object.create(Event.prototype);}}catch(e){}
    try{if(typeof Touch==='undefined'){window.Touch=function T(i){this.identifier=(i&&i.identifier)||0;this.target=(i&&i.target)||document.body;this.clientX=(i&&i.clientX)||0;this.clientY=(i&&i.clientY)||0;this.radiusX=1;this.radiusY=1;this.rotationAngle=0;this.force=0.5;};}}catch(e){}
    try{if(!('ontouchstart' in document))Object.defineProperty(document,'ontouchstart',{get:()=>null,configurable:true});}catch(e){}
    try{if(document.documentElement)Object.defineProperty(document.documentElement,'ontouchstart',{get:()=>null,configurable:true});}catch(e){}
    try{if(!navigator.vibrate)Object.defineProperty(navigator,'vibrate',{value:function(p){return true;},configurable:true});}catch(e){}
    try{if(screen.orientation)Object.defineProperty(screen.orientation,'angle',{get:()=>0});}catch(e){}
    try{if(navigator.userAgentData)Object.defineProperty(navigator.userAgentData,'mobile',{get:()=>true});}catch(e){}
    try{if(navigator.mediaDevices&&!navigator.mediaDevices.enumerateDevices){navigator.mediaDevices.enumerateDevices=function(){return Promise.resolve([{kind:'audioinput',deviceId:'default',label:'',groupId:'default'},{kind:'videoinput',deviceId:'default',label:'',groupId:'default'},{kind:'audiooutput',deviceId:'default',label:'',groupId:'default'}]);};}}catch(e){}
"""
    else:
        sensor_js = ""

    # Chrome loadTimes values — deterministic from canvas_seed (stable per session)
    _seed = fp.get("canvas_seed", 0)
    lt_commit = (_seed % 10) + 1
    lt_finish_doc = (_seed >> 4) % 6
    lt_finish = (_seed >> 8) % 4
    lt_first_paint = ((_seed >> 12) % 7) + 2
    lt_request = ((_seed >> 16) % 11) + 5
    csi_start = ((_seed >> 20) % 4001) + 1000
    csi_onload = ((_seed >> 24) % 901) + 100
    speech_count = ((_seed >> 28) % 10) + 3

    # Build script using string template (NO f-string)
    template = """(function(){
    Object.defineProperty(navigator,'webdriver',{get:()=>undefined});
    try{delete navigator.__proto__.webdriver;}catch(e){}
    try{Object.defineProperty(navigator,'userAgent',{get:()=>__UA__,configurable:true});}catch(e){}
    try{Object.defineProperty(navigator,'platform',{get:()=>'_PLATFORM_'});}catch(e){}
    try{Object.defineProperty(navigator,'languages',{get:()=>_LANGS_});Object.defineProperty(navigator,'language',{get:()=>_LANGS_[0]});}catch(e){}
    try{Object.defineProperty(navigator,'hardwareConcurrency',{get:()=>_HC_});}catch(e){}
    try{Object.defineProperty(navigator,'deviceMemory',{get:()=>_DM_});}catch(e){}
    try{Object.defineProperty(navigator,'maxTouchPoints',{get:()=>_MTP_});}catch(e){}
    try{Object.defineProperty(navigator,'doNotTrack',{get:()=>_DNT_});}catch(e){}
    try{Object.defineProperty(navigator,'standalone',{get:()=>_STANDALONE_});}catch(e){}
    try{
        Object.defineProperty(screen,'width',{get:()=>_SW_});Object.defineProperty(screen,'height',{get:()=>_SH_});
        Object.defineProperty(screen,'availWidth',{get:()=>_AW_});Object.defineProperty(screen,'availHeight',{get:()=>_AH_});
        Object.defineProperty(screen,'colorDepth',{get:()=>_CD_});Object.defineProperty(screen,'pixelDepth',{get:()=>_CD_});
        Object.defineProperty(window,'devicePixelRatio',{get:()=>_PR_});
        Object.defineProperty(window,'outerWidth',{get:()=>_SW_});Object.defineProperty(window,'outerHeight',{get:()=>_IH_+88});  // v1.89: inner+88 < 160 to bypass DevTools detection
        Object.defineProperty(window,'innerWidth',{get:()=>_SW_});Object.defineProperty(window,'innerHeight',{get:()=>_IH_});
        if(screen.orientation)Object.defineProperty(screen.orientation,'type',{get:()=>'_ORIENT_'});
    }catch(e){}
    try{
        const _dtf=Intl.DateTimeFormat;
        Intl.DateTimeFormat=function(loc,opt){opt=opt||{};opt.timeZone=opt.timeZone||'_TZ_';return new _dtf(loc,opt);};
        Intl.DateTimeFormat.prototype=_dtf.prototype;
        const _ro=_dtf.prototype.resolvedOptions;
        _dtf.prototype.resolvedOptions=function(){const r=_ro.call(this);r.timeZone='_TZ_';r.locale='_LOCALE_';return r;};
        // ── v11.0: Date.prototype.getTimezoneOffset spoofing ──
        // CRITICAL LEAK FIX: getTimezoneOffset() reads the OS timezone, NOT
        // the Playwright timezone_id override. So if the server runs in UTC,
        // getTimezoneOffset() returns 0 regardless of timezone_id being
        // "Europe/Stockholm". Smartlinks compare Intl timezone vs
        // getTimezoneOffset() — any mismatch = instant bot flag.
        const _tzOffMin = _TZ_OFFSET_;
        Date.prototype.getTimezoneOffset = function() { return _tzOffMin; };
        // Also patch Date.prototype.toString to show the right timezone abbrev
        const _origDateStr = Date.prototype.toString;
        Date.prototype.toString = function() {
            const s = _origDateStr.call(this);
            // Replace the timezone abbreviation part (e.g. "GMT+0000") with
            // the correct offset for our spoofed timezone
            return s.replace(/GMT[+-]\d{4}/, 'GMT' + (_tzOffMin <= 0 ? '+' : '-') + String(Math.abs(_TZ_OFFSET_HOURS_)).padStart(2,'0') + '00');
        };
    }catch(e){}
    try{
        // ── v11.0: Geolocation API spoofing ──
        // navigator.geolocation.getCurrentPosition returns real GPS/IP location
        // which won't match the proxy country. Spoof it to a plausible city
        // in the proxy's country. Real users' browsers return coords that
        // roughly match their IP location — if ours don't, it's a leak.
        if(navigator.geolocation){
            const _geoLat=_GEO_LAT_, _geoLon=_GEO_LON_, _geoAcc=_GEO_ACC_;
            const _origGetPos=navigator.geolocation.getCurrentPosition.bind(navigator.geolocation);
            const _origWatch=navigator.geolocation.watchPosition.bind(navigator.geolocation);
            navigator.geolocation.getCurrentPosition=function(success,error,opt){
                if(typeof success==='function'){
                    success({coords:{latitude:_geoLat,longitude:_geoLon,accuracy:_geoAcc,altitude:null,altitudeAccuracy:null,heading:null,speed:null},timestamp:Date.now(),address:null});
                }
            };
            navigator.geolocation.watchPosition=function(success,error,opt){
                if(typeof success==='function'){
                    success({coords:{latitude:_geoLat,longitude:_geoLon,accuracy:_geoAcc,altitude:null,altitudeAccuracy:null,heading:null,speed:null},timestamp:Date.now()});
                }
                return 1;
            };
            // Also spoof Permissions API for geolocation
            if(navigator.permissions&&navigator.permissions.query){
                const _origQuery=navigator.permissions.query.bind(navigator.permissions);
                navigator.permissions.query=function(desc){
                    if(desc&&desc.name==='geolocation'){
                        return Promise.resolve({state:'prompt',name:'geolocation',onchange:null});
                    }
                    return _origQuery(desc);
                };
            }
        }
    }catch(e){}
    try{
        // ── v10.0 fix (#2): Canvas fingerprint hardening ──
        // The old patch only hooked toDataURL() and only modified the first 2
        // pixels — leaving toBlob(), OffscreenCanvas, and the rest of the
        // canvas untouched. Many ad networks now read canvas via toBlob()
        // or createImageBitmap(), and some check getImageData() directly.
        // Fix: apply seed-based noise to BOTH toDataURL AND toBlob, AND hook
        // getImageData at the context level so any read path gets the same
        // consistent noise for this session. Noise is deterministic (seed-
        // based) so the same canvas always produces the same noisy output
        // (stable per-session, unique across sessions).
        const _cs=_CANVAS_SEED_;
        function _noisifyCanvas(canvas){
            // v1.85: Full-canvas noise (was only 4x4 — insufficient).
            // Sample every Nth pixel across the ENTIRE canvas for full hash change.
            // Sampling keeps it fast even on large canvases (like Brave browser does).
            try{
                const ctx=canvas.getContext('2d');
                if(!ctx||canvas.width<=0||canvas.height<=0)return;
                const w=canvas.width,h=canvas.height;
                // Sample ratio: for small canvases do all pixels,
                // for large ones sample every 3rd pixel (still changes hash)
                const stride = (w*h > 10000) ? 3 : 1;
                const id=ctx.getImageData(0,0,w,h);
                const d=id.data;
                for(let y=0;y<h;y+=stride){
                    for(let x=0;x<w;x+=stride){
                        const i=(y*w+x)*4;
                        const n=((_cs>>((i*7)%32))&0x7)-3;
                        d[i]=Math.max(0,Math.min(255,d[i]+n));
                        d[i+1]=Math.max(0,Math.min(255,d[i+1]+((n>>1)&0x3)));
                        d[i+2]=Math.max(0,Math.min(255,d[i+2]+((n>>2)&0x3)));
                    }
                }
                ctx.putImageData(id,0,0);
            }catch(e){}
        }
        const origTDU=HTMLCanvasElement.prototype.toDataURL;
        HTMLCanvasElement.prototype.toDataURL=function(){
            _noisifyCanvas(this);
            return origTDU.apply(this,arguments);
        };
        if(HTMLCanvasElement.prototype.toBlob){
            const origTB=HTMLCanvasElement.prototype.toBlob;
            HTMLCanvasElement.prototype.toBlob=function(cb){
                _noisifyCanvas(this);
                return origTB.apply(this,arguments);
            };
        }
        // Also hook getImageData at the context level — some fingerprinters
        // read canvas pixels directly without calling toDataURL/toBlob.
        const origGID=CanvasRenderingContext2D.prototype.getImageData;
        CanvasRenderingContext2D.prototype.getImageData=function(sx,sy,sw,sh){
            const id=origGID.apply(this,arguments);
            try{
                for(let i=0;i<id.data.length;i+=4){
                    const n=((_cs>>((i*3)%16))&0x7)-3;
                    id.data[i]=Math.max(0,Math.min(255,id.data[i]+n));
                    id.data[i+1]=Math.max(0,Math.min(255,id.data[i+1]+((n>>1)&0x3)));
                    id.data[i+2]=Math.max(0,Math.min(255,id.data[i+2]+((n>>2)&0x3)));
                }
            }catch(e){}
            return id;
        };
        // OffscreenCanvas — increasingly used by modern fingerprinters
        if(typeof OffscreenCanvas!=='undefined'&&OffscreenCanvas.prototype.convertToBlob){
            const origCB=OffscreenCanvas.prototype.convertToBlob;
            OffscreenCanvas.prototype.convertToBlob=function(){
                try{
                    const ctx=this.getContext('2d');
                    if(ctx&&this.width>0&&this.height>0){
                        const w=this.width,h=this.height;
                        const stride=(w*h>10000)?3:1;
                        const id=ctx.getImageData(0,0,w,h);
                        const d=id.data;
                        for(let y=0;y<h;y+=stride){
                            for(let x=0;x<w;x+=stride){
                                const i=(y*w+x)*4;
                                const n=((_cs>>((i*7)%32))&0x7)-3;
                                d[i]=Math.max(0,Math.min(255,d[i]+n));
                                d[i+1]=Math.max(0,Math.min(255,d[i+1]+((n>>1)&0x3)));
                                d[i+2]=Math.max(0,Math.min(255,d[i+2]+((n>>2)&0x3)));
                            }
                        }
                        ctx.putImageData(id,0,0);
                    }
                }catch(e){}
                return origCB.apply(this,arguments);
            };
        }
    }catch(e){}
    try{
        // ── v10.0 fix (#2): WebGL fingerprint hardening ──
        // In addition to UNMASKED_VENDOR (37445) and UNMASKED_RENDERER (37446),
        // also spoof the VENDOR (7936) and RENDERER (7937) constants, plus
        // MAX_TEXTURE_SIZE and MAX_VIEWPORT_DIMS — some fingerprinters use
        // these as secondary consistency checks and would flag a mismatch
        // between UNMASKED_* and the regular VENDOR/RENDERER values.
        const og=WebGLRenderingContext.prototype.getParameter;
        WebGLRenderingContext.prototype.getParameter=function(p){
            if(p===37445)return '_WV_';
            if(p===37446)return '_WR_';
            if(p===7936)return 'WebKit';
            if(p===7937)return 'WebKit WebGL';
            return og.call(this,p);
        };
        if(typeof WebGL2RenderingContext!=='undefined'){
            const og2=WebGL2RenderingContext.prototype.getParameter;
            WebGL2RenderingContext.prototype.getParameter=function(p){
                if(p===37445)return '_WV_';
                if(p===37446)return '_WR_';
                if(p===7936)return 'WebKit';
                if(p===7937)return 'WebKit WebGL';
                return og2.call(this,p);
            };
            // v13.7.9 FIX: also hook WebGL2 getExtension — detection scripts
            // create WebGL2 contexts and call getExtension('WEBGL_debug_renderer_info')
            // to read UNMASKED_VENDOR/RENDERER. Without this hook, WebGL2
            // returns the REAL GPU info (e.g. SwiftShader) — leaking.
            const og2Ext=WebGL2RenderingContext.prototype.getExtension;
            WebGL2RenderingContext.prototype.getExtension=function(name){
                return og2Ext.call(this,name);
            };
        }
        // Also hook getExtension + getShaderPrecisionFormat — fingerprinters
        // use available extensions list as a fingerprint vector.
        const ogExt=WebGLRenderingContext.prototype.getExtension;
        WebGLRenderingContext.prototype.getExtension=function(name){
            // Always return the extension object (or null) from the real impl —
            // we don't want to break rendering, just be consistent.
            return ogExt.call(this,name);
        };
    }catch(e){}
    try{
        // ── AudioContext fingerprint noise (Item 8) ──
        // Real audio fingerprinting (fingerprintjs-style) reads raw PCM samples
        // via AudioBuffer.getChannelData()/copyFromChannel() after rendering an
        // OfflineAudioContext oscillator, NOT just the analyser FFT data. Patch
        // ALL the common read paths with tiny, deterministic (seed-based) noise
        // so the same fingerprint always yields the same noisy result (stable
        // per-session) but a different seed yields a different, unique result.
        const _as=_AUDIO_SEED_;
        function _noise(i){ return (((_as>>(i%16))&0xF)-8) * 0.0000008; }

        const ogf=AnalyserNode.prototype.getFloatFrequencyData;
        AnalyserNode.prototype.getFloatFrequencyData=function(a){ogf.call(this,a);for(let i=0;i<a.length;i++){a[i]+=((_as>>(i%12))&0x7)*0.0001-0.0003;}};

        const ogb=AnalyserNode.prototype.getByteFrequencyData;
        if(ogb){AnalyserNode.prototype.getByteFrequencyData=function(a){ogb.call(this,a);for(let i=0;i<a.length;i++){const n=((_as>>(i%10))&0x3)-1;a[i]=Math.max(0,Math.min(255,a[i]+n));}};}

        const ogt=AnalyserNode.prototype.getByteTimeDomainData;
        if(ogt){AnalyserNode.prototype.getByteTimeDomainData=function(a){ogt.call(this,a);for(let i=0;i<a.length;i++){const n=((_as>>(i%10))&0x3)-1;a[i]=Math.max(0,Math.min(255,a[i]+n));}};}

        if(typeof AudioBuffer!=='undefined'&&AudioBuffer.prototype.getChannelData){
            const oggcd=AudioBuffer.prototype.getChannelData;
            AudioBuffer.prototype.getChannelData=function(channel){
                const data=oggcd.call(this,channel);
                try{
                    for(let i=0;i<data.length;i+=Math.max(1,Math.floor(data.length/500))){
                        data[i]=data[i]+_noise(i);
                    }
                }catch(e){}
                return data;
            };
        }

        if(typeof AudioBuffer!=='undefined'&&AudioBuffer.prototype.copyFromChannel){
            const ogcfc=AudioBuffer.prototype.copyFromChannel;
            AudioBuffer.prototype.copyFromChannel=function(dest,channel,startInChannel){
                ogcfc.call(this,dest,channel,startInChannel||0);
                try{
                    for(let i=0;i<dest.length;i+=Math.max(1,Math.floor(dest.length/500))){
                        dest[i]=dest[i]+_noise(i);
                    }
                }catch(e){}
            };
        }
    }catch(e){}
    try{
        if(navigator.getBattery){
            const ogb=navigator.getBattery.bind(navigator);
            navigator.getBattery=function(){
                return ogb().then(function(rb){
                    return{level:_BL_,charging:_BCH_,chargingTime:_BCT_,dischargingTime:_BDT_,addEventListener:function(){},removeEventListener:function(){},onlevelchange:null,onchargingchange:null};
                }).catch(function(){
                    return Promise.resolve({level:_BL_,charging:_BCH_,chargingTime:Infinity,dischargingTime:7200,addEventListener:function(){},removeEventListener:function(){}});
                });
            };
        }
    }catch(e){}
    try{
        if(!navigator.connection){Object.defineProperty(navigator,'connection',{get:()=>({effectiveType:'_CT_',downlink:_CDN_,rtt:_CRTT_,saveData:false,type:'_CTYPE_'})});}
        else{Object.defineProperty(navigator.connection,'effectiveType',{get:()=>'_CT_'});Object.defineProperty(navigator.connection,'downlink',{get:()=>_CDN_});Object.defineProperty(navigator.connection,'rtt',{get:()=>_CRTT_});}
    }catch(e){}
    try{if(window.speechSynthesis){const ogv=speechSynthesis.getVoices.bind(speechSynthesis);speechSynthesis.getVoices=function(){const v=ogv();return v.slice(0,_SPEECH_);};}}catch(e){}
__PLUGINS_BLOCK__
__SENSOR_BLOCK__
    try{
        var _isFbIab=/FBAN|FBAV|FB_IAB|Instagram/i.test(navigator.userAgent);
        var _isRealFF=/Firefox\//.test(navigator.userAgent)&&!/Seamonkey\//.test(navigator.userAgent);
        var _isRealSaf=/Safari\//.test(navigator.userAgent)&&!/Chrome\//.test(navigator.userAgent)&&!/CriOS\//.test(navigator.userAgent);
        if(!_isFbIab&&!_isRealFF&&!_isRealSaf){
        if(!window.chrome)window.chrome={};
        if(!window.chrome.runtime)window.chrome.runtime={OnInstalledReason:{CHROME_UPDATE:'chrome_update',INSTALL:'install',UPDATE:'update'},OnRestartReason:{APP_UPDATE:'app_update',OS_UPDATE:'os_update',PERIODIC:'periodic'},PlatformOs:{ANDROID:'android',CROS:'cros',LINUX:'linux',MAC:'mac',WIN:'win'},connect:function(){return{onDisconnect:{addListener:function(){}},onMessage:{addListener:function(){}}}},sendMessage:function(){},id:undefined};
        if(!window.chrome.loadTimes)window.chrome.loadTimes=function(){return{commitLoadTime:Math.floor(Date.now()/1000)-_LT_COMMIT_,connectionInfo:'h2',finishDocumentLoadTime:Math.floor(Date.now()/1000)-_LT_FDOC_,finishLoadTime:Math.floor(Date.now()/1000)-_LT_FINISH_,firstPaintTime:Math.floor(Date.now()/1000)-_LT_PAINT_,navigationType:'Other',npnNegotiatedProtocol:'h2',requestTime:Math.floor(Date.now()/1000)-_LT_REQ_,startLoadTime:Math.floor(Date.now()/1000)-_LT_REQ_,wasAlternateProtocolAvailable:false,wasFetchedViaSPDY:true,wasNpnNegotiated:true};};
        if(!window.chrome.csi)window.chrome.csi=function(){return{startE:Date.now()-_CSI_START_,onloadT:Date.now()-_CSI_ONLOAD_,pageT:Math.random()*5000+1000,tran:15};};
        if(!window.chrome.app)window.chrome.app={isInstalled:false,InstallState:{DISABLED:'disabled',INSTALLED:'installed',NOT_INSTALLED:'not_installed'},RunningState:{CANNOT_RUN:'cannot_run',READY_TO_RUN:'ready_to_run',RUNNING:'running'},getDetails:function(){return null;},getIsInstalled:function(){return false;}};
        }
    }catch(e){}
    try{if(navigator.permissions){const oq=navigator.permissions.query;navigator.permissions.query=function(p){if(p&&p.name==='notifications')return Promise.resolve({state:'default',onchange:null});return oq.call(navigator.permissions,p);};}}catch(e){}
    try{delete window.__playwright__script;}catch(e){}
    try{delete window.__pwInitScripts;}catch(e){}
    try{delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;}catch(e){}
    try{delete window.cdc_adoQpoasnfa76pfcZLmcfl_Promise;}catch(e){}
    try{const ocw=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'contentWindow');if(ocw){Object.defineProperty(HTMLIFrameElement.prototype,'contentWindow',{get:function(){const w=ocw.get.call(this);if(w){try{delete w.cdc_adoQpoasnfa76pfcZLmcfl_Array;}catch(e){}try{delete w.cdc_adoQpoasnfa76pfcZLmcfl_Promise;}catch(e){}}return w;}});}}catch(e){}
    try{Object.defineProperty(window,'opener',{get:()=>null,configurable:true});}catch(e){}
    try{const pn=Performance.prototype.now;let lv=0;Performance.prototype.now=function(){let v=pn.call(this);if(v-lv<0.1)v=lv+0.1+Math.random()*0.5;lv=v;return v;};}catch(e){}
    // ── FIX 3: performance.memory spoofing (Chrome-specific fingerprint) ──
    // Real Chrome exposes performance.memory with jsHeapSizeLimit, totalJSHeapSize,
    // usedJSHeapSize. Anti-fraud scripts use these values as fingerprint vectors.
    // We inject plausible values that look like a real Chrome session.
    try{
        if(window.performance && !performance.memory){
            const _memBase = _HC_ * 128;  // scale with hardware concurrency
            Object.defineProperty(performance, 'memory', {
                get: () => ({
                    jsHeapSizeLimit: _memBase * 1024 * 1024,
                    totalJSHeapSize: Math.floor(_memBase * 0.4 * 1024 * 1024 * (0.8 + Math.random() * 0.3)),
                    usedJSHeapSize: Math.floor(_memBase * 0.15 * 1024 * 1024 * (0.7 + Math.random() * 0.5))
                }),
                configurable: true
            });
        } else if(window.performance && performance.memory){
            // If memory already exists (real Chrome), just keep it — don't touch
        }
    }catch(e){}
    // ── FIX 4: Performance Navigation Timing — hide proxy timing leaks ──
    // performance.getEntriesByType('navigation') exposes connectStart, connectEnd,
    // domainLookupEnd, requestStart, responseStart, etc. With a proxy, the connect
    // time and DNS time will be different from a direct connection — a proxy
    // detection signal. We patch the PerformanceNavigationTiming entries to show
    // plausible direct-connection-like timing values.
    try{
        const _origGetEntries = performance.getEntries.bind(performance);
        const _origGetEntriesByType = performance.getEntriesByType.bind(performance);
        const _origGetEntriesByName = performance.getEntriesByName.bind(performance);
        // Generate plausible timing offsets (in ms) — looks like direct connection
        const _navStart = performance.timeOrigin || Date.now();
        function _patchEntry(entry) {
            if (!entry || entry.entryType !== 'navigation') return entry;
            try {
                // Build plausible values: DNS ~0-5ms, connect ~5-40ms, TTFB ~20-150ms
                const _dns = Math.random() * 5;
                const _connect = 5 + Math.random() * 35;
                const _ttfb = 20 + Math.random() * 130;
                const _domParse = 10 + Math.random() * 50;
                const _load = _ttfb + _domParse + Math.random() * 200;
                Object.defineProperty(entry, 'connectStart', {get: () => _navStart + _dns, configurable: true});
                Object.defineProperty(entry, 'connectEnd', {get: () => _navStart + _dns + _connect, configurable: true});
                Object.defineProperty(entry, 'domainLookupStart', {get: () => _navStart, configurable: true});
                Object.defineProperty(entry, 'domainLookupEnd', {get: () => _navStart + _dns, configurable: true});
                Object.defineProperty(entry, 'requestStart', {get: () => _navStart + _dns + _connect, configurable: true});
                Object.defineProperty(entry, 'responseStart', {get: () => _navStart + _dns + _connect + _ttfb, configurable: true});
                Object.defineProperty(entry, 'responseEnd', {get: () => _navStart + _dns + _connect + _ttfb + 5, configurable: true});
                Object.defineProperty(entry, 'domContentLoadedEventStart', {get: () => _navStart + _dns + _connect + _ttfb + _domParse, configurable: true});
                Object.defineProperty(entry, 'domContentLoadedEventEnd', {get: () => _navStart + _dns + _connect + _ttfb + _domParse + 2, configurable: true});
                Object.defineProperty(entry, 'loadEventStart', {get: () => _navStart + _load, configurable: true});
                Object.defineProperty(entry, 'loadEventEnd', {get: () => _navStart + _load + 1, configurable: true});
                Object.defineProperty(entry, 'fetchStart', {get: () => _navStart, configurable: true});
                Object.defineProperty(entry, 'secureConnectionStart', {get: () => _navStart + _dns + _connect * 0.5, configurable: true});
            } catch(e) {}
            return entry;
        }
        performance.getEntriesByType = function(type) {
            const entries = _origGetEntriesByType(type);
            if (type === 'navigation' || type === 'resource') {
                return entries.map(_patchEntry);
            }
            return entries;
        };
        performance.getEntries = function() {
            return _origGetEntries().map(_patchEntry);
        };
        performance.getEntriesByName = function(name, type) {
            const entries = _origGetEntriesByName(name, type);
            return entries.map(_patchEntry);
        };
    }catch(e){}
    try{if(!_IS_FIREFOX_){
        const uad={brands:_BRANDS_,mobile:_MOBILE_,platform:_SCH_P_,getHighEntropyValues:function(h){return Promise.resolve({architecture:_ARCH_,bitness:'_BITNESS_',brands:_BRANDS_,fullVersionList:_FVL_,mobile:_MOBILE_,model:'_MODEL_',platform:_SCH_P_,platformVersion:_PV_,uaFullVersion:'_CHROME_VER_.0.0.0'});},toJSON:function(){return{brands:_BRANDS_,mobile:_MOBILE_,platform:_SCH_P_};}};
        Object.defineProperty(navigator,'userAgentData',{get:()=>uad,configurable:true});
    }}catch(e){}
    // NOTE: WebRTC ICE candidate spoofing is handled by bot_engine.py's
    // init script (added AFTER this stealth script). That script intercepts
    // candidate strings and replaces real IPs (IPv4+IPv6) with proxy IP.
    // DO NOT clear iceServers here — empty iceServers is itself a bot signal
    // (real browsers never have empty iceServers) and it prevents the
    // ICE candidate interceptor from ever firing (no candidates = no spoof).
    try{
        // ── toString masking — prevent Function.prototype.toString detection ──
        // Detectors check if overridden functions still return "native code"
        // when toString() is called. We patch toString to return the original
        // native code string for our overridden functions.
        const _nativeToString = Function.prototype.toString;
        const _overrides = new WeakSet();
        const _makeNative = function(fn) {
            try { _overrides.add(fn); } catch(e) {}
            return fn;
        };
        Function.prototype.toString = function() {
            if (_overrides.has(this)) {
                return 'function ' + (this.name||'') + '() { [native code] }';
            }
            return _nativeToString.call(this);
        };
        _overrides.add(Function.prototype.toString);
    }catch(e){}
    try{
        // ── Font fingerprint consistency (Item: font mismatch) ──
        // A page claiming "Android" but reporting Windows fonts (Segoe UI,
        // Calibri) via document.fonts.check() is one of the most reliable
        // "fake mobile" signals. We make the declared device font list
        // check as installed, and known foreign-OS fonts check as NOT installed.
        const _DEVICE_FONTS_ = _FONTS_LIST_.map(f=>f.toLowerCase());
        const _FOREIGN_FONTS_ = ['segoe ui','calibri','cambria','candara','consolas','constantia','corbel','tahoma','verdana','trebuchet ms','ms gothic','sf pro','sf pro display','sf pro text','helvetica neue','san francisco','roboto','noto sans','droid sans mono'].filter(f=>!_DEVICE_FONTS_.includes(f));
        if(document.fonts&&document.fonts.check){
            const origCheck=document.fonts.check.bind(document.fonts);
            document.fonts.check=function(font,text){
                try{
                    const m=/["']([^"']+)["']|(\S+)$/.exec(font.split(',')[0].trim());
                    const name=(m&&(m[1]||m[2])||'').toLowerCase();
                    if(_DEVICE_FONTS_.includes(name))return true;
                    if(_FOREIGN_FONTS_.includes(name))return false;
                    if(['serif','sans-serif','monospace','cursive','fantasy','system-ui'].includes(name))return true;
                }catch(e){}
                return origCheck(font,text);
            };
        }
    }catch(e){}
})();"""

    # Now do all replacements
    script = template
    script = script.replace("__UA__", json.dumps(ua))
    script = script.replace("'_PLATFORM_'", json.dumps(platform))
    script = script.replace("_LANGS_", languages)
    script = script.replace("'_TZ_'", repr(timezone))
    # IMPORTANT: replace _TZ_OFFSET_HOURS_ BEFORE _TZ_OFFSET_ (substring overlap)
    script = script.replace("_TZ_OFFSET_HOURS_", str(tz_offset_hours))
    script = script.replace("_TZ_OFFSET_", str(tz_offset_min))
    script = script.replace("_GEO_LAT_", str(round(geo_lat, 6)))
    script = script.replace("_GEO_LON_", str(round(geo_lon, 6)))
    script = script.replace("_GEO_ACC_", str(geo_acc))
    script = script.replace("'_LOCALE_'", repr(locale))
    script = script.replace("_SW_", str(sw))
    script = script.replace("_SH_", str(sh))
    script = script.replace("_AW_", str(aw))
    script = script.replace("_AH_", str(ah))
    script = script.replace("_CD_", str(cd))
    script = script.replace("_PR_", str(pr))
    # innerHeight must EXACTLY match the Playwright viewport height
    _ih = fp.get("viewport_height", int(sh * 0.72))
    script = script.replace("_IH_", str(_ih))
    script = script.replace("'_ORIENT_'", repr(orientation))
    script = script.replace("_HC_", str(hc))
    script = script.replace("_DM_", str(dm))
    script = script.replace("_MTP_", str(mtp))
    script = script.replace("_DNT_", dnt)
    script = script.replace("_MOBILE_", mobile_str)
    script = script.replace("_CANVAS_SEED_", str(canvas_seed))
    script = script.replace("_AUDIO_SEED_", str(audio_seed))

    # ── v5.1: Firefox-specific anti-detection ──
    # Firefox doesn't have window.chrome or navigator.userAgentData
    # Real Firefox has different properties — ensure we DON'T inject Chrome ones
    if is_firefox:
        firefox_stealth = """
            // ── Firefox-specific anti-detection ──
            // Real Firefox: NO window.chrome, NO navigator.userAgentData
            // If somehow injected (by older stealth), remove them
            try {
                if (window.chrome && !navigator.userAgentData) {
                    // This is Firefox — remove fake chrome object if present
                    // But only if we're actually on Firefox
                    if (/Firefox\//.test(navigator.userAgent)) {
                        delete window.chrome;
                    }
                }
            } catch(e) {}

            // Firefox navigator.webdriver fix
            try {
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                delete navigator.__proto__.webdriver;
            } catch(e) {}

            // Firefox: ensure navigator.installTrigger exists (Firefox-specific API)
            // Real Firefox has navigator.installTrigger — bots don't
            if (!navigator.installTrigger) {
                try {
                    Object.defineProperty(navigator, 'installTrigger', {
                        get: () => ({install: () => {}, startSoftwareUpdate: () => {}})
                    });
                } catch(e) {}
            }

            // Firefox: ensure navigator.mozIsTextFieldVisible (Firefox internal)
            // Real Firefox has this — detect via feature
            if (typeof navigator.mozIsTextFieldVisible === 'undefined') {
                try {
                    Object.defineProperty(navigator, 'mozIsTextFieldVisible', {get: () => false});
                } catch(e) {}
            }

            // Firefox: Style/Performance API differences
            // Real Firefox reports different performance.timing entries
            try {
                if (!window.performance) {
                    window.performance = {timing: {}, navigation: {type: 0}};
                }
            } catch(e) {}

            // Firefox: ensure document.fonts (FontFaceSet) works
            try {
                if (!document.fonts) {
                    document.fonts = {ready: Promise.resolve(), values: () => [], check: () => true, load: () => Promise.resolve()};
                }
            } catch(e) {}

            // Firefox: navigator.doNotTrack
            try {
                Object.defineProperty(navigator, 'doNotTrack', {get: () => 'unspecified'});
            } catch(e) {}
        """
        script += firefox_stealth

    # -- Safari-specific anti-detection (real WebKit engine) --
    # With playwright.webkit, the engine is real WebKit, so most Safari
    # properties are natively correct. We add a few that WebKit Playwright
    # build might not expose.
    if is_safari:
        safari_stealth = """
            // -- Safari-specific anti-detection --
            // Real WebKit engine already handles: no window.chrome, no
            // userAgentData, JavaScriptCore JS engine, correct TLS/JA3.
            // These patches handle Playwright WebKit build gaps.

            // Safari has window.safari.pushNotification (desktop Safari)
            try {
                if (!window.safari) {
                    Object.defineProperty(window, 'safari', {
                        get: () => ({
                            pushNotification: {
                                permission: 'default',
                                requestPermission: function() { return Promise.resolve('denied'); }
                            }
                        }),
                        configurable: true
                    });
                }
            } catch(e) {}

            // Safari: ensure ApplePaySession stub exists
            try {
                if (typeof ApplePaySession === 'undefined') {
                    window.ApplePaySession = function() {};
                    window.ApplePaySession.canMakePayments = () => false;
                    window.ApplePaySession.supportsVersion = () => false;
                }
            } catch(e) {}

            // Safari: navigator.webdriver should be undefined
            try {
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                delete navigator.__proto__.webdriver;
            } catch(e) {}
        """
        script += safari_stealth

    # ── v5.0 EXTRA: Additional 2026 anti-detection measures ──────────────
    extra_2026 = """
        // ── v5.0: Performance API leak fix ──
        // Playwright adds timing entries that real browsers don't have
        try {
            const origGetEntries = PerformanceObserver.prototype.observe;
            // Some anti-bot scripts check performance.getEntriesByType('resource')
            // for CDP-related entries
            const origGetEntriesByType = performance.getEntriesByType.bind(performance);
            performance.getEntriesByType = function(type) {
                const entries = origGetEntriesByType(type);
                if (type === 'resource') {
                    return entries.filter(e => !e.name.includes('devtools') && !e.name.includes('favicon.ico'));
                }
                return entries;
            };
        } catch(e) {}

        // ── v5.0: Fix navigator.languages (must be array) ──
        // Some setups report string instead of array
        try {
            if (typeof navigator.languages === 'string') {
                Object.defineProperty(navigator, 'languages', {get: () => [navigator.language, 'en']});
            }
        } catch(e) {}

        // ── v5.0: Fix navigator.connection (Network Information API) ──
        // Real Chrome has navigator.connection with effectiveType, rtt, downlink
        // Some automated browsers show undefined or wrong values
        try {
            if (!navigator.connection) {
                Object.defineProperty(navigator, 'connection', {
                    get: () => ({effectiveType: '4g', rtt: 50, downlink: 10, saveData: false})
                });
            }
        } catch(e) {}

        // ── v5.0: Fix window.devicePixelRatio ──
        // Must match fingerprint — some setups report 1.0 when should be 1.25
        // (already handled in main stealth script, but double-check)

        // ── v5.0: Fix navigator.getBattery() ──
        // Real Chrome returns a Promise with level, charging, chargingTime, dischargingTime
        if (navigator.getBattery) {
            const origBattery = navigator.getBattery.bind(navigator);
            navigator.getBattery = function() {
                return origBattery().then(b => {
                    // Ensure all properties exist
                    if (b.level === undefined) b.level = 0.75;
                    if (b.charging === undefined) b.charging = false;
                    return b;
                });
            };
        }

        // ── v5.0: Fix navigator.onLine — must be true ──
        // Some headless setups show false
        try {
            Object.defineProperty(navigator, 'onLine', {get: () => true});
        } catch(e) {}

        // ── v5.0: Remove Playwright/Automation-related properties ──
        try {
            // Remove any __playwright or __pw_ properties
            Object.getOwnPropertyNames(window).forEach(p => {
                if (p.startsWith('__playwright') || p.startsWith('__pw_') || p.startsWith('_cdp_')) {
                    try { delete window[p]; } catch(e) {}
                }
            });
        } catch(e) {}

        // ── v1.85: TLS fingerprint note ──
        // Chromium's BoringSSL TLS stack = same as real Chrome.
        // Chrome 136/137/138 all share the same JA3/JA4 hash (cipher suites
        // don't change between minor versions). FB IAB on Android uses
        // Chromium WebView = same BoringSSL = same JA3. So our TLS fingerprint
        // is authentic for ALL our browser types (Chrome, Edge, FB IAB).
        // No JS-level override needed — TLS is at the network layer.

        // ── v5.0: Fix document.hasFocus() — must return true ──
        // Real browser tab in focus returns true
        try {
            document.hasFocus = () => true;
        } catch(e) {}
    """
    script += extra_2026
    script = script.replace("'_WV_'", repr(wv))
    script = script.replace("'_WR_'", repr(wr))
    script = script.replace("_BL_", str(bl))
    script = script.replace("_BCH_", bch)
    script = script.replace("_BCT_", bct)
    script = script.replace("_BDT_", bdt)
    script = script.replace("'_CT_'", repr(ct))
    script = script.replace("_CDN_", str(cdn))
    script = script.replace("_CRTT_", str(crtt))
    script = script.replace("'_CTYPE_'", repr(ctype))
    script = script.replace("_SPEECH_", str(speech_count))
    script = script.replace("_FONTS_LIST_", fonts_json)
    script = script.replace("__PLUGINS_BLOCK__", plugins_js)
    script = script.replace("__SENSOR_BLOCK__", sensor_js)
    script = script.replace("_LT_COMMIT_", str(lt_commit))
    script = script.replace("_LT_FDOC_", str(lt_finish_doc))
    script = script.replace("_LT_FINISH_", str(lt_finish))
    script = script.replace("_LT_PAINT_", str(lt_first_paint))
    script = script.replace("_LT_REQ_", str(lt_request))
    script = script.replace("_CSI_START_", str(csi_start))
    script = script.replace("_CSI_ONLOAD_", str(csi_onload))
    script = script.replace("_IS_FIREFOX_", str(is_firefox).lower())
    script = script.replace("_BRANDS_", brands)
    script = script.replace("_FVL_", fvl)
    script = script.replace("_SCH_P_", sch_p if 'sch_p' in dir() else '""')
    script = script.replace("_ARCH_", arch if 'arch' in dir() else '"x86"')
    script = script.replace("_MODEL_", dm_model)
    script = script.replace("_PV_", pv)
    script = script.replace("_CHROME_VER_", chrome_ver)
    # LEAK 3 fix: real Android Chrome returns bitness: "" (empty), not "64"
    script = script.replace("_BITNESS_", '""' if is_mobile else '"64"')
    # LEAK 4 fix: navigator.standalone is iOS Safari only. Android/Desktop = false
    _standalone = "true" if fp.get("is_ios", False) else "false"
    script = script.replace("_STANDALONE_", _standalone)

    # v13.7.4 — Override document.referrer to match HTTP Referer header
    if referer_url:
        ref_escaped = json.dumps(referer_url)
        ref_override = (
            "try{Object.defineProperty(document,'referrer',"
            "{get:function(){return " + ref_escaped + ";},configurable:true});"
            "}catch(e){}"
        )
        script += ref_override

    # v13.7.5 — Firefox/Safari/FB IAB: remove ALL Chrome-specific APIs
    # If we claim Firefox/Safari/Facebook in the UA but have
    # navigator.userAgentData, window.chrome, or chrome.runtime,
    # ad networks detect the mismatch.
    # v13.7.6 — FB IAB: Meta's embedded Chromium strips userAgentData.
    #   Without stripping, Adsterra sees "Google Chrome" in userAgentData
    #   BEFORE checking UA for FBAN → classifies as Chrome, not Facebook.
    if is_firefox or is_safari or fp.get("is_fb_iab", False):
        ff_safari_strip = (
            "try{delete navigator.userAgentData;}catch(e){}"
            "try{if(window.chrome){delete window.chrome;}}catch(e){}"
            "try{if(window.chrome&&window.chrome.runtime){"
            "delete window.chrome.runtime;}}catch(e){}"
            "try{Object.defineProperty(navigator,'userAgentData',"
            "{get:function(){return undefined;},configurable:true});}catch(e){}"
            # Firefox doesn't have chrome.csi or chrome.loadTimes
            "try{if(window.chrome&&window.chrome.csi){"
            "delete window.chrome.csi;}}catch(e){}"
            "try{if(window.chrome&&window.chrome.loadTimes){"
            "delete window.chrome.loadTimes;}}catch(e){}"
        )
        script += ff_safari_strip

    return script
