#!/bin/bash
# ════════════════════════════════════════════════════════════════════
# Visitor Bot v5.1 — Server Setup Script
# Installs: Real Chrome, Android fonts, Xvfb, Python deps
#           + ALL Playwright engines (Chromium + Firefox + WebKit)
# Run once on a fresh server: bash setup.sh
# ════════════════════════════════════════════════════════════════════

set -e

echo "=========================================="
echo "  Visitor Bot v5.1 — Server Setup"
echo "  Engines: Chromium + Firefox + WebKit"
echo "=========================================="

# ── 1. Install Real Google Chrome ──
echo ""
echo "[1/6] Installing Google Chrome..."
if ! command -v google-chrome &> /dev/null; then
    wget -q -O /tmp/chrome.deb https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb 2>/dev/null || true
    if [ -f /tmp/chrome.deb ]; then
        apt-get install -y /tmp/chrome.deb 2>/dev/null || dpkg -i /tmp/chrome.deb 2>/dev/null || true
        apt-get install -f -y 2>/dev/null || true
        echo "  OK Google Chrome installed"
    else
        echo "  WARN Could not download Chrome — install manually if needed"
    fi
else
    echo "  OK Google Chrome already installed"
fi

# ── 2. Install Xvfb (virtual display for headed mode) ──
echo ""
echo "[2/6] Installing Xvfb (virtual display)..."
if ! command -v Xvfb &> /dev/null; then
    apt-get update -qq && apt-get install -y -qq xvfb 2>/dev/null || true
    echo "  OK Xvfb installed"
else
    echo "  OK Xvfb already installed"
fi

# ── 3. Install Android Fonts (CRITICAL for authentic rendering) ──
echo ""
echo "[3/6] Installing Android fonts (Roboto, Noto Sans)..."
FONT_DIR="/usr/local/share/fonts/android-emulation"
mkdir -p "$FONT_DIR"

download_font() {
    local url="$1"
    local dest="$2"
    if [ ! -f "$dest" ]; then
        wget -q -O "$dest" "$url" 2>/dev/null && echo "  OK $(basename $dest)" || echo "  WARN Failed: $(basename $dest)"
    else
        echo "  OK $(basename $dest) (already exists)"
    fi
}

echo "  Downloading Roboto fonts..."
download_font "https://github.com/googlefonts/roboto-3-classic/raw/main/src/hinted/Roboto-Regular.ttf" "$FONT_DIR/Roboto-Regular.ttf"
download_font "https://github.com/googlefonts/roboto-3-classic/raw/main/src/hinted/Roboto-Bold.ttf" "$FONT_DIR/Roboto-Bold.ttf"
download_font "https://github.com/googlefonts/roboto-3-classic/raw/main/src/hinted/Roboto-Medium.ttf" "$FONT_DIR/Roboto-Medium.ttf"
download_font "https://github.com/googlefonts/roboto-3-classic/raw/main/src/hinted/Roboto-Light.ttf" "$FONT_DIR/Roboto-Light.ttf"
download_font "https://github.com/googlefonts/roboto-3-classic/raw/main/src/hinted/Roboto-Italic.ttf" "$FONT_DIR/Roboto-Italic.ttf"

echo "  Downloading Noto Sans fonts..."
download_font "https://github.com/notofonts/notofonts.github.io/raw/main/fonts/NotoSans/hinted/ttf/NotoSans-Regular.ttf" "$FONT_DIR/NotoSans-Regular.ttf"
download_font "https://github.com/notofonts/notofonts.github.io/raw/main/fonts/NotoSans/hinted/ttf/NotoSans-Bold.ttf" "$FONT_DIR/NotoSans-Bold.ttf"

fc-cache -f "$FONT_DIR" 2>/dev/null || true
echo "  OK Font cache refreshed"

if fc-list | grep -qi roboto; then
    echo "  OK Roboto fonts detected by fontconfig"
else
    echo "  WARN Roboto not detected — canvas font rendering may not match Android"
fi

# ── 4. Install Python dependencies ──
echo ""
echo "[4/6] Installing Python dependencies..."
pip install -r requirements.txt 2>/dev/null || pip3 install -r requirements.txt 2>/dev/null || true
echo "  OK Python dependencies installed"

# ── 5. Install Playwright — ALL THREE engines ──
echo ""
echo "[5/6] Installing Playwright browser engines..."

echo "  [a] Chromium (Chrome, Edge, Samsung Internet)..."
python3 -m playwright install chromium 2>/dev/null || python -m playwright install chromium 2>/dev/null || true

echo "  [b] Firefox (real Gecko engine)..."
python3 -m playwright install firefox 2>/dev/null || python -m playwright install firefox 2>/dev/null || true

echo "  [c] WebKit (real Safari/WebKit engine)..."
python3 -m playwright install webkit 2>/dev/null || python -m playwright install webkit 2>/dev/null || true

echo "  Installing system deps for all engines..."
python3 -m playwright install-deps 2>/dev/null || true

echo "  OK All Playwright engines installed"

# ── 6. Verify ──
echo ""
echo "[6/6] Verifying installation..."
python3 -c "
import playwright, flask, aiohttp
print('  OK playwright')
print('  OK flask')
print('  OK aiohttp')
try:
    import playwright_stealth
    print('  OK playwright-stealth')
except:
    print('  WARN playwright-stealth (optional)')
" 2>/dev/null || echo "  WARN Some packages may need checking"

# ── Summary ──
echo ""
echo "=========================================="
echo "  Setup Complete!"
echo ""
echo "  Engines installed:"
echo "    Chromium  -> Chrome, Edge, Samsung Internet"
echo "    Firefox  -> real Gecko engine"
echo "    WebKit   -> real Safari/WebKit engine"
echo ""
echo "  Next: bash start.sh  (starts Xvfb + dashboard)"
echo "=========================================="
