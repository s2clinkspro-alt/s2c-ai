@echo off
title Visitor Bot v213 Verified Scroll — Auto Setup & Start
color 0A

echo.
echo  ============================================
echo        VISITOR BOT v14.0 — AUTO SETUP
echo        Engines: Chromium + Firefox + WebKit
echo  ============================================
echo.

:: ── Check Python ──────────────────────────────────────────────
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Python not found. Installing Python 3.11...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%TEMP%\python-setup.exe' -UseBasicParsing"
    "%TEMP%\python-setup.exe" /quiet InstallAllUsers=1 PrependPath=1 Include_test=0
    del "%TEMP%\python-setup.exe"

    :: PATH refresh
    set "PATH=%PATH%;C:\Program Files\Python311;C:\Program Files\Python311\Scripts"
    echo [OK] Python installed.
) else (
    echo [OK] Python found.
)

:: ── Run setup.py (installs all deps + ALL Playwright engines) ──
echo.
echo [*] Running auto-setup (Chromium + Firefox + WebKit)...
echo [*] First run may take 5-10 minutes to download all browsers.
echo.
python setup.py
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Setup failed. Check errors above.
    echo [*] Try running manually: python setup_local.py
    pause
    exit /b 1
)

:: ── Start the bot ─────────────────────────────────────────────
echo.
echo [*] Starting Visitor Bot...
echo [*] Dashboard: http://localhost:5000
echo.
python app.py
pause
