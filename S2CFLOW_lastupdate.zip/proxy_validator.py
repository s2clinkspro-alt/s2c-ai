"""
Proxy Validator Module v6.0 — Full SOCKS Support + Multi-Endpoint

v6.0 fixes:
- CRITICAL: Now uses aiohttp_socks ProxyConnector for ALL proxy types
  (HTTP, SOCKS4, SOCKS5). Old v5.0 used aiohttp's built-in proxy= which
  ONLY supports HTTP CONNECT proxies — SOCKS4/SOCKS5 proxies were silently
  failing forever ("Validating..." stuck in UI).
- Authentication now properly embedded in ProxyConnector for SOCKS.
- Multi-endpoint IP detection: ip-api.com -> ipwho.is -> ipinfo.io fallback
  to avoid rate limiting when validating many proxies.
- Tests HTTPS connectivity through the proxy (critical for ad networks).
"""

import asyncio
import aiohttp
import time
from typing import Optional
from aiohttp_socks import ProxyType, ProxyConnector

# v10.10/v11.3: Known residential/mobile gateway provider hostnames. These ALL
# route through real carrier towers or home ISP backhaul (not datacenter
# fiber), so 12-20s round trips are NORMAL and healthy — not a dead proxy.
# Matching hostname (not username keyword) because real gateway usernames are
# opaque tokens like "sp1fua14s5" that never contain "mobile".
KNOWN_RESIDENTIAL_GATEWAYS = (
    "decodo", "smartproxy", "brightdata", "luminati", "oxylabs", "iproyal",
    "soax", "proxyrack", "nodemaven", "packetstream", "netnut", "geosurf",
    "proxyempire", "infatica", "rayobyte", "shifter", "storm",
    "superproxy", "brd-customer", "brd.superproxy",  # Bright Data's actual gateway domain
)


def _guess_proxy_timeout(proxy, base=10):
    """v10.10/v11.3: Residential/mobile carrier proxies need more time.
    Detects known gateway hostnames and gives them 22s instead of 10s."""
    try:
        host = (proxy.get("ip", "") or "").lower()
        blob = f"{host} {proxy.get('username','') or ''}".lower()
        if any(g in host for g in KNOWN_RESIDENTIAL_GATEWAYS):
            return base + 12  # 22s for known residential/mobile gateway
        if "mobile" in blob or "mob-" in blob or "4g" in blob or "5g" in blob:
            return base + 8  # 18s for explicit mobile keyword
    except Exception:
        pass
    return base

SOCKS_MAP = {
    "socks5": ProxyType.SOCKS5,
    "socks4": ProxyType.SOCKS4,
    "http": ProxyType.HTTP,
    "https": ProxyType.HTTP,
}


class ProxyValidator:
    """Validates and scores proxies — v6.0 with full SOCKS support."""

    def __init__(self, cache_duration=60):
        self.cache = {}
        self.cache_duration = cache_duration
        self._last_api_call = 0
        self._min_api_interval = 0.3

    async def validate_proxy(self, proxy, timeout=10):
        """Validate a single proxy — connectivity + IP type + quality score.
        v10.10/v11.3: One automatic retry on transient failures (cold NAT,
        slow carrier tunnel) before marking a fresh proxy as dead."""
        proxy_raw = proxy.get("raw", "")
        cache_key = proxy.get("unique_key") or proxy_raw

        if cache_key in self.cache:
            cached = self.cache[cache_key]
            if time.time() - cached["validated_at"] < self.cache_duration:
                return cached

        result = await self._validate_once(proxy, timeout, cache_key, skip_cache=True)

        # v10.10/v11.3: Retry once on transient failures (NOT on
        # datacenter/VPN which is a permanent disqualification).
        if not result.get("valid") and not result.get("datacenter") and not result.get("vpn"):
            # Cold-NAT / first-hop tower handshake commonly fails first attempt
            await asyncio.sleep(1.0)  # brief pause before retry
            result = await self._validate_once(proxy, timeout, cache_key, skip_cache=True)

        return result

    async def _validate_once(self, proxy, timeout, cache_key, skip_cache=False):
        """Single validation attempt — returns result dict (never raises)."""
        if not skip_cache and cache_key in self.cache:
            cached = self.cache[cache_key]
            if time.time() - cached["validated_at"] < self.cache_duration:
                return cached

        proxy_raw = proxy.get("raw", "")
        result = {
            "proxy": proxy_raw, "valid": False, "ip": proxy.get("ip"),
            "residential": False, "mobile": False, "datacenter": False, "vpn": False,
            "country": None, "country_code": None, "city": None, "isp": None, "asn": None,
            "quality_score": 0, "error": None, "validated_at": time.time(),
            "http_ok": False, "https_ok": False, "exit_ip": None,
        }

        proto = proxy.get("protocol", "http")
        ip = proxy.get("ip")
        port = proxy.get("port")
        username = proxy.get("username")
        password = proxy.get("password")

        if not ip or not port:
            result["error"] = "Invalid proxy format — missing IP or port"
            self.cache[cache_key] = result
            return result

        proxy_type = SOCKS_MAP.get(proto, ProxyType.HTTP)

        # Build ProxyConnector with auth
        try:
            connector_kwargs = {
                "proxy_type": proxy_type,
                "host": ip,
                "port": int(port),
                "rdns": True,
            }
            if username:
                connector_kwargs["username"] = username
                connector_kwargs["password"] = password or ""
            connector = ProxyConnector(**connector_kwargs)
        except Exception as e:
            result["error"] = f"Proxy connector error: {str(e)[:80]}"
            self.cache[cache_key] = result
            return result

        timeout_val = aiohttp.ClientTimeout(total=timeout)

        # Step 1+2: HTTP + HTTPS connectivity test through proxy
        # v11.6 FIX: many residential/mobile gateway providers (Bright Data
        # confirmed, likely others) inject their OWN self-signed certificate
        # into the chain for "SSL Analyzing"/traffic-inspection features on
        # residential zones. aiohttp's default strict cert verification then
        # fails every single HTTPS request through the proxy with
        # "CERTIFICATE_VERIFY_FAILED: self-signed certificate in certificate
        # chain" — even though the proxy is 100% alive and working (confirmed
        # via curl/AdsPower/real browsers, which don't hard-fail on this).
        # Since this is only a liveness/IP-type CHECK (not real traffic — the
        # actual ad-network visit happens through a real browser separately),
        # it's safe to skip cert verification here with ssl=False.
        proxy_status_codes = []
        try:
            async with aiohttp.ClientSession(connector=connector, timeout=timeout_val) as session:
                # HTTP test — get exit IP
                try:
                    async with session.get("http://httpbin.org/ip", ssl=False) as resp:
                        proxy_status_codes.append(resp.status)
                        if resp.status == 200:
                            data = await resp.json(content_type=None)
                            origin = data.get("origin", "")
                            if origin:
                                result["http_ok"] = True
                                result["exit_ip"] = origin.split(",")[0].strip()
                except: pass

                # HTTPS test — critical for ad networks. ssl=False bypasses
                # gateway-injected self-signed certs (see note above) without
                # weakening real ad-network traffic security at all, since
                # this connection is only used to confirm the proxy is alive.
                try:
                    async with session.get("https://api.ipify.org?format=json", ssl=False) as resp:
                        proxy_status_codes.append(resp.status)
                        if resp.status == 200:
                            data = await resp.json(content_type=None)
                            exit_ip = data.get("ip", "")
                            if exit_ip:
                                result["https_ok"] = True
                                if not result.get("exit_ip"):
                                    result["exit_ip"] = exit_ip
                except: pass

                # Fallback HTTP check if httpbin.org specifically misbehaves
                # (some providers/exit IPs get inconsistent ServerDisconnected
                # errors from httpbin.org's own backend while HTTPS to other
                # hosts works fine) — try a second lightweight HTTP-only
                # target before giving up on http_ok entirely.
                if not result["http_ok"]:
                    try:
                        async with session.get("http://ip-api.com/json", ssl=False) as resp:
                            proxy_status_codes.append(resp.status)
                            if resp.status == 200:
                                data = await resp.json(content_type=None)
                                q = data.get("query", "")
                                if q:
                                    result["http_ok"] = True
                                    if not result.get("exit_ip"):
                                        result["exit_ip"] = q
                    except: pass
        except Exception as e:
            err = str(e)[:80]
            if "socks" in err.lower():
                result["error"] = f"SOCKS connection failed: {err}"
            elif "timeout" in err.lower() or isinstance(e, asyncio.TimeoutError):
                result["error"] = "Timed out — proxy too slow or unreachable"
            else:
                result["error"] = f"Connection failed: {err}"
            self.cache[cache_key] = result
            return result

        # Must have at least HTTP working
        if not result["http_ok"] and not result["https_ok"]:
            # Give the user a specific, actionable reason based on the status
            # code the proxy actually returned (instead of a generic "dead").
            if 407 in proxy_status_codes:
                result["error"] = "407 Proxy Authentication Required — wrong username/password"
            elif 503 in proxy_status_codes:
                result["error"] = "503 from proxy provider — account likely expired, out of traffic, or wrong port"
            elif 429 in proxy_status_codes:
                result["error"] = "429 Too Many Requests — proxy provider is rate-limiting this account"
            elif proxy_status_codes:
                result["error"] = f"Proxy returned HTTP {proxy_status_codes[0]} — check credentials/plan with your provider"
            else:
                result["error"] = "Proxy is dead — no response (timeout or connection refused)"
            self.cache[cache_key] = result
            return result

        # HTTPS is critical for ad networks
        if not result["https_ok"]:
            result["error"] = "HTTP works but HTTPS tunneling failed — useless for ad networks"
            result["quality_score"] = 5
            self.cache[cache_key] = result
            return result

        # Step 3: IP type detection (using exit IP if available)
        check_ip = result.get("exit_ip") or ip
        ip_info = await self._detect_ip_type(check_ip)

        dc_unconfirmed = False
        if ip_info:
            result["ip"] = check_ip
            result["country"] = ip_info.get("country")
            result["country_code"] = ip_info.get("country_code")
            result["city"] = ip_info.get("city")
            result["isp"] = ip_info.get("isp")
            result["asn"] = ip_info.get("asn")
            result["residential"] = ip_info.get("residential", False)
            result["mobile"] = ip_info.get("mobile", False)
            result["datacenter"] = ip_info.get("datacenter", False)
            result["vpn"] = ip_info.get("vpn", False)

            # ── v14.7/14.8: corroborate before hard-reject ──
            # ip-api's "hosting" flag alone (or a single keyword match from
            # ipwho.is/ipinfo) is over-eager: it false-positives legit
            # residential proxies. Demand corroboration — hard provider
            # keywords in the ISP/ASN string, or a SECOND geo-IP source
            # agreeing — before the verdict counts as datacenter/VPN.
            if result["datacenter"] or result["vpn"]:
                isp_asn = f"{result.get('isp') or ''} {result.get('asn') or ''}".lower()
                HARD_KW = ("ovh", "hetzner", "linode", "vultr", "digitalocean",
                           "amazon aws", "aws", "azure", "google cloud",
                           "m247", "leaseweb", "choopa", "datacamp",
                           "packet", "contabo", "datacenter", "colocation")
                confirmed = any(kw in isp_asn for kw in HARD_KW)
                if not confirmed:
                    try:
                        confirmed = await self._corroborate_dc(check_ip, ip_info)
                    except Exception:
                        confirmed = False
                if confirmed:
                    pass  # genuine datacenter/VPN — fall through to hard reject below
                else:
                    # Unconfirmed single-source signal: override to usable
                    # residential for scoring, keep a small penalty so a
                    # genuinely mislabeled DC proxy still ranks a bit lower.
                    result["datacenter"] = False
                    result["vpn"] = False
                    result["residential"] = not result["mobile"]
                    dc_unconfirmed = True

        # Step 4: Quality scoring
        score = 0
        if result["http_ok"]: score += 15
        if result["https_ok"]: score += 15
        if result["residential"]: score += 45
        elif result["mobile"]: score += 55
        if result["datacenter"]: score -= 60
        if result["vpn"]: score -= 50
        if result["country"]: score += 10
        if not result["vpn"] and not result["datacenter"]: score += 15
        if result["residential"] and result["country"] and not result["vpn"]:
            score += 10
        if result["mobile"] and not result["datacenter"]:
            score += 5
        if dc_unconfirmed:
            score -= 10  # unconfirmed hosting/VPN signal — mild penalty only
        result["quality_score"] = max(0, min(100, score))

        # Hard reject datacenter/VPN
        if result["datacenter"] or result["vpn"]:
            result["valid"] = False
            result["error"] = "Datacenter/VPN IP — ad networks will detect this"
            result["quality_score"] = 0
        else:
            result["valid"] = True

        self.cache[cache_key] = result
        return result

    async def _corroborate_dc(self, ip, first_info):
        """v14.7: ask the OTHER geo-IP sources whether they also flag this
        IP as datacenter/VPN. Only corroboration from an independent source
        (different from the one that raised the initial flag) confirms a
        hard-reject verdict. Returns True only when a second source agrees.
        """
        source = (first_info or {}).get("source")
        checks = []
        # ip-api (only if it wasn't the first source)
        if source != "ip-api":
            async def _api():
                try:
                    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8)) as s:
                        async with s.get(f"http://ip-api.com/json/{ip}?fields=proxy,hosting") as r:
                            if r.status == 200:
                                d = await r.json()
                                return bool(d.get("proxy")) or bool(d.get("hosting"))
                except Exception:
                    pass
                return False
            checks.append(_api())
        # ipwho.is org keywords (only if it wasn't the first source)
        if source != "ipwho":
            async def _who():
                try:
                    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8)) as s:
                        async with s.get(f"https://ipwho.is/{ip}") as r:
                            if r.status == 200:
                                d = await r.json()
                                org = str((d.get("connection") or {}).get("org") or "").lower()
                                return any(kw in org for kw in ("datacenter", "hosting", "ovh", "hetzner", "amazon", "google cloud", "azure"))
                except Exception:
                    pass
                return False
            checks.append(_who())
        if not checks:
            return False
        results = await asyncio.gather(*checks, return_exceptions=True)
        for r in results:
            if r is True:
                return True
        return False

    async def _detect_ip_type(self, ip):
        """Detect IP type using multiple APIs with fallback."""
        # API 1: ip-api.com
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8)) as session:
                async with session.get(
                    f"http://ip-api.com/json/{ip}?fields=status,query,country,countryCode,city,isp,as,proxy,hosting,mobile"
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("status") == "success":
                            return {
                                "ip": data.get("query", ip),
                                "country": data.get("country"),
                                "country_code": data.get("countryCode"),
                                "city": data.get("city"),
                                "isp": data.get("isp"),
                                "asn": data.get("as"),
                                "proxy": data.get("proxy", False),
                                "hosting": data.get("hosting", False),
                                "mobile": data.get("mobile", False),
                                "residential": not data.get("hosting", False) and not data.get("proxy", False),
                                "datacenter": data.get("hosting", False),
                                "vpn": data.get("proxy", False),
                                "source": "ip-api",
                            }
        except: pass

        # API 2: ipwho.is
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8)) as session:
                async with session.get(f"https://ipwho.is/{ip}") as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("success"):
                            conn = data.get("connection", {})
                            org_lower = str(conn.get("org") or "").lower()
                            dc_kw = ["hosting", "cloud", "datacenter", "server", "ovh", "amazon", "google", "microsoft"]
                            is_dc = any(kw in org_lower for kw in dc_kw)
                            return {
                                "ip": ip, "country": data.get("country"),
                                "country_code": data.get("country_code"),
                                "city": data.get("city"),
                                "isp": conn.get("isp") or conn.get("org"),
                                "asn": None, "proxy": False, "hosting": is_dc,
                                "mobile": False, "residential": not is_dc,
                                "datacenter": is_dc, "vpn": False,
                                "source": "ipwho",
                            }
        except: pass

        # API 3: ipinfo.io
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8)) as session:
                async with session.get(f"https://ipinfo.io/{ip}/json") as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        org_lower = (data.get("org") or "").lower()
                        dc_kw = ["hosting", "cloud", "datacenter", "server", "ovh", "amazon", "google", "microsoft", "azure", "linode", "vultr", "hetzner"]
                        is_dc = any(kw in org_lower for kw in dc_kw)
                        return {
                            "ip": ip, "country": data.get("country"),
                            "country_code": data.get("country"),
                            "city": data.get("city"), "isp": data.get("org"),
                            "asn": None, "proxy": False, "hosting": is_dc,
                            "mobile": False, "residential": not is_dc,
                            "datacenter": is_dc, "vpn": False,
                            "source": "ipinfo",
                        }
        except: pass

        return None

    async def validate_batch(self, proxies, on_result=None):
        results = []
        for p in proxies:
            r = await self.validate_proxy(p)
            results.append(r)
            if on_result:
                on_result(r)
        return results

    def get_cached(self, proxy_raw):
        if proxy_raw in self.cache:
            cached = self.cache[proxy_raw]
            if time.time() - cached["validated_at"] < self.cache_duration:
                return cached
        return None

    def clear_cache(self):
        self.cache.clear()

    def get_stats(self):
        total = len(self.cache)
        valid = sum(1 for v in self.cache.values() if v.get("valid"))
        residential = sum(1 for v in self.cache.values() if v.get("residential"))
        datacenter = sum(1 for v in self.cache.values() if v.get("datacenter"))
        https_failed = sum(1 for v in self.cache.values() if v.get("http_ok") and not v.get("https_ok"))
        avg_score = sum(v.get("quality_score", 0) for v in self.cache.values()) / max(total, 1)
        return {
            "total_checked": total, "valid": valid,
            "residential": residential, "datacenter": datacenter,
            "https_tunnel_failed": https_failed,
            "avg_score": round(avg_score, 1),
        }




# ══════════════════════════════════════════════════════════════════════════════
# v13.6 — Fraud DB Checker (Ads Network Mode)
# Multi-API rotation: IPHub → Proxycheck.io → ip-api.com → ipinfo.io
# Daily limits: IPHub 1000 + Proxycheck 1000 + ip-api unlimited + ipinfo 50k/mo
# Total effective: ~3000-5000 reliable checks/day (free tier)
# ══════════════════════════════════════════════════════════════════════════════
import json as _json
from datetime import datetime as _datetime

_FRAUD_USAGE_FILE = "fraud_db_usage.json"

def _load_fraud_usage():
    """Load today's API usage counters from disk."""
    try:
        with open(_FRAUD_USAGE_FILE) as f:
            data = _json.load(f)
        today = _datetime.utcnow().strftime("%Y-%m-%d")
        if data.get("date") != today:
            return {"date": today, "iphub": 0, "proxycheck": 0, "ipapi": 0, "ipinfo": 0, "total": 0}
        return data
    except Exception:
        return {"date": _datetime.utcnow().strftime("%Y-%m-%d"), "iphub": 0, "proxycheck": 0, "ipapi": 0, "ipinfo": 0, "total": 0}

def _save_fraud_usage(usage):
    try:
        with open(_FRAUD_USAGE_FILE, "w") as f:
            _json.dump(usage, f)
    except Exception:
        pass

def get_fraud_db_usage():
    """Return current day usage stats for dashboard display."""
    u = _load_fraud_usage()
    daily_total = u.get("total", 0)
    limit_hit = daily_total >= 5000
    return {
        "iphub": u.get("iphub", 0),
        "proxycheck": u.get("proxycheck", 0),
        "ipapi": u.get("ipapi", 0),
        "ipinfo": u.get("ipinfo", 0),
        "total": daily_total,
        "limit_hit": limit_hit,
    }

class FraudDBChecker:
    """
    Real-time fraud database checker for Ads Network Mode.
    Rotates across 4 free APIs, tracks daily usage, auto-disables at 5000/day.
    Score threshold: proxy must score 90+ to be accepted.
    """

    # Daily per-API soft limits (stay conservative to avoid bans)
    _LIMITS = {"iphub": 900, "proxycheck": 900, "ipapi": 999999, "ipinfo": 1500}

    async def check(self, ip: str) -> dict:
        """
        Check IP against fraud databases.
        Returns: {
            "fraud_score": 0-100 (higher = more fraudulent),
            "is_proxy": bool,
            "is_vpn": bool,
            "risk": str ("clean"|"suspicious"|"blocked"),
            "api_used": str,
            "passed": bool  (True = safe to use, fraud_score <= 10)
        }
        """
        usage = _load_fraud_usage()
        daily_total = usage.get("total", 0)

        # Hard limit — 5000/day across all APIs
        if daily_total >= 5000:
            return {"fraud_score": -1, "is_proxy": False, "is_vpn": False,
                    "risk": "limit_reached", "api_used": "none", "passed": True,
                    "limit_hit": True}

        result = None

        # Priority 1: IPHub (most accurate for residential detection)
        if usage.get("iphub", 0) < self._LIMITS["iphub"]:
            result = await self._check_iphub(ip)
            if result:
                usage["iphub"] = usage.get("iphub", 0) + 1
                usage["total"] = daily_total + 1
                _save_fraud_usage(usage)
                return self._score_result(result, "iphub")

        # Priority 2: Proxycheck.io
        if usage.get("proxycheck", 0) < self._LIMITS["proxycheck"]:
            result = await self._check_proxycheck(ip)
            if result:
                usage["proxycheck"] = usage.get("proxycheck", 0) + 1
                usage["total"] = daily_total + 1
                _save_fraud_usage(usage)
                return self._score_result(result, "proxycheck")

        # Priority 3: ip-api.com (near-unlimited, less accurate for fraud)
        if usage.get("ipapi", 0) < self._LIMITS["ipapi"]:
            result = await self._check_ipapi(ip)
            if result:
                usage["ipapi"] = usage.get("ipapi", 0) + 1
                usage["total"] = daily_total + 1
                _save_fraud_usage(usage)
                return self._score_result(result, "ipapi")

        # Priority 4: ipinfo.io fallback
        if usage.get("ipinfo", 0) < self._LIMITS["ipinfo"]:
            result = await self._check_ipinfo(ip)
            if result:
                usage["ipinfo"] = usage.get("ipinfo", 0) + 1
                usage["total"] = daily_total + 1
                _save_fraud_usage(usage)
                return self._score_result(result, "ipinfo")

        # All APIs exhausted — pass through (don't block visits due to API limits)
        return {"fraud_score": 0, "is_proxy": False, "is_vpn": False,
                "risk": "api_exhausted", "api_used": "none", "passed": True}

    def _score_result(self, raw: dict, api: str) -> dict:
        """Convert raw API response to unified fraud score (0-100, higher=worse)."""
        fraud_score = 0
        is_proxy = raw.get("is_proxy", False)
        is_vpn = raw.get("is_vpn", False)
        is_hosting = raw.get("is_hosting", False)
        risk_level = raw.get("risk_level", 0)  # 0-100 where available

        if is_proxy: fraud_score += 60
        if is_vpn: fraud_score += 50
        # v14.9: ip-api's "hosting" flag alone is over-eager on legit
        # residential proxies (false positive) — a single unconfirmed
        # hosting signal is a soft hint now (8 pts), not a 40-pt kill.
        if is_hosting: fraud_score += 8
        if risk_level: fraud_score = max(fraud_score, int(risk_level))
        fraud_score = min(fraud_score, 100)

        # Convert to "health score" (100 - fraud = proxy health)
        health = 100 - fraud_score
        passed = health >= 90  # must be 90%+ health

        risk = "clean" if fraud_score <= 10 else ("suspicious" if fraud_score <= 40 else "blocked")
        return {
            "fraud_score": fraud_score,
            "health_score": health,
            "is_proxy": is_proxy,
            "is_vpn": is_vpn,
            "risk": risk,
            "api_used": api,
            "passed": passed,
        }

    async def _check_iphub(self, ip: str) -> dict:
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=6)) as s:
                async with s.get(f"http://v2.api.iphub.info/ip/{ip}",
                                 headers={"X-Key": "free"}) as r:
                    if r.status == 200:
                        d = await r.json()
                        # block=0: clean, block=1: proxy/vpn, block=2: unknown
                        block = d.get("block", 2)
                        return {
                            "is_proxy": block == 1,
                            "is_vpn": block == 1,
                            "is_hosting": False,
                            # v14.9: block=2 is IPHub's "uncertain" bucket,
                            # not a confirmed proxy verdict — soft (8), not 20.
                            "risk_level": 80 if block == 1 else (8 if block == 2 else 0),
                        }
        except Exception:
            pass
        return None

    async def _check_proxycheck(self, ip: str) -> dict:
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=6)) as s:
                async with s.get(f"https://proxycheck.io/v2/{ip}?vpn=1&risk=1") as r:
                    if r.status == 200:
                        d = await r.json()
                        ip_data = d.get(ip, {})
                        proxy_val = str(ip_data.get("proxy", "no")).lower()
                        vpn_val = str(ip_data.get("type", "")).lower()
                        risk = int(ip_data.get("risk", 0) or 0)
                        return {
                            "is_proxy": proxy_val == "yes",
                            "is_vpn": "vpn" in vpn_val,
                            "is_hosting": False,
                            "risk_level": risk,
                        }
        except Exception:
            pass
        return None

    async def _check_ipapi(self, ip: str) -> dict:
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=6)) as s:
                async with s.get(
                    f"http://ip-api.com/json/{ip}?fields=proxy,hosting,mobile"
                ) as r:
                    if r.status == 200:
                        d = await r.json()
                        return {
                            "is_proxy": d.get("proxy", False),
                            "is_vpn": d.get("proxy", False),
                            # v14.9: hosting flag alone is a soft signal here too
                            "is_hosting": d.get("hosting", False),
                            "risk_level": 70 if d.get("proxy") else (8 if d.get("hosting") else 0),
                        }
        except Exception:
            pass
        return None

    async def _check_ipinfo(self, ip: str) -> dict:
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=6)) as s:
                async with s.get(f"https://ipinfo.io/{ip}/json") as r:
                    if r.status == 200:
                        d = await r.json()
                        org = (d.get("org") or "").lower()
                        # v14.9: only EXPLICIT vpn/proxy keywords count as a
                        # hard is_proxy signal; generic hosting/cloud/server
                        # keywords are a soft is_hosting hint (scored at 8).
                        explicit = any(kw in org for kw in ["vpn", "proxy"])
                        generic = any(kw in org for kw in ["hosting","cloud","datacenter","server"])
                        return {
                            "is_proxy": explicit,
                            "is_vpn": "vpn" in org,
                            "is_hosting": generic and not explicit,
                            "risk_level": 50 if explicit else 0,
                        }
        except Exception:
            pass
        return None

# Global singleton
_fraud_checker = FraudDBChecker()

async def fraud_db_check(ip: str) -> dict:
    """Convenience function — check one IP against fraud databases."""
    return await _fraud_checker.check(ip)
# ══════════════════════════════════════════════════════════════════════════════
class NodeMavenConfig:
    """NodeMaven proxy configuration helper."""
    HOSTS = {
        "residential": "residential.nodemaven.com",
        "mobile": "mobile.nodemaven.com",
        "isp": "isp.nodemaven.com",
    }

    def __init__(self, username, password, proxy_type="residential", port=8080):
        self.username = username
        self.password = password
        self.proxy_type = proxy_type
        self.port = port

    def generate_proxy(self, country=None, session_id=None, quality_filter="medium", protocol="http"):
        host = self.HOSTS.get(self.proxy_type, self.HOSTS["residential"])
        port = self.port if protocol == "http" else (self.port + 1 if self.port == 8080 else 1080)
        parts = [self.username]
        if country: parts.append(f"country-{country.lower()}")
        if session_id: parts.append(f"sid-{session_id}")
        if quality_filter == "high": parts.append("quality-high")
        elif quality_filter == "low": parts.append("quality-low")
        user = "-".join(parts)
        return {
            "server": f"{protocol}://{host}:{port}",
            "username": user,
            "password": self.password,
            "raw": f"{host}:{port}:{user}:{self.password}",
            "ip": host,
            "port": port,
            "country": country,
        }
