"""
Human Behavior Simulation Module — v1.89
Simulates realistic human browsing behavior with STRICT user-defined visit time.

v1.89 upgrades (Deep Random Per-Visit Behavior):
- RANDOMIZED PHASE ORDER: each visit shuffles the phase sequence so
  no two visits ever follow the same scroll->click->mouse->idle pattern
- 20 personality profiles (was 15) with micro-variations
- 7 scroll patterns: linear, zigzag, jump-to-end, slow-read, fast-skim,
  overshoot-correct, read-pause-read
- Random idle micro-behaviors injected between phases
- Variable phase time allocation (not fixed 45%/30%/25%)
- Click styles: single, double-click, hover-then-click, miss-click
- Per-visit entropy seed that subtly shifts ALL timing
- v211: mobile scrolls/taps are REAL touch gestures via CDP (trusted events);\n- desktop uses real mouse wheel/moves (no JS evaluate)

v5.0 upgrades (Enhanced Human Interaction):
- Form fillup simulation: detect input fields, type realistic name/email/phone
- Multiple random clicks (1-3 instead of 0-1) on varied elements
- Hover effects on elements before clicking (natural browsing)
- Multi-page navigation: click internal links, browse to another page
- Reading patterns: hover over text sections, pause on content
- Random scroll direction changes (up/down/up pattern)
- Varied click targets: buttons, links, images, divs (not just first 15)
- Form submit button detection + click after filling
"""

import random
import asyncio
import math
import time
from playwright.async_api import Page

_FIRST_NAMES = ["James","John","Robert","Michael","William","David","Sarah","Jennifer","Lisa","Nancy",
                "Emily","Jessica","Ashley","Amanda","Melissa","Stephanie","Rebecca","Laura","Anna","Brenda",
                "Raj","Amit","Priya","Sneha","Karan","Arjun","Pooja","Rahul","Anika","Sadia",
                "Carlos","Maria","Sofia","Diego","Lucas","Ana","Pedro","Camila","Javier","Valentina"]
_LAST_NAMES = ["Smith","Johnson","Brown","Davis","Wilson","Taylor","Anderson","Thomas","Jackson","White",
               "Khan","Ahmed","Hassan","Rahman","Islam","Chowdhury","Das","Bose","Roy","Sen",
               "Garcia","Martinez","Lopez","Gonzalez","Rodriguez","Perez","Sanchez","Ramirez","Cruz","Flores"]
_DOMAINS = ["gmail.com","yahoo.com","outlook.com","hotmail.com","mail.com","proton.me","icloud.com"]

def _random_name():
    return f"{random.choice(_FIRST_NAMES)} {random.choice(_LAST_NAMES)}"

def _random_email():
    name = random.choice(_FIRST_NAMES).lower()
    return f"{name}{random.randint(1,9999)}@{random.choice(_DOMAINS)}"

def _random_phone():
    return f"{''.join([str(random.randint(0,9)) for _ in range(10)])}"

def _random_text(min_len=5, max_len=20):
    words = ["hello","interested","great","awesome","nice","cool","love","want","need","like",
             "thanks","yes","sure","okay","fine","good","perfect","amazing","wonderful","excellent"]
    n = random.randint(min_len, max_len)
    return " ".join(random.choices(words, k=n))


class HumanBehavior:
    """Simulates human-like browsing behavior on a page."""

    def __init__(self, page: Page, fingerprint: dict):
        self.page = page
        self.fingerprint = fingerprint
        self.is_mobile = fingerprint["is_mobile"]
        self.viewport_width = fingerprint["screen"]["width"]
        self.viewport_height = fingerprint["screen"]["height"]
        self.actions_log = []   # v210: which actions actually ran (for engine log)

    async def _get_real_viewport(self):
        try:
            vp = await self.page.evaluate("() => ({w: window.innerWidth, h: window.innerHeight})")
            if vp and vp.get("w", 0) > 0:
                return vp["w"], vp["h"]
        except Exception:
            pass
        return self.viewport_width, self.viewport_height

    # ── v211 BEHAVIOR ARCHETYPES ──────────────────────────────────────────
    # Every visitor gets ONE named archetype with continuous per-visit
    # jitter drawn from that archetype's ranges, and the resulting behavior
    # signature is checked against the run-wide registry — no two visits of
    # the same run ever behave the same (fast/slow/reader/clicker all
    # distinct).
    _ARCHETYPES = {
        "speed_skimmer": {
            "speed": "fast", "engagement": "low", "reading": "short",
            "click": (0, 1), "scroll": (4, 8), "form": 0.10, "mp": 0.20,
            "touch_speed": (1400, 2400), "fling": 0.85, "swipe_px": (300, 650),
            "pause": (0.15, 0.45), "wheel": (250, 600), "patterns": ["fast_skim", "linear", "jump_to_end"],
        },
        "casual_browser": {
            "speed": "medium", "engagement": "medium", "reading": "medium",
            "click": (1, 2), "scroll": (3, 6), "form": 0.35, "mp": 0.45,
            "touch_speed": (700, 1300), "fling": 0.65, "swipe_px": (200, 500),
            "pause": (0.3, 0.9), "wheel": (150, 450), "patterns": ["linear", "overshoot", "zigzag", "read_pause_read"],
        },
        "slow_reader": {
            "speed": "slow", "engagement": "medium", "reading": "long",
            "click": (0, 1), "scroll": (2, 5), "form": 0.25, "mp": 0.30,
            "touch_speed": (250, 600), "fling": 0.25, "swipe_px": (120, 300),
            "pause": (0.8, 2.2), "wheel": (60, 220), "patterns": ["slow_read", "read_pause_read", "linear"],
        },
        "deep_reader": {
            "speed": "slow", "engagement": "high", "reading": "long",
            "click": (0, 2), "scroll": (2, 4), "form": 0.60, "mp": 0.35,
            "touch_speed": (200, 450), "fling": 0.15, "swipe_px": (100, 250),
            "pause": (1.2, 3.0), "wheel": (50, 180), "patterns": ["slow_read", "read_pause_read"],
        },
        "link_clicker": {
            "speed": "medium", "engagement": "high", "reading": "short",
            "click": (2, 4), "scroll": (2, 5), "form": 0.55, "mp": 0.75,
            "touch_speed": (800, 1600), "fling": 0.55, "swipe_px": (150, 400),
            "pause": (0.25, 0.7), "wheel": (120, 380), "patterns": ["linear", "zigzag", "overshoot"],
        },
        "zigzag_scanner": {
            "speed": "fast", "engagement": "medium", "reading": "medium",
            "click": (1, 2), "scroll": (4, 8), "form": 0.20, "mp": 0.40,
            "touch_speed": (900, 1800), "fling": 0.75, "swipe_px": (180, 420),
            "pause": (0.2, 0.6), "wheel": (100, 320), "patterns": ["zigzag", "overshoot", "fast_skim"],
        },
        "curious_explorer": {
            "speed": "medium", "engagement": "high", "reading": "medium",
            "click": (1, 3), "scroll": (3, 6), "form": 0.45, "mp": 0.85,
            "touch_speed": (600, 1200), "fling": 0.55, "swipe_px": (180, 450),
            "pause": (0.3, 0.8), "wheel": (120, 350), "patterns": ["linear", "read_pause_read", "overshoot"],
        },
        "quick_checker": {
            "speed": "fast", "engagement": "low", "reading": "short",
            "click": (0, 1), "scroll": (1, 3), "form": 0.10, "mp": 0.12,
            "touch_speed": (1100, 2000), "fling": 0.90, "swipe_px": (250, 550),
            "pause": (0.15, 0.4), "wheel": (200, 500), "patterns": ["fast_skim", "linear"],
        },
    }

    def _pick_personality(self):
        """v211 - Pick a per-visit BEHAVIOR ARCHETYPE with per-visit jitter.
        A run-wide behavior-signature registry (engine-owned set) guarantees
        no two visits of the same run share the same behavior profile —
        one is a skimmer, one a deep reader, one a clicker, etc."""
        used = getattr(self, "used_behavior_sigs", None)
        for _try in range(15):
            a_name = random.choice(list(self._ARCHETYPES.keys()))
            a = self._ARCHETYPES[a_name]
            # per-visit continuous jitter inside the archetype's ranges
            p = {
                "archetype": a_name,
                "speed": a["speed"],
                "engagement": a["engagement"],
                "reading": a["reading"],
                "click_count": random.randint(a["click"][0], a["click"][1]),
                "scroll_count": random.randint(a["scroll"][0], a["scroll"][1]),
                "form_likelihood": min(1.0, max(0.0, random.gauss(a["form"], 0.08))),
                "multi_page_likelihood": min(1.0, max(0.0, random.gauss(a["mp"], 0.10))),
                # touch realism parameters
                "touch_speed": random.uniform(a["touch_speed"][0], a["touch_speed"][1]),
                "fling_prob": a["fling"],
                "swipe_px_range": a["swipe_px"],
                "pause_range": a["pause"],
                "wheel_range": a["wheel"],
            }
            p["pattern"] = self._pick_scroll_pattern(p)
            sig = (
                a_name, p["pattern"],
                round(p["touch_speed"] / 50.0),
                p["click_count"], p["scroll_count"], p["reading"],
            )
            if used is None or sig not in used:
                if used is not None:
                    used.add(sig)
                self.personality = p
                return p
        # 15 collisions in a row (tiny runs) — accept whatever we drew
        self.personality = p
        return p

    def _get_speed_multiplier(self, speed):
        if speed == "fast":
            return random.uniform(0.4, 0.7)
        elif speed == "slow":
            return random.uniform(1.3, 1.8)
        else:
            return random.uniform(0.8, 1.2)

    def _get_reading_pause(self, reading, speed_mult=1.0):
        if reading == "short":
            base = random.uniform(0.3, 1.0)
        elif reading == "long":
            base = random.uniform(1.5, 3.5)
        else:
            base = random.uniform(0.8, 2.0)
        return base * speed_mult

    def _pick_scroll_pattern(self, personality):
        """v1.89 - Pick a random scroll pattern for this visit."""
        patterns = [
            "linear", "zigzag", "jump_to_end", "slow_read",
            "fast_skim", "overshoot", "read_pause_read",
        ]
        weights = {
            "linear": 3,
            "zigzag": 2,
            "jump_to_end": 2 if personality["speed"] == "fast" else 1,
            "slow_read": 3 if personality["reading"] == "long" else 1,
            "fast_skim": 3 if personality["speed"] == "fast" else 1,
            "overshoot": 2,
            "read_pause_read": 2 if personality["reading"] != "short" else 1,
        }
        pool = []
        for p in patterns:
            pool.extend([p] * weights.get(p, 1))
        return random.choice(pool)

    # ── v211 REAL TOUCH LAYER (CDP input pipeline) ──────────────────────
    # Ad networks on mobile check for touch events (touchstart/touchmove/
    # touchend, pointerType 'touch'). Events injected through CDP go through
    # the browser's real input pipeline, so isTrusted=true and the full
    # touch/pointer event sequence fires — indistinguishable from a finger.
    # The old build scrolled mobile pages with mouse.wheel and tapped with
    # mouse.down/up: wheel/mouse events on a phone UA is a textbook
    # automation tell.

    def _tleft(self):
        """v211: seconds left before this visit's hard deadline (inf if unset)."""
        d = getattr(self, "_session_deadline", None)
        if d is None:
            return 999.0
        return d - time.time()

    async def _cdp(self):
        """Lazily open a CDP session for this page (cached)."""
        if getattr(self, "_cdp_session", None) is None:
            self._cdp_session = await self.page.context.new_cdp_session(self.page)
        return self._cdp_session

    async def _cdp_touch_ok(self):
        """True if CDP touch injection works on this engine (Chromium only)."""
        if getattr(self, "_touch_mode", None) is not None:
            return self._touch_mode
        try:
            cdp = await self._cdp()
            await cdp.send("Input.setTouchEmulationEnabled", {"enabled": True, "maxTouchPoints": 5})
            self._touch_mode = True
        except Exception:
            self._touch_mode = False
        return self._touch_mode

    async def _touch_tap(self, x, y, hold=None):
        """Real touch tap: trusted touchStart -> hold -> touchEnd via CDP.
        Fires touchstart/touchend + pointerdown/pointerup (pointerType 'touch')
        + click — exactly like a real finger tap."""
        if not await self._cdp_touch_ok():
            # Fallback (non-Chromium engine): Playwright touchscreen (still
            # real touch events through the driver where supported), else JS.
            try:
                await self.page.touchscreen.tap(x, y)
                return
            except Exception:
                try:
                    await self.page.evaluate(
                        "(([x, y]) => { const t = new Touch({identifier: 1, target: document.elementFromPoint(x, y), clientX: x, clientY: y});"
                        "document.elementFromPoint(x, y).dispatchEvent(new TouchEvent('touchstart', {touches: [t], targetTouches: [t], changedTouches: [t], bubbles: true, cancelable: true}));"
                        "document.elementFromPoint(x, y).dispatchEvent(new TouchEvent('touchend', {touches: [], targetTouches: [], changedTouches: [t], bubbles: true, cancelable: true})); })([arguments])",
                    ) if False else self.page.evaluate(
                        "([x, y]) => { const el = document.elementFromPoint(x, y); if (!el) return;"
                        "const t = new Touch({identifier: 1, target: el, clientX: x, clientY: y});"
                        "el.dispatchEvent(new TouchEvent('touchstart', {touches: [t], targetTouches: [t], changedTouches: [t], bubbles: true, cancelable: true}));"
                        "el.dispatchEvent(new TouchEvent('touchend', {touches: [], targetTouches: [], changedTouches: [t], bubbles: true, cancelable: true})); }", [x, y])
                except Exception:
                    pass
                return
        p = self.personality if getattr(self, "personality", None) else {}
        force = random.uniform(0.35, 0.75)
        radius = random.uniform(1.5, 3.5)
        point = {"x": float(x), "y": float(y), "force": force, "radiusX": radius, "radiusY": radius, "id": 1}
        cdp = await self._cdp()
        await cdp.send("Input.dispatchTouchEvent", {"type": "touchStart", "touchPoints": [point]})
        await asyncio.sleep(hold if hold is not None else random.uniform(0.05, 0.17))
        await cdp.send("Input.dispatchTouchEvent", {"type": "touchEnd", "touchPoints": []})

    async def _scroll_y(self):
        try:
            return (await self.page.evaluate("window.scrollY")) or 0
        except Exception:
            return None

    async def _page_can_scroll(self):
        try:
            r = await self.page.evaluate(
                "() => ({h: document.documentElement.scrollHeight, v: window.innerHeight})")
            return (r or {}).get("h", 0) > (r or {}).get("v", 0) + 40
        except Exception:
            return True

    async def _gesture_scroll(self, cdp, chunk, down, speed, fling):
        """Finger swipe via Input.synthesizeScrollGesture (needs the
        --enable-gpu-benchmarking launch flag; silently no-ops without it)."""
        sign = self._swipe_down_sign if down else -self._swipe_down_sign
        params = {
            "x": int(random.uniform(self.viewport_width * 0.25, self.viewport_width * 0.75)),
            "y": int(random.uniform(self.viewport_height * 0.45, self.viewport_height * 0.75)),
            "xDistance": int(random.uniform(-14, 14)),
            "yDistance": int(sign * chunk),
            "speed": int(max(150, random.gauss(speed, speed * 0.15))),
            "preventFling": not fling,
            "gestureSourceType": "touch",
        }
        await cdp.send("Input.synthesizeScrollGesture", params)

    async def _drag_scroll(self, cdp, chunk, down, speed, fling):
        """Real finger DRAG: touchStart -> touchMove chain with natural easing
        -> touchEnd, through the CDP input pipeline. Works on stock Chromium
        (no special flags) and fires the full trusted touch event sequence."""
        vw, vh = self.viewport_width, self.viewport_height
        x0 = random.uniform(vw * 0.3, vw * 0.7)
        if down:
            y0 = random.uniform(vh * 0.5, vh * 0.8)   # finger starts low, sweeps up
        else:
            y0 = random.uniform(vh * 0.2, vh * 0.5)
        dir_sign = (-1 if down else 1) * getattr(self, "_drag_dir", 1)  # v213.1: +1 = correct phone-like default (-1 was inverted)
        steps = random.randint(10, 22)
        dur = max(0.10, chunk / max(speed, 200))
        interval = dur / steps
        pt = {"x": x0, "y": y0, "force": random.uniform(0.3, 0.6),
              "radiusX": 2.0, "radiusY": 2.0, "id": 1}
        await cdp.send("Input.dispatchTouchEvent", {"type": "touchStart", "touchPoints": [dict(pt)]})
        for i in range(1, steps + 1):
            prog = i / steps
            if fling:
                eased = prog ** 1.6          # accelerate — lift mid-speed => momentum fling
            else:
                eased = 1 - (1 - prog) ** 2  # decelerate — finger settles, then lifts
            pt["y"] = y0 + dir_sign * chunk * eased
            pt["x"] = x0 + random.uniform(-3, 3)
            await asyncio.sleep(max(0.004, interval))
            await cdp.send("Input.dispatchTouchEvent", {"type": "touchMove", "touchPoints": [dict(pt)]})
        await cdp.send("Input.dispatchTouchEvent", {"type": "touchEnd", "touchPoints": []})

    async def _touch_swipe(self, amount):
        """v213 - Mobile scroll that VERIFIES it actually scrolled.
        The v211 version sent Input.synthesizeScrollGesture once and trusted
        it — but on stock Chrome (without --enable-gpu-benchmarking) that
        command is a SILENT no-op, so visits "scrolled" without the page
        moving an inch, and the first visible action became the tap.
        Now every swipe is checked against scrollY and the METHOD ESCALATES
        until the page really moves: gesture -> finger-drag -> JS scrollBy.
        Whichever method works is remembered for the rest of the visit.
        Accumulated pixels land in the visit log (scroll(1840px))."""
        p = self.personality if getattr(self, "personality", None) else {}
        speed = p.get("touch_speed", random.uniform(700, 1400))
        fling_prob = p.get("fling_prob", 0.6)
        swipe_lo, swipe_hi = p.get("swipe_px_range", (200, 500))
        pause_lo, pause_hi = p.get("pause_range", (0.25, 0.7))
        down = amount >= 0
        remaining = abs(amount)
        if getattr(self, "_swipe_down_sign", None) is None:
            self._swipe_down_sign = -1
        if getattr(self, "_scroll_method", None) is None:
            self._scroll_method = "gesture"
        cdp = None
        try:
            while remaining > 30:
                if self._tleft() <= 0.25:
                    break
                if getattr(self, "_page_unscrollable", False):
                    break
                chunk = int(min(remaining, random.uniform(swipe_lo, swipe_hi),
                                self.viewport_height * 0.65))
                if chunk < 30:
                    chunk = min(remaining, 40)
                fling = random.random() < fling_prob
                before = await self._scroll_y()
                moved = 0
                # try the preferred method first, then escalate until the
                # page actually moves (v213: verified scrolling)
                order = [self._scroll_method] + [m for m in ("gesture", "drag", "js") if m != self._scroll_method]
                for method in order:
                    try:
                        if method == "gesture":
                            cdp = cdp or await self._cdp()
                            await self._gesture_scroll(cdp, chunk, down, speed, fling)
                        elif method == "drag":
                            cdp = cdp or await self._cdp()
                            await self._drag_scroll(cdp, chunk, down, speed, fling)
                        else:
                            await self.page.evaluate(
                                "(d) => window.scrollBy({top: d, behavior: 'smooth'})",
                                (1 if down else -1) * chunk)
                    except Exception:
                        continue
                    after = await self._scroll_y()
                    if before is None or after is None:
                        break  # can't verify — assume it worked
                    delta = after - before
                    if abs(delta) >= 3:
                        moved = abs(delta)
                        self._scroll_method = method  # remember what works here
                        # direction calibration for future chunks
                        # v213.1: flip on observed inversion (was a hardcoded
                        # reset that could re-assert the wrong drag sign).
                        if down and delta < 0:
                            if method == "gesture":
                                self._swipe_down_sign = 1
                            else:
                                self._drag_dir = -getattr(self, "_drag_dir", 1)
                        elif (not down) and delta > 0:
                            if method == "gesture":
                                self._swipe_down_sign = -1
                            else:
                                self._drag_dir = -getattr(self, "_drag_dir", 1)
                        break
                if not moved and before is not None:
                    # nothing moved on ANY method — is the page scrollable at all?
                    if not await self._page_can_scroll():
                        self._page_unscrollable = True
                        break
                if moved:
                    self._scroll_px = getattr(self, "_scroll_px", 0) + moved
                remaining -= int(chunk * (random.uniform(1.0, 1.4) if fling else 1.0))
                if remaining > 30:
                    await asyncio.sleep(max(0.08, min(pause_hi, random.uniform(pause_lo, pause_hi), self._tleft())))
            # post-swipe momentum settle (finger lifted, page gliding/stopping)
            await asyncio.sleep(max(0.05, min(random.uniform(0.15, 0.5), self._tleft())))
        except Exception:
            pass

    async def simulate_session(self, actions_config: dict, deadline: float = None):
        """v210 LIVE ENGAGEMENT - actions start the moment the target page
        finishes loading, and the session ends exactly at an absolute DEADLINE
        set by the engine from the user's visit-duration setting. A 4-8s visit
        behaves like a compressed 45s visit, not a still tab.

        v1.89's old flow opened every session with a fixed 0.5-4s reading
        pause plus a fixed 1.5s ad-check and planned phases against a
        15-45s-shaped budget - on short visits the page just sat still until
        it closed. Now every pause is a proportion of the time actually left,
        the enabled actions (scroll / click / mouse / multi_page) run inside
        the remaining window, and any leftover time is filled with organic
        micro-behavior instead of dead stillness."""
        self._actions_config = actions_config
        self.actions_log = []
        min_time = actions_config.get("min_visit_time", 5)
        max_time = actions_config.get("max_visit_time", 30)

        self._scroll_px = 0            # v213: verified pixels this visit
        self._page_unscrollable = False  # v213: set when the page has no room to scroll
        self._scroll_method = None       # v213: remembered working scroll method
        start = time.time()
        if deadline is None:
            _mean = (min_time + max_time) / 2
            _std = max(0.5, (max_time - min_time) / 6)
            target = max(min_time, min(max_time, random.gauss(_mean, _std)))
            deadline = start + target
        self._session_deadline = deadline  # v211: every action checks this

        def _left():
            return deadline - time.time()

        if _left() <= 0.15:
            return

        personality = self._pick_personality()
        speed_mult = self._get_speed_multiplier(personality["speed"])
        scroll_pattern = personality.get("pattern") or self._pick_scroll_pattern(personality)

        # natural landing state - clear selection/focus (costs nothing)
        try:
            await self.page.evaluate("() => { if (window.getSelection) { window.getSelection().removeAllRanges(); } if (document.activeElement && document.activeElement !== document.body) { document.activeElement.blur(); } }")
        except Exception:
            pass

        # v210: proportional reading pause - never a fixed multi-second block
        if actions_config.get("quick_impression", False):
            initial_pause = max(0.15, min(0.6, random.gauss(0.4, 0.15)))
        else:
            initial_pause = max(0.2, min(0.9, _left() * random.uniform(0.08, 0.15)))
        await asyncio.sleep(initial_pause)

        # v210: ad-check compressed to ~10% of the window (was fixed 1.5s)
        if _left() > 1.5:
            await self._quick_ad_check(max_wait=min(0.6, _left() * 0.10))

        # v210: short windows use fast scroll patterns only - slow_read /
        # read_pause_read carry multi-second pauses that would eat a 4-8s visit
        if _left() < 6:
            scroll_pattern = random.choice(["linear", "fast_skim", "overshoot", "zigzag"])

        # v210: action queue built from the dashboard toggles - scroll leads
        # (the most natural first engagement), the rest shuffle; 30% of the
        # time another action rotates to the front for organic variety.
        queue = []
        if actions_config.get("scroll", True):
            queue.append("scroll")
        if actions_config.get("mouse_movement", True):
            queue.append("mouse")
        if actions_config.get("click", False):
            queue.append("click")
        rest = [p for p in queue if p != "scroll"]
        random.shuffle(rest)
        # v211: scroll ALWAYS leads when enabled (user: scroll on thakle
        # scroll-i age) — variety comes from the archetype, not the order
        queue = (["scroll"] + rest) if "scroll" in queue else rest

        for phase_name in queue:
            left = _left()
            if left <= 0.35:
                break

            if phase_name == "scroll":
                # v210: step count compressed to the time actually available
                budget = min(left * random.uniform(0.45, 0.60), left - 0.1)
                _p = dict(personality)
                _p["scroll_count"] = max(1, min(personality["scroll_count"], max(1, int(budget // 0.7))))
                try:
                    # v211 HARD GUARANTEE: this phase can never run past the
                    # visit deadline — a mid-swipe cancel is exactly what a
                    # real user does when they decide to leave.
                    await asyncio.wait_for(
                        self._execute_scroll_phase(_p, scroll_pattern, max(0.5, budget), speed_mult),
                        timeout=max(0.4, self._tleft() + 0.3))
                    _px = getattr(self, "_scroll_px", 0)
                    _sfx = f"scroll({_px}px)" if _px else (
                        "scroll(page short)" if getattr(self, "_page_unscrollable", False) else "scroll")
                    self.actions_log.append(_sfx)
                except asyncio.TimeoutError:
                    _px = getattr(self, "_scroll_px", 0)
                    _sfx = f"scroll({_px}px)" if _px else (
                        "scroll(page short)" if getattr(self, "_page_unscrollable", False) else "scroll")
                    self.actions_log.append(_sfx)
                    break

            elif phase_name == "mouse":
                budget = min(left * random.uniform(0.35, 0.55), left - 0.1)
                if not self.is_mobile and budget > 0.5:
                    try:
                        await asyncio.wait_for(
                            self._natural_mouse_movements(max_time=budget),
                            timeout=max(0.4, self._tleft() + 0.3))
                        self.actions_log.append("mouse")
                        hover_chance = {"low": 0.3, "medium": 0.5, "high": 0.8}.get(personality["engagement"], 0.5)
                        if random.random() < hover_chance and _left() > 0.8:
                            await asyncio.wait_for(self._hover_elements(), timeout=self._tleft() + 0.3)
                            self.actions_log.append("hover")
                    except asyncio.TimeoutError:
                        break
                elif self.is_mobile and budget > 0.5:
                    try:
                        await asyncio.wait_for(self._simulate_swipe(), timeout=max(0.4, self._tleft() + 0.3))
                        self.actions_log.append("swipe")
                    except asyncio.TimeoutError:
                        break

            elif phase_name == "click":
                # v210: click rounds scaled to remaining time, deadline-checked
                max_rounds = 1 if _left() < 4 else min(personality["click_count"], 3)
                rounds_done = 0
                for _ in range(max_rounds):
                    if _left() <= 0.6:
                        break
                    style = random.choice(["single", "hover_then_click", "double_click", "miss_click"])
                    try:
                        if self.is_mobile:
                            await asyncio.wait_for(self._random_taps(), timeout=max(0.4, self._tleft() + 0.3))
                        else:
                            await asyncio.wait_for(self._random_clicks(style=style), timeout=max(0.4, self._tleft() + 0.3))
                    except asyncio.TimeoutError:
                        rounds_done += 1
                        break
                    rounds_done += 1
                    if _left() > 0.5:
                        await asyncio.sleep(min(0.5, _left() * 0.12))
                if rounds_done:
                    self.actions_log.append("click x%d" % rounds_done)

        # v210: form fill - only if enabled AND real time remains
        if actions_config.get("form_fill", False) and _left() > 3:
            if random.random() < personality["form_likelihood"]:
                if await asyncio.wait_for(self._fill_forms(), timeout=self._tleft() + 0.3):
                    self.actions_log.append("form")
                    if _left() > 0.5:
                        await asyncio.sleep(min(1.0, _left() * 0.15))

        # v210: multi-page LAST - uses whatever window is left. Even a 4-8s
        # visit fits one quick same-origin internal hop when the user enables it.
        if actions_config.get("multi_page", False) and _left() > 1.6:
            hops = 1 if _left() < 7 else random.randint(1, min(3, int(_left() // 2.5)))
            for _ in range(hops):
                if _left() <= 1.1:
                    break
                nav_start = self.page.url
                try:
                    await asyncio.wait_for(
                        self._navigate_internal_page(max_time=max(0.9, _left() * 0.55)),
                        timeout=max(0.9, self._tleft() + 0.3))
                except asyncio.TimeoutError:
                    break
                if self.page.url != nav_start:
                    self.actions_log.append("multipage")
                    # brief on-new-page engagement: one scroll burst
                    if _left() > 1.0 and actions_config.get("scroll", True):
                        await self._natural_scroll(steps=random.randint(1, 2))
                if _left() > 0.8:
                    await asyncio.sleep(min(0.4, _left() * 0.10))

        # v210: organic filler until the deadline - micro idle behaviors
        # (mouse jitter, tiny scrolls) instead of sitting dead-still
        while _left() > 1.2:
            fill = min(_left() - 0.3, random.uniform(0.5, 1.5))
            try:
                await self._random_idle_behavior(duration=max(0.3, fill))
            except Exception:
                await asyncio.sleep(min(fill, max(0.0, _left() - 0.2)))
        if _left() > 0.05:
            await asyncio.sleep(max(0.0, _left()))

    async def _execute_scroll_phase(self, personality, pattern, budget, speed_mult):
        """v1.89 - Execute scroll using the visit's chosen scroll pattern."""
        scroll_steps = personality["scroll_count"]

        if pattern == "linear":
            await self._natural_scroll(steps=scroll_steps)
            if random.random() > 0.4 and budget > 2:
                pause = max(0.3, min(1.5, random.gauss(0.6, 0.2) * speed_mult, self._tleft()))  # v211
                await asyncio.sleep(pause)
                up_steps = random.randint(1, min(3, scroll_steps // 2))
                await self._natural_scroll(direction="up", steps=up_steps)

        elif pattern == "zigzag":
            zigzag_steps = max(2, scroll_steps // 2)
            for i in range(min(4, zigzag_steps)):
                direction = "down" if i % 2 == 0 else "up"
                await self._natural_scroll(direction=direction, steps=random.randint(1, 2))
                await asyncio.sleep(max(0.2, min(0.8, random.gauss(0.4, 0.15) * speed_mult)))

        elif pattern == "jump_to_end":
            await self._natural_scroll(steps=max(3, scroll_steps), scroll_size_range=(300, 700))
            if random.random() > 0.3 and budget > 2:
                await asyncio.sleep(max(0.3, min(1.0, random.gauss(0.5, 0.2) * speed_mult)))
                await self._natural_scroll(direction="up", steps=random.randint(2, 4), scroll_size_range=(100, 300))

        elif pattern == "slow_read":
            for i in range(min(scroll_steps, 5)):
                await self._natural_scroll(steps=1, scroll_size_range=(50, 150))
                read_pause = max(0.5, min(3.0, random.gauss(1.2, 0.5) * speed_mult, self._tleft()))  # v211
                await asyncio.sleep(read_pause)

        elif pattern == "fast_skim":
            await self._natural_scroll(steps=scroll_steps, scroll_size_range=(300, 600))
            await asyncio.sleep(max(0.1, min(0.4, random.gauss(0.2, 0.1) * speed_mult)))

        elif pattern == "overshoot":
            await self._natural_scroll(steps=max(2, scroll_steps), scroll_size_range=(250, 500))
            await asyncio.sleep(max(0.2, min(0.6, random.gauss(0.3, 0.15))))
            await self._natural_scroll(direction="up", steps=random.randint(1, 3), scroll_size_range=(50, 150))

        elif pattern == "read_pause_read":
            first_batch = max(1, scroll_steps // 2)
            await self._natural_scroll(steps=first_batch)
            read_pause = max(1.0, min(4.0, random.gauss(2.0, 0.7) * speed_mult, self._tleft()))  # v211
            await asyncio.sleep(read_pause)
            remaining_steps = scroll_steps - first_batch
            if remaining_steps > 0:
                await self._natural_scroll(steps=remaining_steps)

    async def _fill_forms(self):
        """v5.0 - Detect form input fields and fill them with human typing."""
        try:
            inputs = await self.page.query_selector_all(
                "input[type='text'], input[type='email'], input[type='tel'], "
                "input[type='search'], input:not([type]), textarea, "
                "input[name*='name'], input[name*='email'], input[name*='phone'], "
                "input[placeholder*='name'], input[placeholder*='email'], input[placeholder*='phone']"
            )
            if not inputs:
                return False
            filled_count = 0
            max_fill = min(len(inputs), random.randint(2, 4))
            for i, inp in enumerate(inputs[:max_fill]):
                try:
                    is_visible = await inp.is_visible()
                    if not is_visible:
                        continue
                    box = await inp.bounding_box()
                    if not box or box["width"] < 20 or box["height"] < 10:
                        continue
                    input_type = await inp.evaluate(
                        """el => ({
                            type: el.type || 'text',
                            name: (el.name || '').toLowerCase(),
                            placeholder: (el.placeholder || '').toLowerCase(),
                            id: (el.id || '').toLowerCase()
                        })"""
                    )
                    field_text = self._guess_field_value(input_type)
                    if not field_text:
                        continue
                    target_x = box["x"] + box["width"] / 2 + random.uniform(-5, 5)
                    target_y = box["y"] + box["height"] / 2 + random.uniform(-3, 3)
                    if self.is_mobile:
                        # v213.3 audit fix: touch tap to focus the field
                        await self._touch_tap(target_x, target_y, hold=random.uniform(0.07, 0.18))
                    else:
                        start_x = random.randint(50, min(self.viewport_width - 50, 800))
                        start_y = random.randint(50, min(self.viewport_height - 50, 600))
                        await self._move_mouse_to(start_x, start_y, target_x, target_y,
                                                 target_width=max(10, min(box["width"], box["height"])))
                        await asyncio.sleep(max(0.1, min(0.4, random.gauss(0.2, 0.08))))
                        await self.page.mouse.click(target_x, target_y)
                    await asyncio.sleep(max(0.1, min(0.3, random.gauss(0.15, 0.05))))
                    await self._human_type(inp, field_text)
                    filled_count += 1
                    await asyncio.sleep(max(0.2, min(1.0, random.gauss(0.5, 0.15))))
                except Exception:
                    continue
            return filled_count > 0
        except Exception:
            return False

    def _guess_field_value(self, input_type):
        t = input_type.get("type", "text")
        name = input_type.get("name", "")
        placeholder = input_type.get("placeholder", "")
        combined = f"{name} {placeholder} {t}"
        if "email" in combined:
            return _random_email()
        elif "phone" in combined or "tel" in combined:
            return _random_phone()
        elif "name" in combined:
            return _random_name()
        elif "search" in combined or "query" in combined:
            return _random_text(min_len=2, max_len=5)
        elif t == "textarea":
            return _random_text(min_len=5, max_len=15)
        else:
            return _random_text(min_len=3, max_len=8)

    async def _human_type(self, element, text):
        try:
            # v213.3 audit fix: element.click() is a Playwright MOUSE click —
            # on touch devices the caller already focused the field with a
            # real tap, so skip it (mouse events must never fire on mobile).
            if not self.is_mobile:
                await element.click()
            await asyncio.sleep(random.uniform(0.1, 0.3))
            for char in text:
                await self.page.keyboard.type(char)
                delay = max(0.03, min(0.15, random.gauss(0.07, 0.03)))
                await asyncio.sleep(delay)
            if random.random() > 0.6:
                await asyncio.sleep(random.uniform(0.3, 0.8))
        except Exception:
            pass

    async def _click_submit_button(self):
        try:
            buttons = await self.page.query_selector_all(
                "button[type='submit'], input[type='submit'], "
                "button:has-text('Submit'), button:has-text('Send'), "
                "button:has-text('OK'), button:has-text('Continue'), "
                "a:has-text('Submit'), a:has-text('Send')"
            )
            if buttons:
                btn = buttons[0]
                is_visible = await btn.is_visible()
                if is_visible:
                    box = await btn.bounding_box()
                    if box:
                        target_x = box["x"] + box["width"] / 2
                        target_y = box["y"] + box["height"] / 2
                        if self.is_mobile:
                            # v213.3 audit fix: tap, not mouse click, on touch
                            await asyncio.sleep(random.uniform(0.1, 0.3))
                            await self._touch_tap(target_x, target_y, hold=random.uniform(0.08, 0.2))
                        else:
                            await self._move_mouse_to(
                                random.randint(100, 400),
                                random.randint(100, 300),
                                target_x, target_y,
                                target_width=max(10, min(box["width"], box["height"]))
                            )
                            await asyncio.sleep(random.uniform(0.1, 0.3))
                            await self.page.mouse.click(target_x, target_y)
                        return True
        except Exception:
            pass
        return False

    async def _hover_elements(self):
        """v5.0 - Hover over random elements on the page."""
        try:
            elements = await self.page.query_selector_all(
                "a, button, img, div[class*='card'], div[class*='item'], "
                "span[class*='title'], h1, h2, h3, p"
            )
            if not elements:
                return
            num_hovers = random.randint(1, 3)
            for _ in range(num_hovers):
                elem = random.choice(elements[:20])
                try:
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue
                    box = await elem.bounding_box()
                    if not box:
                        continue
                    target_x = box["x"] + box["width"] / 2 + random.uniform(-10, 10)
                    target_y = box["y"] + box["height"] / 2 + random.uniform(-5, 5)
                    await self._move_mouse_to(
                        random.randint(50, min(self.viewport_width - 50, 600)),
                        random.randint(50, min(self.viewport_height - 50, 400)),
                        target_x, target_y,
                        target_width=max(10, min(box["width"], box["height"]))
                    )
                    await asyncio.sleep(max(0.3, min(1.5, random.gauss(0.6, 0.3))))
                except Exception:
                    continue
        except Exception:
            pass

    async def _navigate_internal_page(self, max_time=5.0):
        await self._navigate_internal_page_impl(max_time)

    async def _navigate_internal_page_impl(self, max_time=5.0):
        try:
            # v1.87 CRITICAL: Only navigate to SAME-ORIGIN links.
            # Never click external links (ad banners, sponsored content, etc.)
            # This prevents the bot from clicking on ads and navigating away.
            current_url = self.page.url
            from urllib.parse import urlparse
            current_host = urlparse(current_url).hostname or ""
            links = await self.page.query_selector_all("a[href]")
            if not links:
                return
            internal_links = []
            for link in links[:30]:
                try:
                    href = await link.get_attribute("href")
                    if not href or href.startswith(("javascript:", "mailto:", "tel:", "#")):
                        continue
                    # Check if same-origin (internal navigation only)
                    link_host = urlparse(href).hostname or ""
                    if link_host and link_host != current_host and not link_host.endswith("." + current_host):
                        continue  # External link — skip (could be ad)
                    # Skip links that look like ads
                    href_lower = href.lower()
                    if any(ad_kw in href_lower for ad_kw in [
                        "doubleclick", "googleads", "googlesyndication",
                        "adsterra", "monetag", "propeller", "popads",
                        "taboola", "mgid", "adskeeper", "popcash",
                        "/ad/", "/ads/", "/banner", "/redirect/",
                        "affiliate", "sponsored", "promo"
                    ]):
                        continue
                    is_visible = await link.is_visible()
                    if is_visible:
                        internal_links.append(link)
                except Exception:
                    continue
            if not internal_links:
                return
            link = random.choice(internal_links[:10])
            box = await link.bounding_box()
            if not box:
                return
            target_x = box["x"] + box["width"] / 2 + random.uniform(-5, 5)
            target_y = box["y"] + box["height"] / 2 + random.uniform(-3, 3)
            if not self.is_mobile:
                start_x = random.randint(50, min(self.viewport_width - 50, 600))
                start_y = random.randint(50, min(self.viewport_height - 50, 400))
                await self._move_mouse_to(start_x, start_y, target_x, target_y,
                                         target_width=max(10, min(box["width"], box["height"])))
                await asyncio.sleep(random.uniform(0.1, 0.4))
                await self.page.mouse.click(target_x, target_y)
            else:
                # v213.3 audit fix: touch devices NAVIGATE BY TAP — never
                # mouse events (pointerType 'mouse' on a phone = mismatch).
                await asyncio.sleep(random.uniform(0.05, 0.2))
                await self._touch_tap(target_x, target_y, hold=random.uniform(0.08, 0.2))
            try:
                await self.page.wait_for_load_state("domcontentloaded", timeout=8000)
            except:
                pass
            browse_time = min(max_time * 0.6, random.uniform(2.0, 5.0))
            await asyncio.sleep(browse_time)
            if random.random() > 0.3:
                await self._natural_scroll(steps=random.randint(1, 3))
            if random.random() > 0.5 and self._actions_config.get("click", False):  # v1.87: default OFF
                if self.is_mobile:
                    await self._random_taps()
                else:
                    await self._random_clicks()
            if not self.is_mobile and random.random() > 0.6:
                await self._hover_elements()
            remaining_browse = max(0, browse_time - 1.5)
            if remaining_browse > 0:
                await asyncio.sleep(remaining_browse)
        except Exception:
            pass

    async def _random_idle_behavior(self, duration=2.0):
        """v5.3.1 - Random idle micro-behaviors that real users do.
        v1.89 - Expanded with more behaviors."""
        try:
            behaviors = []
            if not self.is_mobile:
                behaviors.extend(['mouse_wander', 'hover_random', 'slight_scroll',
                                  'text_select', 'viewport_stare', 'micro_adjust'])
            behaviors.extend(['pause', 'tab_peek'])
            num_behaviors = random.randint(1, 3)
            time_per = duration / num_behaviors
            for _ in range(num_behaviors):
                behavior = random.choice(behaviors)
                if behavior == 'mouse_wander':
                    x = random.randint(100, min(self.viewport_width - 100, 800))
                    y = random.randint(100, min(self.viewport_height - 100, 600))
                    await self.page.mouse.move(x, y, steps=random.randint(5, 15))
                    await asyncio.sleep(random.uniform(0.3, 0.8) * time_per)
                elif behavior == 'hover_random':
                    try:
                        elements = await self.page.query_selector_all("a, button, div, span, p")
                        if elements:
                            el = random.choice(elements[:20])
                            box = await el.bounding_box()
                            if box and box["width"] > 20:
                                await self.page.mouse.move(
                                    box["x"] + box["width"]/2 + random.uniform(-10, 10),
                                    box["y"] + box["height"]/2 + random.uniform(-5, 5),
                                    steps=random.randint(3, 10)
                                )
                                await asyncio.sleep(random.uniform(0.2, 0.6) * time_per)
                    except: pass
                elif behavior == 'slight_scroll':
                    delta = random.choice([50, -50, 100, -30, 80])
                    await self.page.mouse.wheel(0, delta)
                    await asyncio.sleep(random.uniform(0.3, 0.7) * time_per)
                elif behavior == 'tab_peek':
                    await asyncio.sleep(random.uniform(0.5, 1.5) * time_per)
                elif behavior == 'text_select':
                    try:
                        await self.page.evaluate("""() => {
                            const sel = window.getSelection();
                            if (sel && document.body) {
                                const range = document.createRange();
                                const ps = document.querySelectorAll('p, h1, h2, h3, span');
                                if (ps.length > 0) {
                                    const el = ps[Math.floor(Math.random() * Math.min(ps.length, 10))];
                                    range.selectNodeContents(el);
                                    sel.removeAllRanges();
                                    sel.addRange(range);
                                }
                            }
                        }""")
                        await asyncio.sleep(random.uniform(0.3, 0.8) * time_per)
                    except: pass
                elif behavior == 'viewport_stare':
                    try:
                        stare_x = random.randint(200, min(self.viewport_width - 200, 1000))
                        stare_y = random.randint(150, min(self.viewport_height - 150, 600))
                        await self.page.mouse.move(stare_x, stare_y, steps=random.randint(3, 6))
                    except: pass
                    await asyncio.sleep(random.uniform(0.5, 1.5) * time_per)
                elif behavior == 'micro_adjust':
                    try:
                        cur_x = random.randint(100, min(self.viewport_width - 100, 800))
                        cur_y = random.randint(100, min(self.viewport_height - 100, 600))
                        adj_x = cur_x + random.randint(-20, 20)
                        adj_y = cur_y + random.randint(-15, 15)
                        await self.page.mouse.move(adj_x, adj_y, steps=random.randint(2, 5))
                    except: pass
                    await asyncio.sleep(random.uniform(0.2, 0.5) * time_per)
                else:
                    await asyncio.sleep(random.uniform(0.3, 1.0) * time_per)
        except Exception:
            pass

    async def _quick_ad_check(self, max_wait=1.5):
        # v1.89: Only scroll to ads if scroll is enabled in config
        _scroll_enabled = getattr(self, '_actions_config', {}).get("scroll", True)
        try:
            await self.page.wait_for_load_state("networkidle", timeout=int(max_wait * 1000))
        except Exception:
            pass
        if not _scroll_enabled:
            return  # Scroll disabled — don't scroll to ads
        try:
            ad_info = await self.page.evaluate("""() => {
                const adKw = ['ad','google','doubleclick','adsterra','monetag','propeller',
                    'taboola','mgid','syndication','adsbygoogle','popads','popcash','adskeeper'];
                const iframes = document.querySelectorAll('iframe');
                for (const f of iframes) {
                    const s = f.src || '';
                    for (const kw of adKw) {
                        if (s.includes(kw)) {
                            const r = f.getBoundingClientRect();
                            return {
                                found: true,
                                visible: r.width > 10 && r.height > 10,
                                width: r.width,
                                height: r.height,
                                top: r.top,
                                left: r.left
                            };
                        }
                    }
                }
                return {found: false};
            }""")
            if ad_info and ad_info.get("found") and ad_info.get("visible"):
                if ad_info.get("top", 0) > self.viewport_height * 0.7:
                    scroll_target = int(ad_info.get("top", 0) - self.viewport_height * 0.3)
                    try:
                        await self.page.evaluate(f"window.scrollTo({{top: {scroll_target}, behavior: 'smooth'}})")
                        await asyncio.sleep(0.5)
                    except:
                        pass
        except Exception:
            pass

    async def _natural_scroll(self, direction="down", steps=None, scroll_size_range=None):
        """v211 - Mobile: REAL touch swipes via CDP (trusted touch events,
        momentum fling, archetype speed) — ad networks see a genuine finger.
        Desktop: trusted mouse-wheel scrolls, sizes from the visit's archetype.
        v1.89 - Accepts scroll_size_range for pattern-specific scroll amounts."""
        p = self.personality if getattr(self, "personality", None) else {}
        if steps is None:
            steps = random.randint(3, 8)
        if scroll_size_range is None:
            lo, hi = p.get("wheel_range", (50, 800))
        else:
            lo, hi = scroll_size_range
        pause_lo, pause_hi = p.get("pause_range", (0.2, 1.2))
        for i in range(steps):
            if self._tleft() <= 0.2:   # v211: visit time is up — stop scrolling
                break
            if self.is_mobile:
                # v211 REAL TOUCH: one swipe per step, archetype distance/speed
                lo_t, hi_t = p.get("swipe_px_range", (150, 500))
                if scroll_size_range:
                    lo_t, hi_t = scroll_size_range
                amount = int(max(lo_t, min(hi_t, random.gauss((lo_t + hi_t) / 2, (hi_t - lo_t) / 4))))
                if direction == "up":
                    amount = -amount
                await self._touch_swipe(amount)
            else:
                # desktop: wheel events (trusted), archetype-sized
                try:
                    mx = random.randint(100, min(self.viewport_width - 100, 1200))
                    my = random.randint(100, min(self.viewport_height - 100, 800))
                    await self.page.mouse.move(mx, my, steps=random.randint(3, 8))
                except Exception:
                    pass
                mean = (lo + hi) / 2
                std = (hi - lo) / 4
                scroll_amount = int(max(lo, min(hi, random.gauss(mean, std))))
                if direction == "up":
                    scroll_amount = -scroll_amount
                try:
                    await self.page.mouse.wheel(0, scroll_amount)
                    self._scroll_px = getattr(self, "_scroll_px", 0) + abs(scroll_amount)  # v213 log
                except Exception:
                    try:
                        sign = "" if direction == "down" else "-"
                        await self.page.evaluate(f"window.scrollBy({{top: {sign}{abs(scroll_amount)}, behavior: 'smooth'}})")
                        self._scroll_px = getattr(self, "_scroll_px", 0) + abs(scroll_amount)
                    except Exception:
                        pass
                _pz = max(0.15, min(pause_hi, random.gauss((pause_lo + pause_hi) / 2, (pause_hi - pause_lo) / 4)))
                await asyncio.sleep(max(0.0, min(_pz, self._tleft())))  # v211: never past deadline

    @staticmethod
    def _fitts_movement_time(distance, target_width):
        if target_width <= 0:
            target_width = 10
        idx = math.log2(max(1, (2 * distance) / target_width))
        return 0.05 + 0.1 * idx

    async def _move_mouse_to(self, x1, y1, x2, y2, target_width=50):
        """Move mouse from (x1,y1) to (x2,y2) using Bezier curve with micro-tremor."""
        distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        if distance < 5:
            await self.page.mouse.move(x2, y2)
            return
        mt = self._fitts_movement_time(distance, target_width)
        steps = max(8, min(40, int(mt * 60)))
        path = self._bezier_path(x1, y1, x2, y2, steps)
        for x, y in path:
            tremor_x = random.gauss(0, 0.5)
            tremor_y = random.gauss(0, 0.5)
            try:
                await self.page.mouse.move(x + tremor_x, y + tremor_y)
            except Exception:
                pass
            progress = math.sqrt((x - x1) ** 2 + (y - y1) ** 2) / max(distance, 1)
            speed_factor = 1.0
            if progress < 0.2 or progress > 0.8:
                speed_factor = 1.5
            await asyncio.sleep(random.uniform(0.005, 0.015) * speed_factor)
        if random.random() > 0.5:
            overshoot = random.uniform(2, 8)
            angle = math.atan2(y2 - y1, x2 - x1)
            over_x = x2 + math.cos(angle) * overshoot
            over_y = y2 + math.sin(angle) * overshoot
            try:
                await self.page.mouse.move(over_x, over_y)
            except Exception:
                pass
            await asyncio.sleep(random.uniform(0.02, 0.05))
            correction_steps = random.randint(2, 4)
            for i in range(correction_steps + 1):
                t = i / correction_steps
                x = over_x + (x2 - over_x) * t + random.uniform(-0.8, 0.8)
                y = over_y + (y2 - over_y) * t + random.uniform(-0.8, 0.8)
                try:
                    await self.page.mouse.move(x, y)
                except Exception:
                    pass
                await asyncio.sleep(random.uniform(0.01, 0.03))

    async def _natural_mouse_movements(self, max_time=3.0):
        start = time.time()
        num_movements = random.randint(2, 4)
        cur_x = random.randint(100, min(self.viewport_width - 100, 800))
        cur_y = random.randint(100, min(self.viewport_height - 100, 600))
        for _ in range(num_movements):
            if time.time() - start > max_time:
                break
            target_x = random.randint(50, min(self.viewport_width - 50, 1200))
            target_y = random.randint(50, min(self.viewport_height - 50, 800))
            await self._move_mouse_to(cur_x, cur_y, target_x, target_y)
            cur_x, cur_y = target_x, target_y
            await asyncio.sleep(max(0.1, min(1.0, random.gauss(0.5, 0.15))))

    def _bezier_path(self, x1, y1, x2, y2, steps=None):
        if steps is None:
            steps = random.randint(15, 25)
        mid_x = (x1 + x2) / 2
        mid_y = (y1 + y2) / 2
        offset_x = random.randint(-100, 100)
        offset_y = random.randint(-80, 80)
        cp1_x = mid_x + offset_x
        cp1_y = mid_y + offset_y
        cp2_x = mid_x - offset_x * 0.5
        cp2_y = mid_y - offset_y * 0.5
        path = []
        for i in range(steps + 1):
            t = i / steps
            x = ((1 - t) ** 3 * x1 +
                 3 * (1 - t) ** 2 * t * cp1_x +
                 3 * (1 - t) * t ** 2 * cp2_x +
                 t ** 3 * x2)
            y = ((1 - t) ** 3 * y1 +
                 3 * (1 - t) ** 2 * t * cp1_y +
                 3 * (1 - t) * t ** 2 * cp2_y +
                 t ** 3 * y2)
            path.append((x, y))
        return path

    async def _random_clicks(self, style="single"):
        """v5.0 - Multiple random clicks on varied elements.
        v1.89 - Supports different click styles for per-visit variety.
        v1.87 CRITICAL: Avoid clicking on <a> tags that navigate away.
        Only click in-page elements (buttons, divs, images, cards).
        Clicking on ad banner <a> tags navigates away from the smartlink!"""
        try:
            # v1.87: Removed bare 'a' from selector — clicking <a> tags
            # navigates to another page (often an ad). Only keep [role=button]
            # and non-link elements for in-page interaction.
            # v1.89 CRITICAL: NO img, NO [onclick], NO span[class*='link']
            # img elements are often inside <a> → clicking = ad navigation
            # [onclick] handlers often open ad URLs → clicking = ad navigation
            # span[class*='link'] might be clickable ad text → ad navigation
            elements = await self.page.query_selector_all(
                "button, [role='button'], div[class*='card'], div[class*='item'], "
                "div[class*='box']"
            )
            if not elements:
                return
            num_to_click = min(random.randint(1, 3), len(elements))
            clicked_elements = set()
            for _ in range(num_to_click):
                available = [e for i, e in enumerate(elements[:25]) if i not in clicked_elements]
                if not available:
                    break
                elem = random.choice(available)
                idx = elements.index(elem)
                clicked_elements.add(idx)
                try:
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue
                    box = await elem.bounding_box()
                    if not box:
                        continue
                    target_x = box["x"] + box["width"] / 2
                    target_y = box["y"] + box["height"] / 2
                    if style == "miss_click":
                        target_x += random.uniform(15, 30) * random.choice([-1, 1])
                        target_y += random.uniform(10, 20) * random.choice([-1, 1])
                    elif style == "hover_then_click":
                        await self._move_mouse_to(
                            random.randint(100, min(self.viewport_width - 100, 800)),
                            random.randint(100, min(self.viewport_height - 100, 600)),
                            target_x + random.uniform(-5, 5),
                            target_y + random.uniform(-5, 5),
                            target_width=max(10, min(box["width"], box["height"]))
                        )
                        await asyncio.sleep(max(0.2, min(0.8, random.gauss(0.4, 0.15))))
                        target_x = box["x"] + box["width"] / 2 + random.uniform(-3, 3)
                        target_y = box["y"] + box["height"] / 2 + random.uniform(-3, 3)
                    target_x += random.uniform(-5, 5)
                    target_y += random.uniform(-5, 5)
                    target_w = max(10, min(box["width"], box["height"]))
                    if style != "hover_then_click":
                        start_x = random.randint(100, min(self.viewport_width - 100, 800))
                        start_y = random.randint(100, min(self.viewport_height - 100, 600))
                        await self._move_mouse_to(start_x, start_y, target_x, target_y, target_width=target_w)
                    await asyncio.sleep(max(0.05, min(0.35, random.gauss(0.15, 0.08))))
                    await self.page.mouse.click(target_x, target_y)
                    if style == "double_click" and random.random() > 0.4:
                        await asyncio.sleep(max(0.05, min(0.15, random.gauss(0.08, 0.03))))
                        await self.page.mouse.click(target_x, target_y)
                    await asyncio.sleep(max(0.3, min(1.8, random.gauss(0.8, 0.3))))
                except:
                    continue
        except:
            pass

    async def _random_taps(self):
        """v211 - REAL touch taps on mobile (trusted touchStart/touchEnd via
        CDP — pointerType 'touch', isTrusted). v1.88: variable touch hold.
        v1.87 CRITICAL: Avoid tapping <a> tags — navigates to ad pages."""
        try:
            elements = await self.page.query_selector_all(
                "button, [role='button'], div[class*='card']"
            )
            if not elements:
                return
            num_to_tap = min(random.randint(1, 2), len(elements))
            for _ in range(num_to_tap):
                if self._tleft() <= 0.4:   # v211: visit time is up
                    break
                elem = random.choice(elements[:15])
                try:
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue
                    box = await elem.bounding_box()
                    if not box:
                        continue
                    tap_x = box["x"] + box["width"] / 2 + random.uniform(-10, 10)
                    tap_y = box["y"] + box["height"] / 2 + random.uniform(-10, 10)
                    # v211: real finger tap — no mouse events on a phone
                    await self._touch_tap(tap_x, tap_y, hold=random.uniform(0.06, 0.18))
                    await asyncio.sleep(max(0.3, min(1.2, random.gauss(0.7, 0.15))))
                except:
                    continue
        except:
            pass

    async def _simulate_swipe(self):
        """v211 - Mobile swipe is now a REAL touch gesture (CDP, trusted
        events + momentum fling). The old version dragged with mouse events —
        a desktop-mouse gesture on a phone UA."""
        try:
            p = self.personality if getattr(self, "personality", None) else {}
            lo, hi = p.get("swipe_px_range", (180, 450))
            amount = int(random.uniform(lo, hi)) * random.choice([1, 1, 1, -1])  # mostly down
            await self._touch_swipe(amount)
        except:
            pass

