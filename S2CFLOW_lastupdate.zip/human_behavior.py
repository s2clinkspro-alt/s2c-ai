"""
Human Behavior Simulation Module — v1.89
Simulates realistic human browsing behavior with STRICT user-defined visit time.

v1.89 upgrades (Deep Random Per-Visit Behavior):
- RANDOMIZED PHASE ORDER: each visit shuffles the phase sequence so
  no two visits ever follow the same scroll->click->mouse->idle pattern
- 20 personality profiles (was 15) with micro-variations
- 7 scroll patterns: linear, zigzag, jump-to-end, slow-read, fast-skim,
  overshoot-correct, read-pause-read
- Random idle micro-behaviors injected between phases
- Variable phase time allocation (not fixed 45%/30%/25%)
- Click styles: single, double-click, hover-then-click, miss-click
- Per-visit entropy seed that subtly shifts ALL timing
- Real mouse.wheel() for all scrolling (no JS evaluate)

v5.0 upgrades (Enhanced Human Interaction):
- Form fillup simulation: detect input fields, type realistic name/email/phone
- Multiple random clicks (1-3 instead of 0-1) on varied elements
- Hover effects on elements before clicking (natural browsing)
- Multi-page navigation: click internal links, browse to another page
- Reading patterns: hover over text sections, pause on content
- Random scroll direction changes (up/down/up pattern)
- Varied click targets: buttons, links, images, divs (not just first 15)
- Form submit button detection + click after filling
"""

import random
import asyncio
import math
import time
from playwright.async_api import Page

_FIRST_NAMES = ["James","John","Robert","Michael","William","David","Sarah","Jennifer","Lisa","Nancy",
                "Emily","Jessica","Ashley","Amanda","Melissa","Stephanie","Rebecca","Laura","Anna","Brenda",
                "Raj","Amit","Priya","Sneha","Karan","Arjun","Pooja","Rahul","Anika","Sadia",
                "Carlos","Maria","Sofia","Diego","Lucas","Ana","Pedro","Camila","Javier","Valentina"]
_LAST_NAMES = ["Smith","Johnson","Brown","Davis","Wilson","Taylor","Anderson","Thomas","Jackson","White",
               "Khan","Ahmed","Hassan","Rahman","Islam","Chowdhury","Das","Bose","Roy","Sen",
               "Garcia","Martinez","Lopez","Gonzalez","Rodriguez","Perez","Sanchez","Ramirez","Cruz","Flores"]
_DOMAINS = ["gmail.com","yahoo.com","outlook.com","hotmail.com","mail.com","proton.me","icloud.com"]

def _random_name():
    return f"{random.choice(_FIRST_NAMES)} {random.choice(_LAST_NAMES)}"

def _random_email():
    name = random.choice(_FIRST_NAMES).lower()
    return f"{name}{random.randint(1,9999)}@{random.choice(_DOMAINS)}"

def _random_phone():
    return f"{''.join([str(random.randint(0,9)) for _ in range(10)])}"

def _random_text(min_len=5, max_len=20):
    words = ["hello","interested","great","awesome","nice","cool","love","want","need","like",
             "thanks","yes","sure","okay","fine","good","perfect","amazing","wonderful","excellent"]
    n = random.randint(min_len, max_len)
    return " ".join(random.choices(words, k=n))


class HumanBehavior:
    """Simulates human-like browsing behavior on a page."""

    def __init__(self, page: Page, fingerprint: dict):
        self.page = page
        self.fingerprint = fingerprint
        self.is_mobile = fingerprint["is_mobile"]
        self.viewport_width = fingerprint["screen"]["width"]
        self.viewport_height = fingerprint["screen"]["height"]

    async def _get_real_viewport(self):
        try:
            vp = await self.page.evaluate("() => ({w: window.innerWidth, h: window.innerHeight})")
            if vp and vp.get("w", 0) > 0:
                return vp["w"], vp["h"]
        except Exception:
            pass
        return self.viewport_width, self.viewport_height

    def _pick_personality(self):
        """v1.89 - Pick a random browsing personality for this visit.
        20 profiles with micro-variations. Each visit gets a DIFFERENT
        behavior profile so no two visits look alike."""
        profiles = [
            {"speed": "fast", "click_count": random.randint(1, 2), "scroll_count": random.randint(2, 4),
             "engagement": "low", "reading": "short", "form_likelihood": 0.2, "multi_page_likelihood": 0.3},
            {"speed": "medium", "click_count": random.randint(1, 3), "scroll_count": random.randint(3, 5),
             "engagement": "medium", "reading": "medium", "form_likelihood": 0.5, "multi_page_likelihood": 0.5},
            {"speed": "slow", "click_count": random.randint(2, 4), "scroll_count": random.randint(4, 7),
             "engagement": "high", "reading": "long", "form_likelihood": 0.6, "multi_page_likelihood": 0.7},
            {"speed": "fast", "click_count": random.randint(3, 5), "scroll_count": random.randint(5, 8),
             "engagement": "high", "reading": "short", "form_likelihood": 0.7, "multi_page_likelihood": 0.85},
            {"speed": "medium", "click_count": random.randint(0, 1), "scroll_count": random.randint(2, 4),
             "engagement": "low", "reading": "medium", "form_likelihood": 0.3, "multi_page_likelihood": 0.25},
            {"speed": "slow", "click_count": random.randint(2, 5), "scroll_count": random.randint(4, 8),
             "engagement": "high", "reading": "long", "form_likelihood": 0.8, "multi_page_likelihood": 0.8},
            {"speed": "fast", "click_count": random.randint(2, 4), "scroll_count": random.randint(3, 6),
             "engagement": "medium", "reading": "short", "form_likelihood": 0.4, "multi_page_likelihood": 0.5},
            {"speed": "medium", "click_count": random.randint(2, 3), "scroll_count": random.randint(3, 6),
             "engagement": "high", "reading": "medium", "form_likelihood": 0.6, "multi_page_likelihood": 0.65},
            {"speed": "slow", "click_count": random.randint(3, 5), "scroll_count": random.randint(6, 10),
             "engagement": "high", "reading": "long", "form_likelihood": 0.9, "multi_page_likelihood": 0.95},
            {"speed": "fast", "click_count": random.randint(0, 1), "scroll_count": random.randint(1, 2),
             "engagement": "low", "reading": "short", "form_likelihood": 0.1, "multi_page_likelihood": 0.15},
            {"speed": "medium", "click_count": random.randint(1, 3), "scroll_count": random.randint(2, 4),
             "engagement": "medium", "reading": "short", "form_likelihood": 0.3, "multi_page_likelihood": 0.75},
            {"speed": "slow", "click_count": random.randint(0, 1), "scroll_count": random.randint(5, 9),
             "engagement": "medium", "reading": "long", "form_likelihood": 0.2, "multi_page_likelihood": 0.35},
            {"speed": "medium", "click_count": random.randint(1, 2), "scroll_count": random.randint(2, 5),
             "engagement": "high", "reading": "medium", "form_likelihood": 0.85, "multi_page_likelihood": 0.4},
            {"speed": "slow", "click_count": random.randint(0, 2), "scroll_count": random.randint(3, 6),
             "engagement": "medium", "reading": "long", "form_likelihood": 0.3, "multi_page_likelihood": 0.2},
            {"speed": "medium", "click_count": random.randint(2, 4), "scroll_count": random.randint(3, 5),
             "engagement": "high", "reading": "short", "form_likelihood": 0.5, "multi_page_likelihood": 0.6},
            # 16. v1.89 NEW: Impatient
            {"speed": "fast", "click_count": random.randint(1, 3), "scroll_count": random.randint(3, 6),
             "engagement": "medium", "reading": "short", "form_likelihood": 0.15, "multi_page_likelihood": 0.2},
            # 17. v1.89 NEW: Careful reader
            {"speed": "slow", "click_count": random.randint(0, 2), "scroll_count": random.randint(2, 5),
             "engagement": "medium", "reading": "long", "form_likelihood": 0.4, "multi_page_likelihood": 0.45},
            # 18. v1.89 NEW: Window shopper
            {"speed": "fast", "click_count": random.randint(1, 2), "scroll_count": random.randint(5, 9),
             "engagement": "medium", "reading": "medium", "form_likelihood": 0.25, "multi_page_likelihood": 0.5},
            # 19. v1.89 NEW: Distracted
            {"speed": "medium", "click_count": random.randint(1, 3), "scroll_count": random.randint(2, 5),
             "engagement": "low", "reading": "long", "form_likelihood": 0.2, "multi_page_likelihood": 0.3},
            # 20. v1.89 NEW: Power user
            {"speed": "fast", "click_count": random.randint(3, 5), "scroll_count": random.randint(4, 8),
             "engagement": "high", "reading": "short", "form_likelihood": 0.5, "multi_page_likelihood": 0.7},
        ]
        return random.choice(profiles)

    def _get_speed_multiplier(self, speed):
        if speed == "fast":
            return random.uniform(0.4, 0.7)
        elif speed == "slow":
            return random.uniform(1.3, 1.8)
        else:
            return random.uniform(0.8, 1.2)

    def _get_reading_pause(self, reading, speed_mult=1.0):
        if reading == "short":
            base = random.uniform(0.3, 1.0)
        elif reading == "long":
            base = random.uniform(1.5, 3.5)
        else:
            base = random.uniform(0.8, 2.0)
        return base * speed_mult

    def _pick_scroll_pattern(self, personality):
        """v1.89 - Pick a random scroll pattern for this visit."""
        patterns = [
            "linear", "zigzag", "jump_to_end", "slow_read",
            "fast_skim", "overshoot", "read_pause_read",
        ]
        weights = {
            "linear": 3,
            "zigzag": 2,
            "jump_to_end": 2 if personality["speed"] == "fast" else 1,
            "slow_read": 3 if personality["reading"] == "long" else 1,
            "fast_skim": 3 if personality["speed"] == "fast" else 1,
            "overshoot": 2,
            "read_pause_read": 2 if personality["reading"] != "short" else 1,
        }
        pool = []
        for p in patterns:
            pool.extend([p] * weights.get(p, 1))
        return random.choice(pool)

    async def simulate_session(self, actions_config: dict):
        """v1.89 - Full human-like session with RANDOMIZED phase order."""
        self._actions_config = actions_config
        min_time = actions_config.get("min_visit_time", 5)
        max_time = actions_config.get("max_visit_time", 30)

        _mean = (min_time + max_time) / 2
        _std = (max_time - min_time) / 6
        target_duration = max(min_time, min(max_time, random.gauss(_mean, _std)))
        start = time.time()

        if target_duration <= 1:
            await asyncio.sleep(target_duration)
            return

        personality = self._pick_personality()
        speed_mult = self._get_speed_multiplier(personality["speed"])
        scroll_pattern = self._pick_scroll_pattern(personality)

        # v1.89: Random phase time allocation per visit
        scroll_alloc = random.uniform(0.25, 0.50)
        mouse_alloc = random.uniform(0.15, 0.35)
        click_alloc = random.uniform(0.10, 0.25)

        # v1.89: RANDOMIZE phase order
        phase_order = ["scroll", "mouse", "click"]
        random.shuffle(phase_order)

        try:
            await self.page.evaluate("""() => {
                if (window.getSelection) { window.getSelection().removeAllRanges(); }
                if (document.selection) { document.selection.empty(); }
                if (document.activeElement && document.activeElement !== document.body) {
                    document.activeElement.blur();
                }
            }""")
        except Exception:
            pass

        # Phase 1: Initial reading pause
        if actions_config.get("quick_impression", False):
            initial_pause = max(0.3, min(1.5, random.gauss(0.8, 0.3)))
        else:
            initial_pause = self._get_reading_pause(personality["reading"], speed_mult)
            initial_pause = max(0.5, min(4.0, initial_pause))
        await asyncio.sleep(initial_pause)

        await self._quick_ad_check(max_wait=min(1.5, target_duration * 0.1))

        elapsed = time.time() - start
        remaining = target_duration - elapsed
        if remaining <= 0.5:
            if remaining > 0: await asyncio.sleep(remaining)
            return

        # v1.89: Run phases in RANDOMIZED order
        phase_time_map = {"scroll": scroll_alloc, "mouse": mouse_alloc, "click": click_alloc}

        for phase_idx, phase_name in enumerate(phase_order):
            elapsed = time.time() - start
            remaining = target_duration - elapsed
            if remaining <= 1.0:
                break

            # v1.89: Inject random idle micro-behavior between phases (20% chance)
            if phase_idx > 0 and random.random() < 0.20 and remaining > 3:
                idle_time = random.uniform(0.5, min(2.0, remaining * 0.15))
                await self._random_idle_behavior(duration=idle_time)

            phase_budget = remaining * phase_time_map.get(phase_name, 0.3)

            if phase_name == "scroll" and actions_config.get("scroll", True) and phase_budget > 1:
                await self._execute_scroll_phase(personality, scroll_pattern, phase_budget, speed_mult)

            elif phase_name == "mouse" and actions_config.get("mouse_movement", True) and not self.is_mobile and phase_budget > 1:
                mouse_time = phase_budget * (1.5 if personality["engagement"] == "high" else 1.0)
                await self._natural_mouse_movements(max_time=mouse_time)
                hover_chance = {"low": 0.3, "medium": 0.5, "high": 0.8}.get(personality["engagement"], 0.5)
                if random.random() < hover_chance:
                    await self._hover_elements()

            elif phase_name == "mouse" and self.is_mobile and phase_budget > 1:
                await self._simulate_swipe()

            elif phase_name == "click" and actions_config.get("click", False) and phase_budget > 1:  # v1.89: respect dashboard off
                click_count = personality["click_count"]
                for click_round in range(click_count):
                    if time.time() - start > target_duration - 1:
                        break
                    click_style = random.choice(["single", "hover_then_click", "double_click", "miss_click"])
                    if self.is_mobile:
                        await self._random_taps()
                    else:
                        await self._random_clicks(style=click_style)
                    if click_round < click_count - 1:
                        pause = max(0.3, min(1.5, random.gauss(0.7, 0.2) * speed_mult))
                        await asyncio.sleep(pause)

            elapsed = time.time() - start
            remaining = target_duration - elapsed

        # v1.89: Phase 4 - Form fillup
        elapsed = time.time() - start
        remaining = target_duration - elapsed
        if actions_config.get("form_fill", False) and remaining > 3:
            if random.random() < personality["form_likelihood"]:
                filled = await self._fill_forms()
                if filled:
                    pause = max(0.5, min(2.0, random.gauss(1.0, 0.3) * speed_mult))
                    await asyncio.sleep(pause)

        # Phase 6: Multi-page navigation
        elapsed = time.time() - start
        remaining = target_duration - elapsed
        if actions_config.get("multi_page", False) and remaining > 4:  # v1.87: default OFF (was True bug)
            if random.random() < personality["multi_page_likelihood"]:
                pages_to_visit = {
                    "low": random.randint(1, 2),
                    "medium": random.randint(2, 3),
                    "high": random.randint(2, 5),
                }.get(personality["engagement"], 2)
                page_time_budget = remaining / (pages_to_visit + 1)
                for page_num in range(pages_to_visit):
                    if time.time() - start > target_duration - 2:
                        break
                    await self._navigate_internal_page(max_time=page_time_budget)

        # Phase 7: Final dwell - v1.89 randomized
        elapsed = time.time() - start
        remaining = target_duration - elapsed
        if remaining > 0:
            final_choice = random.random()
            if final_choice < 0.25 and remaining > 2:
                await self._natural_scroll(steps=random.randint(1, 2))
                elapsed = time.time() - start
                remaining = target_duration - elapsed
            elif final_choice < 0.40 and remaining > 2:
                await self._random_idle_behavior(duration=min(remaining, 2.0))
                elapsed = time.time() - start
                remaining = target_duration - elapsed
            if remaining > 0:
                await asyncio.sleep(remaining)

    async def _execute_scroll_phase(self, personality, pattern, budget, speed_mult):
        """v1.89 - Execute scroll using the visit's chosen scroll pattern."""
        scroll_steps = personality["scroll_count"]

        if pattern == "linear":
            await self._natural_scroll(steps=scroll_steps)
            if random.random() > 0.4 and budget > 2:
                pause = max(0.3, min(1.5, random.gauss(0.6, 0.2) * speed_mult))
                await asyncio.sleep(pause)
                up_steps = random.randint(1, min(3, scroll_steps // 2))
                await self._natural_scroll(direction="up", steps=up_steps)

        elif pattern == "zigzag":
            zigzag_steps = max(2, scroll_steps // 2)
            for i in range(min(4, zigzag_steps)):
                direction = "down" if i % 2 == 0 else "up"
                await self._natural_scroll(direction=direction, steps=random.randint(1, 2))
                await asyncio.sleep(max(0.2, min(0.8, random.gauss(0.4, 0.15) * speed_mult)))

        elif pattern == "jump_to_end":
            await self._natural_scroll(steps=max(3, scroll_steps), scroll_size_range=(300, 700))
            if random.random() > 0.3 and budget > 2:
                await asyncio.sleep(max(0.3, min(1.0, random.gauss(0.5, 0.2) * speed_mult)))
                await self._natural_scroll(direction="up", steps=random.randint(2, 4), scroll_size_range=(100, 300))

        elif pattern == "slow_read":
            for i in range(min(scroll_steps, 5)):
                await self._natural_scroll(steps=1, scroll_size_range=(50, 150))
                read_pause = max(0.5, min(3.0, random.gauss(1.2, 0.5) * speed_mult))
                await asyncio.sleep(read_pause)

        elif pattern == "fast_skim":
            await self._natural_scroll(steps=scroll_steps, scroll_size_range=(300, 600))
            await asyncio.sleep(max(0.1, min(0.4, random.gauss(0.2, 0.1) * speed_mult)))

        elif pattern == "overshoot":
            await self._natural_scroll(steps=max(2, scroll_steps), scroll_size_range=(250, 500))
            await asyncio.sleep(max(0.2, min(0.6, random.gauss(0.3, 0.15))))
            await self._natural_scroll(direction="up", steps=random.randint(1, 3), scroll_size_range=(50, 150))

        elif pattern == "read_pause_read":
            first_batch = max(1, scroll_steps // 2)
            await self._natural_scroll(steps=first_batch)
            read_pause = max(1.0, min(4.0, random.gauss(2.0, 0.7) * speed_mult))
            await asyncio.sleep(read_pause)
            remaining_steps = scroll_steps - first_batch
            if remaining_steps > 0:
                await self._natural_scroll(steps=remaining_steps)

    async def _fill_forms(self):
        """v5.0 - Detect form input fields and fill them with human typing."""
        try:
            inputs = await self.page.query_selector_all(
                "input[type='text'], input[type='email'], input[type='tel'], "
                "input[type='search'], input:not([type]), textarea, "
                "input[name*='name'], input[name*='email'], input[name*='phone'], "
                "input[placeholder*='name'], input[placeholder*='email'], input[placeholder*='phone']"
            )
            if not inputs:
                return False
            filled_count = 0
            max_fill = min(len(inputs), random.randint(2, 4))
            for i, inp in enumerate(inputs[:max_fill]):
                try:
                    is_visible = await inp.is_visible()
                    if not is_visible:
                        continue
                    box = await inp.bounding_box()
                    if not box or box["width"] < 20 or box["height"] < 10:
                        continue
                    input_type = await inp.evaluate(
                        """el => ({
                            type: el.type || 'text',
                            name: (el.name || '').toLowerCase(),
                            placeholder: (el.placeholder || '').toLowerCase(),
                            id: (el.id || '').toLowerCase()
                        })"""
                    )
                    field_text = self._guess_field_value(input_type)
                    if not field_text:
                        continue
                    target_x = box["x"] + box["width"] / 2 + random.uniform(-5, 5)
                    target_y = box["y"] + box["height"] / 2 + random.uniform(-3, 3)
                    start_x = random.randint(50, min(self.viewport_width - 50, 800))
                    start_y = random.randint(50, min(self.viewport_height - 50, 600))
                    await self._move_mouse_to(start_x, start_y, target_x, target_y,
                                             target_width=max(10, min(box["width"], box["height"])))
                    await asyncio.sleep(max(0.1, min(0.4, random.gauss(0.2, 0.08))))
                    await self.page.mouse.click(target_x, target_y)
                    await asyncio.sleep(max(0.1, min(0.3, random.gauss(0.15, 0.05))))
                    await self._human_type(inp, field_text)
                    filled_count += 1
                    await asyncio.sleep(max(0.2, min(1.0, random.gauss(0.5, 0.15))))
                except Exception:
                    continue
            return filled_count > 0
        except Exception:
            return False

    def _guess_field_value(self, input_type):
        t = input_type.get("type", "text")
        name = input_type.get("name", "")
        placeholder = input_type.get("placeholder", "")
        combined = f"{name} {placeholder} {t}"
        if "email" in combined:
            return _random_email()
        elif "phone" in combined or "tel" in combined:
            return _random_phone()
        elif "name" in combined:
            return _random_name()
        elif "search" in combined or "query" in combined:
            return _random_text(min_len=2, max_len=5)
        elif t == "textarea":
            return _random_text(min_len=5, max_len=15)
        else:
            return _random_text(min_len=3, max_len=8)

    async def _human_type(self, element, text):
        try:
            await element.click()
            await asyncio.sleep(random.uniform(0.1, 0.3))
            for char in text:
                await self.page.keyboard.type(char)
                delay = max(0.03, min(0.15, random.gauss(0.07, 0.03)))
                await asyncio.sleep(delay)
            if random.random() > 0.6:
                await asyncio.sleep(random.uniform(0.3, 0.8))
        except Exception:
            pass

    async def _click_submit_button(self):
        try:
            buttons = await self.page.query_selector_all(
                "button[type='submit'], input[type='submit'], "
                "button:has-text('Submit'), button:has-text('Send'), "
                "button:has-text('OK'), button:has-text('Continue'), "
                "a:has-text('Submit'), a:has-text('Send')"
            )
            if buttons:
                btn = buttons[0]
                is_visible = await btn.is_visible()
                if is_visible:
                    box = await btn.bounding_box()
                    if box:
                        target_x = box["x"] + box["width"] / 2
                        target_y = box["y"] + box["height"] / 2
                        await self._move_mouse_to(
                            random.randint(100, 400),
                            random.randint(100, 300),
                            target_x, target_y,
                            target_width=max(10, min(box["width"], box["height"]))
                        )
                        await asyncio.sleep(random.uniform(0.1, 0.3))
                        await self.page.mouse.click(target_x, target_y)
                        return True
        except Exception:
            pass
        return False

    async def _hover_elements(self):
        """v5.0 - Hover over random elements on the page."""
        try:
            elements = await self.page.query_selector_all(
                "a, button, img, div[class*='card'], div[class*='item'], "
                "span[class*='title'], h1, h2, h3, p"
            )
            if not elements:
                return
            num_hovers = random.randint(1, 3)
            for _ in range(num_hovers):
                elem = random.choice(elements[:20])
                try:
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue
                    box = await elem.bounding_box()
                    if not box:
                        continue
                    target_x = box["x"] + box["width"] / 2 + random.uniform(-10, 10)
                    target_y = box["y"] + box["height"] / 2 + random.uniform(-5, 5)
                    await self._move_mouse_to(
                        random.randint(50, min(self.viewport_width - 50, 600)),
                        random.randint(50, min(self.viewport_height - 50, 400)),
                        target_x, target_y,
                        target_width=max(10, min(box["width"], box["height"]))
                    )
                    await asyncio.sleep(max(0.3, min(1.5, random.gauss(0.6, 0.3))))
                except Exception:
                    continue
        except Exception:
            pass

    async def _navigate_internal_page(self, max_time=5.0):
        await self._navigate_internal_page_impl(max_time)

    async def _navigate_internal_page_impl(self, max_time=5.0):
        try:
            # v1.87 CRITICAL: Only navigate to SAME-ORIGIN links.
            # Never click external links (ad banners, sponsored content, etc.)
            # This prevents the bot from clicking on ads and navigating away.
            current_url = self.page.url
            from urllib.parse import urlparse
            current_host = urlparse(current_url).hostname or ""
            links = await self.page.query_selector_all("a[href]")
            if not links:
                return
            internal_links = []
            for link in links[:30]:
                try:
                    href = await link.get_attribute("href")
                    if not href or href.startswith(("javascript:", "mailto:", "tel:", "#")):
                        continue
                    # Check if same-origin (internal navigation only)
                    link_host = urlparse(href).hostname or ""
                    if link_host and link_host != current_host and not link_host.endswith("." + current_host):
                        continue  # External link — skip (could be ad)
                    # Skip links that look like ads
                    href_lower = href.lower()
                    if any(ad_kw in href_lower for ad_kw in [
                        "doubleclick", "googleads", "googlesyndication",
                        "adsterra", "monetag", "propeller", "popads",
                        "taboola", "mgid", "adskeeper", "popcash",
                        "/ad/", "/ads/", "/banner", "/redirect/",
                        "affiliate", "sponsored", "promo"
                    ]):
                        continue
                    is_visible = await link.is_visible()
                    if is_visible:
                        internal_links.append(link)
                except Exception:
                    continue
            if not internal_links:
                return
            link = random.choice(internal_links[:10])
            box = await link.bounding_box()
            if not box:
                return
            target_x = box["x"] + box["width"] / 2 + random.uniform(-5, 5)
            target_y = box["y"] + box["height"] / 2 + random.uniform(-3, 3)
            if not self.is_mobile:
                start_x = random.randint(50, min(self.viewport_width - 50, 600))
                start_y = random.randint(50, min(self.viewport_height - 50, 400))
                await self._move_mouse_to(start_x, start_y, target_x, target_y,
                                         target_width=max(10, min(box["width"], box["height"])))
                await asyncio.sleep(random.uniform(0.1, 0.4))
            else:
                await self.page.mouse.move(target_x, target_y)
                await asyncio.sleep(random.uniform(0.05, 0.2))
            await self.page.mouse.click(target_x, target_y)
            try:
                await self.page.wait_for_load_state("domcontentloaded", timeout=8000)
            except:
                pass
            browse_time = min(max_time * 0.6, random.uniform(2.0, 5.0))
            await asyncio.sleep(browse_time)
            if random.random() > 0.3:
                await self._natural_scroll(steps=random.randint(1, 3))
            if random.random() > 0.5 and self._actions_config.get("click", False):  # v1.87: default OFF
                if self.is_mobile:
                    await self._random_taps()
                else:
                    await self._random_clicks()
            if not self.is_mobile and random.random() > 0.6:
                await self._hover_elements()
            remaining_browse = max(0, browse_time - 1.5)
            if remaining_browse > 0:
                await asyncio.sleep(remaining_browse)
        except Exception:
            pass

    async def _random_idle_behavior(self, duration=2.0):
        """v5.3.1 - Random idle micro-behaviors that real users do.
        v1.89 - Expanded with more behaviors."""
        try:
            behaviors = []
            if not self.is_mobile:
                behaviors.extend(['mouse_wander', 'hover_random', 'slight_scroll',
                                  'text_select', 'viewport_stare', 'micro_adjust'])
            behaviors.extend(['pause', 'tab_peek'])
            num_behaviors = random.randint(1, 3)
            time_per = duration / num_behaviors
            for _ in range(num_behaviors):
                behavior = random.choice(behaviors)
                if behavior == 'mouse_wander':
                    x = random.randint(100, min(self.viewport_width - 100, 800))
                    y = random.randint(100, min(self.viewport_height - 100, 600))
                    await self.page.mouse.move(x, y, steps=random.randint(5, 15))
                    await asyncio.sleep(random.uniform(0.3, 0.8) * time_per)
                elif behavior == 'hover_random':
                    try:
                        elements = await self.page.query_selector_all("a, button, div, span, p")
                        if elements:
                            el = random.choice(elements[:20])
                            box = await el.bounding_box()
                            if box and box["width"] > 20:
                                await self.page.mouse.move(
                                    box["x"] + box["width"]/2 + random.uniform(-10, 10),
                                    box["y"] + box["height"]/2 + random.uniform(-5, 5),
                                    steps=random.randint(3, 10)
                                )
                                await asyncio.sleep(random.uniform(0.2, 0.6) * time_per)
                    except: pass
                elif behavior == 'slight_scroll':
                    delta = random.choice([50, -50, 100, -30, 80])
                    await self.page.mouse.wheel(0, delta)
                    await asyncio.sleep(random.uniform(0.3, 0.7) * time_per)
                elif behavior == 'tab_peek':
                    await asyncio.sleep(random.uniform(0.5, 1.5) * time_per)
                elif behavior == 'text_select':
                    try:
                        await self.page.evaluate("""() => {
                            const sel = window.getSelection();
                            if (sel && document.body) {
                                const range = document.createRange();
                                const ps = document.querySelectorAll('p, h1, h2, h3, span');
                                if (ps.length > 0) {
                                    const el = ps[Math.floor(Math.random() * Math.min(ps.length, 10))];
                                    range.selectNodeContents(el);
                                    sel.removeAllRanges();
                                    sel.addRange(range);
                                }
                            }
                        }""")
                        await asyncio.sleep(random.uniform(0.3, 0.8) * time_per)
                    except: pass
                elif behavior == 'viewport_stare':
                    try:
                        stare_x = random.randint(200, min(self.viewport_width - 200, 1000))
                        stare_y = random.randint(150, min(self.viewport_height - 150, 600))
                        await self.page.mouse.move(stare_x, stare_y, steps=random.randint(3, 6))
                    except: pass
                    await asyncio.sleep(random.uniform(0.5, 1.5) * time_per)
                elif behavior == 'micro_adjust':
                    try:
                        cur_x = random.randint(100, min(self.viewport_width - 100, 800))
                        cur_y = random.randint(100, min(self.viewport_height - 100, 600))
                        adj_x = cur_x + random.randint(-20, 20)
                        adj_y = cur_y + random.randint(-15, 15)
                        await self.page.mouse.move(adj_x, adj_y, steps=random.randint(2, 5))
                    except: pass
                    await asyncio.sleep(random.uniform(0.2, 0.5) * time_per)
                else:
                    await asyncio.sleep(random.uniform(0.3, 1.0) * time_per)
        except Exception:
            pass

    async def _quick_ad_check(self, max_wait=1.5):
        # v1.89: Only scroll to ads if scroll is enabled in config
        _scroll_enabled = getattr(self, '_actions_config', {}).get("scroll", True)
        try:
            await self.page.wait_for_load_state("networkidle", timeout=int(max_wait * 1000))
        except Exception:
            pass
        if not _scroll_enabled:
            return  # Scroll disabled — don't scroll to ads
        try:
            ad_info = await self.page.evaluate("""() => {
                const adKw = ['ad','google','doubleclick','adsterra','monetag','propeller',
                    'taboola','mgid','syndication','adsbygoogle','popads','popcash','adskeeper'];
                const iframes = document.querySelectorAll('iframe');
                for (const f of iframes) {
                    const s = f.src || '';
                    for (const kw of adKw) {
                        if (s.includes(kw)) {
                            const r = f.getBoundingClientRect();
                            return {
                                found: true,
                                visible: r.width > 10 && r.height > 10,
                                width: r.width,
                                height: r.height,
                                top: r.top,
                                left: r.left
                            };
                        }
                    }
                }
                return {found: false};
            }""")
            if ad_info and ad_info.get("found") and ad_info.get("visible"):
                if ad_info.get("top", 0) > self.viewport_height * 0.7:
                    scroll_target = int(ad_info.get("top", 0) - self.viewport_height * 0.3)
                    try:
                        await self.page.evaluate(f"window.scrollTo({{top: {scroll_target}, behavior: 'smooth'}})")
                        await asyncio.sleep(0.5)
                    except:
                        pass
        except Exception:
            pass

    async def _natural_scroll(self, direction="down", steps=None, scroll_size_range=None):
        """v1.88 - Real mouse wheel scrolling with natural movement.
        v1.89 - Accepts scroll_size_range for pattern-specific scroll amounts."""
        if steps is None:
            steps = random.randint(3, 8)
        if scroll_size_range is None:
            scroll_size_range = (50, 800)
        for i in range(steps):
            if not self.is_mobile:
                try:
                    mx = random.randint(100, min(self.viewport_width - 100, 1200))
                    my = random.randint(100, min(self.viewport_height - 100, 800))
                    await self.page.mouse.move(mx, my, steps=random.randint(3, 8))
                except Exception:
                    pass
            lo, hi = scroll_size_range
            mean = (lo + hi) / 2
            std = (hi - lo) / 4
            scroll_amount = int(max(lo, min(hi, random.gauss(mean, std))))
            if direction == "up":
                scroll_amount = -scroll_amount
            try:
                await self.page.mouse.wheel(0, scroll_amount)
            except Exception:
                try:
                    sign = "" if direction == "down" else "-"
                    await self.page.evaluate(f"window.scrollBy({{top: {sign}{abs(scroll_amount)}, behavior: 'smooth'}})")
                except Exception:
                    pass
            await asyncio.sleep(max(0.2, min(1.5, random.gauss(0.6, 0.25))))

    @staticmethod
    def _fitts_movement_time(distance, target_width):
        if target_width <= 0:
            target_width = 10
        idx = math.log2(max(1, (2 * distance) / target_width))
        return 0.05 + 0.1 * idx

    async def _move_mouse_to(self, x1, y1, x2, y2, target_width=50):
        """Move mouse from (x1,y1) to (x2,y2) using Bezier curve with micro-tremor."""
        distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        if distance < 5:
            await self.page.mouse.move(x2, y2)
            return
        mt = self._fitts_movement_time(distance, target_width)
        steps = max(8, min(40, int(mt * 60)))
        path = self._bezier_path(x1, y1, x2, y2, steps)
        for x, y in path:
            tremor_x = random.gauss(0, 0.5)
            tremor_y = random.gauss(0, 0.5)
            try:
                await self.page.mouse.move(x + tremor_x, y + tremor_y)
            except Exception:
                pass
            progress = math.sqrt((x - x1) ** 2 + (y - y1) ** 2) / max(distance, 1)
            speed_factor = 1.0
            if progress < 0.2 or progress > 0.8:
                speed_factor = 1.5
            await asyncio.sleep(random.uniform(0.005, 0.015) * speed_factor)
        if random.random() > 0.5:
            overshoot = random.uniform(2, 8)
            angle = math.atan2(y2 - y1, x2 - x1)
            over_x = x2 + math.cos(angle) * overshoot
            over_y = y2 + math.sin(angle) * overshoot
            try:
                await self.page.mouse.move(over_x, over_y)
            except Exception:
                pass
            await asyncio.sleep(random.uniform(0.02, 0.05))
            correction_steps = random.randint(2, 4)
            for i in range(correction_steps + 1):
                t = i / correction_steps
                x = over_x + (x2 - over_x) * t + random.uniform(-0.8, 0.8)
                y = over_y + (y2 - over_y) * t + random.uniform(-0.8, 0.8)
                try:
                    await self.page.mouse.move(x, y)
                except Exception:
                    pass
                await asyncio.sleep(random.uniform(0.01, 0.03))

    async def _natural_mouse_movements(self, max_time=3.0):
        start = time.time()
        num_movements = random.randint(2, 4)
        cur_x = random.randint(100, min(self.viewport_width - 100, 800))
        cur_y = random.randint(100, min(self.viewport_height - 100, 600))
        for _ in range(num_movements):
            if time.time() - start > max_time:
                break
            target_x = random.randint(50, min(self.viewport_width - 50, 1200))
            target_y = random.randint(50, min(self.viewport_height - 50, 800))
            await self._move_mouse_to(cur_x, cur_y, target_x, target_y)
            cur_x, cur_y = target_x, target_y
            await asyncio.sleep(max(0.1, min(1.0, random.gauss(0.5, 0.15))))

    def _bezier_path(self, x1, y1, x2, y2, steps=None):
        if steps is None:
            steps = random.randint(15, 25)
        mid_x = (x1 + x2) / 2
        mid_y = (y1 + y2) / 2
        offset_x = random.randint(-100, 100)
        offset_y = random.randint(-80, 80)
        cp1_x = mid_x + offset_x
        cp1_y = mid_y + offset_y
        cp2_x = mid_x - offset_x * 0.5
        cp2_y = mid_y - offset_y * 0.5
        path = []
        for i in range(steps + 1):
            t = i / steps
            x = ((1 - t) ** 3 * x1 +
                 3 * (1 - t) ** 2 * t * cp1_x +
                 3 * (1 - t) * t ** 2 * cp2_x +
                 t ** 3 * x2)
            y = ((1 - t) ** 3 * y1 +
                 3 * (1 - t) ** 2 * t * cp1_y +
                 3 * (1 - t) * t ** 2 * cp2_y +
                 t ** 3 * y2)
            path.append((x, y))
        return path

    async def _random_clicks(self, style="single"):
        """v5.0 - Multiple random clicks on varied elements.
        v1.89 - Supports different click styles for per-visit variety.
        v1.87 CRITICAL: Avoid clicking on <a> tags that navigate away.
        Only click in-page elements (buttons, divs, images, cards).
        Clicking on ad banner <a> tags navigates away from the smartlink!"""
        try:
            # v1.87: Removed bare 'a' from selector — clicking <a> tags
            # navigates to another page (often an ad). Only keep [role=button]
            # and non-link elements for in-page interaction.
            # v1.89 CRITICAL: NO img, NO [onclick], NO span[class*='link']
            # img elements are often inside <a> → clicking = ad navigation
            # [onclick] handlers often open ad URLs → clicking = ad navigation
            # span[class*='link'] might be clickable ad text → ad navigation
            elements = await self.page.query_selector_all(
                "button, [role='button'], div[class*='card'], div[class*='item'], "
                "div[class*='box']"
            )
            if not elements:
                return
            num_to_click = min(random.randint(1, 3), len(elements))
            clicked_elements = set()
            for _ in range(num_to_click):
                available = [e for i, e in enumerate(elements[:25]) if i not in clicked_elements]
                if not available:
                    break
                elem = random.choice(available)
                idx = elements.index(elem)
                clicked_elements.add(idx)
                try:
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue
                    box = await elem.bounding_box()
                    if not box:
                        continue
                    target_x = box["x"] + box["width"] / 2
                    target_y = box["y"] + box["height"] / 2
                    if style == "miss_click":
                        target_x += random.uniform(15, 30) * random.choice([-1, 1])
                        target_y += random.uniform(10, 20) * random.choice([-1, 1])
                    elif style == "hover_then_click":
                        await self._move_mouse_to(
                            random.randint(100, min(self.viewport_width - 100, 800)),
                            random.randint(100, min(self.viewport_height - 100, 600)),
                            target_x + random.uniform(-5, 5),
                            target_y + random.uniform(-5, 5),
                            target_width=max(10, min(box["width"], box["height"]))
                        )
                        await asyncio.sleep(max(0.2, min(0.8, random.gauss(0.4, 0.15))))
                        target_x = box["x"] + box["width"] / 2 + random.uniform(-3, 3)
                        target_y = box["y"] + box["height"] / 2 + random.uniform(-3, 3)
                    target_x += random.uniform(-5, 5)
                    target_y += random.uniform(-5, 5)
                    target_w = max(10, min(box["width"], box["height"]))
                    if style != "hover_then_click":
                        start_x = random.randint(100, min(self.viewport_width - 100, 800))
                        start_y = random.randint(100, min(self.viewport_height - 100, 600))
                        await self._move_mouse_to(start_x, start_y, target_x, target_y, target_width=target_w)
                    await asyncio.sleep(max(0.05, min(0.35, random.gauss(0.15, 0.08))))
                    await self.page.mouse.click(target_x, target_y)
                    if style == "double_click" and random.random() > 0.4:
                        await asyncio.sleep(max(0.05, min(0.15, random.gauss(0.08, 0.03))))
                        await self.page.mouse.click(target_x, target_y)
                    await asyncio.sleep(max(0.3, min(1.8, random.gauss(0.8, 0.3))))
                except:
                    continue
        except:
            pass

    async def _random_taps(self):
        """v5.0 - Multiple random taps on mobile.
        v1.88 - Variable touch hold duration.
        v1.87 CRITICAL: Avoid tapping <a> tags — navigates to ad pages."""
        try:
            # v1.89: Removed img + [onclick] — these trigger ad navigation
            elements = await self.page.query_selector_all(
                "button, [role='button'], div[class*='card']"
            )
            if not elements:
                return
            num_to_tap = min(random.randint(1, 2), len(elements))
            for _ in range(num_to_tap):
                elem = random.choice(elements[:15])
                try:
                    is_visible = await elem.is_visible()
                    if not is_visible:
                        continue
                    box = await elem.bounding_box()
                    if not box:
                        continue
                    tap_x = box["x"] + box["width"] / 2 + random.uniform(-10, 10)
                    tap_y = box["y"] + box["height"] / 2 + random.uniform(-10, 10)
                    await self.page.mouse.move(tap_x, tap_y)
                    await self.page.mouse.down()
                    await asyncio.sleep(random.uniform(0.06, 0.18))
                    await self.page.mouse.up()
                    await asyncio.sleep(max(0.3, min(1.2, random.gauss(0.7, 0.15))))
                except:
                    continue
        except:
            pass

    async def _simulate_swipe(self):
        """v1.88 - Simulate a mobile swipe gesture with natural acceleration."""
        try:
            start_y = random.randint(self.viewport_height * 2 // 3, self.viewport_height - 50)
            end_y = random.randint(50, self.viewport_height // 3)
            x = random.randint(self.viewport_width // 4, self.viewport_width * 3 // 4)
            await self.page.mouse.move(x, start_y)
            await self.page.mouse.down()
            await asyncio.sleep(random.uniform(0.05, 0.15))
            steps = random.randint(6, 12)
            drift_x = random.uniform(-8, 8)
            for i in range(steps):
                progress = (i + 1) / steps
                eased = 0.5 * (1 - (1 - 2 * progress) ** 2) if progress < 0.5 else 0.5 + 0.5 * (2 * progress - 1) ** 2
                y = start_y + (end_y - start_y) * eased
                x_drift = x + drift_x * eased + random.uniform(-2, 2)
                await self.page.mouse.move(int(x_drift), int(y))
                speed = random.uniform(0.015, 0.05) + 0.03 * (1 - abs(0.5 - progress) * 2)
                await asyncio.sleep(speed)
            await asyncio.sleep(random.uniform(0.03, 0.1))
            await self.page.mouse.up()
        except:
            pass
