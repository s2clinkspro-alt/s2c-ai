# Visitor Bot v14.0

## Quick Start

### Windows (RDP)
Double-click `START.bat`  
OR run in CMD: `python setup.py`

### Linux / VPS
```bash
bash start.sh
```

## First Run
- Python packages auto-install হবে
- Playwright Chromium auto-download হবে (~150MB)
- Setup শেষে bot automatically start হবে
- Dashboard: http://localhost:5000

## Next Runs
- `START.bat` → directly bot start হবে (setup skip)
- Setup আবার করতে: `.setup_done` file delete করো

## Requirements
- Python 3.9+ (Windows: auto-install হবে)
- Internet connection (first run only)
