"""Manual profile opener — one "Open" button per account on the dashboard.

Opens the SAME persistent profile the bot uses (same cookies, same stable
fingerprint seed, same proxy) so Facebook sees one consistent device per
account. The browser stays open until the USER closes it — the bot never
closes it automatically. Each open runs in its own thread/event loop.

Anti-"multiple account detected" rules this module enforces:
  * one browser per account at a time (double click = focus, not 2nd launch)
  * refuses to open while the bot is running that same account
  * same fingerprint seed ("fbl_<c_user>") + same proxy as the bot run
  * persistent profile dir (cookies/localStorage stay between opens)
  * staggered window positions, no cookie re-injection over a live session
"""
import asyncio
import os
import threading
import time

import accounts_db
from browser_manager import (open_profile, load_proxies, verify_login,
                             find_system_chrome)

_lock = threading.Lock()
# acc_id -> {"thread": Thread, "state": "opening|open|closed|error", "msg": str,
#            "since": ts, "ctx": BrowserContext|None, "loop": loop|None}
_sessions = {}


def _set(acc_id, **kw):
    with _lock:
        _sessions.setdefault(acc_id, {}).update(kw)


def status() -> dict:
    """{acc_id: {"state":..., "msg":...}} for the dashboard."""
    with _lock:
        return {k: {"state": v.get("state", ""), "msg": v.get("msg", ""),
                    "since": v.get("since", 0)} for k, v in _sessions.items()}


def is_open(acc_id) -> bool:
    with _lock:
        return _sessions.get(acc_id, {}).get("state") in ("opening", "open")


def _proxy_for(account, proxies):
    from browser_manager import proxy_for_account
    return proxy_for_account(account, proxies)


async def _run(acc_id, log):
    account = next((a for a in accounts_db.all_accounts() if a["id"] == acc_id), None)
    if not account:
        _set(acc_id, state="error", msg="account not found")
        return
    c_user = account.get("c_user", "?")
    tag = f"[manual] {account.get('identifier') or c_user}"

    pdir = accounts_db.profile_dir_for(c_user)
    os.makedirs(pdir, exist_ok=True)
    acc = dict(account, profile_dir=pdir)

    pw = br = None
    try:
        _set(acc_id, state="opening", msg="ব্রাউজার খুলছি…", since=time.time())
        proxies = load_proxies()
        proxy_line = _proxy_for(acc, proxies)
        log(f"{tag} 🖱 manual open — persistent profile, stable fingerprint"
            + (f", proxy #{(proxies.index(proxy_line) + 1)}" if proxy_line else ", no proxy"))
        pw, br, ctx, page, fp = await open_profile(
            acc, proxy_line=proxy_line, headless=False, log=log)

        # Land on Facebook. If the saved session is still alive Facebook logs in
        # by itself; the cookies were only re-added for a fresh profile.
        try:
            await page.goto("https://www.facebook.com/", wait_until="domcontentloaded",
                            timeout=90_000)
        except Exception as e:
            log(f"{tag} ⚠ load: {str(e)[:70]}")

        _set(acc_id, state="open", msg="খোলা আছে — কাজ শেষে নিজে ব্রাউজার বন্ধ করো",
             ctx=br)
        log(f"{tag} ✅ browser open — বন্ধ করা তোমার হাতে (bot auto-close করবে না)")

        # Block until the USER closes the window/browser. Never closes it itself.
        closed = asyncio.Event()
        br.on("close", lambda *_: closed.set())
        # persistent context also closes when its last page closes on some builds
        await closed.wait()
        log(f"{tag} 🔒 browser closed by user")
        _set(acc_id, state="closed", msg="বন্ধ করা হয়েছে", ctx=None)
    except Exception as e:
        log(f"{tag} ❌ manual open failed: {str(e)[:120]}")
        _set(acc_id, state="error", msg=str(e)[:120], ctx=None)
    finally:
        try:
            if pw is not None:
                await pw.stop()
        except Exception:
            pass


def open_account(acc_id, log=print, bot_running_check=None):
    """Start a manual session. Returns (ok, message)."""
    if bot_running_check and bot_running_check():
        return False, "bot চলছে — এখন manual open করলে একই অ্যাকাউন্ট দুইবার ধরা পড়তে পারে। Stop দিয়ে আবার চেষ্টা করো"
    with _lock:
        cur = _sessions.get(acc_id, {})
        if cur.get("state") in ("opening", "open"):
            return False, "এই প্রোফাইল ইতিমধ্যে খোলা আছে — টাস্কবারে ব্রাউজারটা দেখো"
        _sessions[acc_id] = {"state": "opening", "msg": "starting…", "since": time.time()}

    def _thread():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(_run(acc_id, log))
        finally:
            try:
                loop.close()
            except Exception:
                pass

    t = threading.Thread(target=_thread, daemon=True, name=f"manual-{acc_id[:6]}")
    t.start()
    return True, "opening"
