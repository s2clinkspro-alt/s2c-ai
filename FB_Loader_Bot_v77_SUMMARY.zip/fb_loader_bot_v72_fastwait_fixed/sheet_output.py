"""Invite-link output system — Excel (openpyxl) + Google Sheet (placeholder).

v73.1: PROTIBAR RUN E ALADA FILE — output/invite_results_YYYY-MM-DD_HH-MM-SS.xlsx
       (run shuru holei notun file name lock hoy, puro run jabe oi file e —
        ager run er file kokhono overwrite/replace hoy na)

Tab layout:
  • Buyer   — BM Name | BM ID | Invite Link (prottek BM er 1st collected
              link) — buyer ke pathanor file (design fixed, thik ase)
  • Backup  — sob link, ACCOUNT-WISE visual grouping:
        - FB ID box: same account e same halka color, alada account e
          alada color (chokhe-i account alada bojha jay)
        - BM Name + BM ID box: prottek BM group e (3 row) alada halka
          color — BM group gulo alada bojha jay
        - BM group er majhe 1 line gap, notun FB ID er age 2 line gap
        - Link column e kono color na
  • Summary — SEI RUN er protita ID: BM count, link count, status r
              PROBLEM red box e (checkpoint / suspend / locked / ...)
              problem detected hole

Google Sheet module: LATER (output_settings.gsheet_url) — placeholder.
"""
import os
import threading
import time

import accounts_db

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(APP_ROOT, "output")

_wlock = threading.Lock()

# ── per-run state ────────────────────────────────────────────────────────────
_RUN = {"file": None, "ids": None}     # run shuru holei set hoy


def set_invite_target(n):
    """Engine run shuru hole target invite count set kore — Summary er
    Bangla 'kajer obostha' column e link X/TARGET hisheb dekhabe."""
    try:
        _RUN["invite_target"] = max(0, int(n or 0))
    except Exception:
        pass


def _raw_bms_of(acc):
    """Raw BM list — page field SOHO (bms_of page strip kore dey)."""
    bd = acc.get("business_data") or {}
    out, seen = [], set()
    for b in (bd.get("bms") or []):
        if isinstance(b, dict) and b.get("id") and b["id"] not in seen:
            seen.add(b["id"])
            out.append(b)
    return out


def _pages_of(acc):
    """Closing-time e ei ID te total koyta page ache + name gulo."""
    pages = []
    for b in _raw_bms_of(acc):
        p = b.get("page")
        nm = (p.get("name") if isinstance(p, dict) else str(p or "")).strip()
        if nm and nm.lower() not in ("none", "false", "0"):
            pages.append(nm)
    return pages


def _bangla_work_status(acc):
    """SEI profile er prottek BM er kajer obostha — EKDUM Bangla te.
    Ki hoyeche, ki baki, ki pore abar try korbe — client er exact cha:
    'page create hoynai pore try korbe' erokom line BM er line e."""
    invs = _real_invites(acc)
    bms = _raw_bms_of(acc)          # page field lagbe
    target = _RUN.get("invite_target") or 0
    prob = _problem_of(acc)
    lines = []
    if prob:
        lines.append("⛔ " + prob["label"] + " — এই আইডিতে আর কাজ হবে না")
    if not bms:
        lines.append("কোনো BM নেই")
        return "\n".join(lines)
    for b in bms:
        nm = str(b.get("name") or b.get("id") or "?")
        bid = str(b.get("id") or "")
        p = b.get("page")
        pnm = (p.get("name") if isinstance(p, dict) else str(p or "")).strip()
        got = sum(1 for i in invs if str(i.get("bm_id") or "") == bid)
        if pnm and pnm.lower() not in ("none", "false", "0"):
            ptxt = "পেজ তৈরি: '" + pnm + "'"
        else:
            ptxt = "পেজ তৈরি হয়নি — পরে ট্রাই করবে"
        if target and got >= target:
            ltxt = f"লিংক {got}/{target} ✓ সম্পূর্ণ"
        elif got > 0:
            if target:
                ltxt = (f"লিংক {got}/{target} — বাকি {target - got}টা, "
                        f"পরে ট্রাই করবে")
            else:
                ltxt = f"লিংক {got}টা নেওয়া হয়েছে"
        else:
            ltxt = "লিংক হয়নি — পরে ট্রাই করবে"
        lines.append(f"BM '{nm}': {ptxt}; {ltxt}")
    return "\n".join(lines)


def begin_run(run_ids=None):
    """Run shuru — notun output file lock + run er account snapshot.
    engine._runner theke call hoy (prottek start_run e)."""
    stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    _RUN["file"] = os.path.join(OUT_DIR, f"invite_results_{stamp}.xlsx")
    _RUN["ids"] = set(run_ids) if run_ids else None
    return _RUN["file"]


def _xlsx_path():
    """Run file lock thakle seta; na thakle (late reaper / manual) notun
    timestamped file — kokhono ager file replace hoy na."""
    if _RUN["file"]:
        return _RUN["file"]
    stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    _RUN["file"] = os.path.join(OUT_DIR, f"invite_results_{stamp}.xlsx")
    return _RUN["file"]


# ── design tokens ────────────────────────────────────────────────────────────
NAVY = "0C1A3A"
GRAY_BG = "F2F5FA"
BORDER = "B9C4D6"
LINK_BLUE = "1155CC"
RED_BG = "C00000"

# account-wise halka colors (FB ID box) — proti account e alada
ACC_PALETTE = ["FFF1B8",   # halka amber
               "C9DDF5",   # halka blue
               "C8EBC8",   # halka green
               "F6CFCF",   # halka rose
               "E3D3F2",   # halka purple
               "C7E6E6",   # halka teal
               "F5D9C0",   # halka peach
               "DCDCA8"]   # halka olive
# BM-wise halka colors (BM Name + BM ID box) — BM group alada korar jonno
BM_PALETTE = ["DDEBF7", "FDE9D9", "E2EFDA", "FFF2CC",
              "F2DCDB", "DAEEF3", "E6E0EC", "FCE4D6"]


# ── settings (accounts.json er 'output_settings' key te) ─────────────────────
def get_output_settings() -> dict:
    db = accounts_db._load()
    return db.get("output_settings") or {}


def save_output_settings(updates: dict) -> dict:
    with _wlock:
        db = accounts_db._load()
        cur = db.get("output_settings") or {}
        cur.update(updates)
        db["output_settings"] = cur
        accounts_db._save(db)
        return cur


# ── data helpers ─────────────────────────────────────────────────────────────
def _real_invites(acc):
    d = acc.get("business_data") or {}
    out = []
    for inv in (d.get("invites") or []):
        if isinstance(inv, dict) and inv.get("link") \
                and not str(inv.get("link", "")).startswith("("):
            out.append(inv)
    out.sort(key=lambda i: str(i.get("ts") or ""))
    return out


def _bms_of(acc):
    d = acc.get("business_data") or {}
    seen, order = set(), []
    for b in (d.get("bms") or []):
        bid = str(b.get("id"))
        if bid and bid not in seen:
            seen.add(bid)
            order.append({"id": bid, "name": b.get("name") or bid})
    return order


def _problem_of(acc):
    """Account er problem label + kind. None = somossa nai."""
    kind = str(acc.get("expired_reason") or "")
    if not kind or kind == "net":
        return None
    label = {"checkpoint": "CHECKPOINT",
             "suspended": "SUSPEND",
             "locked": "LOCKED",
             "login": "LOGGED OUT / EXPIRED"}.get(
                 kind, kind.replace("crash:", "CRASH: ").upper() or "PROBLEM")
    return {"kind": kind, "label": label}


# ── style helpers ─────────────────────────────────────────────────────────────
def _style_header(ws, ncols, row=1):
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    thin = Side(style="thin", color=BORDER)
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = PatternFill("solid", fgColor=NAVY)
        cell.font = Font(bold=True, color="FFFFFF", size=11)
        cell.alignment = Alignment(vertical="center")
        cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws.row_dimensions[row].height = 22


def _set_widths(ws, widths):
    from openpyxl.utils import get_column_letter
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w


def _autosize_note(ws, ncols, row, text):
    from openpyxl.styles import Alignment, Font, PatternFill
    c = ws.cell(row=row, column=1, value=text)
    c.font = Font(italic=True, size=9, color="5B6B85")
    c.alignment = Alignment(vertical="center")
    for i in range(1, ncols + 1):
        ws.cell(row=row, column=i).fill = PatternFill("solid", fgColor=GRAY_BG)


def write_excel(log=None, force=False):
    """Excel output rebuild — invite link collect howar SATHE SATHE call hoy.
    Proti RUN e ALADA file (begin_run e lock kora) — ager file untouched."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    except ImportError:
        log and log("⚠ openpyxl nai — pip install openpyxl")
        return

    buyer_rows, backup, summary_rows = [], [], []
    total_links = 0
    for acc in accounts_db.all_accounts():
        invs = _real_invites(acc)
        if invs:
            profile = acc.get("identifier") or acc.get("c_user", "?")
            fb_id = str(acc.get("c_user") or "?")
            bms = _bms_of(acc)
            bm_names = {b["id"]: b["name"] for b in bms}
            bm_order = [b["id"] for b in bms]
            slot_n = {}
            groups = []                      # [ (bid, [rows]) ]
            for inv in invs:
                bid = str(inv.get("bm_id") or "?")
                if bid not in bm_names:
                    bm_names[bid] = inv.get("bm_name") or bid
                    bm_order.append(bid)
                slot_n[bid] = slot_n.get(bid, 0) + 1
                row = {"ts": inv.get("ts") or "", "profile": profile,
                       "fb_id": fb_id, "bm_name": bm_names.get(bid, bid),
                       "bm_id": bid, "email": inv.get("email") or "",
                       "slot": slot_n[bid], "link": inv["link"]}
                if groups and groups[-1][0] == bid:
                    groups[-1][1].append(row)
                else:
                    groups.append((bid, [row]))
            # v7.3: slot-1 link BUYER-ke gese — backup e oi link NAI.
            # (3 link hole buyer 1, backup 2,3 | 5 hole buyer 1, backup 2-5)
            _bk_groups = [(bid, rows[1:]) for bid, rows in groups
                          if len(rows) > 1]
            if _bk_groups:
                backup.append({"profile": profile, "fb_id": fb_id,
                               "groups": _bk_groups})
            total_links += len(invs)
            for bid, rows in groups:
                # BUYER = ei BM er 1st collected link
                buyer_rows.append([bm_names.get(bid, bid), bid,
                                   rows[0]["link"]])
            summary_rows.append([profile, fb_id, len(bm_order),
                                 len(invs), acc])

    # Summary: SEI RUN er protita ID (invite link thak na thak)
    run_ids = _RUN.get("ids")
    run_accs = []
    if run_ids is not None:
        run_accs = [a for a in accounts_db.all_accounts() if a["id"] in run_ids]
    summary_source = run_accs if run_accs else \
        [r[4] for r in summary_rows] or accounts_db.all_accounts()

    if not buyer_rows and not force:
        return                      # kaj korar kichu nei — file noise na

    path = _xlsx_path()
    with _wlock:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        wb = Workbook()
        thin = Side(style="thin", color=BORDER)
        box = Border(left=thin, right=thin, top=thin, bottom=thin)
        center = Alignment(horizontal="center", vertical="center")
        wrap_left = Alignment(vertical="center")
        fill = lambda c: PatternFill("solid", fgColor=c)

        # ═════════════════ TAB 1: BUYER (design fixed) ═════════════════
        ws = wb.active
        ws.title = "Buyer"
        ws.append(["S/L", "BM Name", "BM ID", "Invite Link"])
        _style_header(ws, 4)
        for n, (name, bid, link) in enumerate(buyer_rows, 1):
            r = ws.max_row + 1
            ws.cell(row=r, column=1, value=n).alignment = center
            ws.cell(row=r, column=2, value=name).alignment = wrap_left
            ws.cell(row=r, column=3, value=str(bid)).alignment = center
            lc = ws.cell(row=r, column=4, value=link)
            lc.hyperlink = link
            lc.font = Font(color=LINK_BLUE, underline="single")
            lc.alignment = wrap_left
            for c in range(1, 5):
                ws.cell(row=r, column=c).border = box
                if n % 2 == 0:
                    ws.cell(row=r, column=c).fill = fill(GRAY_BG)
        _set_widths(ws, [6, 26, 18, 78])
        ws.freeze_panes = "A2"
        if buyer_rows:
            ws.auto_filter.ref = f"A1:D{ws.max_row}"
            _autosize_note(ws, 4, ws.max_row + 2,
                           "Buyer sheet: প্রতি BM এর 1st invite link — "
                           "এই ফাইলটাই buyer কে পাঠানো যাবে")

        # ═════════ TAB 2: BACKUP (account/BM-wise color grouping) ═════════
        ws2 = wb.create_sheet("Backup")
        ws2.append(["Date", "Profile", "FB ID", "BM Name", "BM ID",
                    "Invite Email", "Slot", "Invite Link"])
        _style_header(ws2, 8)
        r = ws2.max_row            # current row pointer
        acc_n = 0
        any_acc = False
        for info in backup:
            if not info:
                continue
            if any_acc:
                r += 2             # notun FB ID er AGE 2 line gap
            any_acc = True
            acc_color = ACC_PALETTE[acc_n % len(ACC_PALETTE)]
            acc_n += 1
            bm_n = 0
            first_bm = True
            for bid, rows in info["groups"]:
                if not first_bm:
                    r += 1         # BM group er majhe 1 line gap
                first_bm = False
                bm_color = BM_PALETTE[bm_n % len(BM_PALETTE)]
                bm_n += 1
                for row in rows:
                    r += 1
                    vals = [row["ts"], row["profile"], row["fb_id"],
                            row["bm_name"], row["bm_id"], row["email"],
                            row["slot"], row["link"]]
                    for c, v in enumerate(vals, 1):
                        cell = ws2.cell(row=r, column=c, value=v)
                        cell.border = box
                        cell.alignment = center if c in (1, 3, 5, 7) \
                            else wrap_left
                        if c == 3:                 # FB ID → account color
                            cell.fill = fill(acc_color)
                        elif c in (4, 5):          # BM Name/ID → BM color
                            cell.fill = fill(bm_color)
                        # baki column e kono color na
                    lc2 = ws2.cell(row=r, column=8)
                    lc2.hyperlink = row["link"]
                    lc2.font = Font(color=LINK_BLUE, underline="single")
        _set_widths(ws2, [19, 22, 16, 26, 18, 26, 7, 78])
        ws2.freeze_panes = "A2"
        if any_acc:
            _autosize_note(ws2, 8, r + 2,
                           "Backup: বাকি সব link — প্রতি BM এর 1st link "
                           "Buyer sheet এ গেছে, এখানে নেই। FB ID box = "
                           "account color, BM Name/ID box = BM group color।")

        # ═════════ TAB 3: SUMMARY (run er protita ID + problem red box) ═══
        ws3 = wb.create_sheet("Summary")
        # v7.7: 2 ta NOTUN column — 'Pages (Closing)' (profile bondho
        # howar somoy ei ID te koyta page) + 'কাজের অবস্থা' (EKDUM
        # Bangla te kon BM er ki kaj baki — pore try korbe...)
        ws3.append(["Profile", "FB ID", "BM Created", "Invite Links",
                    "Pages (Closing)", "কাজের অবস্থা", "Status", "Problem"])
        _style_header(ws3, 8)
        n = 0
        for acc in summary_source:
            invs = _real_invites(acc)
            bms = _bms_of(acc)
            prof = acc.get("identifier") or acc.get("c_user", "?")
            fid = str(acc.get("c_user") or "?")
            status = str(acc.get("status") or "?").upper()
            prob = _problem_of(acc)
            n += 1
            r3 = ws3.max_row + 1
            pages = _pages_of(acc)
            bangla = _bangla_work_status(acc)
            vals = [prof, fid, len(bms), len(invs),
                    str(len(pages)) + "টা" +
                    (" (" + ", ".join(pages) + ")" if pages else ""),
                    bangla, status, prob["label"] if prob else "OK"]
            incomplete = ("হয়নি" in bangla) or ("বাকি" in bangla)
            for c, v in enumerate(vals, 1):
                cell = ws3.cell(row=r3, column=c, value=v)
                cell.border = box
                if c in (2, 3, 4, 5, 7):
                    cell.alignment = center
                elif c == 6:   # Bangla kajer obostha — multiline wrap
                    cell.alignment = Alignment(vertical="top", wrap_text=True)
                else:
                    cell.alignment = wrap_left
                if c == 8:
                    if prob:       # PROBLEM → red box
                        cell.fill = fill(RED_BG)
                        cell.font = Font(bold=True, color="FFFFFF")
                        cell.alignment = center
                    else:
                        cell.font = Font(color="2E7D32")
                        cell.alignment = center
                if c == 6 and incomplete and not prob:
                    # kaj baki → light amber — khekhiye dey
                    cell.fill = fill("FFF3CD")
                elif n % 2 == 0 and c not in (6, 8):
                    cell.fill = fill(GRAY_BG)
        _set_widths(ws3, [22, 16, 11, 12, 18, 52, 13, 24])
        ws3.freeze_panes = "A2"
        _autosize_note(ws3, 8, ws3.max_row + 2,
                       "এই রান-এর প্রতিটা ID — কাজের অবস্থা বাংলায়: কোন BM "
                       "এর কী কাজ বাকি আছে (হলুদ = কাজ বাকি)। Problem "
                       "থাকলে red box (checkpoint / suspend / locked / …)")

        tmp = path + ".tmp"
        wb.save(tmp)
        os.replace(tmp, path)

    log and log(f"📊 Excel save holo — {os.path.basename(path)} "
                f"({total_links} link, {len(buyer_rows)} BM)")


def write_gsheet(log=None):
    """GOOGLE SHEET OUTPUT — v7.0 e setup hobe (module ready)."""
    url = (get_output_settings() or {}).get("gsheet_url", "")
    if not url:
        return False, "gsheet not configured (pore setup)"
    # TODO(v7.0): Apps Script Web App POST — buyer/backup tab e append
    return False, "gsheet module: placeholder (setup baki)"
