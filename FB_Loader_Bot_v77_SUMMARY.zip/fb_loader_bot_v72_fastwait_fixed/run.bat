@echo off
title FB Loader Bot
cd /d "%~dp0"
python setup_check.py
if errorlevel 1 (
  echo Setup failed. Make sure Python is installed and in PATH.
  pause
  exit /b 1
)
python app.py
pause
