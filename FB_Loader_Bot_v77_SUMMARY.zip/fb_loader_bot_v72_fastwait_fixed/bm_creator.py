"""BM Creator — API-based Business Manager creation (deobfuscated flow).

Reimplements the purchased 'Medoz Pro' bookmarklet flow as a first-class,
loggable, verifiable bot module. All endpoints / mutations / doc_ids are
identical to the bought script; the differences are improvements:

  * business name / user name / email come from OUR dashboard pool
    (round-robin), not a hardcoded "Medoz Pro" + random
  * every GraphQL response is PARSED — success carries the new business id;
    failure carries the real reason instead of a blind "Done ✅" log
  * a name-issue failure pulls the NEXT pool entry (max 3 tries per BM)
  * "already has the maximum number of businesses" stops further attempts
    for this profile instead of firing doomed calls
  * adaptive Pace waits between the calls (net-speed aware)

Flow (identical to the bookmarklet's '+Mode', which the seller marks as
"to avoid restricted"):

  1. open https://business.facebook.com/overview  (FB page context)
  2. extract DTSG token + USER_ID (require() modules, DOM/cookie fallback)
  3. unlock_profile()            — doc_id 5507005232662559, enable:false
  4. activate_professional_mode()— token_proxy doc_id 6580386111988379,
                                   category_id 1603
  5. create_bm() × 2             — BusinessCreate doc_id 7183377418404152,
                                   ~8-12s apart

Pass avoid_restricted=False to skip steps 3-4 (the 'BM Only' variant).
"""

import asyncio
import json
import os
import random
import re
import time

from biz_form import Pace

_DEBUG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "debug")


def _dump_response(tag: str, step: str, status, text: str) -> str:
    """Save the RAW graphql response so a failure can be diagnosed from the
    real payload instead of guessing. Returns the saved path ('' on error)."""
    try:
        os.makedirs(_DEBUG_DIR, exist_ok=True)
        safe = re.sub(r"[^A-Za-z0-9_.@-]+", "_", tag or "x")[:40]
        path = os.path.join(_DEBUG_DIR, f"bm_{step}_{safe}_{time.strftime('%H%M%S')}.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"HTTP {status}\n\n{text}")
        return path
    except Exception:
        return ""

BUSINESS_HOME = "https://business.facebook.com/overview"

# ── mutations (doc_ids exactly as in the purchased script) ──────────────────
DOC_BM_CREATE = "7183377418404152"          # BusinessCreate
DOC_UNLOCK = "5507005232662559"             # friendly_name=RenewMedoz, enable:false
DOC_PRO_MODE = "6580386111988379"           # CometProfilePlusOnboardingDialogTransitionMutation

# static FB params kept from the purchased script (it works with these;
# only av= and fb_dtsg are substituted live)
_UNLOCK_TAIL = ("&jazoest=25377&lsd=n4UpKmC7MP8NxIUbrcv7cu&__aaid=810463013458894"
                "&__spin_r=1006364963&__spin_b=trunk&__spin_t=1665516583"
                "&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=RenewMedoz"
                "&variables=%7B%22enable%22%3Afalse%7D&server_timestamps=true"
                f"&doc_id={DOC_UNLOCK}"
                "&fb_api_analytics_tags=%5B%22qpl_active_flow_ids%3D30605361%22%5D")
_UNLOCK_HEAD = ("&__a=1&__dyn=7xeUmxa3-Q8zo9EdoDwyyVuCEb9o9E4a2i5aCG6UtyEgwNxK4UKewSAAzpoixWE-bwjElxKdwJzUmxe488o8ogw8i9y8G6Ehwt8aE4m1qwCwuE9FEdUmCBBwLghUbqQGxBa2dum11K6UC5U7y744FA48a8lwWxe4oeUa85vzo4i1qw9G7o9bzouyUd85WUpwo-m2C2l0FggzE8U984678-3K5E5W7S6UgyE9Ehjy88rwzzXxG4U4S2q4Uowww9Oi3-dwKwHxa1Xxu16Cgqw8O58Gm0BUO1tx64EKu9zawSyES2e0UFU6K19wiU8U6Ci2G1bxC78C&__csr=&__req=15&__hs=19276.BP%3Aads_campaign_manager_pkg.2.0.0.0.0&dpr=1&__ccg=EXCELLENT&__rev=1006364963&__s=1kks0o%3Ai5rx6c%3Abp8ctx&__hsi=7153339255480344225&__comet_req=0&fb_dtsg=")

_PROMODE_BODY = ("&jazoest=25377&lsd=n4UpKmC7MP8NxIUbrcv7cu&__aaid=810463013458894"
                 "&__spin_r=1006364963&__spin_b=trunk&__spin_t=1665516583"
                 "&fb_api_caller_class=RelayModern"
                 "&fb_api_req_friendly_name=CometProfilePlusOnboardingDialogTransitionMutation"
                 "&variables=%7B%22category_id%22%3A%221603%22%7D&server_timestamps=true"
                 f"&doc_id={DOC_PRO_MODE}")
_PROMODE_URL = "https://business.secure.facebook.com/ajax/payment/token_proxy.php?tpe=/api/graphql/"

# response patterns that mean "no more BMs allowed for this profile"
_MAX_BM_MARKS = (
    "maximum number of business", "already have a business portfolio",
    "create up to two business portfolios", "limit of business",
    "too many business", "can't create another business",
)
# response patterns that mean the business NAME was the problem
_NAME_ISSUE_MARKS = (
    "business name", "name isn't available", "name is not available",
    "name you entered", "try a different name", "invalid name",
    "name has already been", "name is taken",
)


class BmResult:
    __slots__ = ("ok", "business_id", "business_name", "reason", "kind")

    def __init__(self, ok=False, business_id=None, business_name=None,
                 reason="", kind=""):
        self.ok = ok
        self.business_id = business_id
        self.business_name = business_name
        self.reason = reason
        self.kind = kind  # "" ok | "name" | "max" | "login" | "error"

    def __repr__(self):
        if self.ok:
            return f"<BmResult OK {self.business_name} id={self.business_id}>"
        return f"<BmResult {self.kind}: {self.reason[:80]}>"


# ── page context ─────────────────────────────────────────────────────────────
async def extract_fb_context(page, log=None):
    """DTSG token + USER_ID with the bookmarklet's own fallbacks."""
    ctx = await page.evaluate("""() => {
        const out = {dtsg: "", user_id: ""};
        try { out.dtsg = require('DTSGInitialData').token || ""; } catch (e) {}
        try { out.user_id = require('CurrentUserInitialData').USER_ID || ""; } catch (e) {}
        if (!out.dtsg) {
            const el = document.querySelector('[name="fb_dtsg"]');
            if (el) out.dtsg = el.value || "";
        }
        if (!out.user_id) {
            const m = document.cookie.match(/c_user=(\\d+)/);
            if (m) out.user_id = m[1];
        }
        return out;
    }""")
    dtsg = (ctx or {}).get("dtsg", "")
    user_id = (ctx or {}).get("user_id", "")
    if dtsg and user_id:
        return {"dtsg": dtsg, "user_id": user_id}
    if log:
        log(f"⚠ FB context incomplete — dtsg:{'✓' if dtsg else '✗'} "
            f"user_id:{'✓' if user_id else '✗'}")
    return None


async def _fetch_in_page(page, url, body, referrer=None):
    """fetch() from the page itself — same cookies/session as the bookmarklet.
    Returns (status, text)."""
    return await page.evaluate(
        """async ([url, body, referrer]) => {
            const r = await fetch(url, {
                headers: {"content-type": "application/x-www-form-urlencoded"},
                ...(referrer ? {referrer} : {}),
                body, method: "POST", mode: "cors", credentials: "include"
            });
            return [r.status, await r.text()];
        }""", [url, body, referrer])



# ── structured error → (kind, human reason) ──────────────────────────────────
# Facebook's top-level "message" is often a useless generic line
# ("A server error field_exception occured"). The REAL cause lives in
# summary / description / api_error_code. Read those FIRST.
_DUP_NAME_MARKS = ("duplicate name", "already in use", "already taken",
                   "name provided is already", "name is taken", "name has already been")
_BAD_NAME_MARKS = ("invalid name", "special character", "not allowed", "isn't allowed",
                   "isn’t allowed", "community standards", "business name", "name you entered",
                   "name isn't available", "name is not available", "try a different name",
                   "choose a different name")
_NO_PERMISSION_MARKS = ("permission", "not authorized", "not allowed to create",
                        "isn't eligible", "isn’t eligible", "not eligible",
                        "restricted", "temporarily blocked", "limit reached",
                        "you can't create", "you can’t create", "cannot create")
_EMAIL_MARKS = ("email", "e-mail")
_SESSION_MARKS = ("session", "log in", "login", "checkpoint", "expired", "not logged")

# api_error_code / code → (kind, Bangla explanation). Extend as new ones are seen.
_ERR_CODES = {
    "3947":    ("name", "নাম আগেই ব্যবহার করা হয়েছে (Duplicate Name)"),
    "1690062": ("name", "নাম আগেই ব্যবহার করা হয়েছে (Duplicate Name)"),
    "1359040": ("max",  "এই অ্যাকাউন্টে আর Business তৈরির অনুমতি নেই (not eligible)"),
}


def _classify_errors(errors, data=None):
    """Return a BmResult with an ACCURATE kind + reason from the real FB payload."""
    items = [e for e in (errors or []) if isinstance(e, dict)]
    parts, codes = [], []
    for e in items:
        for k in ("summary", "description", "message", "error_user_title", "error_user_msg"):
            v = e.get(k)
            if v and str(v) not in parts:
                parts.append(str(v))
        for k in ("api_error_code", "code"):
            if e.get(k) not in (None, ""):
                codes.append(str(e[k]))
    full = " | ".join(parts)
    low = full.lower()
    mids = next((e.get("debug_link") or "" for e in items if e.get("debug_link")), "")

    def mk(kind, why):
        tail = f"  [code {','.join(dict.fromkeys(codes))}]" if codes else ""
        return BmResult(reason=f"{why} — {full[:200]}{tail}", kind=kind)

    # 1) exact known codes win
    for c in codes:
        if c in _ERR_CODES:
            kind, why = _ERR_CODES[c]
            return mk(kind, why)
    # 2) wording
    if any(m in low for m in _DUP_NAME_MARKS):
        return mk("name", "নাম আগেই ব্যবহার করা হয়েছে (Duplicate Name)")
    if any(m in low for m in _MAX_BM_MARKS):
        return mk("max", "এই অ্যাকাউন্টে BM-এর সর্বোচ্চ সীমায় পৌঁছে গেছে")
    if any(m in low for m in _BAD_NAME_MARKS):
        return mk("name", "নামটা Facebook গ্রহণ করেনি")
    if any(m in low for m in _NO_PERMISSION_MARKS):
        return mk("max", "এই অ্যাকাউন্টের Business তৈরির পারমিশন/যোগ্যতা নেই")
    if any(m in low for m in _SESSION_MARKS):
        return mk("login", "সেশন/লগইন সমস্যা")
    if any(m in low for m in _EMAIL_MARKS):
        return mk("email", "ইমেইল সমস্যা (ইমেইল গ্রহণযোগ্য নয় বা ব্যবহৃত)")
    if "field_exception" in low or "server error" in low:
        return mk("error", "Facebook সার্ভার-সাইড এরর (কারণ response-এ স্পষ্ট নেই)")
    return mk("error", "অজানা Facebook এরর")


def _stop_requested() -> bool:
    """Lazy import — engine e cycle hoy na."""
    try:
        from engine import engine_stop_requested
        return engine_stop_requested()
    except Exception:
        return False


def _parse_graphql(text):
    """Extract business id / error message from a BusinessCreate response."""
    raw = (text or "").lstrip()
    if raw.startswith("for (;;);"):            # FB anti-hijack prefix
        raw = raw[len("for (;;);"):]
    data = None
    docs = []
    try:
        data = json.loads(raw)
        docs = [data]
    except Exception:
        # batched / newline-delimited JSON → parse each line
        for ln in raw.splitlines():
            ln = ln.strip()
            if not ln.startswith("{"):
                continue
            try:
                docs.append(json.loads(ln))
            except Exception:
                continue
        if docs:
            data = docs[0]
    if data is None:
        low = (text or "").lower()
        if "login" in low and "facebook" in low:
            return BmResult(reason="login page returned — session lost", kind="login")
        return BmResult(reason=f"non-JSON response ({len(text or '')} chars)", kind="error")
    if len(docs) > 1:                           # merge: scan every doc for errors / id
        data = {"_docs": docs, **(docs[0] if isinstance(docs[0], dict) else {})}

    errors = data.get("errors")
    if not errors and isinstance(data.get("_docs"), list):
        for d_ in data["_docs"]:
            if isinstance(d_, dict) and d_.get("errors"):
                errors = d_["errors"]
                break
    if errors:
        return _classify_errors(errors, data)

    # walk for the created business id
    # v7.4: REAL production response (client log): data.bizkit_create_business.id
    _BIZ_KEYS = ("business", "business_account", "business_portfolio", "new_business",
                 "created_business", "business_create", "business_creation",
                 "bizkit_create_business", "bizkit_business")

    def _find_biz(obj, depth=0):
        if depth > 8:
            return None
        if isinstance(obj, dict):
            for k in ("business_id", "businessID", "new_business_id", "created_business_id"):
                if obj.get(k):
                    return obj[k]
            for k in _BIZ_KEYS:
                b = obj.get(k)
                if isinstance(b, dict):
                    for idk in ("id", "business_id", "legacy_id", "fbid"):
                        if b.get(idk):
                            return b[idk]
            # v7.4: FB mutation name bodle-o jeno kaj hoy — dynamic
            # pattern ("bizkit_*" / "*create_business") er dict-e id khunja
            for k, v in obj.items():
                if isinstance(v, dict) and \
                        ("create_business" in k or k.startswith("bizkit")):
                    for idk in ("id", "business_id", "legacy_id", "fbid"):
                        if v.get(idk):
                            return v[idk]
            for v in obj.values():
                r = _find_biz(v, depth + 1)
                if r:
                    return r
        elif isinstance(obj, list):
            for v in obj:
                r = _find_biz(v, depth + 1)
                if r:
                    return r
        return None

    biz_id = _find_biz(data)
    if biz_id:
        return BmResult(ok=True, business_id=str(biz_id))
    # data present, no error, no id → AMBIGUOUS: could be created-but-id-not-echoed, or a
    # silent no-op. Do not guess — the orchestrator verifies against the real BM list.
    if data.get("data") is not None:
        return BmResult(reason="ok http, but no business id in response", kind="unverified")
    return BmResult(reason=f"unexpected response: {str(data)[:160]}", kind="error")



_ADS_LINK_JS = """() => {
    const vis = el => !!(el && (el.offsetParent !== null || el.getClientRects().length));
    const cands = Array.from(document.querySelectorAll('a[href]')).filter(a => {
        const h = (a.getAttribute('href') || '').toLowerCase();
        const t = ((a.innerText || '') + ' ' + (a.getAttribute('aria-label') || '')).toLowerCase();
        return vis(a) && (h.includes('adsmanager') || h.includes('/ads/manager') ||
                          /ads\\s*manager|বিজ্ঞাপন ম্যানেজার/.test(t));
    });
    if (!cands.length) return null;
    // prefer the left-sidebar entry (small x), then first
    cands.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
    const a = cands[0];
    a.setAttribute('data-s2c-ads', '1');
    return {href: a.href, text: (a.innerText || '').trim().slice(0, 40)};
}"""


async def open_ads_manager_tab(page, log, tag, pace):
    """Human path: on the logged-in Facebook feed find the sidebar 'Ads Manager'
    link and open it in a NEW tab. Returns the new Page (business/ads context)
    or None. Falls back to the direct URL in a new tab if the link isn't there."""
    ctx = page.context
    try:
        await page.goto("https://www.facebook.com/", wait_until="domcontentloaded",
                        timeout=90_000)
        await pace.sleep(2.0, 3.5)
    except Exception as e:
        log(f"{tag} ⚠ facebook feed load: {str(e)[:70]}")

    # sidebar may need a moment / "See more" expansion
    info = None
    for attempt in range(4):
        info = await page.evaluate(_ADS_LINK_JS)
        if info:
            break
        try:
            more = page.get_by_text(re.compile(r"^(See more|আরও দেখুন)$", re.I)).first
            await more.click(timeout=2500)
        except Exception:
            pass
        await pace.sleep(1.5, 2.5)

    new_page = None
    if info:
        log(f"{tag} 📢 sidebar link পেলাম → “{info.get('text') or 'Ads Manager'}” → নতুন ট্যাবে খুলছি")
        try:
            async with ctx.expect_page(timeout=30_000) as pinfo:
                # ctrl/meta click is flaky across OS; target=_blank open via JS is deterministic
                await page.evaluate(
                    "(h) => window.open(h, '_blank')", info["href"])
            new_page = await pinfo.value
        except Exception as e:
            log(f"{tag} ⚠ নতুন ট্যাব খুলতে পারিনি ({str(e)[:60]}) → সরাসরি URL")
    if new_page is None:
        log(f"{tag} ℹ sidebar-এ Ads Manager লিংক নেই → সরাসরি Ads Manager URL নতুন ট্যাবে")
        new_page = await ctx.new_page()
        try:
            await new_page.goto("https://adsmanager.facebook.com/adsmanager/manage/campaigns",
                                wait_until="domcontentloaded", timeout=90_000)
        except Exception as e:
            log(f"{tag} ⚠ ads manager direct load: {str(e)[:70]}")
    try:
        await new_page.bring_to_front()
        await new_page.wait_for_load_state("domcontentloaded", timeout=60_000)
    except Exception:
        pass
    try:
        await new_page.wait_for_load_state("networkidle", timeout=25_000)
    except Exception:
        pass
    return new_page


# ── the three mutations ──────────────────────────────────────────────────────
async def unlock_profile(page, fbctx, pace: Pace, log, tag=""):
    if log:
        log(f"{tag} 🔓 unlock step (avoid-restricted)…")
    body = (f"av={fbctx['user_id']}"
            "&__usid=6-Trjlqme3s52zk%3APrjlstjsj33g5%3A0-Arjlqme1o8gcbt-RV%3D6%3AF%3D"
            f"&__user={fbctx['user_id']}"
            f"{_UNLOCK_HEAD}{fbctx['dtsg']}"
            f"{_UNLOCK_TAIL}")
    try:
        status, text = await _fetch_in_page(
            page, "https://business.facebook.com/api/graphql/", body,
            referrer="https://www.business.facebook.com/")
        if log:
            log(f"{tag} unlock → HTTP {status}")
        return status == 200
    except Exception as e:
        if log:
            log(f"{tag} ⚠ unlock step failed — {e}")
        return False
    finally:
        await pace.sleep(1.5, 2.5)


async def activate_professional_mode(page, fbctx, pace: Pace, log, tag=""):
    if log:
        log(f"{tag} 💼 professional-mode step…")
    body = f"av={fbctx['user_id']}{_PROMODE_BODY}"
    try:
        status, text = await _fetch_in_page(
            page, _PROMODE_URL, body,
            referrer="https://www.business.facebook.com/")
        if log:
            log(f"{tag} professional-mode → HTTP {status}")
        return status == 200
    except Exception as e:
        if log:
            log(f"{tag} ⚠ professional-mode step failed — {e}")
        return False
    finally:
        await pace.sleep(1.5, 2.5)


async def create_bm(page, fbctx, biz, pace: Pace, log, tag=""):
    """One BusinessCreate mutation with THIS pool entry's values."""
    full = (biz.get("your_name") or "").strip() or biz["business_name"]
    parts = full.split(None, 1)
    first_name = parts[0]
    last_name = parts[1] if len(parts) > 1 else " "

    variables = {
        "input": {
            "client_mutation_id": "6",
            "actor_id": fbctx["user_id"],
            "business_name": biz["business_name"],
            "user_first_name": first_name,
            "user_last_name": last_name,
            "user_email": (biz.get("business_email") or "").strip(),
            "creation_source": "MBS_BUSINESS_CREATION_IN_SCOPE_SELECTOR_FOOTER",
        }
    }
    body = ("__a=1&dpr=1&fb_dtsg=" + fbctx["dtsg"]
            + "&variables=" + json.dumps(variables, separators=(",", ":"))
            + "&server_timestamps=true"
            f"&doc_id={DOC_BM_CREATE}")
    if log:
        log(f"{tag} 🚀 BM create → “{biz['business_name']}” "
            f"({biz.get('business_email', '')})")
    try:
        status, text = await _fetch_in_page(
            page, "https://business.facebook.com/api/graphql", body)
    except Exception as e:
        return BmResult(reason=f"fetch failed: {e}", kind="error")
    if status != 200:
        return BmResult(reason=f"HTTP {status}", kind="error" if status != 401
                        else "login")
    res = _parse_graphql(text)
    if res.ok:
        res.business_name = biz["business_name"]
        if log:
            log(f"{tag} ✅ BM created — “{biz['business_name']}” "
                f"(id {res.business_id})")
    else:
        saved = _dump_response(tag, "create", status, text)
        if log:
            icon = "⚠ BM create response unclear" if res.kind == "unverified" else "❌ BM create rejected"
            log(f"{tag} {icon} [{res.kind}] — {res.reason[:260]}")
            # show the REAL payload head so the true cause is readable in the log
            log(f"{tag} 🧾 raw response: {text[:420].replace(chr(10), ' ')}")
            if saved:
                log(f"{tag} 💾 full response saved → {saved}")
    # v7.0: success e GraphQL response-i proof — boro fixed wait NAI.
    # fail e matro brief humanize (revenge-retry chain aagei ache).
    await pace.sleep(0.2, 0.6 if res.ok else 1.5)
    return res



async def _verify_bm_on_select(page, bm_name, log, tag, pace):
    """EK visit e BM verify + NUMERIC ID — /select page e POLLING.
    (networkidle / fixed sleep / BUSINESS_HOME round-trip — sob NAI.)

    Anchor element: <a href="...business_id=<ID>"> → innerText = BM name.
    Name + ID render hole SATHE SATHE return — fast net e 1st-2nd poll e-i.
    Returns (found: bool, id: str) — id khali hole-o found=True (edge)."""
    from adaptive import smart_goto, poll_until
    if not await smart_goto(page, "https://business.facebook.com/select",
                            log=log, tag=f"{tag}[verify]"):
        return False, ""
    lname = (bm_name or "").strip().lower()

    async def _scan():
        try:
            return await page.evaluate("""(nm) => {
                const links = document.querySelectorAll('a[href*="business_id="]');
                for (const a of links) {
                    const m = (a.href || '').match(/business_id=(\\d+)/);
                    const full = (a.innerText || '').toLowerCase();
                    const aria = (a.getAttribute('aria-label') || '').toLowerCase();
                    const first = (a.innerText || '').split('\\n')[0].trim();
                    if (!m || !first || first.length < 2) continue;
                    if (nm && (full.includes(nm) || aria.includes(nm)))
                        return {found: true, id: m[1], name: first};
                }
                return null;
            }""", lname)
        except Exception:
            return None

    got = await poll_until(_scan,
                           timeout_s=max(12.0, 25.0 * pace.factor),
                           interval=0.5)
    if got and got.get("found"):
        return True, str(got.get("id") or "")
    # name-poll fail — sheshbar text match (render slow / name bhinno hole)
    try:
        txt = await page.evaluate(
            "() => (document.body && document.body.innerText) || ''")
        return (bool(lname) and lname in (txt or "").lower()), ""
    except Exception:
        return False, ""


# ── orchestrator ──────────────────────────────────────────────────────────────
async def run_bm_tasks(page, fbctx, bm_result, pace, log, tag="",
                       slot=1, acc_id="", invite_count=0, page_enabled=True):
    """Per-BM kaj (v6.4): BM create hower POR, porer BM kholar AGE —
      STEP 2: ei BM er bhitor Facebook Page create + add
      STEP 3: invite_count ta temp-mail e FULL ACCESS invite → accept LINK
    Sob result accounts_db.business_data te record hoy (dashboard status)."""
    import accounts_db as _adb
    from page_creator import create_bm_page
    from bm_invite import invite_one

    bm_id = getattr(bm_result, "business_id", "") or ""
    bm_name = getattr(bm_result, "business_name", "") or ""

    # "(verified by name)" → numeric ID NAI. Ei placeholder diye URL
    # build korle FB "Something went wrong" page dekhay. Asol ID ta
    # /select page theke name match kore ber kori.
    if bm_id and not bm_id.isdigit():
        log(f"{tag} 🔍 BM create OK kintu response e numeric ID chilo na — "
            f"/select পেজে POLL করে আসল ID খুঁজছি…")
        real_id = ""
        _found = False
        try:
            _found, real_id = await _verify_bm_on_select(
                page, bm_name, log, f"{tag} ", pace)
        except Exception as e:
            log(f"{tag} ⚠ BM ID verify fail: {str(e)[:60]}")
        # v7.4: name pailam kintu ID link-e nai → ekbar wide-scan BM list
        # (khub rare — BM list e name age ashe, ID-poroto link pore)
        if _found and not (real_id or "").isdigit():
            try:
                bms = await collect_profile_bms(page, log, f"{tag} ")
                for b in bms:
                    if (bm_name and b.get("name", "").strip().lower()
                            == bm_name.strip().lower()):
                        real_id = b["id"]
                        break
                if not real_id and len(bms) == 1:
                    real_id = bms[0]["id"]
            except Exception as e:
                log(f"{tag} ⚠ BM list fallback fail: {str(e)[:60]}")
        if real_id:
            log(f"{tag} ✅ asol BM ID: {real_id} ('{bm_name}')")
            bm_id = real_id
            bm_result.business_id = real_id
        else:
            log(f"{tag} ❌ asol numeric BM ID paoa jay nai — numeric ID "
                f"chara Pages URL kaj kore na; BM#{slot} er page/invite "
                f"skip (BM toiri ache, pore 'pageadd' run korle hobe)")
            bm_id = ""

    if not bm_id:
        log(f"{tag} ⚠ BM id pawa jay nai — BM#{slot} er kaj skip")
        return False
    if acc_id:
        _adb.bm_upsert(acc_id, bm_id, bm_name)

    # ── v6.5 SMART-CHECK: ei BM er kaj AGEI koto done hoyeche? ──
    # (purono run e BM/page/invite banano thakle seta abar korbe na —
    #  shudhu BAKI kaj ta kore, profile er kono kaj baki rakhe na)
    _existing_page, _done_inv = "", 0
    if acc_id:
        _bd = _adb.get_business_data(acc_id)
        _rec = _adb.bm_get(_bd, bm_id)
        if isinstance(_rec, dict):
            _pg = _rec.get("page")
            _existing_page = (_pg.get("name") if isinstance(_pg, dict)
                              else str(_pg or ""))
        _done_inv = _adb.bm_invite_count(_bd, bm_id)

    # ── STEP 2: page create + add (Page Info Pool theke random pick) ──
    page_ok, page_name = False, ""
    if not page_enabled:
        log(f"{tag} ⏭ [BM#{slot}] BM Only mode — page create skip")
    elif _existing_page:
        # BM te page AGE THEKEI create kora — abar banabe na
        page_ok, page_name = True, _existing_page
        log(f"{tag} ✓ [BM#{slot}] page age thekei ache ('{_existing_page}') "
            f"— page create skip, invite phase e jachhi")
    else:
        info = _adb.page_pool_take_random()
        if not info:
            log(f"{tag} ⚠ Page Info Pool khali — dashboard e Page pool entry "
                f"dao; BM#{slot} er page create skip")
        else:
            log(f"{tag} 📄 [BM#{slot}] STEP 2 — page create: "
                f"'{info['page_name']}' / '{info['category']}'")
            try:
                page_ok, reason = await create_bm_page(page, bm_id, info,
                                                       pace, log, f"{tag} BM#{slot}")
            except Exception as e:
                page_ok, reason = False, f"page create e error: {e}"
            if page_ok:
                page_name = info["page_name"]
                if acc_id:
                    _adb.bm_record_page(acc_id, bm_id, bm_name, page_name)
                log(f"{tag} ✅ [BM#{slot}] page created + connected: '{page_name}'")
            else:
                log(f"{tag} ⚠ [BM#{slot}] page create hoy nai — {reason}")
                # v7.5 FAST FAIL: page-create fail er karonta ACCOUNT-level
                # (checkpoint/logout page)? hole ei ID te ar somoy nosto NAI
                try:
                    from browser_manager import detect_page_problem, \
                        AccountBlocked
                    _kind = await detect_page_problem(page)
                    if _kind:
                        raise AccountBlocked(_kind, f"page create fail (BM#{slot})")
                except AccountBlocked:
                    raise
                except Exception:
                    pass

    # ── v7.6 CLIENT RULE: page CREATE MUST — page chara invite NA ──
    #    (asset chara temp-mail e full-access link ashe na; page create
    #    fail hole ei BM er invite waste — porer BM er kaj korbe)
    if page_enabled and not page_ok and not _existing_page:
        log(f"{tag} ⏭ [BM#{slot}] page nei → invite phase SKIP — "
            f"porer BM er kaj korbo (page chara invite ortho nai)")
        return False

    # ── STEP 3: temp mail invites — BAKI joto ta link lagbe totota ──
    if invite_count and invite_count > 0:
        remaining = max(0, invite_count - _done_inv)
        if remaining == 0:
            log(f"{tag} ✓ [BM#{slot}] invite link agei sob collect kora "
                f"({_done_inv}/{invite_count}) — ar lagbe na, skip")
            return page_ok
        if _done_inv:
            log(f"{tag} 📨 [BM#{slot}] age theke {_done_inv}/{invite_count} "
                f"link ache — baki {remaining} ta collect korbo")
        else:
            log(f"{tag} 📨 [BM#{slot}] STEP 3 — {invite_count} ta invite link "
                f"collect korbo (temp mail, ekta ekta kore)")
        got = 0
        for i in range(remaining):
            if _stop_requested():
                log(f"{tag} ⏹ stop request — [BM#{slot}] invite loop "
                    f"chere dilam (link gulo save hoye ache)")
                break
            link, email = await invite_one(
                page, bm_id, pace, log, f"{tag} [BM#{slot} invite {i+1}]",
                poll_s=150, page_name=page_name,
                _slot=(slot - 1) * 10 + i + 1)
            if link:
                got += 1
                if acc_id:
                    _adb.bm_record_invite(acc_id, bm_id, bm_name, email, link)
                    # link petei SATHE SATHE file e save — crash/stop
                    # holeo jeta paisi ta saved thake
                    try:
                        from engine import _write_results
                        _write_results(acc_id, log)
                    except Exception as _e:
                        log(f"{tag} ⚠ instant save fail: {str(_e)[:50]}")
                log(f"{tag} 🔗 [BM#{slot}] link {i+1}/{invite_count} ✓ "
                    f"({email})")
            else:
                log(f"{tag} ⚠ [BM#{slot}] invite {i+1} er link paoa gelo na"
                    f"{' (' + email + ')' if email else ''}")
            # v7.0: invite-to-invite gap komalo (FB pacing safety thik-i)
            await pace.sleep(0.8, 1.6)
        log(f"{tag} 🏁 [BM#{slot}] invite links: {got}/{invite_count}")
    return page_ok


async def collect_profile_bms(page, log, tag=""):
    """Profile-er CREATED BM gulo collect (business.facebook.com/select theke
    link + name). Page-add mode er jonno — ager run e banano BM gulo ber kore."""
    bms = []
    try:
        from adaptive import smart_goto
        if not await smart_goto(page, "https://business.facebook.com/select",
                                log=log, tag=f"{tag}[bm-list]"):
            return bms
        from adaptive import poll_until as _poll, NetSpeed
        _JS = """() => {
            const out = [];
            const junk = /report|help|support|policy|policies|learn|setting|create|business suite|meta business/i;
            document.querySelectorAll('a[href*="business_id="]').forEach(a => {
                const m = (a.href || '').match(/business_id=(\\d+)/);
                if (!m) return;
                const name = (a.innerText || '').split('\\n')[0].trim();
                const href = (a.href || '');
                if (!name || name.length < 2) return;
                if (junk.test(name)) return;
                if (/support|help|report|policies|privacy|learn/i.test(href)) return;
                if (!/\\/latest\\/|\\/business|\\/home|business_id=/.test(href)) return;
                out.push({id: m[1], name: name, href: href});
            });
            return out;
        }"""
        async def _scan():
            try:
                d = await page.evaluate(_JS)
                return d if d else None
            except Exception:
                return None
        # v7.0 POLL: link render howa MATEI jay — fixed 3.5s sleep NAI
        data = await _poll(_scan, timeout_s=NetSpeed.scale(12.0, lo=8.0),
                           interval=0.6) or []
        seen = set()
        for b in (data or []):
            if b["id"] in seen:
                continue
            seen.add(b["id"])
            bms.append({"id": b["id"], "name": (b["name"] or "")[:80]})
        log(f"{tag} 📋 BM list collect: {len(bms)} ta business portfolio")
    except Exception as e:
        log(f"{tag} ⚠ BM list collect fail: {str(e)[:80]}")
    return bms


async def run_bm_creation(page, take_biz, log, tag="",
                          avoid_restricted=True, per_profile=2,
                          acc_id="", invite_count=0, page_enabled=True):
    """Full flow for ONE logged-in profile.

    take_biz: callable → next pool entry dict (round-robin), may return None
    Returns (n_created, [names...], stop_reason) where stop_reason is "" on
    success or a human-readable reason the profile can't take more BMs.
    """
    pace = Pace()

    # ═══════════════════════════════════════════════════════════════════
    # PHASE 0 (v6.5): profile e AGE THEKE koyta BM ache dekhi.
    #   • 2ta BM age thekei thakle → notun create korte jabe-i na, duitei
    #     BM er BAKI kaj (page/invite) complete korbe
    #   • 1ta thakle → oi BM er kaj sesh kore THEN arekta create korbe
    #   • 0 ta thakle → ager moto full create flow
    #   Ei plan ta prottek run e age log hoy — track soho.
    # ═══════════════════════════════════════════════════════════════════
    import accounts_db as _adb0
    existing_bms = []
    try:
        existing_bms = await collect_profile_bms(page, log, f"{tag} ")
    except Exception as e:
        log(f"{tag} ⚠ age-theke-BM scan fail: {str(e)[:60]} — 0 ta dhore "
            f"agacchi")
    n_exist = len(existing_bms)
    plan_create = max(0, per_profile - n_exist)
    log(f"{tag} 📋 RUN PLAN — BM target {per_profile} · profile e age theke "
        f"ache {n_exist} · notun create lagbe {plan_create}")
    handled_names = []
    for _ix, _b in enumerate(existing_bms[:per_profile], 1):
        _bid, _bnm = _b.get("id", ""), _b.get("name", "")
        _epg, _din = "", 0
        if acc_id:
            _bd0 = _adb0.get_business_data(acc_id)
            _r0 = _adb0.bm_get(_bd0, _bid)
            if isinstance(_r0, dict):
                _p0 = _r0.get("page")
                _epg = (_p0.get("name") if isinstance(_p0, dict)
                        else str(_p0 or ""))
            _din = _adb0.bm_invite_count(_bd0, _bid)
        log(f"{tag} 📦 [BM#{_ix}] age theke ache: '{_bnm}' — page: "
            f"{'✓ ' + _epg if _epg else 'Nai, banate hobe'} · link: "
            f"{_din}/{invite_count or 0}")
        try:
            from types import SimpleNamespace as _SN
            await run_bm_tasks(
                page, None,
                _SN(business_id=_bid, business_name=_bnm),
                pace, log, tag, _ix,
                acc_id=acc_id, invite_count=invite_count,
                page_enabled=page_enabled)
            handled_names.append(_bnm)
            # v7.5: sob kaj complete KI NA — DB thekei verify kore bole
            _fin = 0
            if acc_id:
                _fin = _adb0.bm_invite_count(
                    _adb0.get_business_data(acc_id), _bid)
            if invite_count and _fin < invite_count:
                log(f"{tag} ⚠ [BM#{_ix}] ('{_bnm}') INCOMPLETE — invite "
                    f"link {_fin}/{invite_count}")
            else:
                log(f"{tag} ✅ [BM#{_ix}] ('{_bnm}') er sob baki kaj complete")
        except Exception as e:
            from browser_manager import AccountBlocked as _AB
            if isinstance(e, _AB):
                raise          # account-level block → engine e porer ID
            log(f"{tag} ⚠ [BM#{_ix}] ('{_bnm}') kaj e somossa — porer BM: "
                f"{str(e)[:80]}")
        await pace.sleep(1.5, 3.0)
    if plan_create <= 0:
        if n_exist:
            log(f"{tag} 🏁 {n_exist} ta BM age thekei chilo — create lagbe "
                f"na, sob BM er kaj complete hoyeche")
        return 0, handled_names, ""

    # 1. Human path (exactly like the bought bookmarklet is used): Facebook feed →
    #    sidebar "Ads Manager" → NEW tab → run the BM calls from THAT tab.
    load_t = asyncio.get_event_loop().time()
    feed_page = page
    try:
        page = await open_ads_manager_tab(feed_page, log, tag, Pace())
    except Exception as e:
        return 0, [], f"ads manager tab failed: {e}"
    if page is None:
        return 0, [], "ads manager tab could not be opened"
    load_s = asyncio.get_event_loop().time() - load_t
    pace.learn(min(load_s, 40.0))
    log(f"{tag} Ads Manager ট্যাব ready {load_s:.1f}s → net {pace.label} "
        f"(wait ×{pace.factor}) · url: {page.url[:70]}")

    # The bought script POSTs to https://business.facebook.com/api/graphql, so the
    # tab must be on that origin (same-origin = cookies + CSRF context accepted).
    # Ads Manager normally redirects there; if it landed on another host, hop to it.
    if "business.facebook.com" not in (page.url or ""):
        log(f"{tag} ↪ origin {page.url[:50]} ≠ business.facebook.com → ওই ট্যাবেই business overview খুলছি")
        try:
            await page.goto(BUSINESS_HOME, wait_until="domcontentloaded", timeout=90_000)
            try:
                await page.wait_for_load_state("networkidle", timeout=20_000)
            except Exception:
                pass
        except Exception as e:
            return 0, [], f"business origin load failed: {str(e)[:80]}"

    # 2. context tokens — v7.0 POLL-FIRST: reload = shudhu somoy noshto.
    #    Token DOM e ash-onto hoy — age poll (beshi beshi bar evaluate,
    #    kono reload nai), na pele EK reload, tarpor abar poll.
    from adaptive import poll_until as _poll
    fbctx = await _poll(lambda: extract_fb_context(page),
                        timeout_s=max(10.0, 20.0 * pace.factor),
                        interval=0.6)
    if not fbctx:
        log(f"{tag} ⏳ context এখনো নেই — একটা reload দিয়ে আবার poll…")
        try:
            await page.reload(wait_until="domcontentloaded", timeout=60_000)
        except Exception:
            pass
        fbctx = await _poll(lambda: extract_fb_context(page),
                            timeout_s=max(12.0, 18.0 * pace.factor),
                            interval=0.6)
    if not fbctx:
        return 0, [], "could not read DTSG/USER_ID from page"

    # 3. +Mode (avoid restricted) — exactly the purchased script's chain
    if avoid_restricted:
        await unlock_profile(page, fbctx, pace, log, tag)
        await activate_professional_mode(page, fbctx, pace, log, tag)

    # 4. up to `per_profile` BMs, round-robin pool entries, name-issue →
    #    next entry (max 3 tries per slot), max-limit → stop early
    created, names, stop_reason = 0, list(handled_names), ""
    # v6.5: slot numbering — age-theke-thaka BM gulo (n_exist ta) handle
    # hoye geche; NOTUN create er slot segulor POR theke shuru
    for slot in range(n_exist + 1, per_profile + 1):
        result, tries = None, 0
        while tries < 3:
            biz = take_biz()
            if not biz:
                stop_reason = "business info pool খালি"
                break
            tries += 1
            result = await create_bm(page, fbctx, biz, pace, log, tag)
            if result.kind == "unverified":
                # v7.0: EK /select visit e name-verify + ASOL numeric ID
                # (poll). BUSINESS_HOME round-trip / extra reload NAI —
                # /select o business.facebook.com origin, GraphQL cholbe.
                log(f"{tag} 🔍 রেসপন্সে id নেই — /select পেজে POLL করে "
                    f"নাম + আসল ID খুঁজছি…")
                _found, _rid = await _verify_bm_on_select(
                    page, biz["business_name"], log, tag, pace)
                if _found:
                    result.ok = True
                    result.kind = ""
                    result.business_name = biz["business_name"]
                    result.business_id = _rid or result.business_id
                    log(f"{tag} ✅ যাচাই হলো — “{biz['business_name']}” BM তালিকায় আছে"
                        + (f" (আসল ID: {_rid})" if _rid else " (ID লিংকে এখনো নেই)"))
                else:
                    log(f"{tag} ❌ যাচাই ব্যর্থ — “{biz['business_name']}” তালিকায় নেই (BM তৈরি হয়নি)")
                    result.reason = "response had no id and name not found in BM list"
                    result.kind = "error"
                # token ta ekhon-o valid — shudhu evaluate, reload nai
                fbctx = await extract_fb_context(page, log) or fbctx
            if result.ok:
                created += 1
                names.append(result.business_name)
                # v6.2: এই BM-এর বাকি কাজ — পরের BM খোলার আগেই সম্পূর্ণ হবে
                try:
                    await run_bm_tasks(page, fbctx, result, pace, log, tag,
                                       slot, acc_id=acc_id,
                                       invite_count=invite_count,
                                       page_enabled=page_enabled)
                except Exception as e:
                    from browser_manager import AccountBlocked as _AB2
                    if isinstance(e, _AB2):
                        raise         # account blocked → engine fast-jump
                    log(f"{tag} ⚠ BM #{slot} per-BM কাজে সমস্যা — পরের BM-এ যাচ্ছি: {str(e)[:80]}")
                break
            if result.kind in ("name", "email"):
                what = "নাম" if result.kind == "name" else "ইমেইল"
                if tries >= 3:
                    log(f"{tag} ⛔ {what} সমস্যা (“{biz['business_name']}”) — ৩ বার চেষ্টা শেষ, আর রিট্রাই নেই")
                    break
                log(f"{tag} 🔁 {what} সমস্যা (“{biz['business_name']}”) — পুলের পরের info নিয়ে "
                    f"আবার ({tries}/3)…")
                await pace.sleep(2.0, 3.5)
                continue
            break  # max / login / error — no point retrying names
        if stop_reason:
            break
        if result and not result.ok:
            if result.kind == "max":
                stop_reason = ("already at maximum businesses"
                               if created else f"not eligible: {result.reason[:80]}")
                if created == 0:
                    return 0, names, stop_reason
                break
            if created == 0:
                stop_reason = f"{result.kind}: {result.reason[:200]}"
                break
            stop_reason = f"{result.kind}: {result.reason[:200]}"
            break
        # small humanized gap between BM1 and BM2 — v7.0: komalo
        # (7-11s → 4-7s) — FB rate-limit safety thik-i thakbe
        if slot < per_profile:
            await pace.sleep(4.0, 7.0)
    log(f"{tag} 🏁 RUN SUMMARY — age theke chilo {n_exist} · ei run e create "
        f"holo {created} · total BM kaj complete {len(names)}")
    return created, names, stop_reason
