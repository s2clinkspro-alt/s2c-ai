"""Accounts registry — single JSON store with duplicate protection.

Every imported account passes through here. Rules:
  • duplicate c_user  → REJECTED (same FB account twice)
  • duplicate identifier (email/phone/uid, case-insensitive) → REJECTED
  • status lifecycle: imported → validated / expired / duplicate / running
  • a profile FOLDER is only ever created for accounts that reach
    status='validated' (live login verified) — expired/unlogin cookies
    never pollute the profiles/ directory.
"""
import json
import os
import re
import threading
import time

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "data", "accounts.json")
PROFILES_ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "profiles")

_lock = threading.RLock()


def _load() -> dict:
    with _lock:
        if not os.path.exists(DB_PATH):
            return {"accounts": []}
        try:
            with open(DB_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"accounts": []}


def _save(db: dict):
    with _lock:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        tmp = DB_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(db, f, ensure_ascii=False, indent=1)
        os.replace(tmp, DB_PATH)


def _norm_identifier(ident: str) -> str:
    return re.sub(r'\s+', '', (ident or "")).lower()


def _c_user_of(acc: dict) -> str:
    raw = acc.get("cookie", "")
    # cheap regex — avoid importing cookie parsing loops twice
    m = re.search(r'c_user["\s:=]+(\d{5,25})', raw)
    if m:
        return m.group(1)
    try:
        from cookie_engine import parse_cookie_string
        return parse_cookie_string(raw).get("c_user", "")
    except Exception:
        return ""


def import_accounts(parsed: list, replace_all: bool = False) -> dict:
    """Add parsed accounts ({identifier,password,cookie,row}) to the
    registry with dedupe. Returns {added, duplicates, expired_invalid,
    accounts, rejected:[{row,reason}]}."""
    from cookie_engine import parse_cookie_string

    db = _load()
    if replace_all:
        db["accounts"] = []

    existing_cusers = {a.get("c_user") for a in db["accounts"] if a.get("c_user")}
    existing_idents = {_norm_identifier(a.get("identifier")) for a in db["accounts"]}

    added, duplicates, invalid, rejected = [], [], [], []
    for acc in parsed:
        row = acc.get("row", "?")
        raw_cookie = acc.get("cookie", "")
        cookie_dict = parse_cookie_string(raw_cookie)
        c_user = cookie_dict.get("c_user", "")
        # a usable FB session cookie MUST have c_user (logged-in uid)
        # and xs (session secret). datr alone = logged-out device.
        if not c_user or not cookie_dict.get("xs"):
            invalid.append({"row": row,
                            "reason": "c_user/xs নেই — এটা logged-in cookie না"})
            rejected.append({"row": row, "reason": "invalid (no c_user/xs)"})
            continue
        ident = (acc.get("identifier") or "").strip()
        if c_user in existing_cusers:
            duplicates.append({"row": row, "c_user": c_user})
            rejected.append({"row": row, "reason": "duplicate c_user"})
            continue
        ni = _norm_identifier(ident)
        if ni and ni in existing_idents:
            duplicates.append({"row": row, "c_user": c_user,
                               "identifier": ident})
            rejected.append({"row": row, "reason": "duplicate identifier"})
            continue

        rec = {
            "id": f"acc_{c_user[:12]}_{int(time.time()*1000)%100000}",
            "identifier": ident,
            "password": acc.get("password", ""),
            "c_user": c_user,
            "cookie": raw_cookie,
            "status": "imported",       # imported|validating|validated|expired|duplicate
            "profile_dir": "",
            "last_validated_at": None,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        db["accounts"].append(rec)
        existing_cusers.add(c_user)
        if ni:
            existing_idents.add(ni)
        added.append(rec)

    _save(db)
    return {"added": added, "duplicates": duplicates, "invalid": invalid,
            "rejected": rejected,
            "accounts": db["accounts"]}


def all_accounts() -> list:
    return _load()["accounts"]


def get_account(acc_id: str) -> dict or None:
    for a in _load()["accounts"]:
        if a["id"] == acc_id:
            return a
    return None


def update_account(acc_id: str, **fields):
    db = _load()
    for a in db["accounts"]:
        if a["id"] == acc_id:
            a.update(fields)
            break
    _save(db)


# fields the client may edit from the dashboard
_EDITABLE_INFO_FIELDS = ("identifier", "password")


def update_account_info(acc_id: str, fields: dict) -> dict or None:
    """Dashboard edit of per-account info (identifier / password). Only
    known keys are accepted."""
    clean = {}
    for k in _EDITABLE_INFO_FIELDS:
        if k in fields:
            v = str(fields[k] or "").strip()
            clean[k] = v
    db = _load()
    for a in db["accounts"]:
        if a["id"] == acc_id:
            a.update(clean)
            _save(db)
            return a
    return None


def set_status_by_ids(acc_ids: list, status: str, extra: dict = None):
    db = _load()
    ids = set(acc_ids)
    for a in db["accounts"]:
        if a["id"] in ids:
            a["status"] = status
            if extra:
                a.update(extra)
    _save(db)


def delete_accounts(acc_ids: list, delete_folders: bool = True):
    """Remove accounts from registry; optionally remove their profile
    folders too. Accepts 'ALL' to wipe everything."""
    db = _load()
    ids = None if acc_ids == "ALL" else set(acc_ids)
    keep, removed = [], []
    for a in db["accounts"]:
        if ids is None or a["id"] in ids:
            removed.append(a)
            if delete_folders and a.get("profile_dir"):
                import shutil
                try:
                    shutil.rmtree(a["profile_dir"], ignore_errors=True)
                except Exception:
                    pass
        else:
            keep.append(a)
    db["accounts"] = keep
    _save(db)
    return removed


# ═════════════════════════════════════════════════════════════════════════════
# BUSINESS INFO POOL — shared list, NOT per-profile.
# Each entry = (business_name, your_name, business_email). During a run
# every profile takes the NEXT entry round-robin: 1st account → entry 1,
# 2nd → entry 2, … wraps around, pointer persists between runs.
# ═════════════════════════════════════════════════════════════════════════════
PAGEPOOL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "data", "pagepool.json")


def _pp_load() -> dict:
    with _lock:
        if not os.path.exists(PAGEPOOL_PATH):
            return {"items": [], "recent": []}
        try:
            with open(PAGEPOOL_PATH, "r", encoding="utf-8") as f:
                d = json.load(f)
                d.setdefault("items", [])
                d.setdefault("recent", [])
                return d
        except Exception:
            return {"items": [], "recent": []}


def _pp_save(d: dict):
    with _lock:
        os.makedirs(os.path.dirname(PAGEPOOL_PATH), exist_ok=True)
        tmp = PAGEPOOL_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
        os.replace(tmp, PAGEPOOL_PATH)


def page_pool_list() -> list:
    return _pp_load()["items"]


def page_pool_add(page_name: str, category: str, bio: str) -> dict:
    """Add one Page Info entry {page_name, category, bio(optional)}.
    প্রতিটা BM-এর জন্য এখান থেকে RANDOM entry pick হয় (তবে সাথে সাথে
    একই entry দুবার আসবে না — সব entry ঘুরে এলে আবার শুরু)।"""
    d = _pp_load()
    pn, cat, bio_ = ((page_name or "").strip(), (category or "").strip(),
                     (bio or "").strip()[:100])
    if not pn or not cat:
        return {"added": False, "reason": "Page name আর Category দুটোই লাগবে"}
    for it in d["items"]:
        if it.get("page_name", "").lower() == pn.lower():
            return {"added": False, "reason": "এই Page name আগেই pool-এ আছে"}
    rec = {"id": f"pg_{int(time.time()*1000)%100000000}_{len(d['items'])}",
           "page_name": pn, "category": cat, "bio": bio_,
           "added_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    d["items"].append(rec)
    _pp_save(d)
    return {"added": True, "item": rec}


def page_pool_delete(ids) -> int:
    d = _pp_load()
    if ids == "ALL":
        n = len(d["items"])
        d["items"] = []
    elif isinstance(ids, list) and ids:
        _ids = set(ids)
        n = len([it for it in d["items"] if it.get("id") in _ids])
        d["items"] = [it for it in d["items"] if it.get("id") not in _ids]
    else:
        return 0
    d["recent"] = [r for r in d.get("recent", [])
                   if r in [it["id"] for it in d["items"]]]
    _pp_save(d)
    return n


def page_pool_take_random() -> dict or None:
    """RANDOM entry — সাথে সাথে আগের কয়েটা repeat হবে না।
    Pool খালি হলে None।"""
    import random as _random
    d = _pp_load()
    items = d["items"]
    if not items:
        return None
    recent = d.get("recent", [])
    fresh = [it for it in items if it["id"] not in recent]
    if not fresh:                       # সব ইদ্দিন ব্যবহার হয়ে গেছে → reset
        fresh = items
        recent = []
    pick = _random.choice(fresh)
    recent.append(pick["id"])
    if len(recent) > max(1, len(items) - 1):
        recent = recent[-max(1, len(items) - 1):]
    d["recent"] = recent
    _pp_save(d)
    return pick


BIZ_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "data", "business_infos.json")


def _biz_load() -> dict:
    with _lock:
        if not os.path.exists(BIZ_PATH):
            return {"items": [], "next_index": 0}
        try:
            with open(BIZ_PATH, "r", encoding="utf-8") as f:
                d = json.load(f)
                d.setdefault("items", [])
                d.setdefault("next_index", 0)
                return d
        except Exception:
            return {"items": [], "next_index": 0}


def _biz_save(d: dict):
    with _lock:
        os.makedirs(os.path.dirname(BIZ_PATH), exist_ok=True)
        tmp = BIZ_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
        os.replace(tmp, BIZ_PATH)


def biz_list() -> list:
    return _biz_load()["items"]


def biz_add(business_name: str, your_name: str, business_email: str,
            skip_dupe: bool = True) -> dict:
    """Add one pool entry. Dedupe: identical trio or same email+name is
    rejected (unless skip_dupe=False)."""
    d = _biz_load()
    bn, yn, be = ((business_name or "").strip(),
                  (your_name or "").strip(), (business_email or "").strip())
    if not (bn or be):
        return {"added": False, "reason": "business name বা email কিছু তো দাও"}
    if skip_dupe:
        for it in d["items"]:
            if it.get("business_email") and it.get("business_email") == be:
                return {"added": False, "reason": "এই email আগেই pool-এ আছে"}
            if (it.get("business_name", "").lower() == bn.lower()
                    and bn):
                return {"added": False, "reason": "এই business name আগেই pool-এ আছে"}
    rec = {"id": f"biz_{int(time.time()*1000)%100000000}_{len(d['items'])}",
           "business_name": bn, "your_name": yn, "business_email": be,
           "added_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    d["items"].append(rec)
    _biz_save(d)
    return {"added": True, "item": rec}


def biz_update(biz_id: str, fields: dict) -> dict or None:
    d = _biz_load()
    for it in d["items"]:
        if it["id"] == biz_id:
            for k in ("business_name", "your_name", "business_email"):
                if k in fields:
                    it[k] = str(fields[k] or "").strip()
            _biz_save(d)
            return it
    return None


def biz_delete(biz_ids) -> int:
    d = _biz_load()
    if biz_ids == "ALL":
        n = len(d["items"])
        d["items"] = []
        d["next_index"] = 0
        _biz_save(d)
        return n
    ids = set(biz_ids)
    before = len(d["items"])
    d["items"] = [it for it in d["items"] if it["id"] not in ids]
    d["next_index"] = d["next_index"] % max(1, len(d["items"]))
    _biz_save(d)
    return before - len(d["items"])


def biz_take_next() -> dict or None:
    """Round-robin pick for the NEXT profile. Pointer persists across
    runs so entry usage stays even."""
    d = _biz_load()
    items = d["items"]
    if not items:
        return None
    idx = d.get("next_index", 0) % len(items)
    d["next_index"] = (idx + 1) % len(items)
    _biz_save(d)
    return items[idx]


def biz_import_from_parsed(parsed: list) -> dict:
    """Route business columns found in an imported file/sheet into the
    POOL (not per-profile). Returns {added, skipped}."""
    added = skipped = 0
    for acc in parsed:
        if not (acc.get("business_name") or acc.get("business_email")):
            continue
        r = biz_add(acc.get("business_name", ""),
                    acc.get("your_name", ""),
                    acc.get("business_email", ""))
        if r.get("added"):
            added += 1
        else:
            skipped += 1
    return {"added": added, "skipped": skipped}


# ── per-account business data: BM → page → invites (dashboard status er source) ──

def get_business_data(acc_id: str) -> dict:
    acc = get_account(acc_id) or {}
    return acc.get("business_data") or {"bms": [], "invites": []}


def _save_business_data(acc_id: str, data: dict):
    update_account(acc_id, business_data=data)


def bm_get(business_data: dict, bm_id) -> dict or None:
    for b in (business_data or {}).get("bms", []):
        if str(b.get("id")) == str(bm_id):
            return b
    return None


def bm_upsert(acc_id: str, bm_id, bm_name: str) -> dict:
    """BM record (page na banaleo BM ta list e thakbe — status dekhar jonno)."""
    d = get_business_data(acc_id)
    rec = bm_get(d, bm_id)
    if not rec:
        rec = {"id": str(bm_id), "name": bm_name or "", "page": None,
               "page_created_at": "", "connected": False}
        d.setdefault("bms", []).append(rec)
        _save_business_data(acc_id, d)
    elif bm_name and not rec.get("name"):
        rec["name"] = bm_name
        _save_business_data(acc_id, d)
    return rec


def bm_record_page(acc_id: str, bm_id, bm_name: str, page_name: str):
    """BM er page create + CONNECTED hoye geche."""
    d = get_business_data(acc_id)
    rec = bm_get(d, bm_id)
    if not rec:
        rec = {"id": str(bm_id), "name": bm_name or "", "page": None,
               "page_created_at": "", "connected": False}
        d.setdefault("bms", []).append(rec)
    rec["page"] = page_name
    rec["page_created_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    rec["connected"] = True
    _save_business_data(acc_id, d)


def bm_record_invite(acc_id: str, bm_id, bm_name: str, email: str, link: str):
    d = get_business_data(acc_id)
    rec = bm_get(d, bm_id)
    if not rec:
        rec = {"id": str(bm_id), "name": bm_name or "", "page": None,
               "page_created_at": "", "connected": False}
        d.setdefault("bms", []).append(rec)
    d.setdefault("invites", []).append({
        "bm_id": str(bm_id), "bm_name": rec.get("name") or bm_name or "",
        "email": email, "link": link,
        "ts": time.strftime("%Y-%m-%d %H:%M:%S")})
    _save_business_data(acc_id, d)


def bm_invite_count(business_data: dict, bm_id) -> int:
    """Ei BM e koyta invite link AGEI collect kora hoyeche (DB theke)."""
    d = business_data or {}
    bid = str(bm_id)
    return sum(1 for i in (d.get("invites") or [])
               if isinstance(i, dict) and i.get("link")
               and str(i.get("bm_id")) == bid)


def missing_work(acc: dict) -> dict:
    """Profile er kaj koto baki — 'Select Incomplete' er source."""
    d = acc.get("business_data") or {}
    bms = d.get("bms", [])
    invites = d.get("invites", [])
    pages = sum(1 for b in bms if b.get("page"))
    return {"bms": len(bms), "pages": pages, "invites": len(invites),
            "no_page": len(bms) - pages,
            "no_invite": sum(1 for b in bms
                             if not any(str(i.get("bm_id")) == str(b.get("id"))
                                        for i in invites))}


def profile_dir_for(c_user: str) -> str:
    d = os.path.join(PROFILES_ROOT, f"fb_{c_user}")
    return d


def stats() -> dict:
    accs = all_accounts()
    s = {"total": len(accs), "validated": 0, "expired": 0,
         "imported": 0, "validating": 0}
    for a in accs:
        st = a.get("status", "")
        if st in s:
            s[st] += 1
    return s
