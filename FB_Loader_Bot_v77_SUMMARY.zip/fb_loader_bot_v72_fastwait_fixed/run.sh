#!/bin/bash
cd "$(dirname "$0")"
python3 setup_check.py || exit 1
exec python3 app.py
