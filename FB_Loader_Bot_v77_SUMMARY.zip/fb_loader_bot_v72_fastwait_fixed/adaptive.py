"""Adaptive net-speed engine — slow hole slow chole, fast hole fast.

NetSpeed singleton: every smart_goto() records how long a real navigation
took. Slow (>8s) hoye gele puro bot er wait gulo scale hoye jay —
verify settles, retries, sleeps. Fast net e kono extra wait nei
(khetre inverse: fast thakle ar besi boste hobe na).
"""
import asyncio
import time


class NetSpeed:
    _last_ms = None
    _slow = False

    @classmethod
    def update(cls, ms: float):
        cls._last_ms = ms
        cls._slow = ms > 8000   # 8s+ = slow net (BD mobile/proxy e common)

    @classmethod
    def status(cls) -> str:
        return "slow" if cls._slow else "fast"

    @classmethod
    def scale(cls, base: float, lo: float = None, hi: float = None) -> float:
        """base wait ke net onujayi scale kore (fast=base, slow=base*2.2)."""
        if not cls._slow:
            return base
        v = base * 2.2
        if lo is not None: v = max(v, lo)
        if hi is not None: v = min(v, hi)
        return v

    @classmethod
    def goto_timeout(cls) -> int:
        """Navigation timeout — fast net e 45s, slow hole 90s."""
        return 90000 if cls._slow else 45000


async def smart_goto(page, url, log=None, tag: str = "") -> bool:
    """Net-tolerant navigation. Slow hole boro timeout + retry; fast hole fast.
    Returns True on success, False after patient retries (kabar throw kore na)."""
    from playwright.async_api import TimeoutError as PWTimeout
    last_err = ""
    for attempt in (1, 2):
        t0 = time.time()
        try:
            await page.goto(url, timeout=NetSpeed.goto_timeout(),
                            wait_until="domcontentloaded")
            NetSpeed.update((time.time() - t0) * 1000)
            return True
        except PWTimeout:
            last_err = "load timeout"
            # first timeout ta net slow er signal — marker set kore abar try
            NetSpeed.update(60000)
            if log:
                log(f"{tag} 🐢 net slow — page load time nishche, "
                    f"boro timeout diye abar try korchi (attempt {attempt + 1})…")
            await asyncio.sleep(NetSpeed.scale(4, hi=12))
        except Exception as e:
            last_err = str(e)[:110]
            if "ERR_TIMED_OUT" in last_err or "Timeout" in last_err:
                NetSpeed.update(60000)
                await asyncio.sleep(NetSpeed.scale(4, hi=12))
                continue
            if attempt == 1 and ("ERR_CONNECTION" in last_err or "ERR_PROXY" in last_err
                                 or "net::ERR" in last_err):
                if log:
                    log(f"{tag} ⚠ connection issue ({last_err[:60]}) — ekbar retry…")
                await asyncio.sleep(NetSpeed.scale(3, hi=8))
                continue
            if log:
                log(f"{tag} ⚠ goto fail: {last_err[:80]}")
            return False
    if log:
        log(f"{tag} ⚠ page load hoye gelo na — {last_err[:60]} (net/ proxy issue)")
    return False


async def poll_until(fn, timeout_s: float, interval: float = 0.5,
                       stop_check=None):
    """Generic element/state POLL — pawa MATEI instant return.

    fn          : awaitable → truthy hole sei value SATHE SATHE return
    timeout_s   : deadline (net slow hole caller boro value debe)
    interval    : poll gap (0.25s floor — fast net e ~instant)
    stop_check  : optional callable — True hole None ferot (stop button)

    FIXED sleep er bodole ei: element/estado jantey SATHE SATHE action.
    Na pele deadline porjonto chup kore poll — net slow hole-o thik
    boshe thake, ar reload diye somoy noshto kore na."""
    t0 = time.time()
    interval = max(0.25, interval)
    while time.time() - t0 < timeout_s:
        try:
            if stop_check and stop_check():
                return None
            v = await fn()
            if v:
                return v
        except Exception:
            pass
        await asyncio.sleep(interval)
    return None


async def settle(page, base: float, lo: float = None, hi: float = None):
    """Adaptive settle — slow net e beshi wait, fast e kom."""
    await asyncio.sleep(NetSpeed.scale(base, lo, hi))
