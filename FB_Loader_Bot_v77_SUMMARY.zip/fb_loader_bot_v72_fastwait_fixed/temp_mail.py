"""Free temp-mail providers — one fresh address per BM invitation.

Providers (both free, no API key):
  * mail.tm          — REST API, unlimited fresh addresses, JSON messages
  * guerrillamail    — fallback when mail.tm is down/rate-limited

The bot needs: a fresh address BEFORE the invite, then poll for Facebook's
invitation email and pull the accept/confirm LINK out of the body.
"""
import asyncio
import random
import re
import string

import urllib.request
import urllib.parse
import json

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/126.0 Safari/537.36",
      "Accept": "application/json"}


def _transient(e) -> bool:
    """Ek-ekbar network hiccup — retry korle thik hoye jay.
    (WinError 10054 = connection reset — tempmail.plus/lol e
    exactly ei jinish ghotto, tai shudhu ek reset-e source bad
    dewa hoy na.)"""
    s = str(e).lower()
    return ("10054" in s or "10060" in s or "reset" in s
            or "timed out" in s or "timeout" in s or "429" in s
            or "502" in s or "503" in s or "504" in s
            or "connection" in s or "refused" in s)


def _http_json(url, data=None, headers=None, timeout=15, tries=2, backoff=1.0):
    """v7.6 RELIABLE: transient error (reset/timeout/429/5xx) hole
    1 bar abar try — 1st/2nd mail source (tempmail.plus/lol) shudhu
    ekta hiccup-er karone dead hoye jay na. Permanent error (4xx)
    e retry NAI."""
    import time as _time
    h = dict(UA)
    if headers:
        h.update(headers)
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        h["Content-Type"] = "application/json"
    for i in range(max(1, tries)):
        try:
            req = urllib.request.Request(url, data=body, headers=h)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.loads(r.read().decode() or "{}")
        except Exception as e:
            code = getattr(e, "code", None)
            permanent = isinstance(code, int) and code < 500 and code != 429
            if i + 1 >= max(1, tries) or (permanent and code != 429 and 408 != code):
                raise
            _time.sleep(backoff * (i + 1))     # 1s, 2s… por abar try


def _http_get_text(url, headers=None, timeout=15, tries=2, backoff=1.0):
    """v7.6: _http_json er motoi transient retry."""
    import time as _time
    h = dict(UA)
    if headers:
        h.update(headers)
    for i in range(max(1, tries)):
        try:
            req = urllib.request.Request(url, headers=h)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read().decode("utf-8", "ignore")
        except Exception as e:
            code = getattr(e, "code", None)
            permanent = isinstance(code, int) and code < 500 and code != 429
            if i + 1 >= max(1, tries) or permanent:
                raise
            _time.sleep(backoff * (i + 1))


# ───────────────────────────── mail.tm ─────────────────────────────

# mail.tm ar mail.gw — EKI API, alada domain (duitar e jaigeh thakle
# ekta rate-limit/block hole onno ta kaj korbe)
_MTM_BASES = ["https://api.mail.tm", "https://api.mail.gw"]


def _mtm_api(path, base=None):
    return f"{base or _MTM_BASES[0]}{path}"


def _mtm_domains():
    d = _http_json(_mtm_api("/domains?page=1"))
    # mail.tm kokhono hydra:member object, kokhono sorsa list dey
    if isinstance(d, list):
        items = d
    elif isinstance(d, dict):
        items = d.get("hydra:member") or d.get("member") or d.get("items") or []
    else:
        items = []
    out = []
    for x in items:
        if isinstance(x, dict):
            dom = x.get("domain")
            if dom and x.get("isActive", True):
                out.append(dom)
        elif isinstance(x, str):
            out.append(x)
    return out


def mtm_new_address():
    last = None
    for base in _MTM_BASES:
        try:
            return _mtm_new_address_at(base)
        except Exception as e:
            last = e
    raise last or RuntimeError("mail.tm/gw: kono base e address holo na")


def _mtm_new_address_at(base):
    domains = _http_json(f"{base}/domains?page=1")
    if isinstance(domains, dict):
        domains = (domains.get("hydra:member") or domains.get("member")
                   or domains.get("items") or [])
    domains = [d.get("domain") for d in domains if d.get("domain")]
    if not domains:
        raise RuntimeError("mail api: kono domain pailam na")
    user = "s2c" + "".join(random.choices(string.ascii_lowercase + string.digits, k=10))
    addr = f"{user}@{random.choice(domains)}"
    pw = "S2c" + "".join(random.choices(string.ascii_letters + string.digits, k=10))
    _http_json(f"{base}/accounts", {"address": addr, "password": pw})
    tok = _http_json(f"{base}/token", {"address": addr, "password": pw})
    if not isinstance(tok, dict) or not tok.get("token"):
        raise RuntimeError("mail api: token response onno format")
    provider = "mail.gw" if "mail.gw" in base else "mail.tm"
    return {"email": addr, "token": tok["token"], "password": pw,
            "provider": provider, "base": base}


def mtm_relogin(mail):
    """mail.tm/gw token EXPIRE hoye gele (HTTP 401) address+password diye
    abar login kore fresh token ney — mail dict update kore dey."""
    base = mail.get("base") or _MTM_BASES[0]
    tok = _http_json(f"{base}/token",
                     {"address": mail["email"], "password": mail["password"]})
    if not isinstance(tok, dict) or not tok.get("token"):
        raise RuntimeError("mail api: relogin fail")
    mail["token"] = tok["token"]
    return mail["token"]


def mtm_messages(token, base=None):
    d = _http_json(_mtm_api("/messages?page=1", base or _MTM_BASES[0]),
                   headers={"Authorization": f"Bearer {token}"})
    if isinstance(d, list):
        return d
    if isinstance(d, dict):
        return d.get("hydra:member") or d.get("member") or d.get("items") or []
    return []


def mtm_message_html(token, msg_id, base=None):
    m = _http_json(_mtm_api(f"/messages/{msg_id}", base or _MTM_BASES[0]),
                   headers={"Authorization": f"Bearer {token}"})
    h = m.get("html")
    if isinstance(h, list):          # মাল্টি-part হলে সব অংশ জোড়া দিই — প্রথম
        h = "\n".join(str(x) for x in h)   # part এ link না থাকলে miss হতো
    return h or m.get("text") or ""


# ───────────────────────────── tempmail.plus ────────────────────────
# VALO MAIL (v6.9): LOGIN/TOKEN system-i NAI — mailbox = shudhu email
# address. Token expire/relogin fail er somossa KABHU NAI. Inbox abar
# abar pora jay (mail dhore rakha → late link collection er jonno).

# fexpost/rover beshi (kom-blocked) — mailto.plus famous domain,
# FB block korar chance beshi tai kom neya hoy
_TP_DOMAINS = ["fexpost.com", "fexpost.com", "rover.info", "rover.info",
               "mailto.plus"]


def tp_new_address():
    addr = "s2c" + "".join(random.choices(string.ascii_lowercase +
                                         string.digits, k=10)) + \
           "@" + random.choice(_TP_DOMAINS)
    mail = {"email": addr, "provider": "tempmail.plus",
            "base": "https://tempmail.plus"}
    _inbox_live_check(mail)      # inbox pora jay kina — prothomei
    return mail


def tp_messages(mail):
    d = _http_json("https://tempmail.plus/api/mails?email="
                   + urllib.parse.quote(mail["email"]) + "&first_id=0")
    if not d.get("result") and d.get("count", 0) <= 0:
        return []
    return d.get("mail_list") or []


def tp_message_body(mail, mid):
    m = _http_json("https://tempmail.plus/api/mails/" + str(mid)
                   + "?email=" + urllib.parse.quote(mail["email"])
                   + "&first_id=0")
    h = m.get("html")
    if isinstance(h, list):
        h = " ".join(str(x) for x in h)
    return (h or m.get("text") or m.get("body") or "")


# ───────────────────────────── tempmail.lol ────────────────────────
# v6.9.2 FALLBACK #1: key-less free API — generate {address, token}
# → inbox GET /auth/{token}. Token opaque, relogin system NAI
# (relogin fail hoy NA — mail.tm er moto kono jhamela nai).

def tl_fetch(url):
    """tempmail.lol GET — 429 (rate limit) ele ekbar 4s wait kore retry."""
    import time as _t
    try:
        return _http_json(url)
    except Exception as e:
        if "429" in str(e):
            _t.sleep(4)
            return _http_json(url)
        raise


def tl_new_address():
    d = tl_fetch("https://api.tempmail.lol/generate")
    if not d.get("address") or not d.get("token"):
        raise RuntimeError("tempmail.lol: generate fail")
    mail = {"email": d["address"], "token": d["token"],
            "provider": "tempmail.lol", "base": "https://api.tempmail.lol"}
    _inbox_live_check(mail)
    return mail


def tl_messages(mail):
    d = tl_fetch("https://api.tempmail.lol/auth/" + (mail.get("token") or ""))
    lst = d.get("email") or d.get("mail_list") or []
    if isinstance(lst, dict):
        lst = list(lst.values())
    return lst


def tl_message_body(m):
    h = m.get("html")
    if isinstance(h, list):
        h = " ".join(str(x) for x in h)
    return (h or m.get("body") or "")


# ───────────────────────────── guerrillamail ────────────────────────

def gm_new_address():
    d = _http_json("https://api.guerrillamail.com/ajax.php?f=get_email_address")
    return {"email": d["email_addr"], "sid": d["sid_token"], "seq": 1, "provider": "guerrilla"}


def gm_messages(mail):
    d = _http_json(f"https://api.guerrillamail.com/ajax.php?f=get_email_list&offset=0&sid_token={mail['sid']}")
    return d.get("list") or []


def gm_message_body(mail, mail_id):
    d = _http_json(f"https://api.guerrillamail.com/ajax.php?f=fetch_email&email_id={mail_id}&sid_token={mail['sid']}")
    return d.get("mail_body") or ""




# ───────────────────────── dropmail.me (GraphQL API) ────────────────────────

_DM_TOKEN = "".join(random.choices("0123456789abcdef", k=16))


def _dm_gql(query):
    d = _http_json(f"https://dropmail.me/api/graphql/{_DM_TOKEN}",
                   {"query": query})
    if not isinstance(d, dict) or d.get("errors"):
        raise RuntimeError("dropmail api error")
    return d.get("data") or {}


def dm_new_address():
    d = _dm_gql("mutation { introduceSession { id, expiresAt, "
                "addresses { address } } }")
    sess = d.get("introduceSession") or {}
    addr = (sess.get("addresses") or [{}])[0].get("address", "")
    if not addr or not sess.get("id"):
        raise RuntimeError("dropmail: address pailam na")
    return {"email": addr, "session": sess["id"], "provider": "dropmail"}


def dm_messages(mail):
    d = _dm_gql(f'query {{ session(id: "{mail["session"]}") '
                f'{{ mails {{ rawSize, fromAddr, toAddr, headerSubject, '
                f'text, html }} }} }}')
    return ((d.get("session") or {}).get("mails")) or []


def dm_message_html(mail, msg):
    h = msg.get("html")
    if isinstance(h, list):
        return " ".join(str(x) for x in h)
    return h or msg.get("text") or ""



# ───────────────────────────── unified API ─────────────────────────

def _inbox_live_check(mail):
    """Mailbox ta SATIKI pora jay kina ekbar check — invite pathanor
    AGE ei test pass korte hobe. Ei ta pass korle mail ta ashole-i
    beche ache ar FB invitation read korte parbe."""
    if mail["provider"] in ("mail.tm", "mail.gw"):
        mtm_messages(mail["token"], mail.get("base") or _MTM_BASES[0])
    elif mail["provider"] == "tempmail.plus":
        tp_messages(mail)
    elif mail["provider"] == "tempmail.lol":
        tl_messages(mail)
    elif mail["provider"] == "guerrilla":
        d = _http_json("https://api.guerrillamail.com/ajax.php"
                       f"?f=get_email_list&offset=0&sid_token={mail['sid']}")
        if "list" not in d:
            raise RuntimeError("guerrilla: inbox read fail")
    elif mail["provider"] == "dropmail":
        dm_messages(mail)
    return True


def new_address(log=None, tag=""):
    """Fresh temp address — 4 ta valo source er chain, prottekta
    LIVE CHECK hoy (inbox pora jay kina). Prothom jeta live check
    pass kore sheta return — invite kokhono mora mail e jay na.
    Source: mail.tm/gw (family) → guerrilla → dropmail."""
    makers = [
        # v6.9.2 chain — client: "mail.tm valueless, 2nd e best working
        # source rakhо jeno tempmail.plus e problem hole kaj miss na hoy":
        #   1. tempmail.plus  — primary, login/token NAI (kaj korche ✓)
        #   2. tempmail.lol   — key-less API, token-based, relogin NAI
        #   3. guerrilla      — purano khara bhaowa, sob kichhur por
        #   4. dropmail       — endpoint ekhon strict, kintu try koro
        #   5. mail.tm/gw     — SHESH e (user-er network e kaj kore na,
        #                        relogin-fail spam — tai dead-last)
        ("tempmail.plus", tp_new_address),
        ("tempmail.lol", tl_new_address),
        ("guerrilla", gm_new_address),
        ("dropmail", dm_new_address),
        ("mail.tm/gw", mtm_new_address),
    ]
    last_err = ""
    for name, maker in makers:
        # v7.6 RELIABLE: ek reset-e source bad dewa hoy na — ekta
        # provider 2 bar try (major+backup duei level e retry).
        for _try in (1, 2):
            try:
                m = maker()
                # LIVE CHECK — ei e main: inbox pora jay kina
                _inbox_live_check(m)
                log and log(f"{tag} 📧 temp mail ({m.get('base') or m['provider']}): "
                            f"{m['email']} ✓ live")
                return m
            except Exception as e:
                last_err = str(e)[:60]
                if _try == 1:
                    import time as _t2
                    log and log(f"{tag} ⚠ {name} try-1 fail ({last_err}) — "
                                f"1.2s pore abar try")
                    _t2.sleep(1.2)
        log and log(f"{tag} ⚠ {name} kaj korche na ({last_err}) → "
                    f"porer mail source try")
    raise RuntimeError(f"shob mail source down ({last_err})")


# Facebook invitation mail e accept/confirm link — ei pattern gulo khunjbo
def _link_score(u):
    """Ekta URL invitation-link kina bolchi. 0 = nao (logo/footer).
    Beshi score = beshi nishchito invitation link."""
    low = u.lower()
    # FB domain lagbe
    if not any(d in low for d in ("facebook.com", "fbmail", "fb.com")):
        return 0
    # bare domain (https://business.facebook.com/) — logo/footer link, bad
    rest = re.sub(r"^https?://[^/]+", "", u, flags=re.I)
    if rest in ("", "/"):
        return 0
    score = 0
    # ✅ ASOL invitation: /invitation/?token=... ("Log in to view
    # invitation" button er link)
    if "/invitation" in low:
        score += 4
    if "token=" in low:
        score += 3
    if any(k in low for k in ("adminrole", "/confirm", "/accept")):
        score += 2
    if "business.facebook.com" in low:
        score += 1
    return score


def _extract_invite_link(html, log=None, tag=""):
    """FB invitation mail body theke EXACT original accept-link ber kora.
    "Log in to view invitation" button er /invitation/?token=... link ta
    e ber kore — logo/footer er bimroto domain link kakhono nao.
    Mane: nishchito invitation-link na pele khali string dibe (pore
    poll cholbe), bhul link kabhu dibe na."""
    if not html:
        return ""
    # mail.tm html list hishebe ase — join kore nei
    if isinstance(html, list):
        html = " ".join(str(x) for x in html)

    cands = [m.group(1) for m in re.finditer(r'href="(https?://[^"]+)"', html)]
    # html link na thakle plain text URL
    if not cands:
        cands = [m.group(0) for m in re.finditer(r'https?://[^\s<>"\']+', html)]

    best, best_key = "", (-1, -1)
    for u in cands:
        s = _link_score(u)
        if s == 0:
            continue
        # same score hole LOMBA link jite — invitation token URL
        # sob somoy lomba hoy
        key = (s, len(u))
        if key > best_key:
            best, best_key = u, key
    if best:
        log and log(f"{tag} 🧲 invitation link: {best[:80]}…")
    return best


def _scan_mailbox_sync(mail, tag, seen, log=None):
    """EK poll pass: provider onujayi inbox pora → FB invitation mail
    khuje link extract. mail.tm/gw er token 401 raise korle caller
    relogin kore. seen = id set (body PORAR POR add hoy — mail harabe na)."""
    if mail["provider"] in ("mail.tm", "mail.gw"):
        msgs = mtm_messages(mail["token"], mail.get("base") or _MTM_BASES[0])
        for m in msgs:
            mid = str(m.get("id"))
            if mid in seen:
                continue
            frm = (m.get("from", {}) or {}).get("address", "") or str(m.get("from", ""))
            subj = (m.get("subject") or "").lower()
            if "facebook" not in (frm + " " + subj) and \
                    "invite" not in subj and "business" not in subj:
                seen.add(mid)
                continue
            body = mtm_message_html(mail["token"], mid,
                                    mail.get("base") or _MTM_BASES[0])
            seen.add(mid)      # body PORAR POR — fetch fail hole mail harabe na
            link = _extract_invite_link(body, log, tag)
            if link:
                return link
    elif mail["provider"] == "tempmail.plus":
        for m in tp_messages(mail):
            mid = str(m.get("mail_id"))
            if mid in seen:
                continue
            frm = (m.get("from") or m.get("from_address") or "").lower()
            subj = (m.get("subject") or "").lower()
            if "facebook" not in (frm + " " + subj) and \
                    "invite" not in subj and "business" not in subj:
                seen.add(mid)
                continue
            body = tp_message_body(mail, mid)
            seen.add(mid)
            link = _extract_invite_link(body, log, tag)
            if link:
                return link
    elif mail["provider"] == "tempmail.lol":
        for m in tl_messages(mail):
            _frm_raw = m.get("from") or ""
            if not isinstance(_frm_raw, str):
                _frm_raw = str(_frm_raw)
            mid = str(m.get("id") or m.get("mail_id") or
                      (m.get("subject") or "") + _frm_raw)
            if mid in seen:
                continue
            frm = m.get("from") or m.get("sender") or ""
            if isinstance(frm, dict):
                frm = frm.get("address") or frm.get("email") or ""
            frm = str(frm).lower()
            subj = (m.get("subject") or "").lower()
            if "facebook" not in (frm + " " + subj) and \
                    "invite" not in subj and "business" not in subj:
                seen.add(mid)
                continue
            body = tl_message_body(m)
            seen.add(mid)
            link = _extract_invite_link(body, log, tag)
            if link:
                return link
    elif mail["provider"] == "dropmail":
        for m in dm_messages(mail):
            mid = str(m.get("rawSize")) + str(m.get("headerSubject"))
            if mid in seen:
                continue
            subj = (m.get("headerSubject") or "").lower()
            frm = (m.get("fromAddr") or "").lower()
            if "facebook" not in (frm + " " + subj):
                continue
            body = dm_message_html(mail, m)
            seen.add(mid)      # body PORAR POR — abar fetch hoy na
            link = _extract_invite_link(body, log, tag)
            if link:
                return link
    else:
        for m in gm_messages(mail):
            mid = str(m.get("mail_id"))
            if mid in seen:
                continue
            subj = (m.get("mail_subject") or "").lower()
            frm = (m.get("mail_from") or "").lower()
            if "facebook" not in (frm + " " + subj):
                seen.add(mid)
                continue
            body = gm_message_body(mail, mid)
            seen.add(mid)
            link = _extract_invite_link(body, log, tag)
            if link:
                return link
    return ""


async def _scan_mailbox_once(mail, tag, seen, log=None):
    """EK poll pass (async, NON-BLOCKING). sync urllib HTTP gulo
    background thread e chole — event loop free thake, poll er
    somoy-o onno lane er browser automation cholbe. mail.tm/gw er
    token 401 raise korle caller relogin kore. seen = id set (body
    PORAR POR add hoy — mail harabe na)."""
    return await asyncio.get_event_loop().run_in_executor(
        None, _scan_mailbox_sync, mail, tag, seen, log)


async def poll_invite_link(mail, wait_s=150, log=None, tag="", stop_check=None):
    """Invite pathanor POR inbox poll — FB invitation mail er accept-link.
    v6.9: mail ASHLE-o jodi wait_s e na ashe, mailbox FELA HOY NA —
    register_late_mail() e DHORE rakha hoy (late-link queue, 15 min)."""
    import time
    deadline = time.time() + wait_s
    seen = set()
    relogin_fails = 0
    # poll shuru korar AGEI token refresh — purano token e 401 waste
    if mail.get("provider") in ("mail.tm", "mail.gw") and mail.get("password"):
        try:
            await asyncio.get_event_loop().run_in_executor(
                None, mtm_relogin, mail)
        except Exception:
            pass
    while time.time() < deadline:
        if stop_check and stop_check():
            if log:
                log(f"{tag} ⏹ stop requested — inbox poll chere dilam")
            return ""
        try:
            link = await _scan_mailbox_once(mail, tag, seen, log)
            if link:
                log and log(f"{tag} 🔗 invite link paowa geche ({mail['email']})")
                return link
        except Exception as e:
            # token expire (401) → re-login kore poll cholbe
            if "401" in str(e) and mail.get("password"):
                try:
                    await asyncio.get_event_loop().run_in_executor(
                        None, mtm_relogin, mail)
                    relogin_fails = 0
                    log and log(f"{tag} 🔑 mail token refresh hole — poll cholbe")
                except Exception as e2:
                    relogin_fails += 1
                    log and log(f"{tag} ⚠ relogin fail ({relogin_fails}/3): "
                                f"{str(e2)[:50]}")
                    if relogin_fails >= 3:
                        # mail.tm ei ACCOUNT DELETE kore dise — ei address
                        # e mail ABAR ashbe na. Dead-mark: late-queue te
                        # dhukbe NA (beyar ব্যর্থ চেষ্টা 15 min erokkom
                        # cholbe na)
                        mail["_dead"] = True
                        log and log(f"{tag} ❌ mail.tm ei account delete "
                                    f"kore dise — ei invite er link ar "
                                    f"ashbe na. Next invite cholbe")
                        break
            else:
                log and log(f"{tag} ⚠ inbox poll error: {str(e)[:60]}")
        await asyncio.sleep(poll_every())
    log and log(f"{tag} ⏳ {wait_s}s e invitation mail ashena ({mail['email']})"
                f" — mailbox DHORE RAKHLAM, background e dekhbo")
    return ""


def poll_every():
    return 12


# ═══════════════════════════ LATE-LINK HOLD QUEUE ═══════════════════
# CLIENT RULE: "invitation link pathiye abar collect kora porjonto sei
# mail DHORE RAKHTE HOBE" — FB mail beshirbhag somoy 1-10 MINUTE e ashe
# (temp domain e deri KHKUB common). Ei queue poll-fail kora mailboxes
# 15 min porjonto re-check kore — link ele SATHE SATHE save (callback).

import time as _time_mod

LATE_MAILS = []                     # [{"mail", "tag", "ctx", "added", "seen"}]
_LATE_CB = None                     # engine set kore: cb(ctx, email, link)
_LATE_REAPER_TASK = None
LATE_MAX_AGE_S = 15 * 60            # 15 min hold


def set_late_callback(cb):
    """Engine এইটা set kore: cb(ctx, email, link) → link save + results.txt.
    cb = None hole late link shudhu log hoy."""
    global _LATE_CB
    _LATE_CB = cb


def register_late_mail(mail, tag="", ctx=None):
    """Poll fail korle mailbox FELAR BDORU queue te DHORE rakha —
    late mail ele link collect + save hobe (15 min porjonto)."""
    for e in LATE_MAILS:
        if (e.get("mail") or {}).get("email") == (mail or {}).get("email"):
            return False
    LATE_MAILS.append({"mail": dict(mail), "tag": tag or "", "ctx": ctx,
                       "added": _time_mod.time(), "seen": set()})
    return True


def late_queue_size() -> int:
    return len(LATE_MAILS)


async def run_late_reaper(log=None, stop_check=None):
    """Background task: 30s por por shob held mailbox re-check.
    mail.tm token refresh kore, tempmail.plus e toke nai-i.
    Link pele → LATE_CB (engine) → results.txt save. 15 min por
    mailbox chere dey (FB mail ashle ashle ekhon)."""
    while True:
        try:
            if stop_check and stop_check():
                return
            now = _time_mod.time()
            for entry in list(LATE_MAILS):
                m = entry["mail"]
                if now - entry["added"] > LATE_MAX_AGE_S:
                    LATE_MAILS.remove(entry)
                    log and log(f"{entry['tag']} ⌛ 15-min late-window shesh — "
                                f"mail ashlo na: {m.get('email')}")
                    continue
                try:
                    # mail.tm/gw token fresh rakha (relogin fail bancha)
                    if m.get("provider") in ("mail.tm", "mail.gw") and \
                            m.get("password") and random.random() < 0.4:
                        try:
                            await asyncio.get_event_loop().run_in_executor(
                                None, mtm_relogin, m)
                        except Exception:
                            pass
                    link = await _scan_mailbox_once(m, entry["tag"],
                                                    entry["seen"], log)
                    if link:
                        LATE_MAILS.remove(entry)
                        log and log(f"{entry['tag']} 🐢 LATE invite link "
                                    f"ASHE — save korlam! {link[:70]}…")
                        if _LATE_CB:
                            try:
                                _LATE_CB(entry.get("ctx"), m.get("email"), link)
                            except Exception as cb_err:
                                log and log(f"{entry['tag']} ⚠ late-link "
                                            f"save fail: {str(cb_err)[:60]}")
                except Exception:
                    pass
        except Exception:
            pass
        await asyncio.sleep(30)


def start_late_reaper(log=None, stop_check=None):
    """Ekbar start (double-start guard ache) — engine run-er shuru te."""
    global _LATE_REAPER_TASK
    if _LATE_REAPER_TASK is not None and not _LATE_REAPER_TASK.done():
        return _LATE_REAPER_TASK
    _LATE_REAPER_TASK = asyncio.create_task(
        run_late_reaper(log=log, stop_check=stop_check))
    return _LATE_REAPER_TASK
