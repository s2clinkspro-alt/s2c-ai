"""Run engine — opens accounts sequential or concurrent (1-5 lanes).

Two modes:
  validate  : open → verify login → close (marks validated / expired).
              This is the import-quality pass: expired cookies get
              status='expired' and NEVER keep a profile folder.
  run       : open → verify → run_profile_job() → close. The per-profile
              job hook is where the client's later step-by-step tasks
              (comment/post/react/...) will plug in.

Every lane gets: own proxy (from proxy.txt in order), staggered start,
isolated browser, per-lane log prefix.
"""
import asyncio
import os

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
import random
import shutil
import threading
import time

import accounts_db
from browser_manager import (open_profile, close_profile, verify_login, load_proxies,
                             AccountBlocked,
                             proxy_for_account)
from accounts_db import profile_dir_for

# ── global run state ──────────────────────────────────────────────────────────
_state_lock = threading.Lock()
_state = {"running": False, "mode": "validate", "lanes": 1, "stop": False,
          "started_at": None, "current": "", "done": 0, "total": 0,
          "ok": 0, "failed": 0, "stopping": False}


# live state push: app.py registers a callback; engine calls it on EVERY
# change (start / each account done / stop requested / finished) so the
# dashboard buttons flip instantly with no polling or refresh.
_listener = None


def set_state_listener(fn):
    global _listener
    _listener = fn


def _push():
    fn = _listener
    if fn:
        try:
            fn(status())
        except Exception:
            pass


def status() -> dict:
    with _state_lock:
        return dict(_state)


def engine_stop_requested() -> bool:
    """Background run thread theke stop check."""
    with _state_lock:
        return bool(_state.get("stop"))


_LOOP_REF = {"loop": None}
_LANE_TASKS = {"tasks": []}


def request_stop():
    """STOP চাপলেই: flag + সব লাইভ ব্রাউজার সাথে সাথে বন্ধ।
    ব্রাউজার বন্ধ হলে চলমান wizard/poll exception দেয় → engine ধরে নেয়
    → lane গুলো flag দেখে বেরিয়ে যায়। আর ১৫০ সেকেন্ড অপেক্ষা নেই।"""
    with _state_lock:
        _state["stop"] = True
        _state["stopping"] = True
    _push()
    # v7.6: PID SNAPSHOT AGE — force_close_all registry clear kore
    # fale, tai nuke er age pids dore rakha LAGBE (r/w race fix)
    _stop_pids = []
    try:
        from browser_manager import active_pids
        _stop_pids = active_pids()
    except Exception:
        pass
    loop = _LOOP_REF.get("loop")
    if loop is not None:
        try:
            from browser_manager import force_close_all
            asyncio.run_coroutine_threadsafe(force_close_all(), loop)
            # GUARANTEE: browser close-er por o kono lane atke thakle
            # (playwright call chara sleep e) 6s por task cancel
            asyncio.run_coroutine_threadsafe(_cancel_lanes_after_grace(), loop)
        except Exception as e:
            print(f"[stop] force close fail: {e}")
    # ULTIMATE GUARANTEE: engine loop jodi kisui kaje atke thake,
    # 1.5s por Flask thread thekei OS-level process tree kill —
    # browser kokhono beche thakbe na
    def _os_nuke():
        time.sleep(1.5)
        try:
            from browser_manager import kill_browsers_os
            n = kill_browsers_os(pids=_stop_pids)
            if n:
                print(f"[stop] OS-level kill: {n} process")
        except Exception as e:
            print(f"[stop] os nuke fail: {e}")
    threading.Thread(target=_os_nuke, daemon=True).start()


async def _cancel_lanes_after_grace(grace_s: float = 6.0):
    """force_close_all er por 6s — tarporo sesh na howa lane task
    cancel — engine kokhono 'running' e atke thakbe na."""
    await asyncio.sleep(grace_s)
    tasks = [t for t in _LANE_TASKS.get("tasks", []) if not t.done()]
    if not tasks:
        return
    for t in tasks:
        t.cancel()
    # cancel er por lane gulo nijei sesh hobe


def is_running() -> bool:
    with _state_lock:
        return _state["running"]


def _write_results(acc_id, log):
    """Output txt: invite LINK গুলোর ফলাফল ফাইল — puro file FRESH
    rebuild kore (DB theke), tai protibar call holeo duplicate hoy na.
    Prottekta link pawar SATHE SATHE call kora hoy — crash/stop holeo
    jeta paisi ta saved thake.
    ফরম্যাট: প্রোফাইল (নাম + FB ID) → Business Manager 01 + তার লিংক গুলো →
    ... এভাবে প্রতিটা প্রোফাইল। একটাও আসল invite link না থাকলে ফাইলে কিছুই না।"""
    try:
        blocks = []
        for acc in accounts_db.all_accounts():
            bdata = acc.get("business_data") or {}
            invites = [inv for inv in (bdata.get("invites") or [])
                       if isinstance(inv, dict) and inv.get("link")
                       and not str(inv.get("link", "")).startswith("(")]
            if not invites:
                continue
            shown = acc.get("identifier") or acc.get("c_user", "?")
            lines = ["", "=" * 60,
                     f"PROFILE: {shown}  (FB ID: {acc.get('c_user', '?')})",
                     "=" * 60]
            order = []
            grouped = {}
            for inv in invites:
                bid = str(inv.get("bm_id") or "?")
                if bid not in grouped:
                    grouped[bid] = {"name": inv.get("bm_name") or bid,
                                    "links": []}
                    order.append(bid)
                grouped[bid]["links"].append(inv["link"])
            for n, bid in enumerate(order, 1):
                g = grouped[bid]
                lines.append(f"Business Manager {n:02d}: {g['name']}")
                for link in g["links"]:
                    lines.append(f"  {link}")
            blocks.append("\n".join(lines))
        os.makedirs(os.path.join(APP_ROOT, "output"), exist_ok=True)
        path = os.path.join(APP_ROOT, "output", "invite_results.txt")
        if blocks:
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(blocks) + "\n")
            log("📤 invite link save holo — output/invite_results.txt")
        # ── EXCEL OUTPUT (Buyer / Backup / Summary) — SATHE SATHE save ──
        try:
            import sheet_output
            sheet_output.write_excel(log=log)
        except Exception as e:
            log(f"⚠ excel output fail: {str(e)[:80]}")
        # ── GOOGLE SHEET OUTPUT — v7.0 e on hobe (module ready) ──
        try:
            import sheet_output as _so
            _so.write_gsheet(log=log)
        except Exception:
            pass
    except Exception as e:
        log(f"⚠ results.txt write fail: {str(e)[:80]}")


# ── per-profile job hook — CLIENT WILL DEFINE TASKS STEP BY STEP LATER ────────
async def run_profile_job(page, account, lane: int, log, biz_info=None):
    """The per-profile work: create the business profile on
    business.facebook.com using this profile's round-robin pool pick
    {business_name, your_name, business_email} → Next × 3 → Done."""
    tag = f"[lane {lane}]"
    if not biz_info:
        log(f"{tag} ⚠ Business Info Pool খালি — আগে entry যোগ করো, এই প্রোফাইল স্কিপ")
        return False
    log(f"{tag} job start — business.facebook.com form fill: "
        f"{biz_info['business_name']} / {biz_info.get('your_name', '')} / "
        f"{biz_info.get('business_email', '')}")

    from biz_form import create_business_profile
    # name problem after Submit → wizard asks for ANOTHER saved business info
    # (next entry in the shared pool), up to 3 tries total, then skips this profile.
    status, detail = await create_business_profile(
        page, biz_info, log, tag, next_biz=accounts_db.biz_take_next)
    acc_id = account.get("id")

    if status == "created":
        import re as _re
        m = _re.search(r"attempt \d+: (.+)\)$", detail or "")
        used = m.group(1) if m else biz_info["business_name"]
        log(f"{tag} ✅ BUSINESS PROFILE CREATED — {used}")
        if acc_id:
            accounts_db.update_account(acc_id, business_profile=used)
        return True
    if status == "exists":
        log(f"{tag} ℹ এই আইডিতে আগেই বিজনেস প্রোফাইল আছে — skip")
        if acc_id:
            accounts_db.update_account(acc_id, business_profile="already exists")
        return True
    log(f"{tag} ❌ ব্যর্থ — {detail}  → পরের প্রোফাইলে যাচ্ছি")
    if acc_id:
        accounts_db.update_account(acc_id, business_profile=f"failed: {detail[:60]}")
    return False


# ─────────────────────────────────────────────────────────────────────────────
# v6.2: handover-ব্রাউজার সিস্টেম বাদ — ওয়ার্কফ্লো নিজেই প্রতি প্রোফাইলের কাজ
# শেষ করে ব্রাউজার বন্ধ করে পরের প্রোফাইলে যায়। ম্যানুয়াল দরকার হলে ড্যাশবোর্ডের
# প্রোফাইল-লাইনের Open বাটন (manual_open) ব্যবহার হবে।


async def _process_account(account, lane, proxies, mode, log, opts=None):
    acc_id = account["id"]
    c_user = account.get("c_user", "?")
    tag = f"[lane {lane}] {account.get('identifier') or c_user}"
    log(f"{tag} opening…")

    pdir = profile_dir_for(c_user)
    # A previously VERIFIED profile keeps its folder (same device identity every
    # time = no "new device" flags). Only never-verified / expired accounts start
    # fresh so a dead session can't leave ghost state.
    _was_live = account.get("status") == "validated" and os.path.isdir(pdir)
    if os.path.exists(pdir) and not _was_live:
        shutil.rmtree(pdir, ignore_errors=True)
    os.makedirs(pdir, exist_ok=True)
    account = dict(account, profile_dir=pdir)

    proxies_used = proxy_for_account(account, proxies)   # same IP for this account, every run

    accounts_db.update_account(acc_id, status="validating",
                               profile_dir=(pdir if _was_live else ""))

    biz_info = None
    pw = br = None
    keep_profile = False
    try:
        _headless = bool((opts or {}).get("headless")) if mode == "bmcreate" else False
        pw, br, ctx, page, fp = await open_profile(
            account, proxy_line=proxies_used, headless=_headless, log=log)
        v = await verify_login(ctx, page, log_fn=log)
        if not v["ok"]:
            kind = v.get("kind", "unknown")
            # v6.1: net/proxy problem = cookie er dosh NA. Ei account ke
            # "expired" bolle valid cookie-er profile folder muchhe jeto —
            # device identity harano = FB flag er direct path. Net-hole
            # status "error" e jay, profile thake, abar run korlei hoy.
            if kind == "net":
                log(f"{tag} 🌐 NET ISSUE (cookie thik e ache) — profile rekhe dilam, "
                    f"pore abar run korle e hobe — {v['reason']}")
                accounts_db.update_account(
                    acc_id, status="error",
                    expired_reason="net", last_validated_at="")
                keep_profile = _was_live
                return False
            icon = {"checkpoint": "🛑 CHECKPOINT", "suspended": "⛔ SUSPENDED",
                    "locked": "🔒 LOCKED", "login": "🔑 LOGGED OUT / EXPIRED"
                    }.get(kind, "❌ NOT USABLE")
            log(f"{tag} {icon} → moved to Expired list — {v['reason']}")
            accounts_db.update_account(
                acc_id, status="expired", expired_reason=kind,
                last_validated_at=time.strftime("%Y-%m-%d %H:%M:%S"))
            return False          # keep_profile stays False → folder wiped after close
        accounts_db.update_account(acc_id, status="validated",
                                   profile_dir=pdir, expired_reason="",
                                   last_validated_at=time.strftime("%Y-%m-%d %H:%M:%S"))
        shown = v["name"] or f"UID {c_user}"
        log(f"{tag} ✅ VERIFIED live — feed OK, logged in as {shown}")

        # business info is consumed ONLY by a verified-live account
        if mode == "run":
            biz_info = accounts_db.biz_take_next()
            if biz_info:
                log(f"{tag} business info picked → {biz_info['business_name']} "
                    f"({biz_info.get('business_email', '')})")

        if mode == "invite":
            # STEP 3 ONLY: BM create/page HOBE NA — profile-er BM gulo theke
            # sudhu invite pathano + link collect (dashboard "Invite only" card)
            from biz_form import Pace
            _pace = Pace()
            from bm_creator import collect_profile_bms
            from bm_invite import invite_one
            # invite-only mode: 2-5 ta invite (dashboard option)
            invite_n = max(2, min(5, int((opts or {}).get("invite_count", 3) or 3)))
            acc_id_ = account.get("id")
            bms = await collect_profile_bms(page, log, tag)
            if not bms:
                log(f"{tag} ⚠ ei profile e kono BM paoa jay nai — skip")
            for bidx, bmrec in enumerate(bms):
                bid, bnm = bmrec["id"], bmrec["name"]
                accounts_db.bm_upsert(acc_id_, bid, bnm)
                _bd = accounts_db.get_business_data(acc_id_)
                _pgr = (accounts_db.bm_get(_bd, bid) or {}).get("page")
                # page record একসময় string (নাম), একসময় dict — দুটোই সামলাই
                _pg = _pgr if isinstance(_pgr, dict) else {"name": str(_pgr or "")}
                # v6.5: agei koyta link collect kora ache dekhe BAKI
                # tuku collect — duplicate link banano bondro
                done_n = accounts_db.bm_invite_count(
                    accounts_db.get_business_data(acc_id_), bid)
                remaining_n = max(0, invite_n - done_n)
                if remaining_n == 0:
                    log(f"{tag} ✓ [BM {bnm}] link sob agei ache "
                        f"({done_n}/{invite_n}) — ei BM skip")
                    continue
                if done_n:
                    log(f"{tag} 📨 [BM {bnm}] age theke {done_n} ta link "
                        f"ache — baki {remaining_n} ta collect korbo")
                else:
                    log(f"{tag} 📨 [BM {bnm}] invite-only phase — {invite_n} ta link")
                got = 0
                for i in range(remaining_n):
                    link, email = await invite_one(
                        page, bid, _pace, log,
                        f"{tag} [BM {bnm} invite {done_n + i + 1}]", poll_s=150,
                        page_name=_pg.get("name", ""),
                        _slot=(bidx + 1) * 10 + i + 1,
                        late_ctx=(acc_id_, bid, bnm))
                    if link:
                        got += 1
                        accounts_db.bm_record_invite(acc_id_, bid, bnm, email, link)
                        _write_results(acc_id_, log)   # SATHE SATHE save
                        log(f"{tag} 🔗 [BM {bnm}] link {done_n + i + 1}/{invite_n} ✓")
                    if engine_stop_requested():
                        log(f"{tag} ⏹ stop request — invite phase chere dilam")
                        break
                log(f"{tag} 🏁 [BM {bnm}] invite links: {got}/{invite_n}")
                if engine_stop_requested():
                    break
            _write_results(acc_id_, log)
            accounts_db.update_account(acc_id_, status="validated",
                                       last_validated_at=time.strftime("%Y-%m-%d %H:%M:%S"))
            keep_profile = True    # LIVE session — profile folder kokhono wipe hobe na
            return True

        if mode == "pageadd":
            from biz_form import Pace
            _pace = Pace()
            # STEP 2 + 3 only: BM create HOBE NA — profile-er CREATED BM gulo
            # collect kore, page nei emon BM e page create + invite links
            from bm_creator import collect_profile_bms
            from page_creator import create_bm_page
            from bm_invite import invite_one
            # page-only: invite_count 0 → page kaj sesh = BM sesh, invite NEI
            invite_n = int((opts or {}).get("invite_count", 0) or 0)
            if invite_n:
                invite_n = max(2, min(5, invite_n))
            if not invite_n:
                log(f"{tag} ℹ Page-only mode — invite skip korche")
            acc_id_ = account.get("id")
            bms = await collect_profile_bms(page, log, tag)
            if not bms:
                log(f"{tag} ⚠ ei profile e kono BM paoa jay nai — skip")
            for bidx, bmrec in enumerate(bms):
                bid, bnm = bmrec["id"], bmrec["name"]
                accounts_db.bm_upsert(acc_id_, bid, bnm)
                bdata = accounts_db.get_business_data(acc_id_)
                rec = accounts_db.bm_get(bdata, bid)
                if rec and rec.get("page"):
                    log(f"{tag} ✓ [BM {bnm}] page already ache "
                        f"('{rec['page']}') — invite phase e jachhi")
                else:
                    info = accounts_db.page_pool_take_random()
                    if not info:
                        log(f"{tag} ⚠ Page Info Pool khali — page create "
                            f"skip; dashboard e entry dao")
                    else:
                        log(f"{tag} 📄 [BM {bnm}] page create: "
                            f"'{info['page_name']}'")
                        try:
                            pok, reason = await create_bm_page(
                                page, bid, info, _pace, log, tag)
                        except Exception as e:
                            pok, reason = False, str(e)[:80]
                        if pok and str(reason).startswith("already:"):
                            # SMART DETECT: BM te already page chilo —
                            # notun banano lagbe na, record + next BM
                            accounts_db.bm_record_page(acc_id_, bid, bnm,
                                                       str(reason)[8:])
                            log(f"{tag} ⏭ [BM {bnm}] already page ache "
                                f"('{str(reason)[8:]}') — skip, next BM")
                        elif pok:
                            accounts_db.bm_record_page(acc_id_, bid, bnm,
                                                       info["page_name"])
                            log(f"{tag} ✅ [BM {bnm}] page created: "
                                f"'{info['page_name']}'")
                        else:
                            log(f"{tag} ⚠ [BM {bnm}] page fail — {reason}")
                # STEP 3: invites (jodi invite_n > 0) — v6.5: BAKI link
                # tuku collect, age-collect-kora link abar na
                _done_n = accounts_db.bm_invite_count(
                    accounts_db.get_business_data(acc_id_), bid)
                _rem_n = max(0, invite_n - _done_n)
                if _rem_n == 0 and invite_n:
                    log(f"{tag} ✓ [BM {bnm}] link sob agei ache "
                        f"({_done_n}/{invite_n}) — ei BM skip")
                    continue
                if _done_n:
                    log(f"{tag} 📨 [BM {bnm}] age theke {_done_n} ta link "
                        f"ache — baki {_rem_n} ta collect korbo")
                got = 0
                for i in range(_rem_n):
                    _pgr = (accounts_db.bm_get(
                        accounts_db.get_business_data(acc_id_), bid)
                        or {}).get("page")
                    _pg = _pgr if isinstance(_pgr, dict) else {"name": str(_pgr or "")}
                    link, email = await invite_one(
                        page, bid, _pace, log,
                        f"{tag} [BM {bnm} invite {i+1}]", poll_s=150,
                        page_name=_pg.get("name", ""),
                        _slot=(bidx + 1) * 10 + i + 1,
                        late_ctx=(acc_id_, bid, bnm))
                    if link:
                        got += 1
                        accounts_db.bm_record_invite(acc_id_, bid, bnm,
                                                     email, link)
                        _write_results(acc_id_, log)   # SATHE SATHE save
                        log(f"{tag} 🔗 [BM {bnm}] link {_done_n + i + 1}/{invite_n} ✓")
                    else:
                        log(f"{tag} ⚠ [BM {bnm}] invite {i+1} fail"
                            f"{' (' + email + ')' if email else ''}")
                log(f"{tag} 🏁 [BM {bnm}] invite links: {got}/{invite_n}")
            _write_results(acc_id_, log)
            keep_profile = True
            log(f"{tag} 🏁 প্রোফাইলের কাজ শেষ — ব্রাউজার বন্ধ হচ্ছে, পরের প্রোফাইলে যাচ্ছি")
            return True

        if mode in ("bmcreate", "bmonly"):
            from bm_creator import run_bm_creation
            _step_page = (mode != "bmonly") and bool((opts or {}).get("step_page", True))
            bm_target = 1 if int((opts or {}).get("bm_count", 2) or 2) == 1 else 2
            log(f"{tag} 🎯 BM create (API mode) — {'Single' if bm_target == 1 else 'Double'} BM target "
                f"({bm_target} business)")
            invite_n = 0 if mode == "bmonly" else int((opts or {}).get("invite_count", 3) or 0)
            if invite_n:
                invite_n = max(2, min(5, invite_n))
            n_created, names, stop = await run_bm_creation(
                page, accounts_db.biz_take_next, log, tag=tag,
                avoid_restricted=bool((opts or {}).get("avoid_restricted", True)),
                per_profile=bm_target,
                acc_id=acc_id, invite_count=invite_n,
                page_enabled=_step_page)
            _write_results(acc_id, log)
            acc_id_ = account.get("id")
            label = ", ".join(names) if names else "—"
            if acc_id_ and names:
                # v6.5: names e ei run e kaj-kora (age theke + notun) sob
                # BM ache — total hisheb dekhacchi
                accounts_db.update_account(
                    acc_id_, business_profile=f"BM×{len(names)}: {label}"[:120])
            keep_profile = True          # session is live whatever the BM outcome
            if n_created or names:
                log(f"{tag} ✅ BM flow done — {n_created} created, "
                    f"{len(names)} BM total handled ({label})")
                if stop:
                    log(f"{tag} ℹ {stop}")
                log(f"{tag} 🏁 প্রোফাইলের কাজ শেষ — ব্রাউজার বন্ধ হচ্ছে, পরের প্রোফাইলে যাচ্ছি")
                return True
            log(f"{tag} ❌ BM create failed — {stop or 'unknown reason'}")
            await asyncio.sleep(3)
            log(f"{tag} 🏁 প্রোফাইলের কাজ শেষ — ব্রাউজার বন্ধ হচ্ছে, পরের প্রোফাইলে যাচ্ছি")
            return False

        job_ok = True
        if mode == "run":
            await asyncio.sleep(random.uniform(1.0, 2.5))   # humanized delay
            job_ok = await run_profile_job(page, account, lane, log, biz_info=biz_info)
            if not job_ok:
                # leave the failed page visible briefly so the problem can be
                # SEEN (screenshot is also saved in data/debug/)
                log(f"{tag} 👀 ব্যর্থ পেজটা ১৫ সেকেন্ড খোলা রাখছি দেখার জন্য…")
                await asyncio.sleep(15)
        else:
            # validate mode: brief humanized dwell then close
            await asyncio.sleep(random.uniform(1.5, 3.0))
        keep_profile = True      # session is still a valid LIVE login either way
        return bool(job_ok)
    except AccountBlocked as ab:
        # v7.5: MAJHPOTHE account-block (checkpoint/suspend/locked/logout).
        # Buyer/Backup e collected sob link SAFE (DB + Excel e save kora) —
        # remove hoy na. Summary te ei ID red-mark hoy last status soho.
        _kind = getattr(ab, "kind", "checkpoint") or "checkpoint"
        _where = getattr(ab, "where", "") or ""
        log(f"{tag} ⛔ {_kind.upper()} DETECTED mid-run"
            + (f" ({_where})" if _where else "")
            + " — ei ID diye ar kaj hobe na")
        try:
            accounts_db.update_account(acc_id, status="expired",
                                       expired_reason=_kind)
            log(f"{tag} 🔴 Summary te ei ID red-mark: {_kind.upper()}"
                f" — collected Buyer/Backup links SAFE")
            _write_results(acc_id, log)
        except Exception:
            pass
        log(f"{tag} 🏁 ei profile bondho — PORER ID te jacchi (fast)")
        keep_profile = False        # blocked ID er ghost profile rakhbo na
        return False
    except Exception as e:
        # v6.1: browser/net crash = "error", "expired" NA. Ager validated
        # (live) profile folder WIPE hoy na — stable device identity thake.
        # Validate abar chalale ei account auto-retry hoy.
        log(f"{tag} ⚠️ browser/net error (cookie er dosh na) — profile rakha hoyeche, "
            f"abar run korle retry hobe — {e}")
        accounts_db.update_account(acc_id, status="error",
                                   expired_reason=f"crash: {str(e)[:90]}")
        keep_profile = _was_live
        return False
    finally:
        # 1) browser down FIRST (releases file locks on the profile dir).
        #    BM mode: honour "I will close it myself" — leave the window open.
        # The run's own event loop ends when the batch ends and would kill the
        # browser, so we close it cleanly here and (if asked) re-open the SAME
        # persistent profile in a long-lived manual session the user owns.
        if br is not None:
            await close_profile(pw, br)
        await asyncio.sleep(0.5)
        # 2) only NOW wipe a dead profile — expired/unlogin accounts must
        #    never leave a ghost folder on disk
        if not keep_profile:
            shutil.rmtree(pdir, ignore_errors=True)


async def _runner(mode, lanes, only_ids, log, opts=None):
    # ── v6.9 LATE-LINK HOLD QUEUE wiring: invite mail deri ashle
    #    (temp domain e common) mailbox 15 min DHORE thake → link ele
    #    SATHE SATHE DB + invite_results.txt e save. ──
    import temp_mail as _tm
    def _late_link_cb(ctx, email, link):
        try:
            acc_id, bid, bnm = (ctx or (None, None, "?"))
            if acc_id and bid:
                accounts_db.bm_record_invite(acc_id, bid, bnm, email, link)
                _write_results(acc_id, log)
                log(f"🐢 late invite link SAVE HOLO ({email}) — "
                    f"invite_results.txt updated")
        except Exception as le:
            log(f"⚠ late-link save fail: {str(le)[:60]}")
    _tm.set_late_callback(_late_link_cb)
    _tm.start_late_reaper(log=log, stop_check=engine_stop_requested)

    proxies = load_proxies()
    if proxies:
        log(f"proxies loaded: {len(proxies)}")

    # only accounts not already validated (unless re-run selected)
    accounts = accounts_db.all_accounts()
    if only_ids:
        ids = set(only_ids)
        accounts = [a for a in accounts if a["id"] in ids]
    elif mode in ("run", "bmcreate", "bmonly", "invite", "pageadd"):
        # job runs on LIVE accounts: validated ones; unverified ones are
        # login-checked first inside _process_account; expired are skipped
        accounts = [a for a in accounts if a["status"] != "expired"]
    else:
        accounts = [a for a in accounts if a["status"] != "validated"]

    if not accounts:
        log("⚠ কাজ করার মতো কোনো অ্যাকাউন্ট নেই — আগে Import করো / Validate করো" if mode == "run"
            else "⚠ validate করার মতো নতুন অ্যাকাউন্ট নেই (সবগুলো আগেই validated)। আবার চেক করতে অ্যাকাউন্ট সিলেক্ট করে Start দাও")

    # ── v73.1: PROTIBAR RUN E ALADA EXCEL FILE — ager file untouched.
    #    Run er account snapshot o ekhane lock hoy (Summary tab er jonno).
    try:
        import sheet_output as _so
        _so.begin_run([a["id"] for a in accounts])
        # v7.7: Summary er Bangla kajer-obostha column e link X/TARGET
        # dekhate run er invite target set kori
        try:
            _so.set_invite_target(int((opts or {}).get("invite_count", 3) or 3))
        except Exception:
            pass
        log("📊 এই রান-এর আউটপুট ফাইল: " +
            _so._RUN["file"].replace(chr(92), "/").split("/")[-1])
    except Exception:
        pass

    with _state_lock:
        _state.update({"done": 0, "total": len(accounts), "ok": 0,
                       "failed": 0, "stop": False, "stopping": False})
    _push()

    _LOOP_REF["loop"] = asyncio.get_running_loop()
    queue = [a for a in accounts]
    q_lock = asyncio.Lock()

    async def lane_worker(lane_id):
        # staggered start — never synchronized bursts
        await asyncio.sleep(0.5 * (lane_id - 1) + random.uniform(0, 0.5))
        while True:
            with _state_lock:
                if _state["stop"] or not queue:
                    return
            async with q_lock:
                if not queue:
                    return
                acc = queue.pop(0)
            with _state_lock:
                _state["current"] = acc.get("identifier") or acc.get("c_user", "?")
            _push()
            try:
                ok = await _process_account(acc, lane_id, proxies, mode, log, opts or {})
            except asyncio.CancelledError:
                log(f"[lane {lane_id}] ⏹ task cancel — lane bondro")
                raise
            except Exception as e:
                log(f"[lane {lane_id}] unexpected: {e}")
                ok = False
            with _state_lock:
                _state["done"] += 1
                if ok:
                    _state["ok"] += 1
                else:
                    _state["failed"] += 1
            _push()
            if queue and not _state.get("stop"):
                await asyncio.sleep(random.uniform(2.0, 5.0))  # between accounts

    workers = [asyncio.create_task(lane_worker(i)) for i in range(1, lanes + 1)]
    _LANE_TASKS["tasks"] = workers
    try:
        await asyncio.gather(*workers, return_exceptions=True)
    finally:
        _LANE_TASKS["tasks"] = []
        _LOOP_REF["loop"] = None
    # ── v6.9: shesh howar AGE late-mail watch — "collect kora porjonto
    #    mail dhore rakhte hobe". Queue te mail thakle abar MAX 10 min
    #    dekhe jai (reaper 30s por por check korei, link pele save kore).
    try:
        import temp_mail as _tmx
        import asyncio as _aiox
        _extra = 0
        while _tmx.late_queue_size() > 0 and _extra < 600:
            if engine_stop_requested():
                log("⏹ stop — late-mail watch chere dilam "
                    "(queue thakle next run e mail Abe ra kore arabe)")
                break
            if _extra == 0:
                log(f"🐢 {_tmx.late_queue_size()} ta invite mail ekhono "
                    f"ashe ni — mail DHORE achhi, abar 10 min dekhchi "
                    f"(link ele sathe sathe save hobe)")
            await _aiox.sleep(15)
            _extra += 15
    except Exception:
        pass
    if _state.get("stop"):
        log(f"■ stopped — {_state['ok']} ok / {_state['failed']} failed / {_state['done']} of {_state['total']} done")
    else:
        log(f"run finished — {_state['ok']} ok / {_state['failed']} failed / {_state['total']} total")


def start_run(mode="validate", lanes=1, only_ids=None, log=print, opts=None):
    """Fire-and-forget background run in its own event loop thread.
    opts: dict for bmcreate mode — {avoid_restricted: bool, headless: bool}"""
    with _state_lock:
        if _state["running"]:
            return False, "already running"
        _state.update({"running": True, "mode": mode, "lanes": max(1, min(5, lanes)),
                       "started_at": time.strftime("%H:%M:%S"), "stop": False,
                       "stopping": False, "done": 0, "ok": 0, "failed": 0})
    _push()

    def _thread():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(_runner(mode, max(1, min(5, lanes)), only_ids, log, opts or {}))
        except Exception as e:
            try: log(f"engine error: {e}")
            except Exception: pass
        finally:
            with _state_lock:
                _state["running"] = False
                _state["stopping"] = False
                _state["current"] = ""
            _push()
            loop.close()
            # v6.2: রানের শেষে নিখুঁত ফলাফল — সব ব্রাউজার আগেই বন্ধ, বট থেমে যায়
            with _state_lock:
                done_n, ok_n, fail_n = _state.get("done",0), _state.get("ok",0), _state.get("failed",0)
            log(f"🏁 রান সম্পূর্ণ শেষ — মোট প্রোফাইল: {done_n} · ✅ সফল: {ok_n} · ❌ ব্যর্থ: {fail_n}")
            log("🔓 সব ব্রাউজার বন্ধ — ম্যানুয়াল দরকার হলে প্রোফাইল লাইনের Open বাটন")

    threading.Thread(target=_thread, daemon=True).start()
    return True, "started"
