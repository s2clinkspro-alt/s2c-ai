"""Browser manager — per-profile stealth browser with cookie session.

Flow per account:
  1. build stable fingerprint from c_user (same device every re-open)
  2. launch PERSISTENT context into profiles/fb_<c_user>/ — but the
     folder is only KEPT if login verifies; on failure it is wiped so
     expired/unlogin profiles never linger on disk
  3. inject cookies (all domains: .facebook.com/.m.facebook.com/...)
  4. navigate to facebook.com and run the live login check
  5. return the live (page, ctx) for the per-profile job stage
"""
import asyncio
import threading
import json
import os
import random

from fingerprint import gen_fingerprint

APP_ROOT = os.path.dirname(os.path.abspath(__file__))

# ─────────────────────────────────────────────────────────────────────────────
# Stealth
# ─────────────────────────────────────────────────────────────────────────────

_STEALTH_JS = """
(function(){
  const override = (obj, prop, val) => {
    try { Object.defineProperty(obj, prop, {get: ()=>val, configurable:true}); } catch(e){}
  };
  override(navigator, 'webdriver', undefined);
  ['__playwright__','__pw_manual','__selenium_unwrapped','__webdriver_evaluate']
    .forEach(k=>{ try{delete window[k];}catch(e){} });
  override(navigator, 'plugins', [
    {name:'Chrome PDF Plugin',filename:'internal-pdf-viewer',description:'Portable Document Format'},
    {name:'Chrome PDF Viewer',filename:'internal-pdf-viewer',description:''},
    {name:'Native Client',filename:'internal-nacl-plugin',description:''},
  ]);
  var __isMac = navigator.userAgent.indexOf('Macintosh') >= 0;
  override(navigator, 'platform', __isMac ? 'MacIntel' : 'Win32');
  if(!window.chrome){
    window.chrome = {app:{isInstalled:false},
      runtime:{connect:function(){return {onMessage:{addListener:function(){}},postMessage:function(){},disconnect:function(){}};}},
    };
  }
  override(navigator, 'languages', ['en-US','en']);
  override(navigator, 'hardwareConcurrency', 8);
  override(navigator, 'deviceMemory', 8);
  override(navigator, 'maxTouchPoints', 0);
  try {
    const gp = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function(p){
      if (p === 37445) return 'Google Inc. (Intel)';
      if (p === 37446) return 'ANGLE (Intel, Intel(R) UHD Graphics 630 (0x00003E92) Direct3D11 vs_5_0 ps_5_0, D3D11)';
      return gp.apply(this, arguments);
    };
  } catch(e){}
  if(navigator.permissions && navigator.permissions.query){
    const oq = navigator.permissions.query.bind(navigator.permissions);
    navigator.permissions.query = (p) => p.name === 'notifications'
      ? Promise.resolve({state:'granted',onchange:null}) : oq(p);
  }
  // Canvas / WebGL / Audio — seeded per profile, stable across sessions
  try {
    var seed = window.__FBLOADER_SEED || 12345;
    var sdat = String(seed);
    var h = 0; for (var i=0;i<sdat.length;i++){ h = ((h<<5)-h+sdat.charCodeAt(i))|0; }
    var n = Math.abs(h)%97+13;
    const toDataURL = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function(t){
      const r = toDataURL.apply(this, arguments);
      return r.slice(0, -8) + (seed%9973).toString(16).padStart(4,'0');
    };
    const getImageData = CanvasRenderingContext2D.prototype.getImageData;
    CanvasRenderingContext2D.prototype.getImageData = function(){
      const d = getImageData.apply(this, arguments);
      for (let i=0;i<d.data.length;i+=n) d.data[i] = (d.data[i]+seed)%256;
      return d;
    };
  } catch(e){}
})();
"""


def _seed_js(seed: int) -> str:
    return f"window.__FBLOADER_SEED = {int(seed)};\n"


def _chromium_args(fingerprint: dict, window_geom=None) -> list:
    return [
        "--no-first-run", "--no-default-browser-check",
        "--disable-dev-shm-usage", "--disable-infobars",
        "--disable-notifications",
        "--disable-background-timer-throttling",
        "--disable-renderer-backgrounding",
        "--disable-backgrounding-occluded-windows",
        "--disable-features=CalculateNativeWinOcclusion,MediaRouter",
        "--disable-blink-features=AutomationControlled",
    ]


def find_system_chrome() -> str:
    """Locate an already-installed Chrome (or Edge) on this device.
    Returns '' if none found (then Playwright's own Chromium is used)."""
    import shutil
    cands = []
    if os.name == "nt":
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
        la = os.environ.get("LOCALAPPDATA", "")
        cands = [
            os.path.join(pf, r"Google\Chrome\Application\chrome.exe"),
            os.path.join(pf86, r"Google\Chrome\Application\chrome.exe"),
            os.path.join(la, r"Google\Chrome\Application\chrome.exe"),
            os.path.join(pf86, r"Microsoft\Edge\Application\msedge.exe"),
            os.path.join(pf, r"Microsoft\Edge\Application\msedge.exe"),
        ]
    elif os.uname().sysname == "Darwin":
        cands = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    else:
        for n in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
            p = shutil.which(n)
            if p:
                cands.append(p)
    for p in cands:
        if p and os.path.exists(p):
            return p
    return ""


def load_proxies() -> list:
    """proxy.txt — one line per profile, any of:
       user:pass@host:port | host:port:user:pass | http://user:pass@host:port"""
    path = os.path.join(APP_ROOT, "proxy.txt")
    if not os.path.exists(path):
        return []
    out = []
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        out.append(line)
    return out


def parse_proxy_line(line: str) -> dict or None:
    import re
    line = line.strip()
    if not line:
        return None
    m = re.match(r'^(?:https?|socks5)://', line)
    scheme = "http"
    rest = line
    if m:
        scheme = line.split("://")[0]
        rest = line.split("://", 1)[1]
    m = re.match(r'^(?:([^:@/]+):([^@/]+)@)?([^:@/]+):(\d+)$', rest)
    if m:
        return {"server": f"{scheme}://{m.group(3)}:{m.group(4)}",
                "username": m.group(1) or "", "password": m.group(2) or ""}
    parts = line.split(":")
    if len(parts) == 4:
        p1d, p3d = parts[1].isdigit(), parts[3].isdigit()
        # v6.1 FIX: host:port:user:pass (Decodo/residential standard) age
        # support-i chilo NA — parse fail → proxy silently drop → account
        # REAL IP te open hoto. Ekhon duita 4-part format e support kore:
        #   host:port:user:pass  → port 2nd position e (host first)
        #   user:pass:host:port  → port last position e
        # Ambiguity (duboi digit) hole hostname-look (dot) diye resolve.
        if p1d and p3d:
            host_first = ("." in parts[0]) and not ("." in parts[2])
        else:
            host_first = p1d
        if host_first:
            return {"server": f"{scheme}://{parts[0]}:{parts[1]}",
                    "username": parts[2], "password": parts[3]}
        return {"server": f"{scheme}://{parts[2]}:{parts[3]}",
                "username": parts[0], "password": parts[1]}
    if len(parts) == 2 and parts[1].isdigit():
        return {"server": f"{scheme}://{parts[0]}:{parts[1]}", "username": "", "password": ""}
    return None


import re as _re
_COOKIE_NAME_OK = _re.compile(r"^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$")


def _sanitize_cookie_objs(cookies: list, log=None) -> list:
    """Chrome 'Invalid cookie fields' the --> name RFC6265 token chars
    chariye ba value te control char thakle reject kore. Ei cleaner
    bad cookie skip kore — ekta kharap cookie puro account noshto
    korbe na. Value er control char strip kore, name invalid hole skip."""
    ok, skipped = [], []
    for c in cookies:
        name = str(c.get("name", "")).strip()
        value = str(c.get("value", ""))
        clean_val = "".join(ch for ch in value if ch >= " " and ch != "\x7f")
        was_dirty = clean_val != value
        # name kharaP hole skip; value e control char THAKLE
        # clean kore KEEP — login cookie er value e onek somoy
        # copy-paste bhebe newline dhuke jay, cookie ta tokhono bhalo
        if not name or not _COOKIE_NAME_OK.match(name):
            skipped.append((name[:24] or "<empty>", "invalid name"))
            continue
        if was_dirty:
            log and log(f"ℹ cookie '{name}' er value e junk chilo — "
                       f"clean kore nilam")
        c = dict(c, name=name, value=clean_val)
        ok.append(c)
    if skipped and log:
        for n, r in skipped[:6]:
            log(f"⚠ kharap cookie skip: '{n}' ({r})")
        if len(skipped) > 6:
            log(f"⚠ +{len(skipped)-6} ta aro skip")
    return ok


def _build_cookie_objects(cookie_dict: dict) -> list:
    """Playwright cookie objects covering all FB domains."""
    cookies = []
    for name, value in cookie_dict.items():
        for domain in (".facebook.com",):
            c = {"name": name, "value": value, "domain": domain,
                 "path": "/", "secure": True, "httpOnly": False}
            if name in ("datr", "sb", "wd", "dpr", "presence", "m_pixel_ratio",
                        "fr", "ps_l", "ps_n", "locale"):
                c["secure"] = name in ("datr", "sb", "wd", "presence",
                                       "fr", "ps_l", "ps_n")
            cookies.append(c)
    return cookies


def proxy_for_account(account: dict, proxies: list):
    """ONE rule for every code path (bot runs AND manual Open): an account always
    maps to the same proxy line. Per-lane assignment would give the same account a
    different IP on each run — exactly what makes Facebook link/flag accounts."""
    if not proxies:
        return None
    try:
        idx = int(str(account.get("c_user", "0"))[-9:] or 0) % len(proxies)
    except Exception:
        idx = 0
    return proxies[idx]


# live browser registry — STOP চাপলেই সব ব্রাউজার instantly বন্ধ
_ACTIVE = {}
_ACTIVE_LOCK = threading.Lock()


def _driver_pid(pw) -> int or None:
    """Playwright driver (node) process er PID — ei process er tree te
    browser ache. OS-level kill er jonno."""
    try:
        return pw._impl_obj._connection._transport._proc.pid
    except Exception:
        try:
            return pw._connection._transport._proc.pid
        except Exception:
            return None


def _reg_browser(pw, br):
    with _ACTIVE_LOCK:
        _ACTIVE[id(br)] = (pw, br, _driver_pid(pw))


def _unreg_browser(br):
    with _ACTIVE_LOCK:
        _ACTIVE.pop(id(br), None)


def active_pids() -> list:
    """Live browser process-gulor PID SNAPSHOT. STOP e force_close_all
    _ACTIVE registry CLEAR kore fale — tarpor OS-nuke cholale registry
    FAKA thake ar kuchui kill hoy na (ei bug e stop kaj korto na).
    Tai pids AGE snapshot kore rakh-te hobe."""
    with _ACTIVE_LOCK:
        return [pid for (_pw, _br, pid) in _ACTIVE.values() if pid]


def _kill_pid_tree(pid) -> int:
    """Ek PID er pura process tree kill — psutil thakle tar children
    soho; NA thakle Windows taskkill /F /T (bare machine e psutil
    install kora thake na — tai taskkill fallback MUST)."""
    try:
        import psutil
        try:
            p = psutil.Process(pid)
            for ch in p.children(recursive=True):
                try:
                    ch.kill()
                except Exception:
                    pass
            p.kill()
            return 1
        except Exception:
            pass
    except ImportError:
        pass
    try:
        import subprocess, sys
        if sys.platform == "win32":
            r = subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                               capture_output=True)
            return 1 if r.returncode == 0 else 0
        import os, signal
        os.kill(pid, signal.SIGKILL)
        return 1
    except Exception:
        return 0


def kill_browsers_os(pids=None) -> int:
    """OS-level nuke: graceful close kaj na korle (engine loop atke
    thakle o) process tree sorasori kill. Sync — jekono thread theke
    callable. pids = age-snapshot kora PID list (request_stop theke)
    — _ACTIVE registry fakai gele o ei gulo kill hoy.
    Returns: killed process count."""
    with _ACTIVE_LOCK:
        items = list(_ACTIVE.values())
        _ACTIVE.clear()
    killed = 0
    _seen = set()
    for pw, br, pid in items:
        if not pid:
            continue
        _seen.add(pid)
        killed += _kill_pid_tree(pid)
    for pid in (pids or []):
        if pid and pid not in _seen:
            killed += _kill_pid_tree(pid)
    return killed


async def force_close_all():
    """STOP চাপার সাথে সাথেই সব লাইভ ব্রাউজার বন্ধ — চলমান wizard/poll
    বন্ধ হলে pending call গুলো exception দেবে আর engine ওইটা ধরে নেবে।"""
    with _ACTIVE_LOCK:
        items = list(_ACTIVE.values())
        _ACTIVE.clear()
    for pw, br, _pid in items:
        try:
            await asyncio.wait_for(br.close(), timeout=4)
        except Exception:
            pass
        try:
            await asyncio.wait_for(pw.stop(), timeout=4)
        except Exception:
            pass


async def open_profile(account: dict, proxy_line: str = None,
                        headless: bool = False, log=print):
    """Launch a browser for ONE account with its cookie session.

    Returns (playwright, browser, context, page, fingerprint) on success
    — or raises with a clear reason. Caller MUST call close_profile().
    IMPORTANT: the profile directory is created FRESH each open and only
    becomes 'kept' storage after verify_login() passes; on failure the
    caller wipes it, so expired sessions never leave a ghost profile.
    """
    from playwright.async_api import async_playwright

    c_user = account.get("c_user", "")
    fp = gen_fingerprint("fbl_" + str(c_user), mobile=False)

    # window position jitter so concurrent tiles never stack exactly
    x = random.randint(0, 400)
    y = random.randint(0, 200)

    # standing rule: always HEADED in production; the env override exists
    # only for sandbox/CI smoke tests
    headless = headless or os.environ.get("FBLOADER_HEADLESS") == "1"

    pw = await async_playwright().start()
    launch_kwargs = {
        "headless": headless,                      # headed per standing rule
        "user_data_dir": account["profile_dir"],   # persistent session
        "chromium_sandbox": False,
        "args": _chromium_args(fp) + [f"--window-position={x},{y}"],
        "viewport": fp["viewport"],
        "user_agent": fp["ua"],
        "locale": fp["locale"],
        "timezone_id": fp["timezone"],
        "device_scale_factor": fp["dpr"],
    }
    proxy = parse_proxy_line(proxy_line) if proxy_line else None
    if proxy:
        launch_kwargs["proxy"] = proxy

    # Prefer the user's REAL installed Chrome/Edge (no Playwright Chromium
    # download needed, and more authentic than the test build)
    chrome = find_system_chrome()
    if chrome:
        launch_kwargs["executable_path"] = chrome
        log(f"using installed browser: {chrome}")
    try:
        browser = await pw.chromium.launch_persistent_context(**launch_kwargs)
        _reg_browser(pw, browser)
    except Exception as e:
        try:
            await pw.stop()
        except Exception:
            pass
        raise RuntimeError(f"browser launch failed: {str(e)[:140]}")
    context = browser
    page = context.pages[0] if context.pages else await context.new_page()

    await context.add_init_script(_seed_js(fp["canvas_seed"]))
    await context.add_init_script(_STEALTH_JS)

    # inject the account cookies — but NEVER on top of an already-live persistent
    # session: re-writing c_user/xs/fr every open looks like a device change and is
    # exactly what makes Facebook link/flag multiple accounts. Only a fresh profile
    # (no existing c_user cookie in the jar) gets the imported cookies.
    from cookie_engine import parse_cookie_string
    cookie_dict = parse_cookie_string(account.get("cookie", ""))
    try:
        _live = any(c.get("name") == "c_user" and str(c.get("value")) == str(c_user)
                    for c in await context.cookies("https://www.facebook.com"))
    except Exception:
        _live = False
    if _live:
        log("♻ persistent session already live — cookies not re-injected")
        cookie_dict = None
    if cookie_dict:
        objs = _sanitize_cookie_objs(
            _build_cookie_objects(cookie_dict), log)
        if not objs:
            log("⚠ kono VALID cookie nai — ei account er cookie string"
                " thik moto na; full cookie copy kore abar import koro")
        else:
            try:
                await context.add_cookies(objs)
            except Exception as e1:
                # EKTA kore inject — jekono ekta kharap cookie
                # puro account ar noshto korbe na
                added = 0
                for ck in objs:
                    try:
                        await context.add_cookies([ck])
                        added += 1
                    except Exception as e2:
                        log(f"⚠ cookie '{ck['name']}' inject fail — "
                            f"skip: {str(e2)[:50]}")
                if added == 0:
                    await pw.stop()
                    raise RuntimeError(f"cookie inject failed: {e1}")
                log(f"✓ {added}/{len(objs)} cookie inject holo"
                    f" ({len(objs)-added} ta kharap chilo, skip)")
    return pw, browser, context, page, fp


async def close_profile(pw, browser):
    _unreg_browser(browser)
    try:
        await browser.close()
    except Exception:
        pass
    try:
        await pw.stop()
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# LIVE login verification — the core "expired profile never created" gate
# ─────────────────────────────────────────────────────────────────────────────

class AccountBlocked(Exception):
    """Mid-run ACCOUNT-level block (checkpoint / suspended / locked /
    login). Raise korle engine SATHE SATHE: ID 'expired' mark + Summary
    red + collected Buyer/Backup links SAFE + porer ID te jump —
    oi ID te ar somoy noshto kore na."""
    def __init__(self, kind: str, where: str = ""):
        super().__init__(f"{kind} @ {where}" if where else kind)
        self.kind = kind
        self.where = where


async def detect_page_problem(page) -> str:
    """LIGHT mid-run detector — CURRENT page thekei (kono navigation NA)
    account-level problem dhore: checkpoint / suspended / locked / login.
    Fail-point e call hoy (fast): button na paoa, page-create fail, invite
    fail — tobe net-proxy fail ke account-problem bhabbe NA.
    Returns kind, problem na thakle ""."""
    try:
        url = (page.url or "").lower()
        for mark, kind in _BAD_URL_MARKS:
            if mark in url:
                if "login" in kind:
                    return "login"
                if "suspend" in kind or "disabled" in kind:
                    return "suspended"
                return "checkpoint"
        text = (await page.evaluate(
            "() => (document.body && document.body.innerText) || ''")).lower()
        for phrase, kind in _BAD_TEXT_MARKS:
            if phrase in text:
                if "login" in kind:
                    return "login"
                if "suspend" in kind or "disabled" in kind:
                    return "suspended"
                if "lock" in kind or "restricted" in kind or "temporarily" in kind:
                    return "locked"
                if "hacked" in kind:
                    return "login"
                return "checkpoint"
        return ""
    except Exception:
        return ""


# URL fragments that mean the account is NOT usable
_BAD_URL_MARKS = (
    ("checkpoint", "checkpoint"),
    ("/disabled", "suspended / disabled"),
    ("accountquarantine", "suspended (quarantine)"),
    ("account_quarantine", "suspended (quarantine)"),
    ("/suspended", "suspended"),
    ("/login", "login required"),
    ("/recover", "recovery required"),
    ("/confirmemail", "email confirmation required"),
    ("/two_step_verification", "2FA required"),
    ("/two_factor", "2FA required"),
    ("/help/contact", "restricted"),
    ("/hacked", "hacked-account flow"),
    ("/device-based/", "login required"),
)

# Page-text phrases (English + Bangla UI) that mean checkpoint / suspended
_BAD_TEXT_MARKS = (
    ("we suspended your account", "suspended"),
    ("your account has been suspended", "suspended"),
    ("your account has been disabled", "disabled"),
    ("account has been disabled", "disabled"),
    ("we've suspended your account", "suspended"),
    ("your account is temporarily locked", "locked"),
    ("account is locked", "locked"),
    ("we've locked your account", "locked"),
    ("confirm your identity", "checkpoint (identity)"),
    ("confirm it's you", "checkpoint (identity)"),
    ("confirm that it's you", "checkpoint (identity)"),
    ("we need to confirm", "checkpoint"),
    ("secure your account", "checkpoint (secure account)"),
    ("your account was hacked", "hacked"),
    ("enter the code we sent", "checkpoint (code)"),
    ("choose a way to confirm", "checkpoint"),
    ("upload a photo of your face", "checkpoint (selfie)"),
    ("take a selfie", "checkpoint (selfie)"),
    ("we need to verify", "checkpoint"),
    ("help us confirm", "checkpoint"),
    ("confirm that you're human", "checkpoint (human)"),
    ("confirm that you’re human", "checkpoint (human)"),
    ("human to use your account", "checkpoint (human)"),
    ("you can't use facebook right now", "restricted"),
    ("you can’t use facebook right now", "restricted"),
    ("temporarily blocked", "temporarily blocked"),
    ("log in to facebook", "login required"),
    ("log into facebook", "login required"),
    ("create new account", "login required"),
    # Bangla
    ("আপনার অ্যাকাউন্ট সাসপেন্ড", "suspended"),
    ("আপনার অ্যাকাউন্ট নিষ্ক্রিয়", "disabled"),
    ("আপনার অ্যাকাউন্ট লক", "locked"),
    ("আপনার পরিচয় নিশ্চিত", "checkpoint (identity)"),
    ("আপনার অ্যাকাউন্ট সুরক্ষিত", "checkpoint (secure account)"),
)


async def _page_signals(page) -> dict:
    """One DOM read: URL-independent evidence of a REAL logged-in feed.
    Positive proof = the left/top navigation that exists ONLY for a usable
    logged-in account (Home/Watch/Marketplace links, create-post box,
    account menu). A checkpoint page has a banner but none of these."""
    return await page.evaluate("""() => {
        const q = (s) => !!document.querySelector(s);
        const text = (document.body?.innerText || '').slice(0, 6000);
        const nav = q('[role="navigation"] a[href="/"], a[aria-label="Home"], a[aria-label="হোম"]');
        const feedNav = q('a[href*="/watch"], a[href*="/marketplace"], a[href*="/friends"], a[href*="/groups/"]');
        const composer = q('[role="main"] [role="button"][aria-label*="mind" i], [aria-label*="Create a post" i], [aria-label*="Create post" i], [aria-label*="পোস্ট" i]');
        const feed = q('[role="feed"], [data-pagelet="FeedUnit_0"], [data-pagelet*="Feed"]');
        const acctMenu = q('[aria-label="Your profile"], [aria-label="Account"], [aria-label="Account controls and settings"], [aria-label*="আপনার প্রোফাইল"]');
        const loginForm = q('form[action*="login"], input[type="password"], input[name="pass"]');
        return {nav, feedNav, composer, feed, acctMenu, loginForm, text};
    }""")


async def verify_login(context, page, timeout_s: int = 45, log_fn=None) -> dict:
    """STRICT real-browser check that this cookie session is a genuinely
    usable logged-in account.

    A session passes ONLY when ALL hold:
      1. final URL is a normal facebook.com page (no checkpoint / disabled /
         suspended / login / 2FA / recover URL)
      2. the page text contains none of the checkpoint / suspended / locked
         / identity-confirmation phrases
      3. session cookies c_user+xs still in the context AND c_user matches
         the account's own UID
      4. POSITIVE proof of a working feed (>=2 of: nav, feed-nav links,
         composer, feed, account menu) — a banner alone is NOT enough
    The check is repeated after a short wait, because checkpoints often
    redirect a second or two AFTER the first paint.
    Returns {"ok": bool, "reason": str, "name": str, "kind": str}
    kind ∈ ok | checkpoint | suspended | locked | login | unknown
    """
    def _bad(reason, kind):
        return {"ok": False, "reason": reason, "name": "", "kind": kind}

    def _kind_of(label: str) -> str:
        l = label.lower()
        if "suspend" in l or "disabled" in l or "quarantine" in l:
            return "suspended"
        if "lock" in l or "restricted" in l or "blocked" in l:
            return "locked"
        if "login" in l or "2fa" in l or "recovery" in l:
            return "login"
        return "checkpoint"

    try:
        # v6.1: adaptive navigation — fast net e fast, slow net e patient
        # (boro timeout + auto-retry). Net-marker ekhane update hoy — puro
        # bot er wait gulo (settles, sleeps) ei onujayi scale kore.
        from adaptive import smart_goto, NetSpeed
        loaded = await smart_goto(page, "https://www.facebook.com/",
                                  log=log_fn, tag="[verify]")
        if not loaded:
            return _bad("page load holo na (net/proxy slow) — cookie er dosh na", "net")
    except Exception as e:
        return _bad(f"goto failed: {e}", "net")

    # two passes: immediately after load, and again after FB's late
    # redirects (checkpoint redirect often lands 2-4s after first paint)
    sig = None
    _settles = (6.0, 8.0) if NetSpeed._slow else (3.0, 4.0)
    for settle in _settles:
        await asyncio.sleep(settle)
        url = (page.url or "").lower()

        for frag, label in _BAD_URL_MARKS:
            if frag in url:
                return _bad(f"{label} — {page.url[:70]}", _kind_of(label))

        try:
            sig = await _page_signals(page)
        except Exception as e:
            # execution context destroyed = page navigated mid-read → retry
            if settle == _settles[0]:
                continue
            return _bad(f"dom check failed: {e}", "unknown")

        low = (sig.get("text") or "").lower()
        for phrase, label in _BAD_TEXT_MARKS:
            if phrase in low:
                return _bad(f"{label} — page says “{phrase}”", _kind_of(label))

        if sig.get("loginForm"):
            return _bad("login form on page — cookie dead", "login")

    if sig is None:
        return _bad("could not read page", "unknown")

    # session cookies still present and belong to THIS account
    try:
        cookies = await context.cookies()
    except Exception:
        cookies = []
    cmap = {c.get("name"): c.get("value") for c in cookies}
    if "c_user" not in cmap or "xs" not in cmap:
        return _bad("session cookies dropped — expired", "login")

    # POSITIVE proof of a real usable feed (banner alone proves nothing)
    proofs = sum(1 for k in ("nav", "feedNav", "composer", "feed", "acctMenu")
                 if sig.get(k))
    if proofs < 2:
        return _bad(f"no real logged-in feed (only {proofs}/5 markers) — "
                    f"likely checkpoint / restricted", "checkpoint")

    # account name for the dashboard (best effort)
    name = ""
    try:
        name = await page.evaluate("""() => {
            const el = document.querySelector('[aria-label="Your profile"], [role="banner"] a[aria-label*="rofile"], [role="banner"] img[alt]');
            return (el && (el.getAttribute('aria-label') || el.getAttribute('alt'))) || '';
        }""")
    except Exception:
        pass
    return {"ok": True, "reason": "logged in (feed verified)",
            "name": str(name).strip(), "kind": "ok"}
