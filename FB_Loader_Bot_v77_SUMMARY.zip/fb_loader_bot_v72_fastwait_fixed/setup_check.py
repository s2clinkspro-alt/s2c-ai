"""Checks what this device already has; installs ONLY what is missing.
Order: system python libs -> (if any missing) pip install only those ->
real Chrome/Edge present? then skip Playwright's Chromium download."""
import importlib.util
import subprocess
import sys

REQ = {  # import name -> pip name
    "flask": "flask",
    "socketio": "python-socketio",
    "openpyxl": "openpyxl",
    "playwright": "playwright",
    "psutil": "psutil",
}

missing = [pip for mod, pip in REQ.items() if importlib.util.find_spec(mod) is None]
if missing:
    print(f"[setup] missing libraries: {', '.join(missing)} -> installing only these")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", *missing])
else:
    print("[setup] all libraries already installed - nothing to download")

from browser_manager import find_system_chrome
chrome = find_system_chrome()
if chrome:
    print(f"[setup] real browser found: {chrome} - skipping Chromium download")
else:
    print("[setup] no Chrome/Edge found -> installing Playwright Chromium (one time)")
    subprocess.check_call([sys.executable, "-m", "playwright", "install", "chromium"])
print("[setup] ready")
