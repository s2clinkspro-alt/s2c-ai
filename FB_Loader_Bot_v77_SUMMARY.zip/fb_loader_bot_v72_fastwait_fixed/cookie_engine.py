"""Account-file parsing engine.

Reads Facebook account files in ANY layout the client throws at us:

  • Excel  (.xlsx/.xls) — UID/Email | Password | Cookie in ANY column
    order, with or without header rows, extra columns ignored
  • CSV   (.csv)        — same smart per-row detection
  • TXT   (.txt)        — blank-line separated blocks, one-per-line,
    ---/### separators, or "key: value" lines
  • JSON  (.json/.jsonl) — EditThisCookie exports, arrays, JSONL
  • Google Sheet link   — share URL auto-converted to the public CSV
    endpoint and fetched live

For every account it extracts THREE things (whatever exists):
    identifier (email / phone / uid), password, cookie (raw)

The cookie cell/string itself may be any format:
    c_user=..; xs=..; datr=..;        (request-header style)
    [{"name":"c_user","value":".."}]  (EditThisCookie JSON)
    {"c_user": "..", "xs": ".."}      (JSON object)
    newline separated key=value
"""
import json
import os
import re
import urllib.parse

# ─────────────────────────────────────────────────────────────────────────────
# Low-level cookie-string parsing
# ─────────────────────────────────────────────────────────────────────────────

def _smart_split(s: str) -> list:
    """Split on ';' ONLY when a genuine cookie name follows — never inside
    a value (presence=C{...};ps_l=1 etc)."""
    SEP = re.compile(r';\s*(?=[a-zA-Z_][a-zA-Z0-9_\-\.:@]*\s*=)')
    return SEP.split(s)


def parse_cookie_string(raw: str) -> dict:
    """Parse FB cookies from ANY of the 4 common formats → {name: value}."""
    raw = (raw or "").strip()
    if not raw:
        return {}
    result = {}

    # 1) JSON array (EditThisCookie / Cookie-Editor export)
    maybe = raw
    if not maybe.startswith('[') and '[' in maybe:
        maybe = maybe[maybe.index('['):]
    if maybe.startswith('['):
        attempt = maybe
        if attempt.count('[') > attempt.count(']'):
            attempt += ']'
        try:
            for item in json.loads(attempt):
                if isinstance(item, dict):
                    name = str(item.get('name', '')).strip()
                    value = str(item.get('value', ''))
                    if name:
                        try: value = urllib.parse.unquote(value)
                        except Exception: pass
                        result[name] = value
            if result:
                return result
        except (json.JSONDecodeError, ValueError, TypeError):
            pass

    # 2) JSON object
    if raw.startswith('{'):
        try:
            obj = json.loads(raw)
            for k, v in obj.items():
                if isinstance(v, (dict, list)):
                    continue
                name, val = str(k).strip(), str(v)
                try: val = urllib.parse.unquote(val)
                except Exception: pass
                result[name] = val
            if result:
                return result
        except (json.JSONDecodeError, ValueError, TypeError):
            pass

    # 3) Semicolon / newline separated key=value
    normalized = re.sub(r'[\r\n]+', '; ', raw)
    for token in _smart_split(normalized):
        token = token.strip()
        if not token or '=' not in token:
            continue
        sep = token.index('=')
        name = token[:sep].strip()
        value = token[sep + 1:].strip()
        if not name or re.search(r'[\s<>{}\[\]"\'\\]', name):
            continue
        try: value = urllib.parse.unquote(value)
        except Exception: pass
        result[name] = value.rstrip(";").strip()
    return result


_COOKIE_MARKERS = ('c_user=', 'datr=', 'xs=', 'sb=', 'fr=', 'ps_l=', 'ps_n=', 'wd=')


def _cookie_score(text: str) -> int:
    """How cookie-like is this cell? >=2 markers = certainly the cookie cell."""
    return sum(1 for m in _COOKIE_MARKERS if m in text)


def _header_map(row: list) -> dict or None:
    """If this Excel/CSV row is a HEADER row, return {col_index: field}
    mapping; otherwise None. A row is a header when >=2 of its cells are
    short header-like words matching known field hints (longest-hint
    match, so 'Business Email' maps to business_email, not identifier)."""
    if not row:
        return None
    mapping = {}
    matched = 0
    for idx, cell in enumerate(row):
        t = str(cell or "").strip().lower()
        if not t or len(t) > 30:
            continue
        field = _match_field(t)
        if field and field not in mapping.values():
            mapping[idx] = field
            matched += 1
    return mapping if matched >= 2 else None


def _account_from_mapped_row(row: list, hmap: dict) -> dict or None:
    """Build an account from a row using the header→field mapping."""
    acc = {}
    for idx, field in hmap.items():
        if idx >= len(row):
            continue
        val = str(row[idx]).strip() if row[idx] is not None else ""
        if val and not acc.get(field):
            acc[field] = val
    if not acc.get("cookie"):
        return None
    acc["cookie"] = _strip_cookie_label(acc["cookie"])
    if not acc.get("identifier"):
        acc["identifier"] = ""
    if not acc.get("password"):
        acc["password"] = ""
    return acc


def _looks_like_identifier(text: str) -> bool:
    if not text:
        return False
    t = text.strip()
    # email
    if re.match(r'^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$', t):
        return True
    # phone (with/without +)
    if re.match(r'^\+?\d{7,15}$', t):
        return True
    # numeric fb uid
    if re.match(r'^\d{8,20}$', t):
        return True
    return False


def _strip_cookie_label(text: str) -> str:
    """A cookie cell often arrives with a label prefix pasted along
    ('Cookie: c_user=...' or 'cookie = datr=...'). Remove a leading
    word-colon label so only the real cookie string remains."""
    m = re.match(r'^[A-Za-z_ ]{2,15}\s*[:=]\s*(?=[a-zA-Z_]+=)', text.strip())
    if m:
        return text.strip()[m.end():].strip()
    return text.strip()


def _extract_account_from_row(cells: list) -> dict or None:
    """From one row of cells (any order, any count) extract
    {identifier, password, cookie} — whichever exist.

    v2: every cell may itself pack several fields separated by '|'
    or tab ('uid|pass|c_user=...'), so cells are split on those first;
    cookie cells get their label prefix stripped; the password heuristic
    requires a single word without spaces/colon so an 'Email: x' line can
    never be misread as a password."""
    # split packed cells on pipes / tabs
    flat = []
    for cell in cells:
        text = str(cell).strip() if cell is not None else ""
        if not text:
            continue
        flat.extend(t.strip() for t in re.split(r'\s*[|\t]\s*', text) if t.strip())

    identifier = ""
    password = ""
    cookie = ""
    best_score = 0
    business_email = ""
    for text in flat:
        s = _cookie_score(text)
        if s >= 2 and s > best_score:
            best_score = s
            cookie = text
            continue
        if _looks_like_identifier(text) and s == 0:
            # first identifier = the account id; a SECOND email address
            # in the same row is the business email
            if not identifier:
                identifier = text
            elif "@" in text and not business_email:
                business_email = text
            continue
        # password: single token, no spaces/colon/equals, not an
        # identifier, short-ish — the FIRST candidate wins
        if (not password and s == 0 and not _looks_like_identifier(text)
                and 3 <= len(text) <= 64 and "http" not in text
                and "=" not in text and ":" not in text and " " not in text):
            password = text
    if not cookie:
        return None
    cookie = _strip_cookie_label(cookie)
    acc = {"identifier": identifier, "password": password, "cookie": cookie}
    if business_email:
        acc["business_email"] = business_email
    return acc


# ─────────────────────────────────────────────────────────────────────────────
# TXT block parsing
# ─────────────────────────────────────────────────────────────────────────────

_TXT_FIELD_HINTS = {
    "identifier": ("email", "mail", "phone", "uid", "id", "username", "user",
                     "account"),
    "password": ("password", "pass", "pwd"),
    "cookie": ("cookie", "cookies"),
    "business_name": ("business name", "business_name", "biz name", "bm name",
                       "page name", "company name"),
    "business_email": ("business email", "business_email", "biz email",
                        "company email"),
    "your_name": ("your name", "your_name", "owner name", "full name",
                   "profile name", "name"),
}


def _match_field(key: str) -> str or None:
    """Best field for a label/header text. Uses the LONGEST hint contained
    in the key, so 'business email' resolves to business_email (14 chars),
    not identifier ('mail' substring, 4 chars) — the substring-trap that
    previously ate the business email."""
    key = (key or "").strip().lower()
    best, best_len = None, 0
    for field, hints in _TXT_FIELD_HINTS.items():
        for h in hints:
            if h in key and len(h) > best_len:
                best, best_len = field, len(h)
    return best


def _parse_txt_blocks(content: str) -> list:
    """Parse TXT into account blocks. Handles:
       - blank-line separated blocks
       - --- / ### / === separators
       - 'Email: x\nPass: y\nCookie: z' label-style blocks
       - one full cookie-string per line
    """
    accounts = []
    lines = content.split('\n')
    current = []
    blocks = []

    def flush():
        if current:
            blocks.append('\n'.join(current))
            current.clear()

    for line in lines:
        stripped = line.strip()
        is_sep = (not stripped) or (
            len(stripped) >= 3 and all(c in '-#=*~' for c in stripped))
        if is_sep:
            flush()
            continue
        # label-style line "Email: ..." always belongs to a block
        current.append(line.rstrip())
    flush()

    for block in blocks:
        labels = {}
        other_cells = []
        for ln in block.split('\n'):
            s = ln.strip()
            if not s:
                continue
            m = re.match(r'^([A-Za-z_ ]{2,20})\s*[:=]\s*(.+)$', s)
            if m:
                key = m.group(1).strip().lower()
                val = m.group(2).strip()
                matched = _match_field(key)
                if matched:
                    # if the same field repeats (two identifier-ish lines),
                    # the FIRST label wins — later ones only fill empties
                    if matched not in labels or matched in ("business_name",):
                        labels[matched] = val
                    continue
            other_cells.append(s)
        acc = _extract_account_from_row(other_cells) if other_cells else {}
        if not acc:
            acc = {}
        for field, val in labels.items():
            if field == "identifier" and not acc.get("identifier"):
                acc["identifier"] = val
            elif field == "password" and not acc.get("password"):
                acc["password"] = val
            elif field == "cookie" and not acc.get("cookie"):
                acc["cookie"] = val
            elif field in ("business_name", "business_email", "your_name"):
                acc[field] = val
        if acc.get("cookie"):
            accounts.append(acc)
    return accounts


def _parse_label_rows_table(content: str) -> list:
    """Handle a TXT where the SAME label prefix repeats per line:
       Email: a | Pass: b | Cookie: c   (all on ONE line, pipe/tab separated)
    """
    accounts = []
    for line in content.split('\n'):
        s = line.strip()
        if not s:
            continue
        parts = re.split(r'\s*[|\t]\s*', s)
        acc = _extract_account_from_row(parts)
        if acc:
            accounts.append(acc)
    return accounts


# ─────────────────────────────────────────────────────────────────────────────
# Main file entry
# ─────────────────────────────────────────────────────────────────────────────

def parse_accounts_file(file_path: str) -> list:
    """Parse an uploaded accounts file → list of account dicts:
    [{identifier, password, cookie, row}]  (cookie guaranteed present)"""
    ext = os.path.splitext(file_path)[1].lower()
    accounts = []

    # ── Excel ──
    if ext in ('.xlsx', '.xlsm'):
        import openpyxl
        wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
        ws = wb.active
        hmap = None
        for row_idx, row in enumerate(ws.iter_rows(values_only=True), 1):
            if not row or not any(c is not None and str(c).strip() for c in row):
                continue
            cells = list(row)
            if hmap is None:
                cand = _header_map(cells)
                if cand:
                    hmap = cand
                    continue          # header row itself is not an account
            acc = (_account_from_mapped_row(cells, hmap) if hmap
                   else _extract_account_from_row(cells))
            if acc:
                acc["row"] = row_idx
                accounts.append(acc)
        wb.close()
        return accounts

    if ext == '.xls':
        try:
            import xlrd
            wb = xlrd.open_workbook(file_path)
            ws = wb.sheet_by_index(0)
            hmap = None
            for row_idx in range(ws.nrows):
                cells = ws.row_values(row_idx)
                if hmap is None:
                    cand = _header_map(cells)
                    if cand:
                        hmap = cand
                        continue
                acc = (_account_from_mapped_row(cells, hmap) if hmap
                       else _extract_account_from_row(cells))
                if acc:
                    acc["row"] = row_idx + 1
                    accounts.append(acc)
            return accounts
        except ImportError:
            raise RuntimeError(
                "Legacy .xls needs the 'xlrd' package — please save as .xlsx.")

    with open(file_path, 'r', encoding='utf-8-sig', errors='replace') as f:
        content = f.read()
    if not content.strip():
        return []

    # ── JSON ──
    if ext in ('.json', '.jsonl'):
        parsed = _parse_json_content(content)
        if parsed:
            return parsed

    # ── CSV ──
    if ext == '.csv':
        import csv, io
        hmap = None
        for row_idx, row in enumerate(csv.reader(io.StringIO(content)), 1):
            if not row:
                continue
            if hmap is None:
                cand = _header_map(row)
                if cand:
                    hmap = cand
                    continue
            acc = (_account_from_mapped_row(row, hmap) if hmap
                   else _extract_account_from_row(row))
            if acc:
                acc["row"] = row_idx
                accounts.append(acc)
        if accounts:
            return accounts

    # ── TXT: single-line pipe/tab TABLE first (only if most lines are
    # actually pipe/tab-separated rows), otherwise label-block style ──
    accounts = []
    nonempty = [ln for ln in content.split('\n') if ln.strip()]
    if nonempty:
        packed = sum(1 for ln in nonempty if ('|' in ln) or ('\t' in ln)
                     or _cookie_score(ln) >= 2)
        if packed >= max(2, len(nonempty) // 2):
            accounts = _parse_label_rows_table(content)
    if not accounts:
        accounts = _parse_txt_blocks(content)
    for i, acc in enumerate(accounts, 1):
        acc.setdefault("row", i)
    return accounts


def _parse_json_content(content: str) -> list:
    """JSON/JSONL files: arrays of arrays (UID, Pass, Cookie), arrays of
    objects, EditThisCookie exports, or mixed records with keys
    like {email, password, cookie}."""
    stripped = content.strip()
    if not stripped.startswith('['):
        idx = stripped.find('[')
        if idx >= 0:
            stripped = stripped[idx:]
    if stripped.count('[') > stripped.count(']'):
        stripped += ']'
    accounts = []
    try:
        arr = json.loads(stripped)
    except (json.JSONDecodeError, ValueError):
        # JSONL fallback
        for i, line in enumerate(content.split('\n'), 1):
            line = line.strip()
            if not line.startswith('{'):
                continue
            try:
                obj = json.loads(line)
                acc = _account_from_json_obj(obj, i)
                if acc:
                    accounts.append(acc)
            except (json.JSONDecodeError, ValueError):
                pass
        return accounts
    if not isinstance(arr, list):
        return []
    for i, item in enumerate(arr, 1):
        acc = _account_from_json_obj(item, i)
        if acc:
            accounts.append(acc)
    return accounts


def _account_from_json_obj(obj, row) -> dict or None:
    if isinstance(obj, list):
        return _extract_account_from_row(obj)
    if isinstance(obj, dict):
        # already one cookie object? treat as cookie itself
        if 'name' in obj and 'value' in obj:
            return {"identifier": "", "password": "",
                    "cookie": json.dumps([obj]), "row": row}
        ident = (obj.get('email') or obj.get('mail') or obj.get('phone')
                 or obj.get('uid') or obj.get('id') or obj.get('username') or "")
        pwd = obj.get('password') or obj.get('pass') or obj.get('pwd') or ""
        cookie = (obj.get('cookie') or obj.get('cookies') or "")
        if isinstance(cookie, (dict, list)):
            cookie = json.dumps(cookie)
        if cookie:
            acc = {"identifier": str(ident), "password": str(pwd),
                   "cookie": str(cookie), "row": row}
            for f in ("business_name", "business_email", "your_name"):
                v = obj.get(f) or obj.get(f.replace("_", " ")) or ""
                if v:
                    acc[f] = str(v)
            return acc
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Google Sheet support
# ─────────────────────────────────────────────────────────────────────────────

def google_sheet_csv_url(sheet_url: str) -> str:
    """Convert any Google Sheet share URL into the public CSV endpoint.
    Accepts:
       https://docs.google.com/spreadsheets/d/<ID>/edit#gid=0
       https://docs.google.com/spreadsheets/d/<ID>/view
       https://docs.google.com/spreadsheets/d/<ID>/gviz/tq?tqx=out:csv
    """
    m = re.search(r'/spreadsheets/d/([a-zA-Z0-9_\-]+)', sheet_url)
    if not m:
        raise RuntimeError(
            "এটা সঠিক Google Sheet link না — link টা docs.google.com/spreadsheets/d/... দিয়ে শুরু হতে হবে।")
    sheet_id = m.group(1)
    gid_m = re.search(r'[#&?]gid=(\d+)', sheet_url)
    gid = gid_m.group(1) if gid_m else "0"
    return f"https://docs.google.com/spreadsheets/d/{sheet_id}/gviz/tq?tqx=out:csv&gid={gid}"


def parse_google_sheet(sheet_url: str) -> list:
    """Fetch a (published/shared-view) Google Sheet as CSV and parse
    accounts from it. The sheet must be shared as 'anyone with the link
    can view' (Viewer)."""
    import tempfile
    import urllib.request
    csv_url = google_sheet_csv_url(sheet_url)
    req = urllib.request.Request(
        csv_url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = resp.read().decode('utf-8-sig', errors='replace')
    tmp = tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False,
                                       encoding='utf-8')
    tmp.write(data)
    tmp.close()
    try:
        accounts = parse_accounts_file(tmp.name)
    finally:
        try: os.remove(tmp.name)
        except Exception: pass
    return accounts
