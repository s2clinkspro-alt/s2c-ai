"""Per-profile device fingerprint generator.

Every profile gets a STABLE, unique device identity derived from its
c_user id, so the same account always re-opens with the same
fingerprint (canvas seed, UA, viewport, timezone) — a real user's
device doesn't change between sessions — while different accounts
never share a fingerprint.
"""
import hashlib
import random

# Real-world Chrome UA strings (Chrome 124-126 era, all TLS-identical
# from the network's point of view)
_UA_DESKTOP = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
]
_UA_MOBILE = [
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
]

_VIEWPORTS_DESKTOP = [(1920, 1080), (1536, 864), (1440, 900), (1366, 768), (1600, 900)]
_VIEWPORTS_MOBILE = [(390, 844), (393, 873), (412, 915), (414, 896)]
_DPR_DESKTOP = [1.0, 1.0, 1.25, 2.0]
_DPR_MOBILE = [2.0, 3.0]

_TIMEZONES = [
    ("Asia/Dhaka", "BD"), ("Asia/Kolkata", "IN"), ("Asia/Jakarta", "ID"),
    ("Asia/Karachi", "PK"), ("Asia/Manila", "PH"), ("Asia/Ho_Chi_Minh", "VN"),
    ("Asia/Kuala_Lumpur", "MY"), ("Asia/Singapore", "SG"), ("Asia/Dubai", "AE"),
    ("Asia/Riyadh", "SA"), ("Europe/Istanbul", "TR"), ("Europe/London", "GB"),
    ("Europe/Berlin", "DE"), ("America/New_York", "US"), ("America/Chicago", "US"),
    ("America/Los_Angeles", "US"), ("America/Sao_Paulo", "BR"), ("Africa/Cairo", "EG"),
    ("Africa/Lagos", "NG"), ("Asia/Tokyo", "JP"), ("Asia/Seoul", "KR"),
    ("Asia/Bangkok", "TH"), ("Australia/Sydney", "AU"), ("Europe/Moscow", "RU"),
]


def _stable_int(seed_text: str, offset: int = 0) -> int:
    h = hashlib.sha256((str(seed_text) + f"#{offset}").encode()).hexdigest()
    return int(h[:12], 16)


def gen_fingerprint(account_key: str, mobile: bool = False) -> dict:
    """Deterministic per-account device profile.

    account_key: any stable unique string (fb c_user / email).
    Returns dict with ua, platform, viewport {w,h}, dpr, timezone,
    canvas_seed, locale.
    """
    pool_ua = _UA_MOBILE if mobile else _UA_DESKTOP
    pool_vp = _VIEWPORTS_MOBILE if mobile else _VIEWPORTS_DESKTOP
    pool_dpr = _DPR_MOBILE if mobile else _DPR_DESKTOP

    ua = pool_ua[_stable_int(account_key, 1) % len(pool_ua)]
    vp = pool_vp[_stable_int(account_key, 2) % len(pool_vp)]
    dpr = pool_dpr[_stable_int(account_key, 3) % len(pool_dpr)]
    tz, _cc = _TIMEZONES[_stable_int(account_key, 4) % len(_TIMEZONES)]

    is_mac = "Macintosh" in ua
    is_win = "Windows" in ua
    platform = "MacIntel" if is_mac else ("Win32" if is_win else ("iPhone" if "iPhone" in ua else "Linux armv8l" if "Android" in ua else "Linux x86_64"))

    # small per-account viewport jitter (±30px) so two profiles on the
    # same base resolution are still distinct
    w = vp[0] + (_stable_int(account_key, 5) % 61) - 30
    h = vp[1] + (_stable_int(account_key, 6) % 41) - 20

    return {
        "ua": ua,
        "platform": platform,
        "mobile": mobile,
        "viewport": {"width": w, "height": h},
        "dpr": dpr,
        "timezone": tz,
        "canvas_seed": _stable_int(account_key, 7) % 100000,
        "locale": "en-US",
        "has_touch": mobile,
    }
