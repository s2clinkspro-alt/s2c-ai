"""business.facebook.com wizard flow — ADAPTIVE + DIAGNOSTIC.

Pool pick (Business Name + Your Name + Email) → fill → Next ×3 → Done.

Adaptive: the bot measures how fast the page really loads (net speed) and
scales every wait with it. It never gives up just because the page is slow;
it waits until the page is genuinely READY (inputs/buttons rendered and the
DOM stopped changing), up to a generous budget, and logs exactly what it is
waiting for.

Diagnostic: on failure it identifies the REAL cause (login wall, checkpoint,
blocked/restricted, no internet/proxy, slow load, unknown layout) and saves
a screenshot so the reason is visible, not guessed.
"""
import asyncio
import os
import random
import time

BASE_URL = "https://business.facebook.com/"
PROFILES_ROOT_SHOTS = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                   "data", "debug")

MAX_SCREENS = 10
BASE_NAV_TIMEOUT_MS = 90_000        # first load budget (slow nets get long)
READY_BUDGET_S = 120                # max wait for a screen to become usable
STEP_BUDGET_S = 60                  # max wait for a click's result

# forward button labels (english + bangla UI)
_ENTRY = ("create a business account", "create an account", "create account",
          "create business account", "get started", "sign up",
          "বিজনেস অ্যাকাউন্ট তৈরি", "অ্যাকাউন্ট তৈরি করুন")
_NEXT = ("next", "continue", "পরবর্তী", "এগিয়ে যান", "সামনে যান")
_DONE = ("submit", "done", "create", "finish", "সম্পন্ন", "তৈরি করুন",
         "জমা দিন", "সাবমিট")
_SUCCESS = ("successfully", "created successfully", "welcome to meta business",
            "business portfolio created", "আপনার বিজনেস")

# after Submit: Facebook may show a validation / "unsuccessful" notice inside the
# popup. NAME problems are retryable with a different pool entry; others are not.
_NAME_ERR_MARKS = (
    "business name", "name isn't available", "name is not available",
    "name can't", "name can’t", "name cannot", "already in use", "already taken",
    "isn't allowed", "isn’t allowed", "not allowed", "special character",
    "doesn't follow", "doesn’t follow", "community standards", "invalid name",
    "unable to use this name", "try a different name", "choose a different name",
    "নাম", "ব্যবহার করা যাবে না", "ব্যবহৃত")
_FAIL_MARKS = (
    "unsuccessful", "couldn't create", "couldn’t create", "could not create",
    "wasn't created", "wasn’t created", "something went wrong", "there was a problem",
    "try again", "unable to create", "can't create", "can’t create",
    "তৈরি করা যায়নি", "সমস্যা হয়েছে", "আবার চেষ্টা")
SUBMIT_WAIT_MIN_S = 3.0             # loading after Submit/Next: 3 .. 10 s (x net factor)
SUBMIT_WAIT_MAX_S = 10.0
MAX_BIZ_ATTEMPTS = 3                # initial + (up to) 2 retries = 3 tries per profile

# diagnosis markers
_LOGIN_MARKS = ("log in to facebook", "log into facebook", "log in to continue",
                "you must log in", "login to continue", "লগ ইন")
_CHECKPOINT_MARKS = ("confirm your identity", "confirm it's you", "checkpoint",
                     "security check", "we need to confirm")
_BLOCK_MARKS = ("you can't use", "you can’t use", "temporarily blocked",
                "restricted", "account has been suspended", "disabled",
                "isn't available", "this page isn't available",
                "something went wrong", "try again later", "সাময়িকভাবে")
_NO_NET_MARKS = ("err_", "this site can’t be reached", "this site can't be reached",
                 "no internet", "err_proxy", "err_tunnel", "dns_probe")


def _norm(s) -> str:
    return " ".join((s or "").lower().split())


# ═════════════════════════════════════════════════════════════════════════════
# adaptive speed
# ═════════════════════════════════════════════════════════════════════════════
class Pace:
    """Measures real load time and scales every wait. factor 1.0 = fast net."""

    def __init__(self):
        self.factor = 1.0
        self.load_s = 0.0

    def learn(self, seconds: float):
        self.load_s = seconds
        if seconds < 3:
            self.factor = 1.0
        elif seconds < 8:
            self.factor = 1.8
        elif seconds < 20:
            self.factor = 3.0
        else:
            self.factor = 4.5

    @property
    def label(self) -> str:
        return ("FAST" if self.factor <= 1.0 else
                "NORMAL" if self.factor <= 1.8 else
                "SLOW" if self.factor <= 3.0 else "VERY SLOW")

    async def sleep(self, lo, hi):
        await asyncio.sleep(random.uniform(lo, hi) * self.factor)


# ═════════════════════════════════════════════════════════════════════════════
# page reading
# ═════════════════════════════════════════════════════════════════════════════
_JS_READ = """() => {
    const vis = el => !!(el && (el.offsetParent !== null || el.getClientRects().length));
    const inputs = [];
    document.querySelectorAll('input, textarea').forEach((el, k) => {
        if (!vis(el) || el.disabled || el.readOnly) return;
        let label = '';
        const id = el.getAttribute('id');
        if (id) {
            const l = document.querySelector('label[for="' + CSS.escape(id) + '"]');
            if (l) label = l.innerText;
        }
        if (!label) { const l = el.closest('label'); if (l) label = l.innerText; }
        if (!label) label = el.getAttribute('aria-label') || '';
        if (!label) label = el.getAttribute('placeholder') || '';
        if (!label) label = el.getAttribute('name') || '';
        el.setAttribute('data-s2c-f', String(k));
        inputs.push({sel: 'input[data-s2c-f="' + k + '"], textarea[data-s2c-f="' + k + '"]',
                     type: (el.type || 'text'), label: (label || '').trim().slice(0, 120),
                     value: (el.value || '').slice(0, 200)});
    });
    const buttons = [];
    // v2: when a modal dialog is open, ONLY its controls count. Facebook keeps the
    // whole page behind the dialog in the DOM, so unscoped scans matched hidden or
    // background "Continue/Next/Create" links instead of the dialog's own button.
    const dialogs = Array.from(document.querySelectorAll('[role="dialog"], [aria-modal="true"]')).filter(vis);
    const scope = dialogs.length ? dialogs[dialogs.length - 1] : document;
    scope.querySelectorAll('button, [role="button"], a[role="button"], input[type="submit"], a[href]').forEach((el, k) => {
        if (!vis(el) || el.disabled || el.getAttribute('aria-disabled') === 'true') return;
        const t = (el.innerText || el.getAttribute('aria-label') || el.value || '').trim();
        if (!t || t.length > 60) return;
        el.setAttribute('data-s2c-b', String(k));
        buttons.push({sel: '[data-s2c-b="' + k + '"]', t: t});
    });
    const spinner = !!document.querySelector(
        '[role="progressbar"], [aria-busy="true"], [class*="spinner" i], [class*="loading" i]');
    return {url: location.href, title: document.title || '',
            ready: document.readyState,
            text: (document.body ? document.body.innerText : '').slice(0, 5000),
            html_len: document.documentElement.outerHTML.length,
            inputs, buttons, spinner};
}"""


async def _read(page) -> dict:
    try:
        return await page.evaluate(_JS_READ)
    except Exception:
        # navigation mid-read — caller will poll again
        return {"url": page.url or "", "title": "", "ready": "loading", "text": "",
                "html_len": 0, "inputs": [], "buttons": [], "spinner": True}


def _find_btn(buttons, texts, exact_first=True):
    for b in buttons:
        t = _norm(b["t"])
        if any(t == x or t.startswith(x) for x in texts):
            return b
    for b in buttons:
        t = _norm(b["t"])
        if any(x in t for x in texts):
            return b
    return None


def _success(s) -> bool:
    low = (s.get("text") or "").lower()
    return any(x in low for x in _SUCCESS)


def _has_any(s, marks) -> str:
    low = (s.get("text") or "").lower() + " " + (s.get("url") or "").lower() \
          + " " + (s.get("title") or "").lower()
    for m in marks:
        if m in low:
            return m
    return ""


def _usable(s) -> bool:
    return bool(s.get("inputs") or s.get("buttons"))


# ═════════════════════════════════════════════════════════════════════════════
# adaptive waiting — waits for a REAL, settled page, never gives up early
# ═════════════════════════════════════════════════════════════════════════════
async def _wait_ready(page, pace: Pace, log, what: str, budget_s: float):
    """Wait until the page has usable controls AND has stopped changing.
    Logs honest progress while waiting. Returns the settled snapshot, or the
    last snapshot if the budget ran out (caller diagnoses it)."""
    t0 = time.time()
    last_sig = None
    stable = 0
    last_log = 0
    s = None
    while time.time() - t0 < budget_s * max(1.0, pace.factor / 2):
        s = await _read(page)
        sig = (s["url"], s["html_len"] // 200, len(s["inputs"]), len(s["buttons"]))
        stable = stable + 1 if sig == last_sig else 0
        last_sig = sig

        waited = int(time.time() - t0)
        if waited - last_log >= 10:
            last_log = waited
            log(f"⏳ {what} — {waited}s waited "
                f"(page: {s['ready']}, buttons: {len(s['buttons'])}, "
                f"inputs: {len(s['inputs'])}, spinner: {'yes' if s['spinner'] else 'no'}"
                f", net: {pace.label})")

        # definitive terminal pages → stop waiting, caller handles
        if _success(s) or _has_any(s, _LOGIN_MARKS) and not _usable(s):
            return s
        # ready = usable controls + DOM quiet for 2 polls + no spinner.
        # (document.readyState is NOT required: on real Facebook it never
        # reaches "complete" because of endless background loading.)
        if _usable(s) and stable >= 2 and not s["spinner"] and s["ready"] != "loading":
            return s
        # usable but a spinner never goes away: accept after a longer quiet
        if _usable(s) and stable >= 6:
            return s
        await asyncio.sleep(0.5)
    return s



async def _robust_click(page, sel, log=None, what: str = "button"):
    """Click that survives invisible overlays / role=button divs.
    sel: CSS selector STRING ba Playwright Locator — dutoi kaj korbe.
    0) SMART WAIT: element visible na hoite loading er time dei (slow net safe)
    1) real click  2) element.click() via JS  3) focus + Enter."""
    # Locator pass hole sei locator-i, string hole locator banai
    loc = sel if not isinstance(sel, str) else page.locator(sel).first
    # ── SMART WAIT: element ash-onto porjonto wait (net slow hole-o thik) ──
    try:
        await loc.wait_for(state="visible", timeout=12_000)
    except Exception:
        if log: log(f"⏳ {what}: element visible hote deri hocche (net slow?) — tar porjo try korchi")
    try:
        await loc.scroll_into_view_if_needed(timeout=5000)
    except Exception:
        pass
    try:
        await loc.click(timeout=8000)
        return "mouse"
    except Exception as e1:
        if log: log(f"⚠ {what}: সাধারণ ক্লিক হয়নি ({str(e1)[:60]}) → JS ক্লিক")
    try:
        await loc.evaluate("el => el.click()")
        return "js"
    except Exception as e2:
        if log: log(f"⚠ {what}: JS ক্লিক হয়নি ({str(e2)[:60]}) → কিবোর্ড Enter")
    try:
        await loc.evaluate("el => el.focus()")
    except Exception:
        pass
    await page.keyboard.press("Enter")
    return "keyboard"



async def _settle_after_click(page, pace: Pace, log, what: str):
    """After Submit / Next the dialog shows a loading state for ~3-10 s before
    the next wizard step (or a notice) appears. Wait the minimum first, then keep
    waiting (adaptive) until the spinner is gone and the DOM stopped changing."""
    # minimum human-like pause (3-10 s), stretched a little on slow nets
    await asyncio.sleep(random.uniform(SUBMIT_WAIT_MIN_S, SUBMIT_WAIT_MAX_S)
                        * (1.0 + (pace.factor - 1.0) * 0.25))
    deadline = time.time() + SUBMIT_WAIT_MAX_S * 3 * pace.factor
    last_len, stable = -1, 0
    while time.time() < deadline:
        s = await _read(page)
        cur = (s.get("html_len") or 0)
        busy = bool(s.get("spinner")) or s.get("ready") != "complete"
        stable = stable + 1 if (abs(cur - last_len) < 40 and not busy) else 0
        last_len = cur
        if stable >= 2:
            return s
        await asyncio.sleep(1.2)
    log(f"⏳ {what}: লোডিং অনেকক্ষণ চলছে, যা আছে সেটাই পড়ছি")
    return await _read(page)


def _read_notice(s: dict) -> tuple:
    """Smartly read the popup text after Submit.
    Returns (kind, snippet): 'name' | 'other' | ''."""
    text = (s.get("text") or "")
    low = text.lower()
    bad = [m for m in _FAIL_MARKS if m in low]
    name_hit = [m for m in _NAME_ERR_MARKS if m in low]
    # the wizard prompt itself says "business and account name" — only treat the
    # name words as an ERROR when a failure/notice word is also on screen, or when
    # one of the unambiguous name-rejection phrases appears.
    strong = ("isn't available", "isn’t available", "is not available", "already in use",
              "already taken", "isn't allowed", "isn’t allowed", "not allowed",
              "special character", "community standards", "invalid name",
              "try a different name", "choose a different name", "unable to use this name",
              "ব্যবহার করা যাবে না", "ব্যবহৃত")
    if any(m in low for m in strong) or (bad and name_hit):
        idx = min([low.find(m) for m in (strong + tuple(bad)) if m in low] or [0])
        return "name", text[max(0, idx - 40): idx + 140].replace("\n", " ").strip()
    if bad:
        idx = low.find(bad[0])
        return "other", text[max(0, idx - 40): idx + 140].replace("\n", " ").strip()
    return "", ""


async def _shot(page, tag: str, why: str) -> str:
    try:
        os.makedirs(PROFILES_ROOT_SHOTS, exist_ok=True)
        path = os.path.join(PROFILES_ROOT_SHOTS,
                            f"{time.strftime('%H%M%S')}_{why}.png")
        await page.screenshot(path=path, full_page=False)
        return path
    except Exception:
        return ""


def _diagnose(s: dict, load_err: str, pace: Pace) -> tuple:
    """Return (code, human-readable diagnosis incl. suggested fix)."""
    if load_err:
        low = load_err.lower()
        if any(m in low for m in ("err_proxy", "err_tunnel", "proxy")):
            return ("proxy", "প্রক্সি কাজ করছে না (tunnel/proxy error) — proxy.txt এর প্রক্সি বদলাও বা বন্ধ করে চালাও")
        if any(m in low for m in ("err_name_not_resolved", "dns")):
            return ("dns", "DNS সমস্যা — ইন্টারনেট/DNS চেক করো")
        if any(m in low for m in ("err_internet_disconnected", "err_network_changed", "err_connection")):
            return ("network", "ইন্টারনেট সংযোগ বিচ্ছিন্ন / অস্থির — নেট চেক করো")
        if "timeout" in low:
            return ("timeout", f"পেজ লোড টাইমআউট (নেট খুব স্লো: avg load {pace.load_s:.0f}s) — নেট বা প্রক্সি স্পিড চেক করো")
        return ("load", f"পেজ লোড হয়নি — {load_err[:90]}")
    if not s:
        return ("empty", "পেজ থেকে কিছুই পড়া যায়নি")

    m = _has_any(s, _CHECKPOINT_MARKS)
    if m:
        return ("checkpoint", f"আইডি checkpoint-এ আটকে (“{m}”) — আইডি আগে ম্যানুয়ালি ঠিক করো")
    m = _has_any(s, _LOGIN_MARKS)
    if m:
        return ("login", "business.facebook.com-এ লগইন চাইছে — facebook.com-এ লগইন থাকলেও business সাইটে সেশন কার্যকর হয়নি; আইডিটা একবার ম্যানুয়ালি business.facebook.com এ খুলে দেখো")
    m = _has_any(s, _BLOCK_MARKS)
    if m:
        return ("blocked", f"Facebook পেজ ব্লক/রেস্ট্রিক্ট দেখাচ্ছে (“{m}”) — আইডি বা IP restricted হতে পারে")
    if s.get("spinner") and not _usable(s):
        return ("slow", f"পেজ এখনো লোড হচ্ছে (spinner) — নেট অনেক স্লো (avg load {pace.load_s:.0f}s)")
    if not _usable(s):
        return ("blank", "পেজ ফাঁকা — কোনো বাটন/ফিল্ড রেন্ডার হয়নি (ধীর নেট, প্রক্সি বা Facebook ব্লক হতে পারে)")
    names = [b["t"] for b in s["buttons"]][:8]
    return ("layout", f"অজানা লেআউট — পাওয়া বাটন: {names}")


# ═════════════════════════════════════════════════════════════════════════════
# humanized interaction
# ═════════════════════════════════════════════════════════════════════════════
async def _human_type(page, locator, text: str, pace: Pace):
    await locator.click()
    try:
        await locator.fill("")
    except Exception:
        pass
    for ch in text:
        await page.keyboard.type(ch, delay=max(15, min(160, abs(random.gauss(60, 25)))))
        if random.random() < 0.07:
            await asyncio.sleep(random.uniform(0.15, 0.5))


def _match_field(inp: dict, biz: dict):
    lab = _norm(inp["label"])
    if inp["value"]:
        return None
    if inp["type"] in ("checkbox", "radio", "hidden", "file", "submit", "button"):
        return None
    if inp["type"] == "email" or "email" in lab or "ইমেইল" in lab:
        v = (biz.get("business_email") or "").strip()
        return ("email", v) if v else None
    if "business" in lab and "name" in lab:
        v = (biz.get("business_name") or "").strip()
        return ("business_name", v) if v else None
    if "your name" in lab or "full name" in lab or "আপনার নাম" in lab:
        v = (biz.get("your_name") or "").strip()
        return ("your_name", v) if v else None
    return None


# ═════════════════════════════════════════════════════════════════════════════
# main flow
# ═════════════════════════════════════════════════════════════════════════════
async def _wizard_once(page, biz: dict, log, tag: str, pace: Pace, first_try: bool):
    """ONE full attempt. Returns (status, detail): created | exists | name_error | failed."""

    def lg(m):
        log(f"{tag} {m}")

    # ── 1. load, measuring real speed ────────────────────────────────────
    load_err = ""
    t0 = time.time()
    lg("business.facebook.com খুলছি…")
    try:
        await page.goto(BASE_URL, timeout=BASE_NAV_TIMEOUT_MS,
                        wait_until="domcontentloaded")
    except Exception as e:
        load_err = str(e)
    pace.learn(time.time() - t0)
    lg(f"প্রথম লোড {pace.load_s:.1f}s → নেট {pace.label}"
       f" (অপেক্ষা ×{pace.factor:g})")

    if load_err:
        # one patient retry before diagnosing — transient glitches are common
        lg(f"⚠ লোড সমস্যা: {load_err[:80]} — ১টা retry দিচ্ছি")
        await pace.sleep(3, 5)
        try:
            t1 = time.time()
            await page.goto(BASE_URL, timeout=BASE_NAV_TIMEOUT_MS,
                            wait_until="domcontentloaded")
            pace.learn(time.time() - t1)
            load_err = ""
        except Exception as e:
            load_err = str(e)
    if load_err:
        code, dx = _diagnose(None, load_err, pace)
        await _shot(page, tag, code)
        lg(f"🔎 DIAGNOSIS [{code}] {dx}")
        return "failed", f"[{code}] {dx}"

    typed = {}
    clicked_next = 0
    entered = False
    s = None
    try:
        for screen in range(MAX_SCREENS):
            # ── 2. wait until THIS screen is truly ready ─────────────────
            s = await _wait_ready(page, pace, lg,
                                  f"স্ক্রিন {screen + 1} লোডের অপেক্ষা", READY_BUDGET_S)

            if _success(s):
                return "created", "success message on screen"

            if not _usable(s):
                code, dx = _diagnose(s, "", pace)
                await _shot(page, tag, code)
                lg(f"🔎 DIAGNOSIS [{code}] {dx}")
                return "failed", f"[{code}] {dx}"

            # login wall even though controls exist (login form)
            if _has_any(s, _LOGIN_MARKS) and any(
                    i["type"] == "password" for i in s["inputs"]):
                code, dx = _diagnose(s, "", pace)
                await _shot(page, tag, code)
                lg(f"🔎 DIAGNOSIS [{code}] {dx}")
                return "failed", f"[{code}] {dx}"

            for marks, code_ in ((_CHECKPOINT_MARKS, "checkpoint"),):
                if _has_any(s, marks):
                    code, dx = _diagnose(s, "", pace)
                    await _shot(page, tag, code)
                    lg(f"🔎 DIAGNOSIS [{code}] {dx}")
                    return "failed", f"[{code}] {dx}"

            # ── 3. fill what this screen asks ────────────────────────────
            new_fills = []
            for inp in s["inputs"]:
                m = _match_field(inp, biz)
                if not m:
                    continue
                key, val = m
                if key in typed or not val:
                    continue
                try:
                    await _human_type(page, page.locator(inp["sel"]), val, pace)
                    typed[key] = True
                    new_fills.append(key)
                    lg(f"✍ {key} লিখলাম: “{val}”")
                    await pace.sleep(0.4, 0.9)
                except Exception as e:
                    lg(f"⚠ {key} লিখতে পারিনি: {str(e)[:80]}")

            entry = _find_btn(s["buttons"], _ENTRY)
            nxt = _find_btn(s["buttons"], _NEXT)
            done = _find_btn(s["buttons"], _DONE)

            # ── 4. already has a business (dashboard, no entry/wizard) ────
            if (not entered and not new_fills and not entry and not nxt
                    and not s["inputs"]):
                low = (s.get("text") or "").lower()
                if any(x in low for x in ("business settings", "meta business suite",
                                          "business manager", "business portfolio")):
                    return "exists", "already has a business profile"

            # ── 5. entry screen ──────────────────────────────────────────
            if not new_fills and entry and not nxt and not entered:
                lg("“Create a business account” চাপছি…")
                await pace.sleep(0.8, 1.6)
                await _robust_click(page, entry["sel"], lg, "Create account")
                entered = True
                await pace.sleep(1.5, 2.5)
                continue

            # ── 6. Next / Done ───────────────────────────────────────────
            _is_submit = bool(done) and _norm(done["t"]) in ("submit", "done", "সাবমিট", "সম্পন্ন")
            if nxt and not _is_submit and (new_fills or not done or clicked_next < 3):
                clicked_next += 1
                lg(f"Next → ({clicked_next})")
                await pace.sleep(0.8, 1.6)
                await _robust_click(page, nxt["sel"], lg, "Next")
                entered = True
                await _settle_after_click(page, pace, lg, "Next")
                continue

            if done:
                lg(f"{done['t']} চাপছি…")
                await pace.sleep(0.8, 1.6)
                await _robust_click(page, done["sel"], lg, "Submit")
                t_done = time.time()
                await _settle_after_click(page, pace, lg, "Submit")
                s2 = None
                while time.time() - t_done < STEP_BUDGET_S * pace.factor:
                    s2 = await _read(page)
                    if _success(s2):
                        return "created", "confirmed after Done"
                    low2 = (s2.get("text") or "").lower()
                    if any(x in low2 for x in ("business settings", "meta business suite",
                                               "business portfolio")) and not s2["inputs"]:
                        return "created", "landed on business dashboard"
                    # read the popup: unsuccessful / name notice?
                    kind, snip = _read_notice(s2)
                    if kind:
                        await _shot(page, tag, "submit_notice_" + kind)
                        lg(f"📖 popup নোটিস পড়লাম [{kind}]: {snip[:120]}")
                        return ("name_error" if kind == "name" else "failed"), f"[notice:{kind}] {snip[:90]}"
                    # another wizard screen appeared (Next / Done again) → keep going
                    if s2.get("buttons") and (_find_btn(s2["buttons"], _NEXT)
                                              or _find_btn(s2["buttons"], _DONE)) \
                            and not _find_btn(s2["buttons"], _DONE) == done:
                        break
                    if s2.get("spinner"):
                        await asyncio.sleep(1.5)
                        continue
                    await asyncio.sleep(1.5)
                else:
                    s2 = s2 or await _read(page)
                    code, dx = _diagnose(s2, "", pace)
                    await _shot(page, tag, "done_unconfirmed")
                    lg(f"🔎 DIAGNOSIS Submit চাপা হয়েছে কিন্তু সফলতার নিশ্চিতকরণ আসেনি — {dx}")
                    return "failed", "Done clicked but success not confirmed"
                continue          # next wizard screen → loop reads/clicks it

            code, dx = _diagnose(s, "", pace)
            await _shot(page, tag, code)
            lg(f"🔎 DIAGNOSIS [{code}] {dx}")
            return "failed", f"[{code}] {dx}"

        return "failed", "[layout] wizard শেষ হয়নি — স্ক্রিন সংখ্যা সীমা পেরিয়েছে"
    except Exception as e:
        try:
            await _shot(page, tag, "error")
        except Exception:
            pass
        lg(f"🔎 DIAGNOSIS [error] ফ্লো চলাকালীন সমস্যা: {str(e)[:120]}")
        return "failed", f"[error] {str(e)[:100]}"


async def create_business_profile(page, biz: dict, log, tag: str = "", next_biz=None):
    """Returns (status, detail): created | exists | failed.
    Name problem after Submit  → take another saved business info (next_biz())
    and try again, up to MAX_BIZ_ATTEMPTS total; still failing → give up so the
    engine skips to the next profile."""
    pace = Pace()
    tried = []
    cur = biz
    for attempt in range(1, MAX_BIZ_ATTEMPTS + 1):
        tried.append(cur.get("business_name", "?"))
        if attempt > 1:
            log(f"{tag} 🔁 চেষ্টা {attempt}/{MAX_BIZ_ATTEMPTS} — নতুন info: "
                f"{cur.get('business_name')} / {cur.get('your_name', '')} / {cur.get('business_email', '')}")
        status, detail = await _wizard_once(page, cur, log, tag, pace, attempt == 1)
        if status in ("created", "exists"):
            return status, detail if attempt == 1 else f"{detail} (attempt {attempt}: {cur.get('business_name')})"
        if status != "name_error":
            return "failed", detail            # login/checkpoint/layout etc → retry won't help
        if attempt >= MAX_BIZ_ATTEMPTS:
            break
        nxt_info = next_biz() if callable(next_biz) else None
        # never reuse an entry already tried in this run
        guard = 0
        while nxt_info and nxt_info.get("business_name") in tried and guard < 10:
            nxt_info = next_biz(); guard += 1
        if not nxt_info or nxt_info.get("business_name") in tried:
            log(f"{tag} ⚠ পুলে আর নতুন business info নেই — retry বন্ধ")
            break
        log(f"{tag} ⚠ নাম সমস্যা (“{cur.get('business_name')}”) — adaptive অপেক্ষা করে অন্য info নিয়ে আবার চেষ্টা")
        await pace.sleep(2.0, 4.0)
        try:                                   # reload wizard clean for the retry
            await page.goto(BASE_URL, timeout=BASE_NAV_TIMEOUT_MS, wait_until="domcontentloaded")
        except Exception as e:
            log(f"{tag} ⚠ রিলোড সমস্যা: {str(e)[:70]}")
        cur = nxt_info
    return "failed", f"[name] {len(tried)}বার চেষ্টা করেও হয়নি ({', '.join(tried)}) — প্রোফাইল স্কিপ"
