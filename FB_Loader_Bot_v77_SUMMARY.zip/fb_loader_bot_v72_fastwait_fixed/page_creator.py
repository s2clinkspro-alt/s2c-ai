"""Page Creator — BM-er bhitor Facebook Page bananor UI automation.

Flow (prottek BM er per-BM task):
  1. business settings pages URL e jaowa: business.facebook.com/latest/
     settings/pages?business_id=<BM_ID>  (adaptive smart_goto)
  2. "Add page" button click → dropdown khulbe
  3. "Create Facebook Page" option click → modal ashbe (Details step)
  4. Details fill: Page Name + Category (search & select) + Bio (optional,
     100 char cap) — dashboard Page Info Pool theke random entry
  5. "Next" click → Confirm step
  6. "I agree..." checkbox tick → "Create Page" button active hobe
  7. "Create Page" click → 7-15s (net-slow hole aro beshi) wait
  8. Success detection: modal close / "Page created" text / Done step

FB UI aria-first selectors, prottek step Bangla log, fail hole
dialog-er text snippet diye exact karon bole dey.
"""
import asyncio
import time as _time
import random

from adaptive import smart_goto
from biz_form import Pace, _robust_click, _human_type

PAGES_URL = ("https://business.facebook.com/latest/settings/pages"
             "?business_id={bm_id}")


async def _dlg(page, timeout_s: float = 15):
    """Open modal-er root locator (na pular porjonto wait)."""
    dlg = page.locator('div[role="dialog"]').last
    try:
        await dlg.wait_for(state="visible",
                           timeout=int(timeout_s * 1000))
        return dlg
    except Exception:
        return None


async def _find_clickable(scope, texts, log=None, what="element"):
    """Text-matched clickable (button/menuitem/link) — FB UI er jonne.
    texts: list of candidate texts, order = priority."""
    import re
    for t in texts:
        for sel in (f'button:has-text("{t}")',
                    '[role="menuitem"]:has-text("%s")' % t,
                    f'[role="button"]:has-text("{t}")',
                    f'a:has-text("{t}")'):
            try:
                loc = scope.locator(sel)
                n = await loc.count()
                if n:
                    # visible + enabled ta nei
                    for i in range(n):
                        el = loc.nth(i)
                        if await el.is_visible():
                            bad = await el.get_attribute("aria-disabled")
                            if bad != "true":
                                return el
            except Exception:
                continue
    return None


async def _read_text(scope) -> str:
    try:
        return (await scope.inner_text())[:800]
    except Exception:
        return ""


def _stop_requested() -> bool:
    try:
        from engine import engine_stop_requested
        return engine_stop_requested()
    except Exception:
        return False

async def create_bm_page(page, bm_id: str, info: dict, pace: Pace,
                         log, tag: str = "") -> tuple:
    """info = {"page_name","category","bio"(optional)}.
    Returns (ok: bool, reason: str)."""
    pn = (info.get("page_name") or "").strip()
    cat = (info.get("category") or "").strip()
    bio = (info.get("bio") or "").strip()[:100]      # 100 char cap
    if not pn or not cat:
        return False, "pool entry te page name/category nei"

    # ── 1. settings → pages tab (adaptive navigation) ──────────────────────
    url = PAGES_URL.format(bm_id=bm_id)
    log(f"{tag} 📄 BM er Pages settings e jacchi…")
    if not await smart_goto(page, url, log=log, tag=tag):
        return False, "pages settings load holo na (net/proxy)"

    # ── SMART WAIT: domcontentloaded ONLY. Fixed settle-sleep NAI —
    #    niche element-driven poll cholche, fixed wait = shudhu somoy noshto.
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=8_000)
    except Exception:
        pass

    # ── 1.5 + 2 MERGED (v6.6 FAST MODE): existing-page DETECT + 'Add'
    #    button khonja EK-I poll e. Element-driven: ja AGE visible hoy,
    #    sei dike cholbe — fast net e prothom poll eii click hoy.
    #      • URL selected_asset_id → page ache (skip)
    #      • "No Pages added" → page nai → Add click NOW
    #      • "ID: <digits>" row → page ache (skip)
    #      • Add button visible + page-marker NAI (N bar steady) → Add click
    #    Net slow hole Add button/body nijei deri ashe — poll deadline
    #    pace.factor diye boro, tai slow net e automatic beshi wait kore.
    existing = ""
    add_btn = None
    _add_confirm = 0
    _btn_deadline = _time.time() + 25 * pace.factor

    async def _find_add_btn():
        b = await _find_clickable(page, ["Add page", "Add Page", "Add Pages",
                                         "Add pages"])
        if b is None:
            # BM UI: button shudhu "Add" (+ icon) — exact text match
            for sel in ('[role="button"]:text-is("Add")', 'button:text-is("Add")',
                        '[role="button"]:has-text("Add")'):
                try:
                    loc = page.locator(sel)
                    for i in range(await loc.count()):
                        el = loc.nth(i)
                        t = ((await el.inner_text()) or "").strip()
                        if await el.is_visible() and \
                                t.lower().replace("+", "").strip() == "add":
                            return el
                except Exception:
                    pass
        if b is None:
            for lbl in ('[aria-label*="Add page" i]', '[aria-label*="পেজ" i]',
                        '[aria-label="Add"]',
                        '[role="button"][aria-label*="Add" i]'):
                try:
                    loc = page.locator(lbl)
                    if await loc.count():
                        return loc.first
                except Exception:
                    pass
        return b

    while _time.time() < _btn_deadline:
        if _stop_requested():
            return False, "stop requested — page wizard chere dilam"
        # (a) URL marker — FB nijei URL e bole dey page select hoyeche
        cur = page.url or ""
        if "selected_asset_id=" in cur and "selected_asset_type=page" in cur:
            return True, ("already: asset "
                          + cur.split("selected_asset_id=")[1].split("&")[0])
        # (b) body markers — ek-i evaluate (empty / existing row)
        try:
            state = await page.evaluate("""() => {
                const t = (document.body && document.body.innerText) || "";
                if (/no pages added/i.test(t)) return {empty: true, name: ""};
                const m = t.match(/\bID:\s*(\d{8,})/);
                if (m) {
                    const lines = t.split("\n").map(x => x.trim()).filter(Boolean);
                    let nm = "";
                    for (let i = 0; i < lines.length; i++) {
                        if (/^ID:\s*\d{8,}/.test(lines[i]) && i > 0) { nm = lines[i-1]; break; }
                    }
                    return {empty: false, name: nm || ("ID " + m[1])};
                }
                return {empty: false, name: ""};
            }""")
        except Exception:
            state = {"empty": False, "name": ""}
        if state.get("name"):
            return True, "already: " + str(state["name"])[:60]
        # Add button khonja (empty ook, inconclusive ook — button lagbei)
        if add_btn is None:
            add_btn = await _find_add_btn()
        if state.get("empty"):
            # CONCLUSIVE: page nai → button pelEI click, ar wait nai
            if add_btn is not None:
                break
        elif add_btn is not None:
            # inconclusive (marker parse hoy nai) → button STABLE hole click.
            # Slow net e marker button-er PORE ashte pare — tai confirm
            # count ta pace.factor er sathe bare (duplicate safety)
            _add_confirm += 1
            if _add_confirm >= 2 + int(pace.factor):
                break
        else:
            _add_confirm = 0
        await asyncio.sleep(0.4)      # fast poll — 1.5s na, 0.4s

    if add_btn is None:
        # page ta thik jaygate load hoylo kina — debug text dump
        try:
            body = (await page.evaluate(
                "() => (document.body && document.body.innerText || '').slice(0,300)"
            )).replace("\n", " | ")
        except Exception:
            body = "(read fail)"
        return False, (f"'Add page' button pawa gelo na — page dekheche: {body[:180]}"
                       " (thik URL e pages settings e aasini ba permission nei)")
    log(f"{tag} ⚡ 'Add' button visible — sathe sathe click (fixed wait nai)")
    await _robust_click(page, add_btn, log=log, what="Add page button")
    await pace.sleep(0.15, 0.3)   # dropdown render — niche option poll cholbe

    # ── 3. dropdown → "Create Facebook Page" ───────────────────────────────
    log(f"{tag} 🔎 dropdown e 'Create a new Facebook Page' option…")
    opt = None
    _opt_deadline = _time.time() + 15 * pace.factor
    _opt_texts = ["Create a new Facebook Page", "Create new Facebook Page",
                  "Create Facebook Page", "নতুন পেজ"]
    while _time.time() < _opt_deadline and opt is None:
        if _stop_requested():
            return False, "stop requested — page wizard chere dilam"
        opt = await _find_clickable(page, _opt_texts)
        if opt is None:
            # menu item plain div/span hote pare (role nei) — text diye dhori
            for t in _opt_texts:
                loc = page.get_by_text(t, exact=False)
                try:
                    n = await loc.count()
                    for i in range(n):
                        el = loc.nth(i)
                        if await el.is_visible():
                            opt = el
                            break
                except Exception:
                    pass
                if opt is not None:
                    break
        if opt is None:
            await asyncio.sleep(0.5)
    if opt is None:
        snippet = (await _read_text(page.locator("body")))[:200]
        return False, ("'Create a new Facebook Page' option paoa gelo na — dropdown: "
                       + snippet.replace("\n", " "))
    await _robust_click(page, opt, log=log, what="Create a new Facebook Page option")

    # ── 4. Details modal ───────────────────────────────────────────────────
    dlg = await _dlg(page, 20 * max(1.0, pace.factor))
    if dlg is None:
        return False, "create-page modal khulche na"
    log(f"{tag} 📝 Modal khuleche — Details fill korchi: "
        f"'{pn}' / '{cat}' / bio={'ache' if bio else 'na'}")

    # Page Name: modal render hote time lage — input visible hOTO MATROI
    # type korbo (smart poll, net slow hole-o cholbe, fast hole 0s wait)
    name_input = None
    _inp_deadline = _time.time() + 15 * pace.factor
    while _time.time() < _inp_deadline and name_input is None:
        if _stop_requested():
            return False, "stop requested — page wizard chere dilam"
        # sob input variant try: text input, label-less, aria, contenteditable
        for sel in ('input[aria-label*="name" i]', 'input[placeholder*="name" i]',
                    'input[type="text"]', 'input:not([type])',
                    '[role="textbox"][contenteditable="true"]'):
            try:
                inputs = dlg.locator(sel)
                n = await inputs.count()
                for i in range(n):
                    el = inputs.nth(i)
                    if await el.is_visible():
                        name_input = el
                        break
                if name_input is not None:
                    break
            except Exception:
                continue
        if name_input is None:
            await asyncio.sleep(0.5)      # modal ekhono render hocche
    if name_input is None:
        return False, "Page name input pawa gelo na (modal render holo na 15s te)"
    await _human_type(page, name_input, pn, pace)
    await pace.sleep(0.8, 1.5)

    # Category: combobox e type → suggestion SELECT — v7.6 REWRITE
    # (BUG [screenshot]: dropdown khule highlight hoy kintu SELECT hoy
    #  na → 'Next' button e ja-i na → page create fail. Ekhan thekei:
    #  poll-option → 3-layer click → VERIFY → na hole clear+retype.)
    cat_box = None
    _cat_deadline = _time.time() + 10 * pace.factor
    while _time.time() < _cat_deadline and cat_box is None:
        if _stop_requested():
            return False, "stop requested — page wizard chere dilam"
        cb = dlg.locator('input[role="combobox"], input[aria-label*="categor" i]').first
        try:
            if await cb.count() and await cb.is_visible():
                cat_box = cb
                break
        except Exception:
            pass
        await asyncio.sleep(0.8)
    if cat_box is None:
        return False, "category combobox pawa gelo na"

    await _human_type(page, cat_box, cat, pace)
    await pace.sleep(1.0, 1.8)
    cat_ok = False
    for _catt in (1, 2, 3):
        if _stop_requested():
            return False, "stop requested — page wizard chere dilam"
        if _catt > 1:
            log(f"{tag} 🔄 category select retry ({_catt}/3)…")
            # element re-render hole stale — abar khuje nei
            cb2 = dlg.locator('input[role="combobox"], input[aria-label*="categor" i]').first
            try:
                if await cb2.count() and await cb2.is_visible():
                    cat_box = cb2
            except Exception:
                pass
            try:
                await cat_box.fill("")
            except Exception:
                try:
                    await cat_box.click()
                    await page.keyboard.press("Control+a")
                    await page.keyboard.press("Backspace")
                except Exception:
                    pass
            await _human_type(page, cat_box, cat, pace)
            await pace.sleep(1.0, 1.8)

        # (a) suggestion option poll — FB er best-match 1st e thake
        opt = None
        _opt_dl = _time.time() + 6 * pace.factor
        while _time.time() < _opt_dl and opt is None:
            for sel in ('[role="option"]',
                        '[role="listbox"] li',
                        'div[role="dialog"] li[role="option"]'):
                try:
                    loc = page.locator(sel)
                    n = await loc.count()
                    match = None
                    first = None
                    for i in range(min(n, 12)):
                        el = loc.nth(i)
                        try:
                            if not await el.is_visible():
                                continue
                            t = ((await el.inner_text()) or "").strip()
                        except Exception:
                            continue
                        if not t or len(t) > 60:
                            continue
                        if first is None:
                            first = el
                        tl = t.lower()
                        cl = cat.lower()
                        if tl.startswith(cl[:8]) or cl[:8] in tl:
                            match = el
                            break
                    # text-match AGE; na thakle first visible option
                    # (FB typed text-er best suggestion list e 1st e)
                    opt = match or first
                    if opt is not None:
                        break
                except Exception:
                    continue
            if opt is None:
                await asyncio.sleep(0.5)

        if opt is not None:
            await _robust_click(page, opt, log=log,
                                what=f"category suggestion '{cat}'")
        else:
            # keyboard fallback: highlight-first + Enter
            try:
                await cat_box.click()
            except Exception:
                pass
            await cat_box.press("ArrowDown")
            await pace.sleep(0.3, 0.6)
            await cat_box.press("Enter")

        await pace.sleep(0.6, 1.2)
        # (b) VERIFY — category BOSHECHE kina? Selected hole FB input
        # CLEAR kore dey (chip/pill e dhuke jay), dropdown bondho/khola
        # jai. Typo-ra text input-ei jomay ase → oi state e RETRY.
        try:
            st = await page.evaluate("""(c) => {
                const d = document.querySelector('div[role="dialog"]');
                if (!d) return {ok: false};
                const inp = d.querySelector('input[role="combobox"]');
                const val = inp ? (inp.value || '').toLowerCase() : '';
                const open = Array.from(
                    d.querySelectorAll('[role="option"], [role="listbox"] li')
                ).some(el => el.offsetParent !== null);
                // select success: input clear, ba exact-value + dropdown bondho
                return {ok: (!val) || (val === c.toLowerCase() && !open)};
            }""", cat)
        except Exception:
            st = {"ok": False}
        if st.get("ok"):
            cat_ok = True
            log(f"{tag} ✅ category selected: '{cat}'")
            break
        try:
            await cat_box.press("Escape")   # khola dropdown bond kore
        except Exception:
            pass
        await pace.sleep(0.4, 0.8)
    if not cat_ok:
        return False, (f"category '{cat}' dropdown theke select hoy na — "
                       f"suggestion click + keyboard duitai kaj korchena")

    # Bio (optional): textarea ba contenteditable
    if bio:
        bio_box = dlg.locator("textarea").first
        if not await bio_box.count():
            bio_box = dlg.locator('[contenteditable="true"]').first
        if await bio_box.count():
            await _human_type(page, bio_box, bio, pace)
            log(f"{tag} ✍ bio bosano hoyeche ({len(bio)}/100)")
        else:
            log(f"{tag} ⚠ bio field pawa gelo na — bio chara jaitesi")

    await pace.sleep(0.8, 1.5)

    # ── 5. Next ───────────────────────────────────────────────────────────
    nxt = None
    _nxt_deadline = _time.time() + 10 * pace.factor
    while _time.time() < _nxt_deadline and nxt is None:
        if _stop_requested():
            return False, "stop requested — page wizard chere dilam"
        nxt = await _find_clickable(dlg, ["Next", "পরবর্তী"])
        if nxt is None:
            await asyncio.sleep(0.8)
    if nxt is None:
        return False, "'Next' button pawa gelo na"
    await _robust_click(page, nxt, log=log, what="Next button")

    # ── 6. Confirm step: checkbox → Create Page ────────────────────────────
    dlg2 = await _dlg(page, 15 * max(1.0, pace.factor))
    if dlg2 is None:
        return False, "Confirm step ashlo na (Next click kaj korle na)"
    log(f"{tag} ☑ Confirm step — 'I agree' checkbox tick korchi…")

    chk = None
    _chk_deadline = _time.time() + 10 * pace.factor
    while _time.time() < _chk_deadline and chk is None:
        if _stop_requested():
            return False, "stop requested — page wizard chere dilam"
        c = dlg2.locator('[role="checkbox"], input[type="checkbox"]').first
        try:
            if await c.count():
                chk = c
                break
        except Exception:
            pass
        await asyncio.sleep(0.8)
    if chk is None:
        return False, "I agree checkbox pawa gelo na"
    try:
        state = (await chk.get_attribute("aria-checked") or
                 ("checked" if await chk.is_checked() else ""))
        if state != "true":
            await _robust_click(page, chk, log=log, what="I agree checkbox")
    except Exception as e:
        # input[type=checkbox] er is_checked ate runtime error hole aria diye click
        try:
            await chk.click(force=True)
        except Exception:
            return False, f"checkbox tick kora gelo na: {e}"

    await pace.sleep(1.0, 2.0)

    # Create Page button — active howa porjonto wait (10-20s net-aware)
    log(f"{tag} ⏳ 'Create Page' button active howar opekkhay…")
    cp = None
    budget = 20 * max(1.0, pace.factor)
    waited = 0.0
    while waited < budget:
        cand = dlg2.locator('button:has-text("Create Page"), '
                            '[role="button"]:has-text("Create Page")')
        n = await cand.count()
        for i in range(n):
            el = cand.nth(i)
            if await el.is_visible():
                dis = (await el.get_attribute("aria-disabled")
                       or ("true" if not await el.is_enabled() else "false"))
                if dis != "true":
                    cp = el
                    break
        if cp:
            break
        await asyncio.sleep(1.0)
        waited += 1.0
    if cp is None:
        return False, ("'Create Page' button active holo na — checkbox tick "
                       "hoy ni ba UI e problem")

    # ── 7. click + 7-15s wait (page creating) ──────────────────────────────
    await _robust_click(page, cp, log=log, what="Create Page button")
    wait_s = random.uniform(7, 15) * pace.factor
    log(f"{tag} ⏳ Page create hocche — {wait_s:.0f}s opekkha…")
    await asyncio.sleep(wait_s)

    # ── 8. success detection ───────────────────────────────────────────────
    # modal close / "Page created" / Done step — jekono ekta holei success
    body = (await _read_text(page.locator("body")))
    low = body.lower()
    success_marks = ("page created", "পেজ তৈরি",
                     "your page has been created", "page name is available")
    dlg_still = await page.locator('div[role="dialog"]').count()
    done_btn = await page.locator(
        'button:has-text("Done"), [role="button"]:has-text("Done")').count()

    if dlg_still == 0:
        ok, reason = True, "modal close hoyeche — page create hoyer pashapashi list e fire"
    elif any(m in low for m in success_marks):
        ok, reason = True, "'Page created' text dekha geche"
    elif done_btn:
        ok, reason = True, "Done step esheche"
        d = await _find_clickable(page, ["Done"])
        if d:
            await _robust_click(page, d, log=log, what="Done button")
    else:
        # modal ekhono open + success text nei — aro 10s wait kore abar check
        await asyncio.sleep(10 * max(1.0, pace.factor))
        body = (await _read_text(page.locator("body")))
        low = body.lower()
        if await page.locator('div[role="dialog"]').count() == 0:
            ok, reason = True, "late response: modal kkhonpor close holo"
        elif any(m in low for m in success_marks):
            ok, reason = True, "late response: 'Page created' text"
        else:
            ok = False
            reason = ("page create confirm holo na — modal ekhono khola, "
                      "success text nei. Dialog: "
                      + (await _read_text(
                          page.locator('div[role="dialog"]'))
                          )[:200].replace("\n", " "))

    if ok:
        log(f"{tag} ✅ PAGE CREATED — '{pn}' (BM: {bm_id[:12]}…) — {reason}")
    else:
        log(f"{tag} ❌ page create fail — {reason}")
    return ok, reason
