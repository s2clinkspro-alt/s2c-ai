"""FB Loader Bot — dashboard server (Flask + SocketIO).

Pages / API:
  GET  /                    dashboard
  POST /api/import/file     upload .txt/.csv/.xlsx/.json accounts file
  POST /api/import/sheet    Google Sheet share link
  GET  /api/accounts        registry list + stats
  POST /api/accounts/delete {ids:[...] | "ALL"}
  POST /api/run             {mode: validate|run|bmcreate|pageadd, lanes: 1-5, ids?,
                              avoid_restricted?, visible?}
  POST /api/stop
  GET  /api/status
SocketIO events: 'log' (live engine log), 'state' (run state)
"""
import os
import socketio
from flask import Flask, render_template, request, jsonify

import accounts_db
import engine
from cookie_engine import parse_accounts_file, parse_google_sheet


APP_ROOT = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, template_folder=os.path.join(APP_ROOT, "templates"))
sio = socketio.Server(async_mode="threading", cors_allowed_origins="*")
app.wsgi_app = socketio.WSGIApp(sio, app.wsgi_app)

# ── License system (S2C BM Creator — S2C Flow architecture) ──
# Source mode (not compiled) = dev bypass; compiled exe enforces fully.
# MUST come AFTER app is built — v1.0.1 fixed placement bug.
try:
    from license_integration import init_license_system
    init_license_system(app)
    print("[License] system initialized")
except Exception as _lic_err:
    print(f"[License] init error: {_lic_err}")


def _emit_log(msg):
    try:
        sio.emit("log", {"msg": str(msg), "ts": __import__("time").strftime("%H:%M:%S")})
    except Exception:
        print(msg)


@sio.on("connect")
def _on_connect(sid, env):
    sio.emit("state", engine.status(), to=sid)


# ── dashboard ─────────────────────────────────────────────────────────────────
@app.route("/")
def dashboard():
    return render_template("dashboard.html")


# ── import: file ─────────────────────────────────────────────────────────────
@app.route("/api/import/file", methods=["POST"])
def api_import_file():
    if "file" not in request.files:
        return jsonify({"error": "কোনো ফাইল দাওনি"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "ফাইল সিলেক্ট করো"}), 400

    import tempfile
    suffix = os.path.splitext(f.filename)[1].lower() or ".txt"
    if suffix not in (".txt", ".csv", ".xlsx", ".xlsm", ".xls", ".json", ".jsonl"):
        return jsonify({"error": f"এই ফরম্যাট সাপোর্ট করে না: {suffix} — .txt/.csv/.xlsx/.json"}), 400

    tmp = os.path.join(tempfile.gettempdir(),
                       f"fbl_import_{int(__import__('time').time())}{suffix}")
    f.save(tmp)
    replace_all = request.form.get("replace_all") == "1"
    try:
        parsed = parse_accounts_file(tmp)
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"ফাইল পড়া গেল না: {e}"}), 400
    finally:
        try: os.remove(tmp)
        except Exception: pass

    if not parsed:
        return jsonify({"error": "ফাইলে কোনো ভ্যালিড কুকি পাওয়া যায়নি। প্রতি অ্যাকাউন্টে c_user, xs, datr সহ কুকি থাকতে হবে।"}), 400

    res = accounts_db.import_accounts(parsed, replace_all=replace_all)
    biz = accounts_db.biz_import_from_parsed(parsed)
    if biz["added"] or biz["skipped"]:
        _emit_log(f"business pool: {biz['added']} new, {biz['skipped']} already there")
    _emit_log(f"import: {len(res['added'])} added, {len(res['duplicates'])} duplicate, {len(res['invalid'])} invalid")
    return jsonify({
        "added": len(res["added"]),
        "duplicates": res["duplicates"],
        "invalid": res["invalid"],
        "biz_added": biz["added"],
        "biz_skipped": biz["skipped"],
        "total": accounts_db.stats()["total"],
    })


# ── import: Google Sheet ──────────────────────────────────────────────────────
@app.route("/api/import/sheet", methods=["POST"])
def api_import_sheet():
    url = (request.json or {}).get("url", "").strip()
    if not url:
        return jsonify({"error": "Sheet link দাও"}), 400
    try:
        parsed = parse_google_sheet(url)
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Sheet থেকে পড়া গেল না: {e} — sheet টা 'Anyone with the link (Viewer)' করে দাও।"}), 400
    if not parsed:
        return jsonify({"error": "Sheet-এ কোনো ভ্যালিড কুকি পাওয়া যায়নি।"}), 400
    res = accounts_db.import_accounts(parsed,
                                      replace_all=(request.json or {}).get("replace_all") == "1")
    biz = accounts_db.biz_import_from_parsed(parsed)
    if biz["added"]:
        _emit_log(f"business pool: {biz['added']} new from sheet")
    return jsonify({
        "added": len(res["added"]),
        "duplicates": res["duplicates"],
        "invalid": res["invalid"],
        "biz_added": biz["added"],
        "biz_skipped": biz["skipped"],
        "total": accounts_db.stats()["total"],
    })


# ── accounts ─────────────────────────────────────────────────────────────────
@app.route("/api/accounts")
def api_accounts():
    accs = []
    for a in accounts_db.all_accounts():
        accs.append({
            "id": a["id"], "identifier": a["identifier"] or a.get("c_user", "?"),
            "c_user": a["c_user"], "status": a["status"],
            "expired_reason": a.get("expired_reason", ""),
            "business_profile": a.get("business_profile", ""),
            "last_validated_at": a.get("last_validated_at"),
            "created_at": a["created_at"],
        })
    return jsonify({"accounts": accs, "stats": accounts_db.stats(),
                    "running": engine.is_running()})


# ── business info pool ───────────────────────────────────────────────────────
@app.route("/api/business")
def api_biz_list():
    return jsonify({"items": accounts_db.biz_list()})


@app.route("/api/business/add", methods=["POST"])
def api_biz_add():
    data = request.json or {}
    r = accounts_db.biz_add(data.get("business_name", ""),
                            data.get("your_name", ""),
                            data.get("business_email", ""))
    if not r.get("added"):
        return jsonify({"error": r.get("reason", "যোগ করা গেল না")}), 400
    _emit_log(f"business info added: {r['item']['business_name']} ({r['item']['business_email']})")
    return jsonify({"added": True, "item": r["item"]})


@app.route("/api/business/update", methods=["POST"])
def api_biz_update():
    data = request.json or {}
    biz_id = data.get("id")
    if not biz_id:
        return jsonify({"error": "id লাগবে"}), 400
    it = accounts_db.biz_update(biz_id, data)
    if not it:
        return jsonify({"error": "entry পাওয়া যায়নি"}), 404
    return jsonify({"updated": True, "item": it})


@app.route("/api/business/delete", methods=["POST"])
def api_biz_delete():
    data = request.json or {}
    ids = data.get("ids")
    if ids == "ALL" or (isinstance(ids, list) and ids):
        n = accounts_db.biz_delete(ids)
        return jsonify({"deleted": n})
    return jsonify({"error": "id দাও বা ALL"}), 400


@app.route("/api/pagepool", methods=["GET"])
def api_pagepool():
    return jsonify({"items": accounts_db.page_pool_list()})


@app.route("/api/pagepool/add", methods=["POST"])
def api_pagepool_add():
    data = request.json or {}
    r = accounts_db.page_pool_add(data.get("page_name", ""),
                                   data.get("category", ""),
                                   data.get("bio", ""))
    if not r.get("added"):
        return jsonify({"error": r.get("reason", "add fail")}), 400
    return jsonify(r)


@app.route("/api/pagepool/delete", methods=["POST"])
def api_pagepool_delete():
    data = request.json or {}
    ids = data.get("ids")
    if ids == "ALL" or (isinstance(ids, list) and ids):
        n = accounts_db.page_pool_delete(ids)
        return jsonify({"deleted": n})
    return jsonify({"error": "id dao ba ALL"}), 400


@app.route("/api/accounts/delete", methods=["POST"])
def api_accounts_delete():
    data = request.json or {}
    ids = data.get("ids")
    if ids == "ALL" or (isinstance(ids, list) and ids):
        removed = accounts_db.delete_accounts(ids)
        _emit_log(f"deleted {len(removed)} accounts")
        return jsonify({"deleted": len(removed)})
    return jsonify({"error": "কোনো id দাওনি"}), 400


# ── run ──────────────────────────────────────────────────────────────────────
@app.route("/api/run", methods=["POST"])
def api_run():
    data = request.json or {}
    mode = data.get("mode", "validate")
    if mode not in ("validate", "run", "bmcreate", "bmonly", "invite", "pageadd"):
        return jsonify({"error": "mode bhul — validate/run/bmcreate/bmonly/invite/pageadd"}), 400
    lanes = int(data.get("lanes", 1) or 1)
    ids = data.get("ids") or None
    invite_count = int(data.get("invite_count", 3) or 0)
    if invite_count:
        invite_count = max(2, min(5, invite_count))
    opts = {
        "bm_count": 1 if int(data.get("bm_count", 2) or 2) == 1 else 2,
        "avoid_restricted": bool((data.get("avoid_restricted", True))),
        "invite_count": invite_count,
        "headless": False,   # browser window ALWAYS stays open — only the BM API calls are silent
    }
    ok, msg = engine.start_run(mode=mode, lanes=lanes, only_ids=ids, log=_emit_log,
                               opts=opts if mode in ("bmcreate", "bmonly",
                                                     "invite", "pageadd") else None)
    if not ok:
        return jsonify({"error": msg}), 400
    return jsonify({"started": True})


engine.set_state_listener(lambda st: sio.emit("state", st))


# ── manual profile open (one button per account row) ─────────────────────────
@app.route("/api/profile/open", methods=["POST"])
def api_profile_open():
    import manual_open
    acc_id = (request.json or {}).get("id", "")
    if not acc_id:
        return jsonify({"error": "id নেই"}), 400
    acc = next((a for a in accounts_db.all_accounts() if a["id"] == acc_id), None)
    if not acc:
        return jsonify({"error": "অ্যাকাউন্ট পাওয়া যায়নি"}), 404
    if acc.get("status") == "expired":
        return jsonify({"error": "এই অ্যাকাউন্ট expired — আগে নতুন cookie/login দিয়ে Validate করো"}), 400
    ok, msg = manual_open.open_account(acc_id, log=_emit_log,
                                       bot_running_check=engine.is_running)
    if not ok:
        return jsonify({"error": msg}), 409
    return jsonify({"opening": True})


@app.route("/api/profile/status")
def api_profile_status():
    import manual_open
    return jsonify(manual_open.status())


# ── output settings (Excel auto / Google Sheet URL — v7.0) ─────────────────────
@app.route("/api/output/settings", methods=["GET", "POST"])
def api_output_settings():
    import sheet_output
    if request.method == "POST":
        data = request.json or {}
        cur = sheet_output.save_output_settings({
            "gsheet_url": (data.get("gsheet_url") or "").strip(),
        })
        _emit_log("output settings save holo (Google Sheet: " +
                  ("set" if cur.get("gsheet_url") else "khali") + ")")
        return jsonify(cur)
    st = sheet_output.get_output_settings()
    import glob
    files = sorted(glob.glob(os.path.join(sheet_output.OUT_DIR,
                                          "invite_results_*.xlsx")))
    st.update({"excel_path": "output/" + os.path.basename(files[-1])
               if files else "output/ (run শুরু হলে তৈরি হবে)",
               "excel_ready": bool(files)})
    return jsonify(st)


@app.route("/api/stop", methods=["POST"])
def api_stop():
    engine.request_stop()
    _emit_log("⏹ stop requested — সব ব্রাউজার বন্ধ হচ্ছে, run থামছে…")
    return jsonify({"stopping": True})


@app.route("/api/status")
def api_status():
    return jsonify(engine.status())


def _kill_old_instances():
    """Purano app.py instance (zombie) kill — na korle notun run er
    Stop button purano instance ke chere na, tar browser/log cholte thake."""
    try:
        import psutil, os, sys
    except ImportError:
        return
    me = os.getpid()
    my_dir = os.path.dirname(os.path.abspath(__file__))
    killed = 0
    try:
        for p in psutil.process_iter(["pid", "name", "cmdline", "cwd"]):
            try:
                if p.info["pid"] == me:
                    continue
                cl = " ".join(str(x) for x in (p.info["cmdline"] or []))
                if "app.py" not in cl:
                    continue
                try:
                    cwd = p.cwd()
                except Exception:
                    cwd = p.info["cwd"]
                if cwd and my_dir and os.path.abspath(cwd) != my_dir:
                    continue        # onno project er app.py — chere de
                p.kill()
                killed += 1
            except Exception:
                continue
    except Exception:
        pass
    if killed:
        print(f"killed {killed} old instance(s)")


if __name__ == "__main__":
    _kill_old_instances()
    print("FB Loader Bot → http://127.0.0.1:8500")
    from werkzeug.serving import run_simple
    run_simple("127.0.0.1", 8500, app, use_reloader=False, threaded=True)
