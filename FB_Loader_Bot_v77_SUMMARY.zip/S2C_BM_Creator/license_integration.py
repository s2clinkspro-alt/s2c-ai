"""
Skill2CashBD - License Integration for S2C BM Creator (v1.0)

v4.1: Background revalidation, smoother UX, no blocking during use.
"""

import os
from logger import license_log as log
import sys
from flask import Flask, request, jsonify, redirect

from license_client import (
    activate_license,
    check_license,
    get_license_info,
    get_device_fingerprint,
    clear_local_cache,
    detect_time_tampering,
    start_background_revalidation,
)

# v5.0: Bot activity heartbeat
try:
    from activity_reporter import start_heartbeat, send_final_heartbeat, stop_heartbeat
    _heartbeat_available = True
except Exception:
    _heartbeat_available = False

# Compiled builds (Nuitka/PyInstaller): bundled read-only assets can live
# in the onefile extraction dir (module dir) OR _MEIPASS; the launcher also
# chdir()s to the exe dir. Resolve the first location that has the gate file.
_MEIPASS = getattr(sys, "_MEIPASS", None)
_CANDIDATES = [
    os.path.dirname(os.path.abspath(__file__)),
    _MEIPASS,
    os.path.dirname(os.path.abspath(sys.executable)) if getattr(sys, "frozen", False) else None,
]
_BASE_DIR = next((d for d in _CANDIDATES
                  if d and os.path.isfile(os.path.join(d, "license_gate.html"))),
                 _CANDIDATES[0])


def check_or_gate() -> bool:
    """
    Called by setup_launcher.py during startup.
    Returns True if license is valid (including offline grace), False if activation needed.
    v91: Returns True in source mode (dev/testing bypass).
    """
    if ("__compiled__" not in dir()) and (not getattr(sys, 'frozen', False)):
        log.info("Source mode — license check bypassed")
        return True
    try:
        if detect_time_tampering():
            return False
        result = check_license()
        lic_ok = result.get('valid', False)

        # If license is valid, start background revalidation
        if lic_ok:
            start_background_revalidation()
            # v5.0: Start bot heartbeat for admin monitoring
            if _heartbeat_available:
                try:
                    start_heartbeat()
                    log.info("Heartbeat started")
                except Exception as e:
                    log.warning(f"Heartbeat start error: {e}")

        return lic_ok
    except Exception as e:
        print(f"[License] check_or_gate error: {e}")
        return False


def init_license_system(app: Flask):
    """Initialize license routes and guards on the Flask app."""

    # v91: Detect source mode (not compiled) — bypass license for dev/testing
    _SOURCE_MODE = ("__compiled__" not in dir()) and (not getattr(sys, 'frozen', False))
    if _SOURCE_MODE:
        log.warning("Running from SOURCE mode — license guard BYPASSED (dev/testing)")

    @app.errorhandler(500)
    def _handle_500(e):
        if request.path.startswith('/api/'):
            return jsonify({'success': False, 'valid': False, 'error': f'Internal server error: {e}', 'code': 'INTERNAL_ERROR'}), 500
        return e

    @app.route('/license')
    def license_gate():
        result = check_license()
        if result.get('valid'):
            # License became valid - start bg revalidation + heartbeat
            start_background_revalidation()
            if _heartbeat_available:
                try:
                    start_heartbeat()
                except Exception:
                    pass
            return redirect('/')
        html_path = os.path.join(_BASE_DIR, 'license_gate.html')
        if os.path.exists(html_path):
            with open(html_path, 'r', encoding='utf-8') as f:
                return f.read()
        return "License gate not found", 404

    @app.route('/api/activate-license', methods=['POST'])
    def api_activate_license():
        try:
            data = request.json or {}
            license_key = data.get('license_key', '').strip().upper()
            if not license_key:
                return jsonify({'success': False, 'error': 'Please enter a license key.'}), 400
            result = activate_license(license_key)
            if result.get('success'):
                # Start background revalidation after successful activation
                start_background_revalidation()
                # v5.0: Start bot heartbeat for admin monitoring
                if _heartbeat_available:
                    try:
                        start_heartbeat()
                        log.info("Heartbeat started after activation")
                    except Exception as e:
                        log.warning(f"Heartbeat start error: {e}")
                return jsonify({'success': True, 'data': result.get('data', {}), 'message': 'License activated successfully'})
            return jsonify({'success': False, 'error': result.get('error', 'Activation failed'), 'code': result.get('code', 'UNKNOWN')}), 403
        except Exception as e:
            return jsonify({'success': False, 'error': f'Internal error: {e}', 'code': 'INTERNAL_ERROR'}), 500

    @app.route('/api/license-info')
    def api_license_info():
        try:
            info = get_license_info()
            result = check_license()
            info['valid'] = result.get('valid', False)
            info['offline'] = result.get('offline', False)
            info['remaining_days'] = result.get('data', {}).get('remaining_days', 0)
            info['expires_at'] = result.get('data', {}).get('expires_at', info.get('expires_at', ''))
            info['grace_remaining_hours'] = result.get('data', {}).get('grace_remaining_hours', 0)
            return jsonify(info)
        except Exception as e:
            return jsonify({'valid': False, 'error': f'Internal error: {e}', 'code': 'INTERNAL_ERROR'}), 500

    @app.route('/api/deactivate-license', methods=['POST'])
    def api_deactivate_license():
        try:
            clear_local_cache()
            return jsonify({'success': True, 'message': 'License cleared'})
        except Exception as e:
            return jsonify({'success': False, 'error': f'Internal error: {e}', 'code': 'INTERNAL_ERROR'}), 500

    @app.before_request
    def _license_guard():
        # v91: Source mode — skip license guard entirely
        if _SOURCE_MODE:
            return None

        # Allowed paths that don't require license
        allowed_paths = ['/license', '/api/activate-license', '/api/license-info', '/api/deactivate-license', '/static/']
        for path in allowed_paths:
            if request.path.startswith(path):
                return None

        result = check_license()
        if not result.get('valid'):
            code = result.get('code', '')

            # If server connectivity issue, try offline grace via cached expiry
            if code in ('SERVER_UNREACHABLE', 'TIMEOUT', 'NETWORK_ERROR', 'CHALLENGE_FAILED', 'CHALLENGE_RETRY_EXHAUSTED'):
                from license_client import load_local_cache
                import datetime
                cache = load_local_cache()
                if cache and cache.get('expires_at'):
                    try:
                        expires = datetime.datetime.fromisoformat(
                            cache['expires_at'].replace('Z', '+00:00')
                        )
                        if datetime.datetime.now(datetime.timezone.utc) < expires:
                            return None
                    except Exception:
                        pass

            if request.path.startswith('/api/'):
                return jsonify({
                    'success': False,
                    'error': 'License required',
                    'code': code or 'NO_LICENSE',
                    'redirect': '/license'
                }), 403
            return redirect('/license')
        return None

    return app


def license_required(func):
    def wrapper(*args, **kwargs):
        result = check_license()
        if not result.get('valid'):
            raise RuntimeError(f"License required: {result.get('error', 'No license')}")
        return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper
