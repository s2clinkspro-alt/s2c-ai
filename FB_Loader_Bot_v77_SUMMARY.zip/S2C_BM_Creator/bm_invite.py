"""BM Invite — temp email ke BM + Page er FULL ACCESS e invite pathano.

EXACT 4-step wizard flow (client-verified real FB screenshots onujayi,
2026-10-15):

  0. https://business.facebook.com/latest/settings/business_users/
     ?business_id=<BM_ID>  ← BM ID profile theke fetch (bm_id param)
     → top-right "Invite people" button click → wizard popup

  1. Enter email    → temp mail type → popup-er BLANK WHITE SPACE e
                     click (validation trigger → Next active hoy) →
                     instantly Next click
  2. Give access    → Full access er "Manage" switch ON →
                     "View advanced options" click → dropdown-er
                     "View" + "Manage" duita switch ON → Next
  3. Assign assets  → "Select business asset(s)" dropdown click →
                     BM-er page select (tick) → "Confirm selection" →
                     page-er access switch gulo khule (shob OFF thake) →
                     halka scroll → "Partial access (business tools
                     and Facebook)" ON (uporer shob auto ON hoy) →
                     niche "Full access" → "Everything" ON → Next
  4. Review         → Next-er jaygay "Invite with 1 asset" button e
                     click → invitation send

Temp mail poll (temp_mail.py) → inbox theke ACCEPT/CONFIRM link collect
→ account-wise BM-wise output/invite_results.txt e save (engine).
invite_emails.txt thakle nijer domain addresses use hoy (link mailbox e).
"""
import asyncio
import os
import random

from biz_form import Pace, _robust_click, _human_type
from adaptive import smart_goto

# client-verified URL: business_users settings page, BM ID last-e param
BUSINESS_USERS_URL = ("https://business.facebook.com/latest/settings/"
                      "business_users/?business_id={bid}")

# Real full-control task IDs (live account theke verified 2026-10-14) —
# API mode er jonno reference, UI mode e lagbe na:
REAL_FULL_CONTROL_TASKS = [
    "2848818871965443", "967306614466178", "1633404653754086",
    "6161001899617846786", "862159105082613", "1327662214465567",
    "603931664885191", "768085000593466",
]


def _stop_requested() -> bool:
    """Engine STOP চাপা হইছে কিনা — wizard-er majhkhan thekeo check."""
    try:
        from engine import engine_stop_requested
        return engine_stop_requested()
    except Exception:
        return False


async def _dlg(page):
    return page.locator('div[role="dialog"]').first


async def _read_text(loc):
    try:
        return (await loc.inner_text(timeout=2500) or "").strip()
    except Exception:
        return ""


async def _click_text(page, texts, what, log, tag, scope=None, required=True,
                    max_wait_s: float = 12):
    """Multi-fallback text click — English/Bangla UI duita handle.
    SMART WAIT: element load hote somoy lage — visible na hoite
    max_wait_s porjonto poll kor (net slow hole-o kaj cholbe)."""
    import time as _t
    base = scope or page
    deadline = _t.time() + max_wait_s
    while _t.time() < deadline:
        for t in texts:
            for sel in (f'button:has-text("{t}")',
                        f'[role="button"]:has-text("{t}")',
                        f'[role="menuitem"]:has-text("{t}")',
                        f'a:has-text("{t}")',
                        f'[role="combobox"]:has-text("{t}")',
                        f'[aria-label*="{t}" i]',
                        'text="%s"' % t,
                        f':text("{t}")'):
                try:
                    loc = base.locator(sel).first
                    if await loc.count() and await loc.is_visible():
                        await _robust_click(page, sel, log=log, what=what)
                        return True
                except Exception:
                    continue
        await asyncio.sleep(1.5)      # element ash-onto wait
    if required:
        log(f"{tag} ⚠ '{what}' button khuje pailam na {int(max_wait_s)}s wait er por (tried: {texts})")
    return False


# ─────────────────────────────────────────────────────────────────────────────
# switch helpers — FB toggle gulo div[role="switch"], aria-checked on/off
# ─────────────────────────────────────────────────────────────────────────────

async def _row_text(sw) -> str:
    """Switch-er 6-level uporer text joriye fele — section/label khuje
    ber kar jonno (FB toggle er row-er exact structure change hoy)."""
    try:
        return await sw.evaluate(
            "el => { let t=''; let p=el; "
            "for (let i=0; i<3 && p; i++) { "
            "  t += ' ' + (p.innerText || ''); p = p.parentElement; } "
            "return t; }") or ""
    except Exception:
        return ""


async def _toggle_near(page, dlg, must: list, log, tag,
                        must_not: tuple = ("basic",), timeout_s: float = 14):
    """`must` text soho PROTHOM unchecked switch ON kore. FB switch e
    aria-label thake (e.g. 'Manage'/'Everything') — SHETA AGE match kori,
    na thakle 3-level row text. must_not thakle skip. Na pele False."""
    import time as _t
    deadline = _t.time() + timeout_s
    while _t.time() < deadline:
        try:
            sws = dlg.locator('[role="switch"]')
            n = await sws.count()
            for i in range(n):
                try:
                    sw = sws.nth(i)
                    if (await sw.get_attribute("aria-checked")) == "true":
                        continue
                    aria = ((await sw.get_attribute("aria-label")) or "").lower()
                    hit = all(m.lower() in aria for m in must) \
                        and not any(m.lower() in aria for m in must_not)
                    if not hit:
                        txt = (await _row_text(sw) or "").lower()
                        hit = all(m.lower() in txt for m in must) \
                            and not any(m.lower() in txt for m in must_not)
                    if hit:
                        try:
                            await sw.scroll_into_view_if_needed()
                        except Exception:
                            pass
                        await sw.click()
                        return True
                except Exception:
                    continue
        except Exception:
            pass
        await asyncio.sleep(1.0)
    return False


async def _toggle_all_matching(page, dlg, words: tuple, log, tag,
                                must_not: tuple = ("basic",),
                                max_clicks: int = 6):
    """Row-te words-er JAKHONO text thaka sob unchecked switch ON
    (e.g. 'view'/'manage' — advanced options er pair)."""
    on = 0
    for _ in range(max_clicks):
        try:
            sws = dlg.locator('[role="switch"]')
            n = await sws.count()
            hit = False
            for i in range(n):
                try:
                    sw = sws.nth(i)
                    if (await sw.get_attribute("aria-checked")) == "true":
                        continue
                    aria = ((await sw.get_attribute("aria-label")) or "").lower()
                    hit = any(w in aria for w in words) \
                        and not any(m in aria for m in must_not)
                    if not hit:
                        txt = (await _row_text(sw) or "").lower()
                        hit = any(w in txt for w in words) \
                            and not any(m in txt for m in must_not)
                    if hit:
                        try:
                            await sw.scroll_into_view_if_needed()
                        except Exception:
                            pass
                        await sw.click()
                        await asyncio.sleep(random.uniform(0.5, 0.9))
                        # click er POR state verify — na flip holei ON count
                        if (await sw.get_attribute("aria-checked")) == "true":
                            on += 1
                        hit = True
                        break
                except Exception:
                    continue
            if not hit:
                break
        except Exception:
            break
    return on


async def _click_blank(page, dlg, log, tag) -> bool:
    """Popup-er BLANK WHITE SPACE e click — email type korar por eta
    validation trigger kore, Next button active hoy. Header-er faka
    jaygay (close-X er kachakachi na, sidebar-er step-e na) click kori."""
    try:
        box = await dlg.bounding_box()
        if box:
            # main panel-er top-header zone: x-center, y ~10% (X button
            # right edge e, sidebar bame — duitai eeror )
            await page.mouse.click(box["x"] + box["width"] * 0.55,
                                   box["y"] + box["height"] * 0.10)
            return True
    except Exception:
        pass
    # fallback: heading text e click (button na, harmless)
    for t in ("Enter email addresses", "Invite people"):
        try:
            loc = dlg.locator(f'h2:has-text("{t}"), h1:has-text("{t}"), '
                              f'span:has-text("{t}")').first
            if await loc.count():
                await loc.click()
                return True
        except Exception:
            continue
    return False


async def _next_click(page, dlg, what, log, tag, timeout_s: float = 15) -> bool:
    """DIALOG-scope-er Next button — DISABLED obostha theke ENABLED howa
    porjonto poll kore (validation complete hole) then click."""
    import time as _t
    deadline = _t.time() + timeout_s
    while _t.time() < deadline:
        try:
            btns = dlg.locator('button:has-text("Next"), '
                               '[role="button"]:has-text("Next")')
            n = await btns.count()
            for i in range(n):
                try:
                    b = btns.nth(i)
                    if not await b.is_visible():
                        continue
                    if (await b.get_attribute("aria-disabled")) == "true":
                        continue
                    if await b.get_attribute("disabled") is not None:
                        continue
                    await b.click()
                    return True
                except Exception:
                    continue
        except Exception:
            pass
        # v7.7: 1.0s → 0.4s poll — Next enable holei click
        await asyncio.sleep(random.uniform(0.35, 0.5))
    log(f"{tag} ⚠ Next ({what}) {int(timeout_s)}s e enabled hoy nai")
    return False


async def _open_assets_dropdown(page, dlg, log, tag, timeout_s=20):
    """"Select business asset(s)" dropdown khola — FB ei box ta button na
    (combobox/styled div), tai 6-Strategy: aria-label → combobox → button
    → text-engine → JS click parent → mouse coordinate.

    v7.7 FALLBACK (client screenshot): majhe majhe assign-assets step e
    standard "Select Assets" list-er bodole FB "All N business asset
    included" full-control box dekhay. Oi khane "Assign manually" button
    thake — sheta click korlei AGER moto standard Select Assets list
    ashe. Ei function ekhon PROTTEK cycle e 2-ta check kore:
      1. standard dropdown ashle-i click (ag-er moto-i)
      2. dropdown na pele "Assign manually" button khunje click (max 2
         bar) — tarpor abar dropdown-er jonno poll cholbe.
    Fail-safe deadline 20s (ag-er 15s-er theke beshi, karon ekta extra
    UI state-er modde diye jete hoy)."""
    import time as _t
    deadline = _t.time() + timeout_s
    _manual_tried = 0
    while _t.time() < deadline:
        # ── check 1: standard "Select business asset(s)" dropdown ──
        for sel in ('[aria-label*="Select business asset" i]',
                    '[role="combobox"][aria-label*="Select" i]',
                    'button:has-text("Select business asset")',
                    '[role="button"]:has-text("Select business asset")',
                    'text="Select business asset"',
                    ':text("Select business asset")',
                    '[role="combobox"]'):
            try:
                loc = dlg.locator(sel).first
                if not (await loc.count()):
                    continue
                if not (await loc.is_visible()):
                    continue
                await _robust_click(page, loc, log=log, what="assets dropdown")
                log(f"{tag} 📂 assets dropdown khullo ({sel[:36]}…)")
                return True
            except Exception:
                continue
        # ── check 2 (v7.7 fallback): "All N asset included" shortcut
        #    box-er "Assign manually" button — click korle standard
        #    Select Assets list ashe, tarpor uporer check-i dhorbe ──
        if _manual_tried < 2:
            for sel in ('button:has-text("Assign manually")',
                        '[role="button"]:has-text("Assign manually")',
                        'text="Assign manually"',
                        ':text("Assign manually")'):
                try:
                    mb = dlg.locator(sel).first
                    if (await mb.count()) and (await mb.is_visible()):
                        log(f"{tag} ℹ 'All asset included' shortcut box "
                            f"dekhche — 'Assign manually' click korlam "
                            f"(standard Select Assets list ashbe)")
                        await _robust_click(page, mb, log=log,
                                            what="Assign manually")
                        _manual_tried += 1
                        # choto smooth wait — list render howa lagbe
                        await asyncio.sleep(random.uniform(0.5, 0.9))
                        break
                except Exception:
                    continue
        # v7.7: 1.2s → 0.5s poll — net bhalo hole dropdown ashlei click
        await asyncio.sleep(random.uniform(0.4, 0.6))
    return False


async def _confirm_selection_click(page, dlg, log, tag, timeout_s: float = 15):
    """"Confirm selection" — bulletproof: dual scope (dlg + page portal),
    4-selector chain, enabled-poll, JS fallback click, click-er POR
    switch-zone ashe kina diye verify."""
    import time as _t
    deadline = _t.time() + timeout_s
    clicked = False
    while _t.time() < deadline:
        for scope in (dlg, page):
            for sel in ('button:has-text("Confirm selection")',
                        '[role="button"]:has-text("Confirm selection")',
                        'text="Confirm selection"',
                        ':text("Confirm selection")'):
                try:
                    b = scope.locator(sel).first
                    if not (await b.count()) or not (await b.is_visible()):
                        continue
                    if (await b.get_attribute("aria-disabled")) == "true":
                        continue
                    if await b.get_attribute("disabled") is not None:
                        continue
                    await _robust_click(page, b, log=log,
                                        what="Confirm selection")
                    clicked = True
                    log(f"{tag} ✔ Confirm selection click hoyeche")
                    break
                except Exception:
                    continue
            if clicked:
                break
        if clicked:
            break
        # v7.7: 1.2s → 0.5s poll
        await asyncio.sleep(random.uniform(0.4, 0.6))
    if not clicked:
        # শেষ চেষ্টা: বাটন visible kintu enabled-detect kaj kortese na —
        # JS দিয়ে জোর করে click, তারপর switch zone এলেই success
        try:
            b = page.locator('button:has-text("Confirm selection"), '
                             '[role="button"]:has-text("Confirm selection")').first
            if await b.count() and await b.is_visible():
                await b.evaluate("el => el.click()")
                clicked = True
                log(f"{tag} ✔ Confirm selection — JS click (forced)")
        except Exception:
            pass
    if not clicked:
        log(f"{tag} ⚠ Confirm selection button pailam na/click hoy nai")
        return False
    # verify: switch zone ash-onto (max 8s) — FB ekhane ekto somoy ney
    vdl = _t.time() + 8
    while _t.time() < vdl:
        try:
            n = await dlg.locator('[role="switch"]').count()
            if n:
                return True
            n = await page.locator('[role="switch"]').count()
            if n:
                return True
        except Exception:
            pass
        # v7.7: 1.0s → 0.5s poll — switch zone ashlei fire
        await asyncio.sleep(random.uniform(0.4, 0.6))
    log(f"{tag} ⚠ Confirm click hoyeche kintu switch zone ashe nai")
    return False


async def _confirm_enabled(page, dlg, log=None, tag="") -> bool:
    """"Confirm selection" button ER কথা ENABLED kina — eihta-i page
    select howar GROUND TRUTH (tick check er cheye reliable)."""
    try:
        btns = dlg.locator('button:has-text("Confirm selection"), '
                           '[role="button"]:has-text("Confirm selection")')
        n = await btns.count()
        for i in range(n):
            b = btns.nth(i)
            if not await b.is_visible():
                continue
            if (await b.get_attribute("aria-disabled")) == "true":
                continue
            if (await b.get_attribute("disabled")) is not None:
                continue
            return True
    except Exception:
        pass
    # page-scope eo khujbo (portal layer)
    try:
        btns = page.locator('button:has-text("Confirm selection"), '
                            '[role="button"]:has-text("Confirm selection")')
        n = await btns.count()
        for i in range(n):
            b = btns.nth(i)
            if not await b.is_visible():
                continue
            if (await b.get_attribute("aria-disabled")) == "true":
                continue
            return True
    except Exception:
        pass
    return False


async def _tick_state_js(page, page_name) -> dict:
    """DOM ground truth: kon checkbox CHECKED + tar row text (JS, stale-free).
    input.checked + aria-checked dutoi dekhe."""
    try:
        return await page.evaluate("""() => {
            const els = document.querySelectorAll(
                '[role="checkbox"], input[type="checkbox"], [aria-checked]');
            for (const el of els) {
                const checked = el.getAttribute('aria-checked') === 'true' ||
                    (el.tagName === 'INPUT' && el.checked);
                if (checked) {
                    let p = el, t = '';
                    for (let i = 0; i < 4 && p; i++) {
                        t += ' ' + (p.innerText || ''); p = p.parentElement;
                    }
                    return {checked: true, row: (t || '').trim().slice(0, 80)};
                }
            }
            return {checked: false, row: ''};
        }""")
    except Exception:
        return {"checked": False, "row": ""}


async def _cb_coordinate_click(page, loc, log, what):
    """Checkbox er upor COORDINATE click — Playwright-er actionability
    check NAI, tai 8s timeout block NAI. Manual click er moto-i:
    oi point e je element ache tar-i upor click. JS/keyboard fallback."""
    try:
        box = await loc.bounding_box()
        if box and box.get("width", 0) > 0:
            off = min(box["width"], 22) / 2.0     # square er upor bame
            await page.mouse.click(box["x"] + off,
                                   box["y"] + box["height"] / 2.0)
            return True
    except Exception:
        pass
    # fallback 1: real click (choto timeout)
    try:
        await loc.click(timeout=1500)
        return True
    except Exception:
        pass
    # fallback 2: JS click
    try:
        await loc.evaluate("el => el.click()")
        return True
    except Exception:
        if log:
            log(f"⚠ {what}: coordinate/real/JS kaj korlo na")
    return False


async def _select_page_asset(page, dlg, page_name, log, tag):
    """v6.8 RETRY-AWARE (client-er exact chahida):
      '1st time open ei click koruk, na parle 2nd, 3rd try koruk'

    PRIO: VISIBLE checkbox element gulo (input[type=checkbox] +
    [role=checkbox] + [aria-checked]) — ei gulo ASHOL asset-list layer
    er bhitore thake, dimmed background/sidebar-er sathe conflict NAI
    (ager bug: 'text="Alina Jason"' diye sidebar-er BUSINESS-NAME e
    click hoto — modal overlay-er niche 8s timeout + background flicker).

    Flow: attempt = checkbox scan → coordinate click → tick verify
    (JS DOM + Confirm enabled). Tick na hole dropdown ABAR khule
    next attempt (max 4). Click COORDINATE-first — kono 8s block nai.
    """
    import time as _t
    deadline = _t.time() + 60

    def _left():
        return (page_name or "").strip().lower()

    attempts = 0
    while _t.time() < deadline:
        if _stop_requested():
            return False
        # ground truth: agei tick hoye thakle done
        if await _confirm_enabled(page, dlg):
            return True

        clicked_any = False
        # ── 1. VISIBLE checkbox gulo (ashol list layer) ──
        for scope in (dlg, page):
            for sel in ('input[type="checkbox"]', '[role="checkbox"]',
                        '[aria-checked]'):
                try:
                    boxes = scope.locator(sel)
                    n = await boxes.count()
                    target = None
                    first_vis = None
                    for i in range(min(n, 15)):
                        b = boxes.nth(i)
                        try:
                            if not (await b.is_visible()):
                                continue
                        except Exception:
                            continue
                        if first_vis is None:
                            first_vis = b
                        row = (await _row_text(b) or "").lower()
                        if _left() and _left() in row:
                            target = b
                            break
                    # match paile sei row; na paile first visible
                    # (BM-er ektai page thake beshirbhag)
                    if target is None:
                        target = first_vis
                    if target is not None:
                        await _cb_coordinate_click(page, target, log,
                                                   "asset checkbox")
                        clicked_any = True
                        # v7.7: 1.2s → 0.5s smooth wait
                        await asyncio.sleep(random.uniform(0.4, 0.6))
                        # verify 1: Confirm selection ENABLED
                        if await _confirm_enabled(page, dlg):
                            log(f"{tag} ✔ checkbox tick — Confirm enabled")
                            return True
                        # verify 2: DOM e checked ache kina
                        st = await _tick_state_js(page, page_name)
                        if st.get("checked") and (not _left() or _left() in
                                                  (st.get("row") or "").lower()):
                            log(f"{tag} ✔ tick hoyeche "
                                f"('{(st.get('row') or '')[:40]}')")
                            return True
                        if st.get("checked") and not _left():
                            return True
                except Exception:
                    continue
            if clicked_any and await _confirm_enabled(page, dlg):
                return True

        # ── 2. row/option click (checkbox selector match na dile) ──
        if not clicked_any:
            for sel in ('[role="option"]', '[role="listitem"]',
                        'li:has-text("Facebook Page")'):
                try:
                    rows = page.locator(sel)
                    n = await rows.count()
                    for i in range(min(n, 8)):
                        r = rows.nth(i)
                        try:
                            if not (await r.is_visible()):
                                continue
                        except Exception:
                            continue
                        row = (await _row_text(r) or "").lower()
                        if _left() and _left() not in row:
                            continue
                        await _cb_coordinate_click(page, r, log,
                                                   "asset row")
                        await asyncio.sleep(1.2)
                        if await _confirm_enabled(page, dlg):
                            log(f"{tag} ✔ row click e tick hoyeche")
                            return True
                        st = await _tick_state_js(page, page_name)
                        if st.get("checked"):
                            return True
                except Exception:
                    continue

        # ── 3. ei attempt e tick hoy nai → dropdown ABAR khulbo ──
        attempts += 1
        if attempts > 4:
            log(f"{tag} ⚠ 4 bar try-er poro tick hoy nai — ei BM skip")
            return False
        log(f"{tag} 🔄 tick hoy nai — dropdown abar khulchi "
            f"(attempt {attempts + 1})…")
        if not await _open_assets_dropdown(page, dlg, log, tag,
                                           timeout_s=8):
            await asyncio.sleep(1.0)
        else:
            await asyncio.sleep(1.0)
    return False

async def _toggle_last_two(page, dlg, log, tag, timeout_s: float = 14) -> bool:
    """Assets-step er switch list e EKDOM LAST 2 ta ON korlei shob auto ON
    (client-verified): order e DOM shonibadhan — shesh er duita first click,
    tarpor auto-ON howa wait, baki OFF thakle segulo-o ON (safety net)."""
    import time as _t
    deadline = _t.time() + timeout_s

    async def _switches():
        for scope in (dlg, page):
            try:
                sws = scope.locator('[role="switch"]')
                n = await sws.count()
                if n:
                    return [sws.nth(i) for i in range(n)]
            except Exception:
                continue
        return []

    # switch zone ashe ontor wait
    while _t.time() < deadline:
        lst = await _switches()
        if len(lst) >= 2:
            break
        # v7.7: 1.2s → 0.5s poll
        await asyncio.sleep(random.uniform(0.4, 0.6))
    if len(lst) < 2:
        log(f"{tag} ⚠ switch pailam na ({len(lst)} ta)")
        return False

    # ekdom LAST 2 ta (list er shesh) ON — scroll soho robust click
    clicked = 0
    for sw in lst[-2:]:
        try:
            if (await sw.get_attribute("aria-checked")) != "true":
                try:
                    await sw.scroll_into_view_if_needed()
                except Exception:
                    pass
                await _robust_click(page, sw, log=log, what="last switch")
                clicked += 1
                # v7.7: 0.6-1.2s → 0.2-0.5s gap
                await asyncio.sleep(random.uniform(0.2, 0.5))
        except Exception:
            continue
    log(f"{tag} 🔓 last 2 switch ON korlam ({clicked} ta click)")
    if clicked == 0:
        # dutoi already ON thakle o success — nothing to do
        try:
            if all((await s.get_attribute("aria-checked")) == "true" for s in lst[-2:]):
                return True
        except Exception:
            pass
        return False

    # v7.7: auto-ON howa ADAPTIVE wait — fixed 2.5s bashe thakto; ekhon
    # 0.4s poll e shob switch ON holei (max 4s) fire. FB last-2 click e
    # shob switch auto-ON kore dey.
    _auto_dl = _t.time() + 4.0
    while _t.time() < _auto_dl:
        try:
            _lst = await _switches()
            if _lst and all(
                    (await s.get_attribute("aria-checked")) == "true"
                    for s in _lst):
                break
        except Exception:
            pass
        await asyncio.sleep(0.4)
    try:
        lst = await _switches()
    except Exception:
        lst = []
    off = []
    for sw in lst:
        try:
            if (await sw.get_attribute("aria-checked")) != "true":
                off.append(sw)
        except Exception:
            continue
    for sw in off:
        try:
            await sw.scroll_into_view_if_needed()
        except Exception:
            pass
        try:
            await _robust_click(page, sw, log=log, what="bak OFF switch")
            await asyncio.sleep(0.5)
        except Exception:
            continue
    if off:
        log(f"{tag} 🔓 shob ON — bak {len(off)} ta switch-o ON korlam")
    return True



async def send_invite(page, bm_id, email, pace: Pace, log, tag="", page_name=""):
    """EKTA email ke FULL ACCESS (BM + Page) soho invite — exact
    client-verified 4-step wizard. Returns (ok, reason)."""
    try:
        # ── 0. business_users page (BM ID param) → Invite people button ──
        ok = await smart_goto(page, BUSINESS_USERS_URL.format(bid=bm_id),
                              log=log, tag=f"{tag}[invite]")
        if not ok:
            return False, "business_users page load holo na (net/proxy)"
        # v7.0: fixed sleep NAI — niche _click_text er 15s POLL nijei
        # button render howa wait kore, pawa matroi click kore.

        if not await _click_text(page, ["Invite people", "Invite People",
                                        "Add people", "Add People"],
                                 "Invite people (top right)", log, tag,
                                 max_wait_s=15):
            for sel in ('[aria-label*="Invite people" i]',
                        '[aria-label*="Invite People" i]',
                        '[aria-label*="Add people" i]',
                        '[role="button"][aria-label*="invite" i]'):
                try:
                    loc = page.locator(sel).first
                    if await loc.count() and await loc.is_visible():
                        await _robust_click(page, sel, log=log,
                                            what="Invite people")
                        break
                except Exception:
                    continue
            else:
                return False, "Invite people button pailam na"
        # v7.0: sleep NAI — dialog visible-howar wait_for e-i poll cholche

        # dialog khulbe
        try:
            await page.locator('div[role="dialog"]').first.wait_for(
                state="visible", timeout=15_000)
        except Exception:
            return False, "invite wizard popup khuleni"
        dlg = await _dlg(page)

        # ── 1. Enter email — type → BLANK SPACE click → Next ──
        inp = None
        import time as _t
        _INP_SELS = ('div[role="dialog"] input[role="combobox"]',
                     'div[role="dialog"] input[type="email"]',
                     'div[role="dialog"] input[type="text"]',
                     'div[role="dialog"] input[type="search"]',
                     'div[role="dialog"] input',
                     'div[role="dialog"] [role="textbox"][contenteditable="true"]',
                     'div[role="dialog"] input[placeholder*="mail" i]',
                     'div[role="dialog"] input[placeholder*="email" i]')
        # v7.4 FIX: email input shudhu DIALOG er VITORE + VISIBLE hole nebe.
        # Age scopeless 'input[placeholder*="mail"]' fallback diye BACKGROUND
        # input (business page er search box) e type hoto — popup e emon
        # likhto na. Ekhon 3-shomoy check: count + visible + enabled.
        _dl = _t.time() + 20
        while _t.time() < _dl and inp is None:
            for sel in _INP_SELS:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() and await loc.is_visible() \
                            and await loc.is_enabled():
                        inp = loc
                        break
                except Exception:
                    continue
            if inp is None:
                await asyncio.sleep(0.7)
        if inp is None:
            return False, "email input pailam na (popup thik moto khuleni?)"
        # v7.4: FB dialog re-render hole element stale hoy — type fail
        # korle abar khuje abar type (max 2 try)
        typed = False
        for _try in (1, 2):
            try:
                await _human_type(page, inp, email, pace)
                typed = True
                break
            except Exception as _e:
                log(f"{tag} ⚠ email type fail — retry ({_try}/2): {str(_e)[:70]}")
                await asyncio.sleep(1.0)
                inp = None
                for sel in _INP_SELS:
                    try:
                        loc = page.locator(sel).first
                        if await loc.count() and await loc.is_visible() \
                                and await loc.is_enabled():
                            inp = loc
                            break
                    except Exception:
                        continue
                if inp is None:
                    break
        if not typed:
            return False, "email input e likhte parlam na (element stale/hidden)"
        await asyncio.sleep(0.3)
        await pace.sleep(0.5, 1.0)
        # popup-er blank white space e click — Next active howa lagbe
        await _click_blank(page, dlg, log, tag)
        if not await _next_click(page, dlg, "email step", log, tag):
            return False, "email step e Next active hoy nai (email invalid?)"
        log(f"{tag} ✉️ email step OK — Give access e dhuklam")
        await pace.sleep(1.8, 3.0)
        dlg = await _dlg(page)

        if _stop_requested():
            return False, "stop requested"

        # ── 2. Give access — Full access "Manage" ON → advanced
        #    options → View + Manage ON → Next ──
        if await _toggle_near(page, dlg, ["manage"], log, tag,
                              must_not=("basic", "partial", "view")):
            log(f"{tag} 🔓 Full access → Manage switch ON")
        else:
            log(f"{tag} ⚠ Full access Manage toggle pailam na — shob switch ON korar try")
            await _toggle_all_matching(page, dlg, ("manage", "full access"),
                                        log, tag)
        await pace.sleep(0.8, 1.5)
        if await _click_text(page, ["View advanced options"],
                             "View advanced options", log, tag, scope=dlg,
                             max_wait_s=8):
            await pace.sleep(0.8, 1.5)
            adv = await _toggle_all_matching(page, dlg,
                                              ("view", "manage"), log, tag,
                                              must_not=("basic", "partial"))
            log(f"{tag} 🔓 advanced options — {adv} ta switch ON (View+Manage)")
        else:
            log(f"{tag} ℹ 'View advanced options' link pailam na — skip")
        if not await _next_click(page, dlg, "give access", log, tag):
            return False, "give access e Next active hoy nai"
        log(f"{tag} ✅ Give access OK — Assign assets e dhuklam")
        await pace.sleep(1.8, 3.0)
        dlg = await _dlg(page)

        if _stop_requested():
            return False, "stop requested"

        # ── 3. Assign assets — dropdown → page select (tick) →
        #    Confirm selection → Partial access ON → Everything ON → Next
        #    HARD RULE: ei step er KONO অংশ fail korle Next e jabo NA —
        #    asset chara invite orthohin (temp mail e full-access link ashe na) ──
        if not await _open_assets_dropdown(page, dlg, log, tag):
            return False, "'Select business asset(s)' dropdown pailam na"
        await pace.sleep(1.0, 2.0)
        if not await _select_page_asset(page, dlg, page_name, log, tag):
            return False, ("BM te page nai / page select hoy nai —"
                           " asset chara invite jabe na")
        log(f"{tag} 📄 page selected (tick) —"
            f"{f' {page_name}' if page_name else ' first page'}")
        if not await _confirm_selection_click(page, dlg, log, tag):
            return False, "Confirm selection click hoy nai"
        log(f"{tag} ✔ Confirm selection OK — access switches khulche")
        await pace.sleep(1.2, 2.0)

        # client rule: EKDOM LAST 2 switch ON → shob auto ON
        if not await _toggle_last_two(page, dlg, log, tag):
            return False, "page access switch ON hoy nai"
        if not await _next_click(page, dlg, "assign assets", log, tag):
            return False, "assign assets e Next active hoy nai"
        log(f"{tag} ✅ Assign assets OK — Review te dhuklam")
        await pace.sleep(1.8, 3.0)
        dlg = await _dlg(page)

        if _stop_requested():
            return False, "stop requested"

        # ── 4. Review → "Invite with 1 asset" → send ──
        sent = await _click_text(page, ["Invite with 1 asset",
                                        "Invite with 2 assets",
                                        "Invite with 3 assets",
                                        "Invite with",
                                        "Send invite", "Send Invite"],
                                 "Invite with 1 asset (send)", log, tag,
                                 max_wait_s=15)
        if not sent:
            return False, "'Invite with 1 asset' button pailam na"

        # v7.0 POLL: 'Invitation sent' text O dialog-close — jegulo AGE
        # hoy sathe sathi return. Fixed sleep nai, net slow hole deadline
        # pace.factor diye boro — tokhon-o boshe thake, bhul kore fail nai.
        import time as _st
        _dl2 = _st.time() + max(10.0, 20.0 * pace.factor)
        while _st.time() < _dl2:
            if _stop_requested():
                return False, "stop requested"
            try:
                body = (await page.evaluate(
                    "() => (document.body && document.body.innerText) || ''"))[:4000]
                if "invitation sent" in body.lower() or "you sent an invitation" in body.lower():
                    log(f"{tag} ✅ 'Invitation sent' — FB mail pathiyeche")
                    return True, "invitation sent"
            except Exception:
                pass
            try:
                if await page.locator('div[role="dialog"]').count() == 0:
                    log(f"{tag} ✅ invite complete — dialog closed")
                    return True, "invite sent (dialog closed)"
            except Exception:
                pass
            await asyncio.sleep(0.8)
        # deadline sesh — dialog ekhono khola: text dekhe final bosta
        try:
            txt = await _read_text(page.locator('div[role="dialog"]').first)
            if txt and "sent" not in txt.lower():
                return False, f"dialog ekhono khola: {txt[:120]}"
        except Exception:
            pass
        return True, "invite sent"

    except Exception as e:
        return False, f"invite flow error: {str(e)[:100]}"


async def invite_one(page, bm_id, pace: Pace, log, tag="",
                     late_ctx=None,
                     poll_s=150, page_name="", _mail_mod=None,
                     _new_addr=None, _poll=None, _slot=1):
    """Full cycle: fresh mail → 4-step invite → inbox poll → accept LINK.
    invite_emails.txt thakle nijer domain address (bm01@, bm02@...)
    sequential use hoy — oi mode e link faka thake (mailbox tumi porbe).
    Returns (link, email)."""
    import temp_mail
    mm = _mail_mod or temp_mail

    mail = None
    try:
        fp = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "invite_emails.txt")
        if os.path.exists(fp):
            lines = [l.strip() for l in open(fp, encoding="utf-8")
                     if l.strip() and not l.strip().startswith("#")]
            if lines:
                idx = (_slot - 1) % len(lines) if isinstance(_slot, int) and _slot > 0 else 0
                mail = {"email": lines[idx], "password": "",
                        "provider": "user-domain"}
                log(f"{tag} 📧 nijer domain email: {mail['email']} "
                    f"(link mailbox theke porbe)")
    except Exception:
        mail = None

    if mail is None:
        try:
            # v6.9.3: new_address er provider-chain HTTP gulo sync —
            # thread e chalano hoy, jate multi-lane e ekta lane er
            # temp-mail khonjha puro bot freeze na kore
            import asyncio as _aio
            mail = await _aio.get_event_loop().run_in_executor(
                None, lambda: (_new_addr or mm.new_address)(log=log, tag=tag))
        except Exception as e:
            return "", f"(temp mail fail: {str(e)[:60]})"

    ok, reason = await send_invite(page, bm_id, mail["email"], pace, log, tag,
                                   page_name=page_name)
    if not ok:
        log(f"{tag} ⚠ invite pathano fail — {reason}")
        # v7.5 FAST FAIL: button khuije na paoa/mar er karon ki ACCOUNT-level
        # (checkpoint/logout)? hole ei ID er BAKI invite gulo waste hobe na
        try:
            from browser_manager import detect_page_problem, AccountBlocked
            _kind = await detect_page_problem(page)
            if _kind:
                log(f"{tag} ⛔ ACCOUNT BLOCKED ({_kind}) — "
                    f"ei ID-er baki invite skip")
                raise AccountBlocked(_kind, "invite send fail")
        except AccountBlocked:
            raise
        except Exception:
            pass
        return "", mail["email"]

    if mail.get("provider") == "user-domain":
        return "(user-domain — mailbox theke link poro)", mail["email"]

    log(f"{tag} 📨 invite pathano hoye — inbox poll cholche…")
    link = await (_poll or mm.poll_invite_link)(mail, wait_s=poll_s,
                                                log=log, tag=tag,
                                                stop_check=_stop_requested)
    if not link and not mail.get("_dead"):
        # v6.9 CLIENT RULE: mail DHORE rakhte hobe — FB invitation mail
        # beshirbhag somoy 1-10 min e deri ashe. Queue te dhukiye dilam:
        # late-link reaper 15 min porjonto background e check korbe,
        # link ele SATHE SATHE results.txt e save hobe.
        # (mail["_dead"] = mail.tm account delete — late check er kono
        #  manei nai, queue te dhukbe na)
        try:
            mm.register_late_mail(mail, tag=tag, ctx=late_ctx)
            log(f"{tag} 📬 mailbox dhore rakhlam — mail late ashle-o "
                f"link save hoye jabe (15 min background check cholbe)")
        except Exception:
            pass
    return link, mail["email"]
