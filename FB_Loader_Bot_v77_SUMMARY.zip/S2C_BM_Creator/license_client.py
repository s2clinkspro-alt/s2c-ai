"""
═══════════════════════════════════════════════════════════════════
S2C BM Creator License Client v1.0 — ported from S2C Flow v4.1 (AES + RSA + HMAC)
═══════════════════════════════════════════════════════════════════

v4.1 Changes:
- Background revalidation thread (every 30 min) — no blocking during use
- Startup uses local cache immediately if valid — no server wait on open
- In-memory cache TTL increased to 1 hour for smoother UX
- 24h offline grace: if no server contact for 24h, ask for license

Security features:
1. Device fingerprint (hardware-locked, SHA256)
2. RSA-2048 signature verification (offline tamper-proof)
3. AES-128 encryption for local cache
4. 24-hour offline grace period
5. Server-side expiry checking (anti-clock-tamper)
6. InfinityFree JS challenge bypass
7. Time tampering detection
═══════════════════════════════════════════════════════════════════
"""

import os
import sys
import json
import time
import hashlib
import platform
import subprocess
import uuid
import base64
import threading
from datetime import datetime, timezone, timedelta
from pathlib import Path

# v78 FIX: Import logger — was missing, caused NameError on cache write failure
from logger import license_log as log

try:
    import requests
except ImportError:
    requests = None

try:
    import rsa as rsa_lib
    _HAS_RSA = True
except ImportError:
    _HAS_RSA = False

try:
    import pyaes
    _HAS_AES = True
except ImportError:
    _HAS_AES = False

# ── Configuration ──────────────────────────────────────────────────
# ════════════════════════════════════════════════════════════════════
# !! এই লাইনে তোমার LICENSE PANEL-এর domain বসাও (build করার আগে) !!
# S2C BM Creator আলাদা domain-এ license নেবে — নিচের URL change করো।
# ════════════════════════════════════════════════════════════════════
LICENSE_SERVER_URL = "https://s2c-bmcreate.site.je"
# domain (host-only) — JS-challenge cookie এই host-এ বসে
_SERVER_HOST = LICENSE_SERVER_URL.split("://", 1)[-1].split("/")[0].split(":")[0]
OFFLINE_GRACE_HOURS = 24
LOCAL_CACHE_DIR = Path.home() / ".s2c_bm" / "license"
LOCAL_CACHE_FILE = LOCAL_CACHE_DIR / "cache.dat"
# v4.2 FIX: Cache salt is now dynamic — server issues a per-license random salt
# at activation time. This prevents cache forgery even if source is extracted.
# Falls back to a device-specific salt if server salt is not yet available.
CACHE_SALT = None  # Set from server response at activation

def _get_cache_salt():
    """Get the current cache salt — server-issued or device-specific fallback."""
    global CACHE_SALT
    if CACHE_SALT is not None:
        return CACHE_SALT
    # Fallback: derive from device fingerprint (unique per machine, not in source)
    fp = get_device_fingerprint()
    return hashlib.sha256(fp.encode("utf-8") + b"s2c-cache-salt-fallback-v42").digest()

# ── RSA Public Key ──
RSA_PUBLIC_KEY_PEM = """-----BEGIN RSA PUBLIC KEY-----
MIIBCgKCAQEAn75IMc8EiIR8Hr7lFIkcN4uBH6Kx2WCLbo17oxJhlzNYgaXgyVN1
gjn4c6QhawdahhEA4amYJ94dJtCch3vHjs2oN/pagqT0/mbBIghQrjWEx9wWdLk0
VEQ+7A2YrqyMbo8KTLXUPkv31nYosvhHTBBRkOumalDCruesOyKB1unnOSBul0OJ
nJTs2rdDQZ+GjC2GZL8SZuz+hADL0kVYCD/ntBC1QH1AqjLYfUCtf6EaHnZl6cr/
wX2CoT6pg7ElwfUNrzD5GJFIhbv3NEAQQQXzP7kTXEpVViGrW6emWYMT8V6KB7dY
E/TPx3VuB7uREfN/1+1I4HVhkTqPVwImwQIDAQAB
-----END RSA PUBLIC KEY-----"""

# ── In-memory validation cache ──
_validation_cache = None  # (timestamp, result_dict)
_VALIDATION_CACHE_TTL = 600  # 10 minutes — faster revocation response

# ── Thread safety ──
_validation_lock = threading.Lock()
_cache_file_lock = threading.Lock()

# ── Background revalidation ──
_bg_thread = None
_bg_thread_stop = threading.Event()
_BG_REVALIDATE_INTERVAL = 600  # 10 minutes — background server check

_session = None

def _get_session():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
            "Accept": "application/json, text/html;q=0.9",
            "Content-Type": "application/json",
        })
    return _session


# ── InfinityFree JS Challenge Bypass ──────────────────────────────
def _solve_slowaes_challenge(text: str):
    import re, binascii
    try:
        hex_vals = re.findall(r'toNumbers\("([0-9a-fA-F]+)"\)', text)
        cookie_match = re.search(r'document\.cookie\s*=\s*["\']([^=+"\']+)=', text)
        redirect_match = re.search(r'location\.href\s*=\s*["\']([^"\']+)["\']', text)
        if len(hex_vals) < 3 or not cookie_match:
            return None
        import pyaes
        key = binascii.unhexlify(hex_vals[0])
        iv = binascii.unhexlify(hex_vals[1])
        ciphertext = binascii.unhexlify(hex_vals[2])
        if len(key) not in (16, 24, 32) or len(iv) != 16 or len(ciphertext) % 16 != 0 or not ciphertext:
            return None
        mode = pyaes.AESModeOfOperationCBC(key, iv)
        plaintext = b''
        for i in range(0, len(ciphertext), 16):
            plaintext += mode.decrypt(ciphertext[i:i + 16])
        cookie_name = cookie_match.group(1)
        cookie_value = binascii.hexlify(plaintext).decode()
        redirect_url = redirect_match.group(1) if redirect_match else None
        return (cookie_name, cookie_value, redirect_url)
    except Exception:
        return None


def _bypass_js_challenge(session, url):
    import re
    try:
        resp = session.get(url, timeout=15, allow_redirects=True)
        text = resp.text
        if 'slowAES' in text or 'toNumbers' in text:
            solved = _solve_slowaes_challenge(text)
            if solved:
                cookie_name, cookie_value, redirect_url = solved
                session.cookies.set(cookie_name, cookie_value, domain=_SERVER_HOST)
                if redirect_url:
                    if not redirect_url.startswith('http'):
                        redirect_url = LICENSE_SERVER_URL + '/' + redirect_url.lstrip('/')
                    session.get(redirect_url, timeout=15)
                return True
        if 'document.cookie' in text and ('location.reload' in text or 'location.href' in text):
            cookie_pattern = r'document\.cookie\s*=\s*["\']([^=]+)=([^;"\']+)'
            matches = re.findall(cookie_pattern, text)
            if matches:
                for name, value in matches:
                    session.cookies.set(name, value, domain=_SERVER_HOST)
                return True
            meta_pattern = r'<meta[^>]*http-equiv=["\']refresh["\'][^>]*content=["\'][^"\']*url=([^"\']+)'
            meta_match = re.search(meta_pattern, text, re.IGNORECASE)
            if meta_match:
                redirect_url = meta_match.group(1)
                if not redirect_url.startswith('http'):
                    redirect_url = LICENSE_SERVER_URL + '/' + redirect_url.lstrip('/')
                session.get(redirect_url, timeout=15)
                return True
        if '<iframe' in text and 'challenge' in text.lower():
            iframe_pattern = r'<iframe[^>]*src=["\']([^"\']+)'
            iframe_match = re.search(iframe_pattern, text)
            if iframe_match:
                iframe_url = iframe_match.group(1)
                if not iframe_url.startswith('http'):
                    iframe_url = LICENSE_SERVER_URL + '/' + iframe_url.lstrip('/')
                session.get(iframe_url, timeout=15)
                return True
        return False
    except Exception:
        return False


# ── RSA Signature Verification ─────────────────────────────────────
def _verify_signature(data: dict, rsa_sig_b64: str) -> bool:
    if not _HAS_RSA:
        return False
    try:
        payload = json.dumps(data, sort_keys=False, separators=(',', ':')).encode('utf-8')
        signature = base64.b64decode(rsa_sig_b64)
        pub_key = rsa_lib.PublicKey.load_pkcs1(RSA_PUBLIC_KEY_PEM.encode('utf-8'))
        try:
            rsa_lib.verify(payload, signature, pub_key)
            return True
        except rsa_lib.VerificationError:
            return False
    except Exception:
        return False


# ── AES Encryption for Local Cache ─────────────────────────────────
def _derive_aes_key() -> bytes:
    fp = get_device_fingerprint()
    salt = _get_cache_salt()
    if isinstance(salt, str):
        salt = salt.encode('utf-8')
    derived = hashlib.sha256(fp.encode('utf-8') + salt).digest()
    return derived[:32]

def _aes_encrypt(data: bytes, key: bytes) -> bytes:
    if not _HAS_AES:
        raise RuntimeError("pyaes not installed")
    iv = os.urandom(16)
    aes = pyaes.AESModeOfOperationCTR(key, counter=pyaes.Counter(initial_value=int.from_bytes(iv, 'big')))
    encrypted = aes.encrypt(data)
    return iv + encrypted

def _aes_decrypt(data: bytes, key: bytes) -> bytes:
    if not _HAS_AES:
        raise RuntimeError("pyaes not installed")
    iv = data[:16]
    encrypted = data[16:]
    aes = pyaes.AESModeOfOperationCTR(key, counter=pyaes.Counter(initial_value=int.from_bytes(iv, 'big')))
    return aes.decrypt(encrypted)


# ── Device Fingerprint ─────────────────────────────────────────────
def get_device_fingerprint() -> str:
    parts = []
    parts.append(platform.node() or "unknown")
    parts.append(platform.processor() or "unknown")
    parts.append(str(platform.machine() or "unknown"))
    try:
        parts.append(str(uuid.getnode()))
    except Exception:
        parts.append("no-mac")
    if sys.platform == 'win32':
        try:
            parts.append(str(os.environ.get('COMPUTERNAME', '')))
            parts.append(str(os.environ.get('USERDOMAIN', '')))
            import ctypes
            parts.append(str(ctypes.windll.kernel32.GetSystemMetrics(0)))
            parts.append(str(ctypes.windll.kernel32.GetSystemMetrics(1)))
        except Exception:
            pass
    elif sys.platform == 'linux':
        try:
            with open('/etc/machine-id', 'r') as f:
                parts.append(f.read().strip())
        except Exception:
            pass
    raw = ':'.join(parts)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()

def get_device_info() -> dict:
    return {
        "platform": platform.system(),
        "machine": platform.machine(),
        "node": platform.node(),
        "hostname": platform.node(),
        "python": platform.python_version(),
    }


# ── Encrypted Local Cache (AES) ────────────────────────────────────
def save_local_cache(license_data: dict):
    LOCAL_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    license_data['_cached_at'] = datetime.now(timezone.utc).isoformat()
    license_data['_cache_version'] = '4.1.0'
    raw = json.dumps(license_data).encode('utf-8')
    key = _derive_aes_key()
    encrypted = _aes_encrypt(raw, key)
    encoded = base64.b64encode(encrypted)

    if sys.platform == 'win32':
        try:
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(str(LOCAL_CACHE_FILE), 0x80)
        except Exception:
            pass

    with _cache_file_lock:
        last_err = None
        for attempt in range(5):
            try:
                tmp_path = str(LOCAL_CACHE_FILE) + f'.tmp{os.getpid()}'
                with open(tmp_path, 'wb') as f:
                    f.write(encoded)
                os.replace(tmp_path, LOCAL_CACHE_FILE)
                last_err = None
                break
            except PermissionError as e:
                last_err = e
                time.sleep(0.15 * (attempt + 1))
            except Exception as e:
                last_err = e
                break
        if last_err is not None:
            log.debug(f"[License] Warning: could not write local cache: {last_err}")

    try:
        if sys.platform == 'win32':
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(str(LOCAL_CACHE_FILE), 0x02)
    except Exception:
        pass

def load_local_cache() -> dict:
    if not LOCAL_CACHE_FILE.exists():
        return None
    with _cache_file_lock:
        try:
            with open(LOCAL_CACHE_FILE, 'rb') as f:
                encoded = f.read()
            encrypted = base64.b64decode(encoded)
            key = _derive_aes_key()
            raw = _aes_decrypt(encrypted, key)
            return json.loads(raw)
        except Exception:
            return None

def clear_local_cache():
    global _validation_cache
    _validation_cache = None
    with _cache_file_lock:
        try:
            if LOCAL_CACHE_FILE.exists():
                LOCAL_CACHE_FILE.unlink()
        except Exception:
            pass


# ── API Call ───────────────────────────────────────────────────────
# v4.2 FIX: Client-side API authentication secret
# This is verified by the server to ensure requests come from the real app,
# not from a random script brute-forcing license keys.
# Derived from RSA public key hash (embedded in app, not easily changeable)
_CLIENT_API_SECRET = hashlib.sha256(
    RSA_PUBLIC_KEY_PEM.encode() + b"s2c-client-auth-v42"
).hexdigest()[:48]


def _api_call(endpoint: str, payload: dict) -> dict:
    if requests is None:
        raise RuntimeError("requests module not installed")
    session = _get_session()
    url = f"{LICENSE_SERVER_URL}/api/{endpoint}"
    
    # v4.2 FIX: Add HMAC signature header for API authentication
    import hmac as _hmac
    import time as _time_mod
    _ts = str(int(_time_mod.time()))
    _msg = f"{endpoint}:{_ts}:{payload.get('license_key','')}".encode()
    _sig = _hmac.new(_CLIENT_API_SECRET.encode(), _msg, hashlib.sha256).hexdigest()
    session.headers.update({
        "X-Client-Auth": _sig,
        "X-Client-TS": _ts,
    })
    # v1.0.2 DUAL-AUTH: kichhu hosting edge custom X- headers strip kore —
    # tai auth query param e-o pathai. Server dui jayga theke-i kabul kore.
    _sep = '&' if '?' in url else '?'
    _authed_url = f"{url}{_sep}client_auth={_sig}&client_ts={_ts}"
    
    try:
        for _attempt in range(5):
            resp = session.post(_authed_url, json=payload, timeout=25)
            content_type = resp.headers.get('Content-Type', '')

            # JS challenge (InfinityFree)
            if 'text/html' in content_type and ('slowAES' in resp.text or 'toNumbers' in resp.text):
                solved = _solve_slowaes_challenge(resp.text)
                if solved:
                    cookie_name, cookie_value, redirect_url = solved
                    session.cookies.set(cookie_name, cookie_value, domain=_SERVER_HOST)
                    if redirect_url:
                        if not redirect_url.startswith('http'):
                            redirect_url = LICENSE_SERVER_URL + '/' + redirect_url.lstrip('/')
                        session.get(redirect_url, timeout=15)
                    continue
                else:
                    bypassed = _bypass_js_challenge(session, LICENSE_SERVER_URL)
                    if bypassed:
                        continue
                    return {"error": "Could not bypass server security challenge", "code": "CHALLENGE_FAILED"}

            # Rate limited
            if resp.status_code == 429:
                return {"error": "Rate limited. Please wait.", "code": "RATE_LIMITED"}

            # Server error (500/502/503) - retry with backoff
            if resp.status_code >= 500:
                import time as _time
                _time.sleep(1 + _attempt)
                continue

            # Empty or non-JSON response (server hiccup)
            if not resp.text or not resp.text.strip():
                import time as _time
                _time.sleep(1 + _attempt)
                continue

            # Try to parse JSON
            try:
                return resp.json()
            except Exception:
                # Response is not JSON (might be HTML error page)
                if _attempt < 4:
                    import time as _time
                    _time.sleep(1 + _attempt)
                    continue
                return {"error": "Invalid server response. Try again later.", "code": "SERVER_ERROR"}

        return {"error": "Server challenge retry exhausted", "code": "CHALLENGE_RETRY_EXHAUSTED"}
    except requests.exceptions.ConnectionError:
        return {"error": "Cannot connect to license server", "code": "SERVER_UNREACHABLE"}
    except requests.exceptions.Timeout:
        return {"error": "License server timeout", "code": "TIMEOUT"}
    except Exception as e:
        return {"error": f"Network error: {e}", "code": "NETWORK_ERROR"}


# ── License Operations ─────────────────────────────────────────────
def _try_offline_activation(license_key: str, fingerprint: str) -> dict:
    """
    Offline activation fallback: when server is unreachable, check if
    the entered license key matches a previously-activated local cache.

    Rules:
    1. Cache must exist (previously activated on this device)
    2. License key must match the cached key
    3. Device fingerprint must match
    4. License must NOT be expired (check expiry date)
    5. RSA signature in cache must still verify (anti-tamper)

    If ALL pass: extend the 24h grace period (reset _last_validated)
    If ANY fail: return error (cannot activate offline)
    """
    cache = load_local_cache()
    if not cache:
        return {"success": False, "error": "No previous activation found on this device. Please connect to internet to activate.", "code": "NO_CACHE"}

    # Key must match exactly
    cached_key = cache.get("license_key", "")
    if cached_key.upper() != license_key.upper():
        return {"success": False, "error": "License key does not match previous activation on this device.", "code": "KEY_MISMATCH"}

    # Device must match
    cached_fp = cache.get("device_fingerprint", "")
    if cached_fp != fingerprint:
        return {"success": False, "error": "Device mismatch. This license was activated on a different device.", "code": "DEVICE_MISMATCH"}

    # License must not be expired
    expires_at_str = cache.get("expires_at")
    if not expires_at_str:
        return {"success": False, "error": "No expiry data in cache.", "code": "NO_EXPIRY"}
    try:
        expires_at = datetime.fromisoformat(expires_at_str.replace('Z', '+00:00'))
        now = datetime.now(timezone.utc)
        if now > expires_at:
            return {"success": False, "error": "License has expired. Please renew your subscription.", "code": "EXPIRED"}
    except Exception:
        return {"success": False, "error": "Corrupted expiry data.", "code": "CACHE_CORRUPT"}

    # Verify cached RSA signature (anti-tamper)
    cached_rsa_sig = cache.get("rsa_sig", "")
    cached_data = cache.get("_signed_data")
    if cached_data is None:
        cached_data = {k: v for k, v in cache.items() if k not in ("_cached_at", "_cache_version", "rsa_sig", "_last_validated", "_signed_data")}
    if cached_rsa_sig and _HAS_RSA:
        if not _verify_signature(cached_data, cached_rsa_sig):
            clear_local_cache()
            return {"success": False, "error": "Cache tampering detected. Please connect to internet.", "code": "TAMPERED"}

    # v4.2 FIX: Do NOT reset _last_validated on offline validation.
    # Only server validation should reset the timer. This prevents
    # the infinite offline grace loop (block server → 24h → reset → 24h → forever).
    save_local_cache(cache)

    return {
        "success": True,
        "data": {
            "status": "active (offline)",
            "expires_at": expires_at_str,
            "customer_name": cache.get("customer_name", ""),
            "plan": cache.get("plan", ""),
            "offline": True,
            "message": "License verified offline. 24h grace extended."
        }
    }


def activate_license(license_key: str) -> dict:
    """
    Activate license. Tries server first, falls back to offline activation
    if server is unreachable (uses cached license data + key verification).
    """
    fingerprint = get_device_fingerprint()
    device_info = get_device_info()

    # Step 1: Try server activation
    # NOTE: device_info must be a STRING (JSON-encoded), not a dict
    # PHP's trim() on array = fatal error in PHP 8
    device_info_str = json.dumps(device_info) if isinstance(device_info, dict) else str(device_info)
    result = _api_call("activate.php", {
        "license_key": license_key,
        "device_fingerprint": fingerprint,
        "device_info": device_info_str
    })

    if "error" not in result:
        # Server activation succeeded
        data = result.get("data", {})
        rsa_sig = result.get("rsa_sig", "")
        if rsa_sig:
            if not _verify_signature(data, rsa_sig):
                return {"success": False, "error": "Server signature verification failed.", "code": "SIG_FAILED"}
        # v4.2 FIX: Store server-issued cache salt (per-license, random)
        server_salt = data.get("cache_salt", "")
        if server_salt:
            global CACHE_SALT
            CACHE_SALT = server_salt
        cache_data = {
            "license_key": license_key,
            "device_fingerprint": fingerprint,
            "expires_at": data.get("expires_at"),
            "activated_at": data.get("activated_at"),
            "customer_name": data.get("customer_name"),
            "plan": data.get("plan"),
            "grace_hours": data.get("grace_hours", OFFLINE_GRACE_HOURS),
            "server_time": data.get("server_time"),
            "rsa_sig": rsa_sig,
            "_signed_data": data,
            "cache_salt": server_salt,  # per-license salt from server
        }
        save_local_cache(cache_data)
        global _validation_cache
        _validation_cache = None
        return {"success": True, "data": data}

    # Step 2: Server failed -- check WHY
    error_code = result.get("code", "")

    # Connectivity issues -> ONLY try offline if cache exists (returning user)
    # First-time users (no cache) should see a clear "server unreachable" error
    if error_code in ("SERVER_UNREACHABLE", "TIMEOUT", "CHALLENGE_FAILED", "CHALLENGE_RETRY_EXHAUSTED"):
        existing_cache = load_local_cache()
        if existing_cache:
            # Returning user - try offline activation
            offline_result = _try_offline_activation(license_key, fingerprint)
            if offline_result.get("success"):
                _validation_cache = None
                return offline_result
            # Offline failed - return helpful error
            return {"success": False, "error": offline_result.get("error", "Offline activation failed."), "code": offline_result.get("code", error_code)}
        else:
            # FIRST TIME - no cache, server unreachable
            return {"success": False, "error": "Could not connect to license server. Please check your internet connection and try again.", "code": "SERVER_UNREACHABLE"}

    # Transient server errors (NETWORK_ERROR, SERVER_ERROR, RATE_LIMITED) -> NOT offline
    if error_code in ("NETWORK_ERROR", "SERVER_ERROR", "RATE_LIMITED"):
        return {"success": False, "error": result["error"], "code": error_code}

    # Server returned a definitive error (INVALID_KEY, EXPIRED, REVOKED, DEVICE_LOCKED)
    return {"success": False, "error": result["error"], "code": error_code}


def _check_offline_grace(cache: dict) -> dict:
    """Check offline grace period — 24 HOURS."""
    cached_at_str = cache.get("_last_validated") or cache.get("_cached_at")
    if not cached_at_str:
        cached_at_str = cache.get("_cached_at")
    if not cached_at_str:
        return {"valid": False, "error": "No cached validation data", "code": "NO_CACHE", "offline": True}

    try:
        cached_at = datetime.fromisoformat(cached_at_str.replace('Z', '+00:00'))
    except Exception:
        return {"valid": False, "error": "Corrupted cache data", "code": "CACHE_CORRUPT", "offline": True}

    now = datetime.now(timezone.utc)
    age_hours = (now - cached_at).total_seconds() / 3600
    grace_hours = cache.get("grace_hours", OFFLINE_GRACE_HOURS)

    if age_hours > grace_hours:
        return {
            "valid": False,
            "error": f"Offline grace period ({grace_hours}h) exceeded. Please connect to internet.",
            "code": "GRACE_EXPIRED",
            "offline": True
        }

    cached_rsa_sig = cache.get("rsa_sig", "")
    cached_data = cache.get("_signed_data")
    if cached_data is None:
        cached_data = {k: v for k, v in cache.items() if k not in ("_cached_at", "_cache_version", "rsa_sig", "_last_validated", "_signed_data")}
    if cached_rsa_sig and _HAS_RSA:
        if not _verify_signature(cached_data, cached_rsa_sig):
            clear_local_cache()
            return {"valid": False, "error": "Cache tampering detected.", "code": "TAMPERED", "offline": True}

    expires_at_str = cache.get("expires_at")
    if not expires_at_str:
        return {"valid": False, "error": "No expiry data in cache", "code": "NO_EXPIRY", "offline": True}

    try:
        expires_at = datetime.fromisoformat(expires_at_str.replace('Z', '+00:00'))
        if now > expires_at:
            clear_local_cache()
            return {"valid": False, "error": "License expired (offline)", "code": "EXPIRED", "offline": True}
    except Exception:
        return {"valid": False, "error": "Corrupted expiry data", "code": "CACHE_CORRUPT", "offline": True}

    result = {
        "valid": True,
        "data": {
            "status": "active (offline)",
            "expires_at": expires_at_str,
            "remaining_days": max(0, (expires_at - now).days),
            "offline": True,
            "hours_offline": round(age_hours, 1),
            "grace_remaining_hours": round(max(0, grace_hours - age_hours), 1),
        },
        "offline": True
    }
    return result


def _validate_with_server(cache: dict) -> dict:
    """Try to validate with server. Returns result dict."""
    license_key = cache.get("license_key")
    fingerprint = get_device_fingerprint()

    if cache.get("device_fingerprint") != fingerprint:
        clear_local_cache()
        return {"valid": False, "error": "Device mismatch.", "code": "DEVICE_MISMATCH"}

    result = _api_call("validate.php", {
        "license_key": license_key,
        "device_fingerprint": fingerprint
    })

    if "error" in result:
        code = result.get("code", "")
        if code in ("SERVER_UNREACHABLE", "TIMEOUT", "NETWORK_ERROR", "CHALLENGE_FAILED", "CHALLENGE_RETRY_EXHAUSTED"):
            return _check_offline_grace(cache)
        return {"valid": False, "error": result["error"], "code": code}

    data = result.get("data", {})
    rsa_sig = result.get("rsa_sig", "")
    status = data.get("status")

    if status == "active":
        if rsa_sig:
            if not _verify_signature(data, rsa_sig):
                clear_local_cache()
                return {"valid": False, "error": "Signature verification failed.", "code": "SIG_FAILED"}

        cache["expires_at"] = data.get("expires_at", cache.get("expires_at"))
        cache["server_time"] = data.get("server_time")
        cache["rsa_sig"] = rsa_sig
        cache["_signed_data"] = data
        cache["_last_validated"] = datetime.now(timezone.utc).isoformat()
        # v4.2 FIX: Update server-issued cache salt if server sends a new one
        server_salt = data.get("cache_salt", "")
        if server_salt:
            cache["cache_salt"] = server_salt
            global CACHE_SALT
            CACHE_SALT = server_salt
        save_local_cache(cache)

        return {"valid": True, "data": data, "offline": False}

    return {"valid": False, "error": data.get("message", "Validation failed"), "code": "INVALID"}


def check_license() -> dict:
    """
    Main license check. Uses in-memory cache (1 hour TTL).
    On first call after restart: loads local cache, tries server.
    If server unreachable: uses 24h offline grace.
    While running: background thread keeps cache fresh.
    """
    global _validation_cache

    # Fast path: in-memory cache still valid
    if _validation_cache is not None:
        cached_ts, cached_result = _validation_cache
        if (datetime.now(timezone.utc) - cached_ts).total_seconds() < _VALIDATION_CACHE_TTL:
            return cached_result

    with _validation_lock:
        # Double-checked locking
        if _validation_cache is not None:
            cached_ts, cached_result = _validation_cache
            if (datetime.now(timezone.utc) - cached_ts).total_seconds() < _VALIDATION_CACHE_TTL:
                return cached_result
        return _check_license_uncached()


def _check_license_uncached() -> dict:
    """Full license check — loads cache, validates with server or offline grace."""
    global _validation_cache
    cache = load_local_cache()
    if not cache:
        return {"valid": False, "error": "No license found. Please activate first.", "code": "NO_LICENSE"}

    fingerprint = get_device_fingerprint()
    if cache.get("device_fingerprint") != fingerprint:
        clear_local_cache()
        return {"valid": False, "error": "Device mismatch.", "code": "DEVICE_MISMATCH"}

    # ── SMART STARTUP: check cache age first ──
    # If cache was validated recently (within grace period), try server
    # but don't block the user if server is slow/unreachable.
    last_validated_str = cache.get("_last_validated") or cache.get("_cached_at")
    
    result = _validate_with_server(cache)

    # If server validation worked, cache and return
    if result.get("valid"):
        _validation_cache = (datetime.now(timezone.utc), result)
        return result

    # If server failed but not due to connectivity (e.g. expired, revoked),
    # return the failure
    code = result.get("code", "")
    if code not in ("SERVER_UNREACHABLE", "TIMEOUT", "NETWORK_ERROR", "CHALLENGE_FAILED", "CHALLENGE_RETRY_EXHAUSTED"):
        return result

    # Server unreachable — check offline grace
    grace_result = _check_offline_grace(cache)
    if grace_result.get("valid"):
        _validation_cache = (datetime.now(timezone.utc), grace_result)
    return grace_result


# ── Background Revalidation Thread ─────────────────────────────────
def start_background_revalidation():
    """
    Start a background thread that revalidates the license with the server
    every 30 minutes. This keeps the local cache fresh and the in-memory
    cache updated, so the user never experiences blocking during use.

    While the bot is running:
    - Background thread hits server every 30 min
    - If server OK: updates cache, resets 24h grace timer
    - If server down: does nothing (offline grace continues)
    - User is NEVER blocked by license checks during use
    """
    global _bg_thread
    if _bg_thread is not None:
        return  # Already running

    def _bg_worker():
        global _validation_cache
        while not _bg_thread_stop.wait(_BG_REVALIDATE_INTERVAL):
            try:
                cache = load_local_cache()
                if not cache:
                    continue

                fingerprint = get_device_fingerprint()
                if cache.get("device_fingerprint") != fingerprint:
                    # Device changed — kill immediately
                    clear_local_cache()
                    _validation_cache = (datetime.now(timezone.utc),
                        {"valid": False, "error": "Device mismatch", "code": "DEVICE_MISMATCH"})
                    continue

                result = _validate_with_server(cache)
                if result.get("valid"):
                    # Server OK — update in-memory cache
                    _validation_cache = (datetime.now(timezone.utc), result)
                else:
                    code = result.get("code", "")
                    if code in ("REVOKED", "EXPIRED", "DEVICE_MISMATCH", "DEVICE_LOCKED", "SIG_FAILED"):
                        # DEFINITIVE revocation/expiry — kill immediately
                        clear_local_cache()
                        _validation_cache = (datetime.now(timezone.utc), result)
                    # If SERVER_UNREACHABLE etc — do nothing, offline grace continues
            except Exception:
                pass  # Background errors are non-fatal

    _bg_thread = threading.Thread(target=_bg_worker, daemon=True, name="license-revalidator")
    _bg_thread.start()


def stop_background_revalidation():
    """Stop the background revalidation thread."""
    global _bg_thread
    _bg_thread_stop.set()
    if _bg_thread:
        _bg_thread.join(timeout=2)
    _bg_thread = None
    _bg_thread_stop.clear()


# ── Time Tampering Detection ──
def detect_time_tampering() -> bool:
    """v4.2 FIX: Detect BOTH backward AND forward clock manipulation."""
    cache = load_local_cache()
    if not cache:
        return False
    last_validated = cache.get("_last_validated") or cache.get("_cached_at")
    if not last_validated:
        return False
    try:
        last_dt = datetime.fromisoformat(last_validated.replace('Z', '+00:00'))
        now = datetime.now(timezone.utc)
        
        # Backward: current time is before last validation (clock rolled back)
        if now < last_dt - timedelta(hours=1):
            return True
        
        # v4.2 Forward: clock jumped more than 7 days ahead since last validation
        # (normal usage would never have 7+ days between validations with bg thread
        # checking every 30 min — only clock tampering causes this)
        if (now - last_dt) > timedelta(days=7):
            return True
        
        # v4.2: Check if cache expiry is suspiciously far in the future
        # compared to what the plan allows (max 90 days)
        expires_str = cache.get("expires_at")
        if expires_str:
            try:
                expires_dt = datetime.fromisoformat(expires_str.replace('Z', '+00:00'))
                activated_str = cache.get("activated_at") or cache.get("_cached_at")
                if activated_str:
                    activated_dt = datetime.fromisoformat(activated_str.replace('Z', '+00:00'))
                    duration = expires_dt - activated_dt
                    if duration > timedelta(days=95):  # max plan is 90 days + 5 day buffer
                        return True
            except Exception:
                pass
        
        return False
    except Exception:
        return False


def check_license_full() -> dict:
    if detect_time_tampering():
        return {"valid": False, "error": "System time manipulation detected.", "code": "TIME_TAMPER"}
    result = check_license()
    if not result.get("valid"):
        code = result.get("code", "")
        if code in ("EXPIRED", "REVOKED", "DEVICE_MISMATCH", "GRACE_EXPIRED", "TIME_TAMPER", "SIG_FAILED"):
            clear_local_cache()
    return result

validate_license = check_license


def get_license_info() -> dict:
    cache = load_local_cache()
    if not cache:
        return {"activated": False}
    return {
        "activated": True,
        "license_key": cache.get("license_key", ""),
        "customer_name": cache.get("customer_name", ""),
        "plan": cache.get("plan", ""),
        "expires_at": cache.get("expires_at", ""),
        "device_fingerprint": cache.get("device_fingerprint", "")[:16] + "...",
    }

def is_licensed() -> bool:
    return check_license().get("valid", False)


if __name__ == "__main__":
    log.debug("=== Skill2CashBD License Client v4.1 ===")
    log.debug(f"Server: {LICENSE_SERVER_URL}")
    log.debug(f"Grace: {OFFLINE_GRACE_HOURS} hours")
    log.debug(f"RSA: {'enabled' if _HAS_RSA else 'DISABLED'}")
    log.debug(f"AES: {'enabled' if _HAS_AES else 'DISABLED'}")
    log.debug(f"Fingerprint: {get_device_fingerprint()[:32]}...")
    try:
        session = _get_session()
        resp = session.get(f"{LICENSE_SERVER_URL}/api/status.php", timeout=15)
        log.debug(f"Server: {resp.status_code} -- {resp.text[:200]}")
    except Exception as e:
        log.debug(f"Server error: {e}")
