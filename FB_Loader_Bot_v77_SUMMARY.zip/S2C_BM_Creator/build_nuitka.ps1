# ═══════════════════════════════════════════════════════════════════════
#  S2C BM Creator — SECURE BUILD (Nuitka, C-level compiled exe)
#  ─────────────────────────────────────────────────────────────────────
#  Run:  Right-click build_nuitka.ps1  →  "Run with PowerShell"
#
#  Why Nuitka (not PyInstaller):
#    • Transpiles Python → C → native machine code: NO extractable
#      bytecode, NO easy decompile (PyInstaller exes unpack with
#      pyinstxtractor + decompile in minutes)
#    • ~all anti-bypass logic compiled into the binary itself
#    • Single .exe output (onefile, zstd-compressed)
#
#  What this script does:
#    1. Blocks the build if LICENSE_SERVER_URL is still the placeholder
#    2. venv + installs all deps + Nuitka + zstandard + Pillow
#    3. logo.png → logo.ico (exe icon) + logo bundled inside exe
#    4. Compiles launcher.py → S2C_BM_Creator.exe (standalone, windowed)
#    5. Playwright driver + templates + license gate bundled inside
# ═══════════════════════════════════════════════════════════════════════

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
Write-Host "══ S2C BM Creator — Nuitka secure build ══" -ForegroundColor Cyan

# ── 1. Domain gate: refuse to build with placeholder license server ──────
$lc = Get-Content (Join-Path $Root "license_client.py") -Raw
if ($lc -match "YOUR-LICENSE-DOMAIN-HERE") {
    Write-Host ""
    Write-Host "⛔ BUILD BLOCKED: LICENSE_SERVER_URL is still the placeholder." -ForegroundColor Red
    Write-Host "   Open license_client.py and set LICENSE_SERVER_URL to your"
    Write-Host "   license panel domain first (https://your-domain.com)."
    exit 1
}
Write-Host "[1/5] License server domain: OK" -ForegroundColor Green

# ── 2. Virtual env + dependencies ───────────────────────────────────────
if (-not (Test-Path ".venv")) {
    Write-Host "[2/5] Creating virtual environment…" -ForegroundColor Yellow
    python -m venv .venv
}
$py = Join-Path $Root ".venv\Scripts\python.exe"
& $py -m pip install --upgrade pip -q
& $py -m pip install -r requirements.txt -q
& $py -m pip install nuitka zstandard pillow -q
Write-Host "[2/5] Dependencies installed" -ForegroundColor Green

# ── 3. logo.png → logo.ico (exe icon) ────────────────────────────────────
if (-not (Test-Path "logo.png")) {
    Write-Host ""
    Write-Host "⚠ logo.png not found in this folder." -ForegroundColor Yellow
    Write-Host "  Drop your logo.png next to this script and run again —" 
    Write-Host "  the exe will carry it as its icon + boot window icon."
    exit 1
}
& $py -c "from PIL import Image; img = Image.open('logo.png').convert('RGBA'); img.save('logo.ico', sizes=[(256,256),(128,128),(64,64),(48,48),(32,32),(16,16)])"
Write-Host "[3/5] logo.ico generated" -ForegroundColor Green

# ── 4. Nuitka compile ─────────────────────────────────────────────────────
Write-Host "[4/5] Compiling with Nuitka (this takes 5-15 min)…" -ForegroundColor Yellow
& $py -m nuitka `
    --standalone --onefile `
    --windows-console-mode=disable `
    --enable-plugin=tkinter `
    --windows-icon-from-ico=logo.ico `
    --company-name="S2C" `
    --product-name="S2C BM Creator" `
    --file-version=1.0.0.0 `
    --product-version=1.0.0.0 `
    --file-description="S2C BM Creator — Premium Workstation" `
    --copyright="S2C" `
    --include-data-file="license_gate.html=license_gate.html" `
    --include-data-dir="templates=templates" `
    --include-data-file="logo.png=logo.png" `
    --include-package-data=playwright `
    --nofollow-import-to="*.tests" `
    --noinclude-pyi-files `
    --python-flag=no_site `
    --assume-yes-for-downloads `
    --output-dir=build `
    --output-filename=S2C_BM_Creator.exe `
    launcher.py

if ($LASTEXITCODE -ne 0) {
    Write-Host "⛔ Nuitka build failed — see messages above." -ForegroundColor Red
    exit 1
}
Write-Host "[4/5] Compiled successfully" -ForegroundColor Green

# ── 5. Package ────────────────────────────────────────────────────────────
$dist = Join-Path $Root "dist"
New-Item -ItemType Directory -Force -Path $dist | Out-Null
Move-Item (Join-Path $Root "build\S2C_BM_Creator.exe") -Destination $dist -Force
Copy-Item "logo.png" $dist -Force
Write-Host ""
Write-Host "[5/5] ✔ BUILD COMPLETE" -ForegroundColor Green
Write-Host "   dist\S2C_BM_Creator.exe  — ready to distribute." -ForegroundColor Cyan
Write-Host "   (Requirements: Windows 10/11 64-bit. First run auto-installs" 
Write-Host "    Chrome if missing + asks for the license key in the browser.)"
