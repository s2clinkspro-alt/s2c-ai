"""
logger.py — Structured logging for S2C BM Creator v1.0
Rotating file logs + console output with log levels.
Logs stored in ~/.skill2cash/logs/ (persistent across updates)
"""
import logging
import logging.handlers
import os
import sys
import datetime

# ── Log directory (persistent) ────────────────────────────────────────────────
_LOG_DIR = os.path.join(os.path.expanduser("~"), ".skill2cash", "logs")
os.makedirs(_LOG_DIR, exist_ok=True)

# ── Log file paths ────────────────────────────────────────────────────────────
_APP_LOG = os.path.join(_LOG_DIR, "bm_app.log")
_ERROR_LOG = os.path.join(_LOG_DIR, "bm_error.log")

# ── Log format ────────────────────────────────────────────────────────────────
_FMT = logging.Formatter(
    "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

# ── Rotating handlers (5MB per file, 5 backups) ───────────────────────────────
_file_handler = logging.handlers.RotatingFileHandler(
    _APP_LOG, maxBytes=5_000_000, backupCount=5, encoding="utf-8"
)
_file_handler.setLevel(logging.DEBUG)
_file_handler.setFormatter(_FMT)

_error_handler = logging.handlers.RotatingFileHandler(
    _ERROR_LOG, maxBytes=2_000_000, backupCount=3, encoding="utf-8"
)
_error_handler.setLevel(logging.ERROR)
_error_handler.setFormatter(_FMT)

# Console handler (stdout)
_console_handler = logging.StreamHandler(sys.stdout)
_console_handler.setLevel(logging.INFO)
_console_handler.setFormatter(_FMT)

# ── Root logger setup ─────────────────────────────────────────────────────────
_root = logging.getLogger("s2c")
_root.setLevel(logging.DEBUG)
_root.addHandler(_file_handler)
_root.addHandler(_error_handler)
_root.addHandler(_console_handler)
_root.propagate = False

# ── Convenience loggers ───────────────────────────────────────────────────────
def get_logger(name: str = "s2c") -> logging.Logger:
    """Get a child logger under the s2c namespace."""
    return _root.getChild(name)

# ── Export ───────────────────────────────────────────────────────────────────
log = get_logger("app")
db_log = get_logger("db")
browser_log = get_logger("browser")
license_log = get_logger("license")
engine_log = get_logger("engine")
