"""activity_reporter.py — S2C BM Creator heartbeat (ported from S2C Flow v1.0)

Periodic heartbeats to the license server for admin monitoring:
  - profile counts (total/validated)
  - running state + current activity
Uses the same HMAC-signed session as license_client (challenge-aware).
"""
import os, sys, json, time, threading
from datetime import datetime

try:
    import requests
except ImportError:
    requests = None

from license_client import (
    LICENSE_SERVER_URL, _get_session, _bypass_js_challenge,
    get_device_fingerprint, load_local_cache, _CLIENT_API_SECRET,
)

_interval_running = 30
_interval_idle = 60
_timeout = 10

_state_lock = threading.Lock()
_running = False
_last_payload = {}

def set_activity(running: bool, activity: str = "", counts: dict = None):
    """Called by engine.py — updates what the next heartbeat will report."""
    global _last_payload
    with _state_lock:
        _last_payload = {"running": bool(running), "activity": str(activity)[:120],
                         "counts": counts or {}}

def _collect():
    try:
        import accounts_db
        accs = accounts_db.all_accounts()
        return {"profiles": len(accs),
                "validated": sum(1 for a in accs if a.get("status") == "validated")}
    except Exception:
        return {}

def _send_once():
    if requests is None:
        return False
    try:
        cache = load_local_cache()
        if not cache:
            return False
        session = _get_session()
        import hmac, hashlib
        ts = str(int(time.time()))
        msg = f"heartbeat:{ts}".encode()
        sig = hmac.new(_CLIENT_API_SECRET.encode(), msg, hashlib.sha256).hexdigest()
        # v1.0.2 DUAL-AUTH: header + query param (hosting edge strip-purno header er jonno)
        session.headers.update({"X-Client-Auth": sig, "X-Client-TS": ts})
        with _state_lock:
            act = dict(_last_payload)
        # v1.0.1 FIX: field names aligned with S2C Flow panel API
        # (heartbeat.php reads device_fingerprint + is_running)
        payload = {
            "device_fingerprint": get_device_fingerprint(),
            "license_key": cache.get("license_key", ""),
            "product": "s2c_bm_creator",
            "time": datetime.utcnow().isoformat() + "Z",
            **act,
            **_collect(),
        }
        # engine side sets "running"/"activity" — map to server's is_running
        if "running" in payload:
            payload["is_running"] = 1 if payload.pop("running") else 0
        url = f"{LICENSE_SERVER_URL}/api/heartbeat?client_auth={sig}&client_ts={ts}"
        resp = session.post(url, json=payload, timeout=_timeout)
        if 'text/html' in resp.headers.get('Content-Type', ''):
            if _bypass_js_challenge(session, LICENSE_SERVER_URL):
                resp = session.post(url, json=payload, timeout=_timeout)
        return resp.status_code == 200
    except Exception:
        return False

_worker_stop = threading.Event()

def _worker():
    while not _worker_stop.is_set():
        _send_once()
        with _state_lock:
            delay = _interval_running if _last_payload.get("running") else _interval_idle
        _worker_stop.wait(delay)

def start_heartbeat():
    global _running
    if _running:
        return
    _running = True
    threading.Thread(target=_worker, daemon=True, name="bm-heartbeat").start()

def stop_heartbeat():
    global _running
    _worker_stop.set()
    _running = False

def send_final_heartbeat():
    _send_once()
