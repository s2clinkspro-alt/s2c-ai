"""launcher.py — S2C BM Creator exe entry point.

Flow (same security path as S2C Flow):
  1. Anti-tamper + environment checks (compiled build only)
  2. License check (local cache instant; server revalidate in background)
  3. Start Flask+SocketIO dashboard server
  4. Open browser (straight to /license if activation needed)
"""
import os
import sys
import threading
import webbrowser

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
# Nuitka onefile: __file__ points at the onefile temp extraction dir —
# writable app root (accounts DB, output, cache) must sit NEXT TO the exe.
if getattr(sys, "frozen", False) or ("__compiled__" in dir()):
    _EXE_DIR = os.path.dirname(os.path.abspath(sys.executable))
    os.chdir(_EXE_DIR)
    APP_ROOT = _EXE_DIR
else:
    os.chdir(APP_ROOT)

PORT = 8500
COMPILED = getattr(sys, "frozen", False) or ("__compiled__" in dir())


def _anti_tamper_checks() -> bool:
    """Compiled-build integrity checks. Source mode returns True (dev)."""
    if not COMPILED:
        return True
    try:
        import ctypes
        # Windows: debugger attached to this process?
        if os.name == "nt":
            if ctypes.windll.kernel32.IsDebuggerPresent():
                return False
            # remote debugger port check (soft)
            if ctypes.windll.kernel32.CheckRemoteDebuggerPresent(
                    ctypes.windll.kernel32.GetCurrentProcess(), ctypes.byref(ctypes.c_bool())):
                if ctypes.c_bool.from_address(
                        ctypes.byref(ctypes.c_bool())).value:
                    return False
        # running under common tracing tools?
        bad_env = [v for v in ("PYDEVD_LOAD_VALUES", "PYCHARM_HOSTED")
                   if v in os.environ]
        if bad_env:
            return False
    except Exception:
        pass
    return True


# ── Premium status window (first-run setup + boot progress) ──────────
def _boot_window():
    """Neumorphic-styled boot status window. Returns (root, set_status_fn,
    close_fn). Falls back to silent mode when Tk unavailable."""
    try:
        import tkinter as tk
        root = tk.Tk()
    except Exception:
        # No GUI available / Tk broken — degrade silently to console mode
        return None, None, None
    root.title("S2C BM Creator")
    root.configure(bg="#eaf0f7")
    root.geometry("380x210")
    root.resizable(False, False)
    # exe/window icon from logo.png (packaged alongside exe)
    try:
        from PIL import ImageTk
        _lp = os.path.join(APP_ROOT, "logo.png")
        if os.path.isfile(_lp):
            root.iconphoto(True, ImageTk.PhotoImage(file=_lp))
    except Exception:
        pass

    tk.Label(root, text="S2C BM Creator", bg="#eaf0f7", fg="#1d4ed8",
             font=("Plus Jakarta Sans", 17, "bold")).pack(pady=(26, 2))
    tk.Label(root, text="PREMIUM WORKSTATION", bg="#eaf0f7", fg="#6b7390",
             font=("Inter", 8)).pack(pady=(0, 14))
    bar = tk.Canvas(root, width=300, height=6, bg="#eaf0f7", highlightthickness=0)
    bar.pack()
    bar_id = [None]

    def _progress(pct):
        bar.delete("all")
        bar.create_rectangle(0, 0, 300 * min(pct, 1.0), 6, fill="#1d4ed8", width=0)
        bar.update_idletasks()

    status_lbl = tk.Label(root, text="Initializing…", bg="#eaf0f7", fg="#1e2333",
                          font=("Inter", 9))
    status_lbl.pack(pady=(14, 0))

    def _set_status(msg, pct=None):
        try:
            status_lbl.config(text=msg)
            if pct is not None:
                _progress(pct)
            root.update_idletasks()
            root.update()
        except Exception:
            pass

    return root, _set_status, root.destroy


def _kill_old_instances():
    """v1.0.1 ZOMBIE-INSTANCE FIX (compiled exe): purano S2C_BM_Creator
    process jodi port 8500 dhore beche thake, notun exe er dashboard STOP
    button purano instance ke chere jeto — bot thamto na, restart er
    somoy terminal o lage. Exe-mode e shudhu AMADER exe-name match kore
    purono instance kill (user-er onno kichu dhora jabe na)."""
    if not getattr(sys, "frozen", False):
        return  # source dev: app.py er nijer _kill_old_instances ache
    try:
        import psutil
        me = os.getpid()
        my_exe = os.path.basename(sys.executable).lower()
        killed = 0
        for p in psutil.process_iter(["pid", "name", "exe"]):
            try:
                if p.info["pid"] == me:
                    continue
                nm = (p.info["name"] or "").lower()
                if nm == my_exe:
                    p.kill()
                    killed += 1
            except Exception:
                continue
        if killed:
            import time as _t
            _t.sleep(1.5)  # port release howar somoy dao
            print(f"killed {killed} old instance(s)")
    except ImportError:
        pass
    except Exception:
        pass


def main():
    if not _anti_tamper_checks():
        print("Runtime integrity check failed.")
        sys.exit(1)

    _kill_old_instances()

    # ── boot window ──
    _root, _set_status, _close_win = _boot_window()
    if _set_status:
        _set_status("Verifying environment…", 0.15)

    # ── FIRST-RUN SETUP: folders + real Chrome auto-install ──
    setup_ok, setup_steps = True, []
    try:
        from first_run_setup import run_setup
        setup_ok, setup_steps = run_setup(_set_status)
        for s in setup_steps:
            print(f"[Setup] {s}")
    except Exception as e:
        print(f"[Setup] error: {e}")

    # license gate — same module S2C Flow uses
    if _set_status:
        _set_status("Checking license…", 0.55)
    lic_ok = True
    try:
        from license_integration import check_or_gate
        lic_ok = check_or_gate()
    except Exception as e:
        print(f"[License] gate error: {e}")
        lic_ok = False

    # start dashboard server (license guard active inside app)
    from app import app  # noqa: E402  (import after cwd set)

    url = f"http://127.0.0.1:{PORT}/"
    target = f"{url}license" if not lic_ok else url

    def _serve():
        try:
            from werkzeug.serving import run_simple
            # v1.7.1 CRITICAL FIX: threaded=True chara werkzeug SINGLE-threaded —
            # SocketIO er long-poll ekta thread dhore rekhe diye dashboard er
            # shob request (upload/refresh/accounts) queue-te atke jeto:
            # upload 5-6 bar try korle hoto, refresh sudhu "loading" e jhulto,
            # logs update hoto na. app.py er __main__ e eta thik chhilo,
            # launcher.py te missing chhilo.
            run_simple("127.0.0.1", PORT, app, use_reloader=False, threaded=True)
        except Exception as e:
            print(f"[Server] {e}")

    threading.Thread(target=_serve, daemon=True).start()

    # brief settle then open browser
    import time
    time.sleep(1.0)
    webbrowser.open(target)

    if _set_status:
        _set_status("Ready — dashboard opening…", 1.0)
        import time as _t
        _t.sleep(0.9)
    if _close_win:
        try:
            _close_win()
        except Exception:
            pass
    if not lic_ok:
        print("License activation required — browser opened.")
    print(f"S2C BM Creator running: {url}")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
