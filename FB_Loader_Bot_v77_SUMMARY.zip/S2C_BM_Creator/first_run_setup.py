"""first_run_setup.py — S2C BM Creator new-device auto setup.

Runs on EVERY exe start (fast no-op when already set up):
  1. App folders (accounts DB, output, logs)
  2. REAL Google Chrome check — auto silent-install if missing (Windows)
     (bot drives real Chrome via Playwright 'chrome' channel — a fresh
     device without Chrome cannot run; this closes that gap)
  3. Fallback check: Edge (bot can use msedge channel too)

All results reported as (ok: bool, steps: list[str]) for the launcher UI.
"""
import os
import sys
import subprocess
import tempfile

APP_ROOT = os.path.dirname(os.path.abspath(__file__))

CHROME_INSTALLER_URL = "https://dl.google.com/chrome/install/latest/chrome_installer.exe"
_EDGE_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]


def _ensure_dirs() -> list:
    steps = []
    for d in ("output", "browsers", os.path.join("templates",)):
        try:
            os.makedirs(os.path.join(APP_ROOT, d), exist_ok=True)
            steps.append(f"📁 {d} — ready")
        except Exception:
            pass
    return steps


def _chrome_path() -> str:
    """Reuse browser_manager's real-Chrome finder (no Playwright import cost)."""
    try:
        from browser_manager import find_system_chrome
        return find_system_chrome()
    except Exception:
        return None


def _edge_path() -> str:
    if os.name != "nt":
        return None
    for p in _EDGE_PATHS:
        if os.path.isfile(p):
            return p
    return None


def _install_chrome_silent() -> bool:
    """Download official Chrome bootstrapper and silent-install it."""
    if os.name != "nt":
        return False
    try:
        import requests
        tmp = os.path.join(tempfile.gettempdir(), "s2c_chrome_installer.exe")
        with requests.get(CHROME_INSTALLER_URL, stream=True, timeout=60) as r:
            r.raise_for_status()
            with open(tmp, "wb") as f:
                for chunk in r.iter_content(65536):
                    f.write(chunk)
        # /silent /install → no UI, auto-updates enabled
        proc = subprocess.run([tmp, "/silent", "/install"],
                              capture_output=True, timeout=600)
        try:
            os.remove(tmp)
        except Exception:
            pass
        return proc.returncode in (0, 4)  # 4 = "already running/install newer"
    except Exception:
        return False


def run_setup(status_fn=None) -> tuple:
    """Full first-run pipeline. status_fn(msg) for launcher UI updates."""
    say = status_fn or (lambda m: None)
    steps = []

    steps += _ensure_dirs()
    say("Checking browser engine…")

    chrome = _chrome_path()
    if chrome:
        steps.append(f"✅ Real Chrome found: {chrome}")
        return True, steps

    say("Chrome not found — auto-installing (one time only)…")
    if _install_chrome_silent():
        chrome = _chrome_path()
        if chrome:
            steps.append("✅ Google Chrome auto-installed successfully")
            return True, steps
        steps.append("⚠ Chrome installer ran — restart the app to pick it up")
        return False, steps

    # fallback hope: Edge
    edge = _edge_path()
    if edge:
        steps.append(f"✅ Chrome missing — Edge found (bot will use it): {edge}")
        return True, steps

    steps.append("❌ Chrome install failed — install Google Chrome manually once")
    say("Chrome setup failed — please install Google Chrome manually")
    return False, steps
